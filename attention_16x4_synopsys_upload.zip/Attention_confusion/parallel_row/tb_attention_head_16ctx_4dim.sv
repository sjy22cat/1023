`timescale 1ns/1ps

// Works with official DW simulation models, or explicitly opted-in functional
// substitutes. The real reference does not reproduce the RTL reduction tree.
module tb_attention_head_16ctx_4dim #(
    parameter integer TILE_SIZE=32,
    parameter integer HEAD_DIM=4*TILE_SIZE,
    parameter integer CONTEXT_PARALLEL=16,
    parameter integer MAX_CONTEXT=1152,
    parameter integer CONTEXT=1152,
    parameter integer RUN_BOUNDARIES=0,
    parameter [31:0] SCALE_BITS=32'h3db504f3
);
    import nonmac_test_math::*;
    real clock_period_ns=1.0;
    integer runtime_context=CONTEXT, context_first=0, context_last=0;
    integer runtime_seed=20261023, power_activity=0;
    reg measurement_active=0;
    real measurement_start_ns;
    integer measured_kv_loads=0;
    string dump_vcd;
    initial begin
        if ($value$plusargs("CLOCK_NS=%f",clock_period_ns)) begin end
        if (clock_period_ns<=0) $fatal(1,"CLOCK_NS must be positive");
        if ($value$plusargs("CONTEXT_N=%d",runtime_context)) begin end
        if ($value$plusargs("CONTEXT_FIRST=%d",context_first)) begin end
        if ($value$plusargs("CONTEXT_LAST=%d",context_last)) begin end
        if ($value$plusargs("SEED=%d",runtime_seed)) begin end
        power_activity=$test$plusargs("POWER_ACTIVITY");
        if ($value$plusargs("DUMP_VCD=%s",dump_vcd)) begin
            $dumpfile(dump_vcd); $dumpvars(0,dut);
        end
    end
    reg clk=0;
    always #(clock_period_ns/2.0) clk=~clk;
    reg rst_n=0, cmd_valid=0, kv_valid=0, out_ready=0;
    reg [10:0] context_len=0;
    reg [HEAD_DIM*32-1:0] query=0;
    reg [TILE_SIZE*HEAD_DIM*32-1:0] key_tile=0, value_tile=0;
    wire cmd_ready, kv_ready, out_valid, error_flag;
    wire [HEAD_DIM*32-1:0] result;
    wire [31:0] cycles;
    // Report only complete run_case commands, excluding reset/abort/error
    // tests, output hold, and downstream backpressure from the power window.
    always @(posedge clk) if (measurement_active && rst_n) begin
        if (cmd_valid && cmd_ready) begin
            measurement_start_ns=$realtime;
            measured_kv_loads=0;
            $display("MEASURE_BEGIN n=%0d time_ns=%0.6f seed=%0d clock_ns=%g power_activity=%0d",
                context_len,$realtime,runtime_seed,clock_period_ns,power_activity);
        end
        if (kv_valid && kv_ready) measured_kv_loads=measured_kv_loads+1;
    end
    always @(posedge out_valid) if (measurement_active) begin
        $display("MEASURE_END n=%0d begin_ns=%0.6f end_ns=%0.6f cycles=%0d kv_load_cycles=%0d",
            context_len,measurement_start_ns,$realtime,cycles,measured_kv_loads);
        measurement_active=0;
    end
    attention_head_16ctx_4dim_eval #(
        .HEAD_DIM(HEAD_DIM), .TILE_SIZE(TILE_SIZE), .MAX_CONTEXT(MAX_CONTEXT),
        .CONTEXT_PARALLEL(CONTEXT_PARALLEL), .SCALE_BITS(SCALE_BITS)
    ) dut (
        .clk(clk), .rst_n(rst_n), .i_cmd_valid(cmd_valid), .o_cmd_ready(cmd_ready),
        .i_context_len(context_len), .i_query(query),
        .i_kv_valid(kv_valid), .o_kv_ready(kv_ready), .i_key_tile(key_tile), .i_value_tile(value_tile),
        .o_valid(out_valid), .i_ready(out_ready), .o_result(result),
        .o_error(error_flag), .o_cycle_count(cycles)
    );

`define CHECK_EXP(INST) \
    initial if (INST.sig_width != 23 || INST.exp_width != 8 || \
        INST.ieee_compliance != 0 || INST.arch != 2 || \
        $bits(INST.a) != 32 || $bits(INST.z) != 32) \
        $fatal(1, "%m: exp format must be explicitly FP32 arch=2");
    genvar c, p, m;
    generate
        for (c=0; c<CONTEXT_PARALLEL; c=c+1) begin : g_format_context
            for (p=0; p<TILE_SIZE; p=p+1) begin : g_format_exp
                `CHECK_EXP(dut.g_context[c].u_lane.g_score[p].u_exp)
            end
        end
        for (m=1; m<CONTEXT_PARALLEL; m=m+1) begin : g_format_merge
            `CHECK_EXP(dut.g_merge[m].u_merge.u_a_exp)
            `CHECK_EXP(dut.g_merge[m].u_merge.u_b_exp)
        end
    endgenerate
    `CHECK_EXP(dut.u_global_merge.u_a_exp)
    `CHECK_EXP(dut.u_global_merge.u_b_exp)
`undef CHECK_EXP

    real q [0:HEAD_DIM-1];
    real k [0:MAX_CONTEXT-1][0:HEAD_DIM-1];
    real v [0:MAX_CONTEXT-1][0:HEAD_DIM-1];
    real scores [0:MAX_CONTEXT-1], weights [0:MAX_CONTEXT-1];
    reg [31:0] rng=32'd20261023;
    integer clock_count=0;
    always @(posedge clk) clock_count=clock_count+1;
    function automatic real sample(input integer divisor);
        begin
            rng=rng*32'd1664525+32'd1013904223;
            sample=(rng[31:21]-1024.0)/divisor;
        end
    endfunction
    function automatic integer finite_word(input [31:0] w);
        finite_word=((^w)!==1'bx) && w[30:23]!=8'hff;
    endfunction

    // Check exp(0), not merely the final normalized result. A common wrong
    // multiplicative exp encoding can otherwise cancel during normalization.
    generate for (c=0; c<CONTEXT_PARALLEL; c=c+1) begin : g_beta_check
        integer j;
        always @(negedge clk) if (rst_n &&
                dut.g_context[c].u_lane.state==dut.g_context[c].u_lane.S_PV_MUL) begin
            for (j=0; j<TILE_SIZE; j=j+1)
                if (dut.g_context[c].u_lane.active_q && dut.g_context[c].u_lane.token_mask_q[j]) begin
                    if (!finite_word(dut.g_context[c].u_lane.beta_q[j]))
                        $fatal(1,"nonfinite beta lane=%0d token=%0d",c,j);
                    if (dut.g_context[c].u_lane.diff_q[j][30:0]==0 &&
                        dut.g_context[c].u_lane.beta_q[j]!==32'h3f800000)
                        $fatal(1,"exp(0) encoding lane=%0d token=%0d",c,j);
                end
        end
    end endgenerate

    task automatic run_case(input integer n, input integer stalls);
        integer t, d, base, lane, start_clock, expected_cycles, tile_count;
        real max_s, denom, expected, actual, err, abs_ref, max_err;
        reg [HEAD_DIM*32-1:0] held_result;
        reg [31:0] held_cycles;
        begin
            rng=runtime_seed+n;
            for (d=0; d<HEAD_DIM; d=d+1) begin
                q[d]=sample(2048); query[d*32 +:32]=real_fp(q[d]);
            end
            for (t=0; t<n; t=t+1)
                for (d=0; d<HEAD_DIM; d=d+1) begin
                    k[t][d]=sample(2048); v[t][d]=sample(1024);
                end
            // A much larger last score exercises both the context merge tree
            // and rescaling of the running state after a later wave.
            if (!power_activity)
                for (d=0; d<HEAD_DIM; d=d+1) k[n-1][d]=q[d]<0.0 ? -2.0 : 2.0;
            max_s=-1.0e100;
            for (t=0; t<n; t=t+1) begin
                scores[t]=0.0;
                for (d=0; d<HEAD_DIM; d=d+1)
                    scores[t]=scores[t]+q[d]*fp_real(SCALE_BITS)*k[t][d];
                if (scores[t]>max_s) max_s=scores[t];
            end
            denom=0.0;
            for (t=0; t<n; t=t+1) begin
                weights[t]=$exp(scores[t]-max_s); denom=denom+weights[t];
            end
            while (!cmd_ready) @(negedge clk);
            measurement_active=1;
            context_len=n; cmd_valid=1;
            @(negedge clk); start_clock=clock_count; cmd_valid=0;
            tile_count=(n+TILE_SIZE-1)/TILE_SIZE;
            for (base=0; base<n; base=base+TILE_SIZE) begin
                while (!kv_ready) @(negedge clk);
                repeat (stalls) @(negedge clk);
                for (lane=0; lane<TILE_SIZE; lane=lane+1)
                    for (d=0; d<HEAD_DIM; d=d+1) begin
                        key_tile[(lane*HEAD_DIM+d)*32 +:32]=base+lane<n ?
                            real_fp(k[base+lane][d]) : (power_activity ? 32'h0 : 32'h7fc00000);
                        value_tile[(lane*HEAD_DIM+d)*32 +:32]=base+lane<n ?
                            real_fp(v[base+lane][d]) : (power_activity ? 32'h0 : 32'h7fc00000);
                    end
                kv_valid=1;
                @(negedge clk); kv_valid=0;
                // Buses are not required to remain stable after handshake.
                key_tile=power_activity ? '0 : 'x;
                value_tile=power_activity ? '0 : 'x;
            end
            while (!out_valid) @(negedge clk);
            expected_cycles=(3*$clog2(TILE_SIZE)+8+5*($clog2(CONTEXT_PARALLEL)+1))*
                ((n+CONTEXT_PARALLEL*TILE_SIZE-1)/(CONTEXT_PARALLEL*TILE_SIZE))+
                tile_count+3+tile_count*stalls;
            if (error_flag || cycles!=expected_cycles || clock_count-start_clock!=cycles)
                $fatal(1,"schedule n=%0d got=%0d measured=%0d expected=%0d error=%0d",
                    n,cycles,clock_count-start_clock,expected_cycles,error_flag);
            max_err=0.0;
            for (d=0; d<HEAD_DIM; d=d+1) begin
                if (!finite_word(result[d*32 +:32])) $fatal(1,"nonfinite result d=%0d",d);
                expected=0.0;
                for (t=0; t<n; t=t+1) expected=expected+weights[t]*v[t][d]/denom;
                actual=fp_real(result[d*32 +:32]); err=actual-expected;
                if (err<0.0) err=-err;
                abs_ref=expected<0.0 ? -expected : expected;
                if (err>1.0e-4+1.0e-3*abs_ref)
                    $fatal(1,"numerical n=%0d d=%0d actual=%g reference=%g error=%g",n,d,actual,expected,err);
                if (err>max_err) max_err=err;
            end
            held_result=result; held_cycles=cycles;
            repeat (3) begin
                @(negedge clk);
                if (!out_valid || result!==held_result || cycles!==held_cycles || cmd_ready || kv_ready)
                    $fatal(1,"output/backpressure state changed");
            end
            $display("PASS 16ctx4dim n=%0d head_dim=%0d context_parallel=%0d stalls/tile=%0d cycles=%0d max_abs_error=%g",
                n,HEAD_DIM,CONTEXT_PARALLEL,stalls,cycles,max_err);
            out_ready=1; @(negedge clk); out_ready=0;
        end
    endtask

    task automatic reject_case(input integer n);
        begin
            while (!cmd_ready) @(negedge clk);
            context_len=n; cmd_valid=1; @(negedge clk); cmd_valid=0;
            if (!out_valid || !error_flag || cycles!=0 || result!=={HEAD_DIM*32{1'b0}} || kv_ready)
                $fatal(1,"invalid context not rejected n=%0d",n);
            out_ready=1; @(negedge clk); out_ready=0;
        end
    endtask

    initial begin
        repeat (3) @(negedge clk); rst_n=1;
        // Abort a partially loaded command; stale banks must not leak into
        // the following legal transaction, even though datapath has no reset.
        context_len=MAX_CONTEXT; cmd_valid=1; @(negedge clk); cmd_valid=0;
        while (!kv_ready) @(negedge clk);
        kv_valid=1; @(negedge clk); kv_valid=0;
        rst_n=0; repeat (2) @(negedge clk); rst_n=1;
        if (RUN_BOUNDARIES) begin
            run_case(1,0); run_case(TILE_SIZE,0); run_case(TILE_SIZE+1,1);
            run_case(CONTEXT_PARALLEL*TILE_SIZE-1,0);
            run_case(CONTEXT_PARALLEL*TILE_SIZE,0);
            run_case(CONTEXT_PARALLEL*TILE_SIZE+1,0);
            run_case(MAX_CONTEXT,2); run_case(1,0);
        end else if (context_first>0 || context_last>0) begin : g_runtime_sweep
            integer n;
            if (context_first<1 || context_last<context_first || context_last>MAX_CONTEXT)
                $fatal(1,"invalid CONTEXT_FIRST/LAST range");
            for (n=context_first; n<=context_last; n=n+1) run_case(n,0);
        end else begin
            if (runtime_context<1 || runtime_context>MAX_CONTEXT) $fatal(1,"invalid CONTEXT_N");
            run_case(runtime_context,0);
        end
        reject_case(0);
        if (MAX_CONTEXT<2047) reject_case(MAX_CONTEXT+1);
        $display("PASS command errors, reset/reuse, output backpressure, FP32 exp configuration");
        $finish;
    end
    // Worst sweep has MAX_CONTEXT commands, each bounded by MAX_CONTEXT*16.
    initial begin repeat (MAX_CONTEXT*(MAX_CONTEXT*16+200)+30000) @(negedge clk); $fatal(1,"timeout"); end
endmodule
