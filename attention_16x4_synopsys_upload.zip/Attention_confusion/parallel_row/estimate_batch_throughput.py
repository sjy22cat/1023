"""Explicit architectural budget, NOT a calibrated SIM-1017 execution.

Batching holds each weight block across all B sequences at a layer/step.
The physical array is not replicated: compute and sequence-specific traffic
scale with B; weight traffic does not. GQA read sharing is an external
scheduler assumption, not functionality provided by this single-head RTL.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

LAYERS = 28
TRANSFORMER_WEIGHT_BYTES = 233_963_520
LM_HEAD_WEIGHT_BYTES = 82_653_184
WEIGHT_BYTES = TRANSFORMER_WEIGHT_BYTES + LM_HEAD_WEIGHT_BYTES
TRANSFORMER_BLOCKS = 420
LM_HEAD_BLOCKS = 149
ACTIVATION_BYTES_PER_POSITION = 5 * 1024**2  # Planning allowance, not measured.
NONMAC_NS_PER_POSITION = 30_000            # Planning allowance, not measured.
KV_BYTES_PER_CONTEXT_TOKEN = 30_464        # MXFP4, 8 KV heads, all 28 layers.


def phase(prompt: int, output: int, *, prefill: bool, wave_cycles: int,
          clock_ns: float, bandwidth: float, block_cycles: int,
          gqa_share: bool) -> dict[str, float]:
    steps = prompt if prefill else output - 1
    if prefill:
        # Match the current scheduler: full P*P prefill work, no triangular skip.
        contexts = [prompt] * prompt
        blocks = TRANSFORMER_BLOCKS * prompt + LM_HEAD_BLOCKS
        weight_bytes = WEIGHT_BYTES
    else:
        contexts = range(prompt + 1, prompt + output)
        blocks = (TRANSFORMER_BLOCKS + LM_HEAD_BLOCKS) * steps
        weight_bytes = WEIGHT_BYTES * steps
    kv_factor = 1 if gqa_share else 2
    # Compute-only cycles: replace ideal input-handshake cycles with the
    # separately budgeted storage service; do not add both in full.
    attn_cycles = LAYERS * sum(wave_cycles * math.ceil(n / 512) + 3 for n in contexts)
    return {
        "linear_compute_s": blocks * block_cycles * clock_ns * 1e-9,
        "nonmac_allowance_s": steps * NONMAC_NS_PER_POSITION * 1e-9,
        "attention_compute_s": attn_cycles * clock_ns * 1e-9,
        "activation_transfer_s": steps * ACTIVATION_BYTES_PER_POSITION / bandwidth * 1e-9,
        "kv_transfer_s": sum(contexts) * KV_BYTES_PER_CONTEXT_TOKEN * kv_factor / bandwidth * 1e-9,
        "shared_weight_transfer_s": weight_bytes / bandwidth * 1e-9,
    }


def batch_phase(parts: dict[str, float], batch: int, weight_copies: int) -> float:
    return sum(v * (weight_copies if k == "shared_weight_transfer_s" else batch)
               for k, v in parts.items())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bandwidth-gbs", type=float, default=256.0)
    parser.add_argument("--clock-ns", type=float, default=1.0)
    parser.add_argument("--block-cycles", type=int, default=200)
    parser.add_argument("--wave-cycles", type=int, default=48,
                        help="48: new local RTL schedule; 55: previous speculative budget")
    parser.add_argument("--no-gqa-share", action="store_true")
    parser.add_argument("--weight-reuse-limit", type=int, default=0,
                        help="0: retain weights across the whole batch; 32: reload per microbatch")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if min(args.bandwidth_gbs, args.clock_ns, args.block_cycles, args.wave_cycles) <= 0:
        parser.error("all costs and bandwidth must be positive")
    if args.weight_reuse_limit < 0:
        parser.error("weight reuse limit must be nonnegative")

    report = {
        "status": "ARCHITECTURAL_ESTIMATE_NOT_MEASURED",
        "assumptions": {
            "clock_ns": args.clock_ns, "effective_bandwidth_GB_s": args.bandwidth_gbs,
            "warm_1024_square_block_cycles": args.block_cycles,
            "attention_compute_cycles_per_512_token_wave": args.wave_cycles,
            "gqa_shared_KV_reads": not args.no_gqa_share,
            "weight_reuse_across_batch": True, "compute_transfer_overlap": False,
            "weight_reuse_limit_sequences": args.weight_reuse_limit or "whole_logical_batch",
            "SIM_1017_max_micro_batch": 32,
            "prefill_triangular_skip": False,
            "extra_activation_bytes_per_position": ACTIVATION_BYTES_PER_POSITION,
            "other_nonmac_ns_per_position": NONMAC_NS_PER_POSITION,
            "KV_and_weight_format": "MXFP4, 17 bytes per 32 elements; RTL arithmetic FP32",
        },
        "results": [],
    }
    print("input output batch batch_total_s aggregate_e2e_tok_s aggregate_decode_tok_s mean_sequence_e2e_tok_s")
    for prompt, output in ((1024, 128), (128, 1024)):
        pre = phase(prompt, output, prefill=True, wave_cycles=args.wave_cycles,
                    clock_ns=args.clock_ns, bandwidth=args.bandwidth_gbs,
                    block_cycles=args.block_cycles, gqa_share=not args.no_gqa_share)
        dec = phase(prompt, output, prefill=False, wave_cycles=args.wave_cycles,
                    clock_ns=args.clock_ns, bandwidth=args.bandwidth_gbs,
                    block_cycles=args.block_cycles, gqa_share=not args.no_gqa_share)
        for batch in (1, 32, 64, 128):
            weight_copies = math.ceil(batch / args.weight_reuse_limit) if args.weight_reuse_limit else 1
            pre_s = batch_phase(pre, batch, weight_copies)
            dec_s = batch_phase(dec, batch, weight_copies)
            total = pre_s + dec_s
            row = {
                "input_tokens_per_sequence": prompt, "output_tokens_per_sequence": output,
                "batch": batch, "prefill_and_first_step_s": pre_s,
                "microbatches": math.ceil(batch / 32), "weight_load_copies_per_step": weight_copies,
                "remaining_decode_s": dec_s, "batch_total_s": total,
                "aggregate_e2e_tok_s": batch * output / total,
                "aggregate_decode_tok_s": batch * (output - 1) / dec_s,
                "mean_sequence_e2e_tok_s": output / total,
                "max_KV_cache_GiB": batch * KV_BYTES_PER_CONTEXT_TOKEN * 1152 / 1024**3,
                "prefill_single_sequence_components_s": pre,
                "decode_single_sequence_components_s": dec,
            }
            report["results"].append(row)
            print(f"{prompt:5d} {output:6d} {batch:5d} {total:13.6f} "
                  f"{row['aggregate_e2e_tok_s']:19.2f} {row['aggregate_decode_tok_s']:22.2f} "
                  f"{row['mean_sequence_e2e_tok_s']:23.2f}")
    if args.json:
        args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
