`timescale 1ns/1ps

// One context row: TILE_SIZE tokens x four TILE_SIZE-wide dimension blocks.
// QK and PV reuse the same four multiplier/reduction planes in distinct
// phases. The score includes all four dimension blocks before Softmax.
// Reductions allocate only real tree nodes (2*TILE_SIZE-1 per output).
module attention_context_4dim_lane #(
    parameter integer TILE_SIZE = 32,
    parameter integer HEAD_DIM = 128
) (
    input wire clk, rst_n,
    input wire i_load,
    input wire [TILE_SIZE-1:0] i_token_mask,
    input wire [TILE_SIZE*HEAD_DIM*32-1:0] i_key, i_value,
    input wire i_start, i_active,
    input wire [HEAD_DIM*32-1:0] i_query_scaled,
    output wire o_done,
    output wire o_present,
    output wire [31:0] o_m, o_l,
    output wire [HEAD_DIM*32-1:0] o_z
);
    localparam integer LEVELS = $clog2(TILE_SIZE);
    localparam integer NODES = 2*TILE_SIZE;
    localparam integer S_IDLE=0, S_QK_MUL=1, S_QK_TREE=2,
        S_DIM_1=3, S_DIM_2=4, S_MAX=5, S_DIFF=6, S_EXP=7,
        S_PV_MUL=8, S_PV_TREE=9, S_DONE=10;
    reg [3:0] state;
    integer level_q;
    reg active_q;
    reg [TILE_SIZE-1:0] token_mask_q;
    reg [TILE_SIZE*HEAD_DIM*32-1:0] key_q, value_q;
    reg [31:0] mac_q [0:3][0:TILE_SIZE-1][1:NODES-1];
    reg [31:0] dim_q [0:TILE_SIZE-1][0:1];
    reg [31:0] score_q [0:TILE_SIZE-1];
    reg [31:0] max_q [1:NODES-1];
    reg [31:0] sum_q [1:NODES-1];
    reg [31:0] diff_q [0:TILE_SIZE-1];
    reg [31:0] beta_q [0:TILE_SIZE-1];

    function automatic [31:0] fp_max(input [31:0] a, b);
        if (a[31] != b[31]) fp_max = a[31] ? b : a;
        else if (a[31]) fp_max = (a[30:0] < b[30:0]) ? a : b;
        else fp_max = (a[30:0] > b[30:0]) ? a : b;
    endfunction

    initial begin
        if (TILE_SIZE < 2 || TILE_SIZE > 32 || (TILE_SIZE & (TILE_SIZE-1)) != 0 ||
            HEAD_DIM != 4*TILE_SIZE) $fatal(1, "lane requires HEAD_DIM=4*TILE_SIZE");
    end
    assign o_done = (state == S_DONE);
    assign o_present = active_q && (|token_mask_q);
    // Empty states use finite zero; merge presence bits carry emptiness.
    assign o_m = o_present ? max_q[1] : 32'b0;
    assign o_l = o_present ? sum_q[1] : 32'b0;

    wire [31:0] product [0:3][0:TILE_SIZE-1][0:TILE_SIZE-1];
    wire [31:0] mac_add [0:3][0:TILE_SIZE-1][1:TILE_SIZE-1];
    wire [31:0] dim_add [0:TILE_SIZE-1][0:2];
    wire [31:0] diff [0:TILE_SIZE-1], beta [0:TILE_SIZE-1];
    wire [31:0] max_node [1:NODES-1], sum_add [1:TILE_SIZE-1];
    genvar b, p, k, n;
    generate
        for (b=0; b<4; b=b+1) begin : g_block
            for (p=0; p<TILE_SIZE; p=p+1) begin : g_output
                assign o_z[(b*TILE_SIZE+p)*32 +: 32] = o_present ? mac_q[b][p][1] : 32'b0;
                for (k=0; k<TILE_SIZE; k=k+1) begin : g_mul
                    wire qk_valid = active_q && token_mask_q[p];
                    wire pv_valid = active_q && token_mask_q[k];
                    wire [31:0] a = (state == S_QK_MUL) ?
                        (qk_valid ? i_query_scaled[(b*TILE_SIZE+k)*32 +: 32] : 32'b0) :
                        ((state == S_PV_MUL && pv_valid) ? beta_q[k] : 32'b0);
                    wire [31:0] v = (state == S_QK_MUL) ?
                        (qk_valid ? key_q[(p*HEAD_DIM+b*TILE_SIZE+k)*32 +: 32] : 32'b0) :
                        ((state == S_PV_MUL && pv_valid) ?
                        value_q[(k*HEAD_DIM+b*TILE_SIZE+p)*32 +: 32] : 32'b0);
                    wire [7:0] status;
                    DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_mul (
                        .a(a), .b(v), .rnd(3'b000), .z(product[b][p][k]), .status(status));
                end
                for (n=1; n<TILE_SIZE; n=n+1) begin : g_reduce
                    wire [7:0] status;
                    DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_add (
                        .a(mac_q[b][p][2*n]), .b(mac_q[b][p][2*n+1]),
                        .rnd(3'b000), .op(1'b0), .z(mac_add[b][p][n]), .status(status));
                end
            end
        end
        for (p=0; p<TILE_SIZE; p=p+1) begin : g_score
            wire [7:0] s0, s1, s2, sd, se;
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_dim0 (
                .a(mac_q[0][p][1]), .b(mac_q[1][p][1]), .rnd(3'b000), .op(1'b0),
                .z(dim_add[p][0]), .status(s0));
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_dim1 (
                .a(mac_q[2][p][1]), .b(mac_q[3][p][1]), .rnd(3'b000), .op(1'b0),
                .z(dim_add[p][1]), .status(s1));
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_dim2 (
                .a(dim_q[p][0]), .b(dim_q[p][1]), .rnd(3'b000), .op(1'b0),
                .z(dim_add[p][2]), .status(s2));
            assign max_node[TILE_SIZE+p] = active_q && token_mask_q[p] ? score_q[p] : 32'hff800000;
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_diff (
                .a(active_q && token_mask_q[p] ? score_q[p] : 32'b0),
                .b(o_present ? max_q[1] : 32'b0), .rnd(3'b000), .op(1'b1),
                .z(diff[p]), .status(sd));
            DW_fp_exp #(.sig_width(23), .exp_width(8), .ieee_compliance(0), .arch(2)) u_exp (
                .a(diff_q[p]), .z(beta[p]), .status(se));
        end
        for (n=1; n<TILE_SIZE; n=n+1) begin : g_softmax_tree
            // Bottom max level reads score registers directly; higher levels
            // read the previous registered level. One comparator per stage.
            if (n >= TILE_SIZE/2) begin : g_bottom
                assign max_node[n] = fp_max(max_node[2*n], max_node[2*n+1]);
            end else begin : g_upper
                assign max_node[n] = fp_max(max_q[2*n], max_q[2*n+1]);
            end
            wire [7:0] status;
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_sum (
                .a(sum_q[2*n]), .b(sum_q[2*n+1]), .rnd(3'b000), .op(1'b0),
                .z(sum_add[n]), .status(status));
        end
    endgenerate

    // No reset fanout on K/V or tree datapath banks. Masks and state prevent
    // reading any bank before it has been written for the current wave.
    always @(posedge clk) if (rst_n && i_load) begin
        key_q <= i_key; value_q <= i_value; token_mask_q <= i_token_mask;
    end
    integer ib, ip, ik, inode;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin state <= S_IDLE; level_q <= 0; active_q <= 0; end
        else case (state)
            S_IDLE: if (i_start) begin active_q <= i_active; state <= S_QK_MUL; end
            S_QK_MUL, S_PV_MUL: begin
                for (ib=0; ib<4; ib=ib+1)
                    for (ip=0; ip<TILE_SIZE; ip=ip+1)
                        for (ik=0; ik<TILE_SIZE; ik=ik+1)
                            mac_q[ib][ip][TILE_SIZE+ik] <= product[ib][ip][ik];
                if (state == S_PV_MUL)
                    for (ip=0; ip<TILE_SIZE; ip=ip+1) sum_q[TILE_SIZE+ip] <= beta_q[ip];
                level_q <= 1;
                state <= (state == S_QK_MUL) ? S_QK_TREE : S_PV_TREE;
            end
            S_QK_TREE, S_PV_TREE: begin
                for (inode=1; inode<TILE_SIZE; inode=inode+1)
                    if (inode >= (TILE_SIZE >> level_q) && inode < (TILE_SIZE >> (level_q-1))) begin
                        for (ib=0; ib<4; ib=ib+1)
                            for (ip=0; ip<TILE_SIZE; ip=ip+1)
                                mac_q[ib][ip][inode] <= mac_add[ib][ip][inode];
                        if (state == S_PV_TREE) sum_q[inode] <= sum_add[inode];
                    end
                if (level_q == LEVELS) state <= (state == S_QK_TREE) ? S_DIM_1 : S_DONE;
                else level_q <= level_q+1;
            end
            S_DIM_1: begin
                for (ip=0; ip<TILE_SIZE; ip=ip+1) begin
                    dim_q[ip][0] <= dim_add[ip][0]; dim_q[ip][1] <= dim_add[ip][1];
                end
                state <= S_DIM_2;
            end
            S_DIM_2: begin
                for (ip=0; ip<TILE_SIZE; ip=ip+1) score_q[ip] <= dim_add[ip][2];
                level_q <= 1; state <= S_MAX;
            end
            S_MAX: begin
                for (inode=1; inode<TILE_SIZE; inode=inode+1)
                    if (inode >= (TILE_SIZE >> level_q) && inode < (TILE_SIZE >> (level_q-1)))
                        max_q[inode] <= max_node[inode];
                if (level_q == LEVELS) state <= S_DIFF;
                else level_q <= level_q+1;
            end
            S_DIFF: begin
                for (ip=0; ip<TILE_SIZE; ip=ip+1)
                    diff_q[ip] <= active_q && token_mask_q[ip] ? diff[ip] : 32'b0;
                state <= S_EXP;
            end
            S_EXP: begin
                for (ip=0; ip<TILE_SIZE; ip=ip+1)
                    beta_q[ip] <= active_q && token_mask_q[ip] ? beta[ip] : 32'b0;
                state <= S_PV_MUL;
            end
            S_DONE: state <= S_IDLE;
            default: state <= S_IDLE;
        endcase
    end
endmodule
