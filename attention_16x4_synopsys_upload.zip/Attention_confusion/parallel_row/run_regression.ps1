param([switch]$FullSize)
$ErrorActionPreference = 'Stop'
$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$runDir = Join-Path ([System.IO.Path]::GetTempPath()) ('yrr-attention16x4-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $runDir | Out-Null
Push-Location -LiteralPath $repoRoot
try {
    $sources = @(
        'RTL/RTL_1017SIM/tb/nonmac_tb_math.sv',
        'RTL/RTL_1017SIM/tb/nonmac_test_dw.sv',
        'Attention_confusion/parallel_row/attention_online_merge_fp32.sv',
        'Attention_confusion/parallel_row/attention_context_4dim_lane.sv',
        'Attention_confusion/parallel_row/attention_head_16ctx_4dim_eval.sv',
        'Attention_confusion/parallel_row/tb_attention_head_16ctx_4dim.sv'
    )
    $small = Join-Path $runDir 'small.vvp'
    & iverilog -g2012 -Wall -DNONMAC_TEST_DW -s tb_attention_head_16ctx_4dim `
        -P tb_attention_head_16ctx_4dim.TILE_SIZE=4 `
        -P tb_attention_head_16ctx_4dim.MAX_CONTEXT=145 `
        -P tb_attention_head_16ctx_4dim.RUN_BOUNDARIES=1 -o $small @sources
    if ($LASTEXITCODE -ne 0) { throw 'Small regression compilation failed' }
    & vvp -i $small
    if ($LASTEXITCODE -ne 0) { throw 'Small regression failed' }
    if ($FullSize) {
        $full = Join-Path $runDir 'default.vvp'
        & iverilog -g2012 -Wall -DNONMAC_TEST_DW -s tb_attention_head_16ctx_4dim -o $full @sources
        if ($LASTEXITCODE -ne 0) { throw 'Default-size compilation failed' }
        & vvp -i $full
        if ($LASTEXITCODE -ne 0) { throw 'Default-size regression failed' }
    }
    Write-Output "Simulation artifacts: $runDir"
} finally { Pop-Location }
