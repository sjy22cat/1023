# 16 context rows x 4 dimension blocks, single-query Attention evaluator

Top: `attention_head_16ctx_4dim_eval`.

This directory is independent of `../single_row`. The original 2ctx x 2dim
implementation is unchanged. Compile all three RTL sources in `sources.f`,
with paths relative to the repository root. Do not compile any testbench or
functional DW substitute for synthesis.

## Work and mapping

Default command:

```text
Q                 [1, 128]
K, V              [N, 128], 1 <= N <= 1152
accepted K/V tile [32, 128] each, FP32
output            [1, 128], FP32

one wave: 16 context tiles x 32 tokens = 512 tokens
one context row: 4 parallel head-dimension blocks x 32 dimensions = 128
one head unit: 16 x 4 = 64 logical 32x32 MAC planes
```

All four dimension partials are reduced before the corresponding QK score
enters Softmax. Each context row computes local `(m,l,z)`:

```text
s[t] = dot(Q/sqrt(128), K[t])
m = max(s)
l = sum(exp(s-m))
z[d] = sum(exp(s-m)*V[:,d])
```

The 16 local states merge through a four-level balanced tree. For two states:

```text
m = max(m_a,m_b)
l = exp(m_a-m)*l_a + exp(m_b-m)*l_b
z = exp(m_a-m)*z_a + exp(m_b-m)*z_b
```

The wave root merges with the running state across waves; only after the last
wave is `O=z/l` evaluated. An explicit presence bit represents empty states,
including unused rows in the final wave. Empty states never require exp of
`-Inf - -Inf`. Invalid token inputs are masked before multiplication; NaNs in
padding cannot affect valid scores or PV.

QK and PV reuse the same four multiplier/tree planes per context row. PV and
the local denominator reduction run concurrently. Tree arrays contain only
real nodes, unlike a rectangular allocation with unused per-level slots.
Large K/V and arithmetic data banks have no reset; control/presence bits make
every read follow a write in the current command. Reset aborts outstanding
work. This avoids reset distribution to millions of datapath bits.

On a hypothetical 32x32 tile array, one 16x4 unit uses 64 logical tiles.
Sixteen such head units can be placed as two row groups and eight column
groups: `2 * 8 = 16` heads, `16 * 64 = 1024` tiles. This source instantiates
**one head unit**, not sixteen units or a batch scheduler.

These are FP32 evaluation planes. They do not instantiate or replace the
physical `mx_tile_1017` MXFP4 PE. Direct physical integration still requires
format conversion, multi-column command/broadcast control, tile-state
storage, and a scheduler. The current array enables only `i_calc_col`; that
existing interface cannot issue all four dimension columns concurrently.
The FP32 evaluator's mapped area is not the area of 64 existing MXFP4 tiles.

## Files

| File | Purpose |
|---|---|
| `attention_head_16ctx_4dim_eval.sv` | Command/input FSM, 16 context lanes, merge tree, running state, final normalization |
| `attention_context_4dim_lane.sv` | One 32-token context lane, four dimension planes, local stable Softmax/PV |
| `attention_online_merge_fp32.sv` | Five-stage merge: max, subtraction, exp, multiplication, addition |
| `tb_attention_head_16ctx_4dim.sv` | Nonzero reference and schedule regression |
| `run_regression.ps1` | Icarus functional regression, optional full-size run |
| `estimate_batch_throughput.py` | Standalone architectural throughput budget; does not modify simulator calibration |

`SCALE_BITS=0x3db504f3` is FP32 `1/sqrt(128)`. If changing `HEAD_DIM` for a
different mathematical head size, set its reciprocal-square-root constant
explicitly. The small regression deliberately checks the supplied scale.
`HEAD_DIM` must equal `4*TILE_SIZE`. `TILE_SIZE` and `CONTEXT_PARALLEL` must be
powers of two; default values are 32 and 16. Context lengths are 11 bits.

Every DW instance explicitly selects FP32 (23 fraction, 8 exponent,
`ieee_compliance=0`). All 544 default exp instances also select `arch=2`.
The valid input domain is finite Q/K/V values with finite intermediate
arithmetic; this is not a complete IEEE NaN/Inf propagation specification.
The internal merge accepts transactions at least five cycles apart. The top
controller satisfies this interval and holds the required data stable.

## Interface and cycles

1. Handshake `i_cmd_valid && o_cmd_ready` with query and context length.
2. Send `ceil(N/32)` consecutive K/V tiles in increasing context order using
   `i_kv_valid && o_kv_ready`. A partial last tile needs no special encoding.
3. Consume `o_result` when `o_valid && i_ready`. Result and cycle count remain
   stable under output backpressure. No next command is accepted until then.

The input bus accepts one tile per cycle, not sixteen tiles per cycle.
Loading and compute do not overlap; there is no double buffer. Each full
512-token wave requires 16 input handshakes. Invalid context lengths (zero or
greater than `MAX_CONTEXT`) return zero result and `o_error`, without loading.

Default schedule, excluding input stalls:

| Per-wave activity | Cycles |
|---|---:|
| Launch context lanes | 1 |
| QK multiplication, 5 reduction levels, 2 dimension-merge levels | 8 |
| Local max (5), difference (1), exp (1) | 7 |
| PV multiplication and 5 reduction levels; denominator tree overlaps | 6 |
| Four context-merge levels, 5 stages each | 20 |
| Merge with previous waves | 5 |
| Commit running state | 1 |
| Compute/control total per wave | **48** |

Query prescaling takes one cycle; final reciprocal and scaling take two:

```text
C(N) = 48*ceil(N/512) + ceil(N/32) + 3
N           1   32   33   511   512   513   1024   1152
cycles     52   52   53    67    67   116    131    183
```

Each extra input wait cycle adds one cycle. Count is from command handshake
to first output valid; output holding time is excluded. For general test
parameters, replace 48 with
`3*clog2(TILE_SIZE)+8+5*(clog2(CONTEXT_PARALLEL)+1)` and 512 with
`CONTEXT_PARALLEL*TILE_SIZE`.

The original default design counts 849 cycles for N=1152; the new schedule
counts 183, a 4.64x cycle reduction, with sixteen times as many MAC planes
(64 versus 4). These do not imply a proportional area/energy improvement.
At a 1 ns target, 183 ns is a nominal RTL schedule, not timing closure.

Single-head default structure includes 65,536 shared QK/PV FP32 multipliers,
63,488 MAC-tree FP32 adders, 544 exponentials, additional statistic operators,
and one divider. K/V buffering alone is 4,194,304 register bits. This is a
large synthesis target; hierarchical synthesis of the context lane and merge
module is useful before full mapping. No area or power value is inferred
from these structural counts.

## Verification and Synopsys usage

Local functional substitutes are explicitly test-only. From repository root:

```powershell
powershell -ExecutionPolicy Bypass -File Attention_confusion/parallel_row/run_regression.ps1 -FullSize
```

Without `-FullSize`, run the small 16-context-lane boundary suite. It checks
single-token/partial tiles, a full wave and wave+1, multiple waves, later
maxima, input stalls, reset/reuse, invalid commands, stable output under
backpressure, cycle count versus measured clocks, and actual exp parameters.
The default-size test covers nonzero 128-dimensional Q/K/V and 1152 tokens,
with poisoned padding and reference tolerance
`abs_error <= 1e-4 + 1e-3*abs(reference)`.

Local results (2026-10-23, Icarus functional DW substitutes): all eight small
boundary/reuse cases passed, as did input-stall counting, invalid commands,
reset/reuse and output backpressure. The full default HEAD_DIM=128,
TILE_SIZE=32, CONTEXT_PARALLEL=16, N=1152 nonzero test passed in **183 cycles**,
with maximum absolute output error **5.82751e-08**. All 544 exp instance format
checks passed. No local VCS/DC/PrimeTime executables were available; official
model verification, mapping, timing and power are still to be run externally.

Official-model simulation on a Synopsys Linux host, from repository root:

```bash
vcs -full64 -sverilog +incdir+"${DW_SIM_DIR}" \
  -y "${DW_SIM_DIR}" +libext+.v \
  RTL/RTL_1017SIM/tb/nonmac_tb_math.sv \
  -f Attention_confusion/parallel_row/sources.f \
  Attention_confusion/parallel_row/tb_attention_head_16ctx_4dim.sv \
  -top tb_attention_head_16ctx_4dim -o simv -l compile.log
./simv -l simulation.log
```

Do not define `NONMAC_TEST_DW` or compile `nonmac_test_dw.sv` in the official
run. Confirm numerical checks, 183 cycles and zero port-width warnings before
capturing new SAIF. Never reuse activity from the 2ctx x 2dim design.

DC should use actual SMIC 28nm target/link libraries and its licensed DW
library, then analyze the three RTL sources and elaborate:

```tcl
analyze -format sverilog [list \
  Attention_confusion/parallel_row/attention_online_merge_fp32.sv \
  Attention_confusion/parallel_row/attention_context_4dim_lane.sv \
  Attention_confusion/parallel_row/attention_head_16ctx_4dim_eval.sv]
elaborate attention_head_16ctx_4dim_eval
current_design attention_head_16ctx_4dim_eval
link
check_design
```

Use the same characterized corner, I/O loads, uncertainty, and clock as the
original report. Keep hierarchy for resource control if necessary, but report
the complete top area, unresolved references/black boxes, timing and coverage.
No functional FSM false paths or multicycle exceptions are needed to hide
arithmetic paths. Max, subtraction, exp, multiplication and each reduction
level have distinct register boundaries. Individual combinational FP32 exp or
division may still exceed 1 ns; inspect STA before choosing internal operator
pipelining. Adding operator latency also requires changing the valid/control
schedule. Area, timing and power remain unmeasured locally.

## Batch-throughput budget

The standalone estimator retains the previous architectural assumptions:
1 ns target, effective aggregate bandwidth 256 GB/s, MXFP4 storage (17 B per
32 elements), 200 cycles per warm 1024x1024 GEMV block, a 30 us non-MAC and
5 MiB activation-traffic allowance per position, and no compute/transfer
overlap. It uses the new 48-cycle wave schedule instead of the previous
speculative 55-cycle allowance. These assumptions are not calibrated values.
Prefill follows the current scheduler's full P*P work, without causal
triangular skipping. The first output comes from prefill; decode runs O-1
times with growing contexts P+1 through P+O-1.

With a fixed array and synchronized same-length sequences, sequence-specific
compute/traffic scale with B, but each weight block is read only once per
batch/step, then reused before eviction:

```text
T_batch(B) = B*T_sequence_specific + T_shared_weights
aggregate output tok/s = B*O/T_batch(B)
```

The simulator's physical `max_micro_batch` is 32. Logical batches 64 and 128
need two/four microbatches. The main budget assumes the weight block remains
resident across those microbatches; that scheduling is not implemented here.
If weights reload at every microbatch, use `--weight-reuse-limit 32`; aggregate
throughput then plateaus at the batch-32 value for batches 64 and 128.
Without cross-sequence reuse, batching gives no aggregate-throughput gain in
this no-overlap model. This single-head RTL adds no sequence/batch scheduler.

Assuming external GQA sharing of K/V reads between the two Q heads belonging
to one KV head (also not implemented by this single-head unit):

| Input/output per sequence | Batch | Aggregate end-to-end tok/s | Aggregate decode tok/s | Batch completion seconds |
|---|---:|---:|---:|---:|
| 1024 / 128 | 1 | 277 | 652 | 0.461 |
| 1024 / 128 | 32 | 415 | 2972 | 9.860 |
| 1024 / 128 | 64 | 419 | 3153 | 19.562 |
| 1024 / 128 | 128 | 420 | 3252 | 38.966 |
| 128 / 1024 | 1 | 667 | 676 | 1.534 |
| 128 / 1024 | 32 | 3331 | 3552 | 9.837 |
| 128 / 1024 | 64 | 3560 | 3814 | 18.408 |
| 128 / 1024 | 128 | 3687 | 3960 | 35.549 |

End-to-end includes prefill; decode excludes it and divides B*(O-1) by decode
time. These are aggregate rates, not per-sequence rates. Larger batches
increase each sequence's latency. At batch128 the end-to-end component
budgets are approximately:

| Component | 1024 / 128 | 128 / 1024 |
|---|---:|---:|
| Linear compute | 33.0% | 45.8% |
| Non-MAC allowance | 11.3% | 12.4% |
| Attention compute | 1.1% | 1.0% |
| Extra activation traffic | 7.7% | 8.5% |
| KV traffic | 46.4% | 28.8% |
| Weight traffic | 0.4% | 3.6% |

If K/V cannot be shared between Q heads, aggregate end-to-end rates for
batches 32/64/128 become approximately 285/286/287 tok/s (1024 / 128) and
2644/2787/2864 tok/s (128 / 1024). This option is closer to independently
feeding every single-head instance. Neither version accounts for measured
format-conversion overhead, a real memory arbitration schedule, placement or
power limits. Required MXFP4 KV capacity at 1152 tokens is approximately
1.05/2.09/4.18 GiB for batches 32/64/128, plus weights and activations. An FP32
backing KV store would need about 7.53 times as much capacity and KV bandwidth.

Reproduce or change the assumptions:

```powershell
python Attention_confusion/parallel_row/estimate_batch_throughput.py --json Attention_confusion/parallel_row/throughput_budget.json
python Attention_confusion/parallel_row/estimate_batch_throughput.py --no-gqa-share --json Attention_confusion/parallel_row/throughput_budget_no_gqa_share.json
python Attention_confusion/parallel_row/estimate_batch_throughput.py --weight-reuse-limit 32
python Attention_confusion/parallel_row/estimate_batch_throughput.py --wave-cycles 55
```

The last command reproduces the preceding speculative throughput budget.
Neither the simulator's measured calibration file nor the physical array RTL
is changed by this work.
# 新思上传与 SIM-1023

新增上传包脚本、缺项测量模板和两份可直接粘贴的提示词位于 [synopsys](synopsys/)。运行 `python Attention_confusion/parallel_row/synopsys/build_upload.py` 生成独立 Attention 包及 SIM-1023 缺项测量包。Prompt1 用于本目录单 head 综合，Prompt2 用于只补模拟器缺少的数据；已有校准文件不修改。

测试台新增运行时 `+CONTEXT_N=N`、`+CONTEXT_FIRST=A +CONTEXT_LAST=B`、`+CLOCK_NS=T`、`+SEED=S`、`+POWER_ACTIVITY` 和 `+DUMP_VCD=path`。无需因改变输入长度重复编译硬件。MEASURE_BEGIN/END 标记功耗窗口；POWER_ACTIVITY 去除人工最大值压力输入，避免有效输入外的X活动。官方模型和默认配置综合仍须在新思主机验证。

