`timescale 1ns/1ps

// Single-query/head evaluation unit: 16 context rows x 4 dimension columns.
// Defaults: Q[128], 512 context tokens/wave, 64 logical 32x32 MAC planes.
// One 32x128 FP32 K/V tile is accepted per handshake; loading and computing
// are separate phases. This is an FP32 architectural evaluator, not a wrapper
// around the MXFP4 physical array or a complete sixteen-head scheduler.
module attention_head_16ctx_4dim_eval #(
    parameter integer HEAD_DIM = 128,
    parameter integer TILE_SIZE = 32,
    parameter integer MAX_CONTEXT = 1152,
    parameter integer CONTEXT_PARALLEL = 16,
    parameter [31:0] SCALE_BITS = 32'h3db504f3
) (
    input wire clk, rst_n,
    input wire i_cmd_valid,
    output wire o_cmd_ready,
    input wire [10:0] i_context_len,
    input wire [HEAD_DIM*32-1:0] i_query,
    input wire i_kv_valid,
    output wire o_kv_ready,
    input wire [TILE_SIZE*HEAD_DIM*32-1:0] i_key_tile, i_value_tile,
    output wire o_valid,
    input wire i_ready,
    output wire [HEAD_DIM*32-1:0] o_result,
    output reg o_error,
    output reg [31:0] o_cycle_count
);
    localparam integer S_IDLE=0, S_QUERY_SCALE=1, S_LOAD=2, S_LAUNCH=3,
        S_WAIT=4, S_INV=5, S_NORMALIZE=6, S_RESPONSE=7;
    localparam integer LOAD_W = (CONTEXT_PARALLEL <= 1) ? 1 : $clog2(CONTEXT_PARALLEL);
    reg [2:0] state;
    reg [10:0] context_q, loaded_q;
    reg [LOAD_W-1:0] load_lane_q;
    reg [CONTEXT_PARALLEL-1:0] active_q;
    reg [HEAD_DIM*32-1:0] query_q, query_scaled_q, result_q;
    reg running_present_q;
    reg [31:0] running_m_q, running_l_q, inverse_q;
    reg [HEAD_DIM*32-1:0] running_z_q;

    initial begin
        if (HEAD_DIM != 4*TILE_SIZE || TILE_SIZE < 2 || TILE_SIZE > 32 ||
            (TILE_SIZE & (TILE_SIZE-1)) != 0 || MAX_CONTEXT < 1 || MAX_CONTEXT > 2047 ||
            CONTEXT_PARALLEL < 2 || (CONTEXT_PARALLEL & (CONTEXT_PARALLEL-1)) != 0)
            $fatal(1, "invalid 16ctx/4dim Attention configuration");
    end
    assign o_cmd_ready = state == S_IDLE;
    assign o_kv_ready = state == S_LOAD;
    assign o_valid = state == S_RESPONSE;
    assign o_result = result_q;

    wire [HEAD_DIM*32-1:0] query_scaled, normalized;
    wire [31:0] inverse;
    wire [7:0] inv_status;
    DW_fp_div #(.sig_width(23), .exp_width(8), .ieee_compliance(0), .faithful_round(0)) u_inv (
        .a(32'h3f800000), .b(running_l_q), .rnd(3'b000), .z(inverse), .status(inv_status));
    genvar d;
    generate for (d=0; d<HEAD_DIM; d=d+1) begin : g_dim
        wire [7:0] sq, so;
        DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_query_scale (
            .a(query_q[d*32 +: 32]), .b(SCALE_BITS), .rnd(3'b000),
            .z(query_scaled[d*32 +: 32]), .status(sq));
        DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_output_scale (
            .a(running_z_q[d*32 +: 32]), .b(inverse_q), .rnd(3'b000),
            .z(normalized[d*32 +: 32]), .status(so));
    end endgenerate

    wire [TILE_SIZE-1:0] load_mask;
    genvar t;
    generate for (t=0; t<TILE_SIZE; t=t+1) begin : g_load_mask
        assign load_mask[t] = ({1'b0,loaded_q} + t) < {1'b0,context_q};
    end endgenerate

    // Complete binary tree, root=1, leaves=CONTEXT_PARALLEL..2*C-1.
    wire node_fire [1:2*CONTEXT_PARALLEL-1];
    wire node_present [1:2*CONTEXT_PARALLEL-1];
    wire [31:0] node_m [1:2*CONTEXT_PARALLEL-1], node_l [1:2*CONTEXT_PARALLEL-1];
    wire [HEAD_DIM*32-1:0] node_z [1:2*CONTEXT_PARALLEL-1];
    genvar c, n;
    generate
        for (c=0; c<CONTEXT_PARALLEL; c=c+1) begin : g_context
            attention_context_4dim_lane #(.HEAD_DIM(HEAD_DIM), .TILE_SIZE(TILE_SIZE)) u_lane (
                .clk(clk), .rst_n(rst_n),
                .i_load(o_kv_ready && i_kv_valid && load_lane_q == c),
                .i_token_mask(load_mask), .i_key(i_key_tile), .i_value(i_value_tile),
                .i_start(state == S_LAUNCH), .i_active(active_q[c]),
                .i_query_scaled(query_scaled_q),
                .o_done(node_fire[CONTEXT_PARALLEL+c]),
                .o_present(node_present[CONTEXT_PARALLEL+c]),
                .o_m(node_m[CONTEXT_PARALLEL+c]), .o_l(node_l[CONTEXT_PARALLEL+c]),
                .o_z(node_z[CONTEXT_PARALLEL+c]));
        end
        for (n=1; n<CONTEXT_PARALLEL; n=n+1) begin : g_merge
            attention_online_merge_fp32 #(.HEAD_DIM(HEAD_DIM)) u_merge (
                .clk(clk), .rst_n(rst_n), .i_fire(node_fire[2*n] && node_fire[2*n+1]),
                .i_a_present(node_present[2*n]), .i_b_present(node_present[2*n+1]),
                .i_a_m(node_m[2*n]), .i_a_l(node_l[2*n]), .i_a_z(node_z[2*n]),
                .i_b_m(node_m[2*n+1]), .i_b_l(node_l[2*n+1]), .i_b_z(node_z[2*n+1]),
                .o_fire(node_fire[n]), .o_present(node_present[n]),
                .o_m(node_m[n]), .o_l(node_l[n]), .o_z(node_z[n]));
        end
    endgenerate

    wire merged_fire, merged_present;
    wire [31:0] merged_m, merged_l;
    wire [HEAD_DIM*32-1:0] merged_z;
    attention_online_merge_fp32 #(.HEAD_DIM(HEAD_DIM)) u_global_merge (
        .clk(clk), .rst_n(rst_n), .i_fire(node_fire[1]),
        .i_a_present(running_present_q), .i_a_m(running_m_q),
        .i_a_l(running_l_q), .i_a_z(running_z_q),
        .i_b_present(node_present[1]), .i_b_m(node_m[1]),
        .i_b_l(node_l[1]), .i_b_z(node_z[1]),
        .o_fire(merged_fire), .o_present(merged_present),
        .o_m(merged_m), .o_l(merged_l), .o_z(merged_z));

    // Wide data are not reset; the control/presence bits guarantee overwrite.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE; context_q <= 0; loaded_q <= 0; load_lane_q <= 0;
            active_q <= 0; running_present_q <= 0;
            o_error <= 0; o_cycle_count <= 0;
        end else begin
            if (state != S_IDLE && state != S_RESPONSE) o_cycle_count <= o_cycle_count+1;
            case (state)
                S_IDLE: if (i_cmd_valid) begin
                    query_q <= i_query; context_q <= i_context_len;
                    loaded_q <= 0; load_lane_q <= 0; active_q <= 0;
                    running_present_q <= 0; o_cycle_count <= 0;
                    o_error <= (i_context_len == 0 || i_context_len > MAX_CONTEXT);
                    if (i_context_len == 0 || i_context_len > MAX_CONTEXT) begin
                        result_q <= 0; state <= S_RESPONSE;
                    end else state <= S_QUERY_SCALE;
                end
                S_QUERY_SCALE: begin query_scaled_q <= query_scaled; state <= S_LOAD; end
                S_LOAD: if (i_kv_valid) begin
                    active_q[load_lane_q] <= 1'b1;
                    // Clamp the last partial tile, avoiding 11-bit overflow
                    // when the maximum supported context is 2047 tokens.
                    if ({1'b0,loaded_q}+TILE_SIZE >= {1'b0,context_q}) begin
                        loaded_q <= context_q; state <= S_LAUNCH;
                    end else begin
                        loaded_q <= loaded_q+TILE_SIZE;
                        if (load_lane_q == CONTEXT_PARALLEL-1) state <= S_LAUNCH;
                        else load_lane_q <= load_lane_q+1'b1;
                    end
                end
                S_LAUNCH: state <= S_WAIT;
                S_WAIT: if (merged_fire) begin
                    running_present_q <= merged_present;
                    running_m_q <= merged_m; running_l_q <= merged_l; running_z_q <= merged_z;
                    if (loaded_q == context_q) state <= S_INV;
                    else begin active_q <= 0; load_lane_q <= 0; state <= S_LOAD; end
                end
                S_INV: begin inverse_q <= inverse; state <= S_NORMALIZE; end
                S_NORMALIZE: begin result_q <= normalized; state <= S_RESPONSE; end
                S_RESPONSE: if (i_ready) state <= S_IDLE;
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
