#!/usr/bin/env python3
"""Build self-contained source bundles; no licensed IP or synthetic DW models."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
OUTPUT = REPO / "Attention_confusion/parallel_row/upload"
ALLOWED = {".py", ".md", ".json", ".txt", ".f", ".tcl", ".sdc", ".sv", ".v", ".vh", ".sh", ".ps1"}

VERIFY = '''from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
records=json.loads((root/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))["files"]
bad=[n for n,h in records.items() if not (root/n).is_file() or hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit("Missing/changed files: "+str(bad))
print("PASS upload SHA256:",len(records),"files")
'''


def sources(root):
    return {p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in ALLOWED
            and not {"__pycache__", ".pytest_cache", "sim", "results", "upload"}.intersection(p.parts)
            and p.name != "nonmac_test_dw.sv"}


def bundle(name, files):
    files = sorted(files)
    manifest = {p.relative_to(REPO).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    with zipfile.ZipFile(OUTPUT/name, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(REPO).as_posix())
        archive.writestr("verify_upload.py", VERIFY)
        archive.writestr("UPLOAD_MANIFEST.json", json.dumps(dict(
            files=manifest,
            omitted="nonmac_test_dw.sv; local vvp/caches; licensed SMIC/DW libraries",
            note="Use official DW models on Synopsys host. Some old system RTL lists have stale filenames; audit before use."), indent=2)+"\n")
    with zipfile.ZipFile(OUTPUT/name) as archive:
        assert archive.testzip() is None
        for filename, digest in manifest.items():
            assert hashlib.sha256(archive.read(filename)).hexdigest() == digest
    print(f"{OUTPUT/name}: {len(files)} source files, {(OUTPUT/name).stat().st_size:,} bytes; SHA256 verified")


def main():
    OUTPUT.mkdir(exist_ok=True)
    # Refresh inventory and templates; inputs are read-only.
    import prepare_measurements
    prepare_measurements.main()
    files = sources(REPO/"Attention_confusion/parallel_row")
    files |= {REPO/"RTL/RTL_1017SIM/tb/nonmac_tb_math.sv", REPO/"scripts/sim_operation1.txt"}
    bundle("attention_16x4_synopsys_upload.zip", files)
    system = files | sources(REPO/"simulator/SIM-1023")
    bundle("sim1023_missing_data_upload.zip", system)


if __name__ == "__main__":
    main()
