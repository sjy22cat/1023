#!/usr/bin/env python3
"""Read-only audit of existing prices; generate requests/templates in this folder.

Run from any directory. Never writes into existing calibration JSON files.
The exact N profile list includes both requested workloads and N=1152 baseline.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
SIM = REPO / "simulator/SIM-1023/simulator/simulator/SIM-1017"
RTL = HERE.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def leaves(value, path=""):
    if isinstance(value, dict):
        for key, val in value.items():
            if key.startswith("_"):
                continue
            yield from leaves(val, f"{path}.{key}" if path else key)
    elif isinstance(value, list):
        if not value:
            yield path, value
        for index, val in enumerate(value):
            yield from leaves(val, f"{path}[{index}]")
    else:
        yield path, value


def write(name, obj):
    (HERE/name).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")


def main():
    files = {}
    for path in sorted((SIM/"calibration/rtl_1017sim").glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        values = dict(leaves(data))
        files[str(path.relative_to(REPO)).replace("\\", "/")] = dict(
            sha256=sha(path), status=data.get("status"), schema=data.get("schema"),
            missing_null_paths=[key for key, value in values.items() if value is None],
            preserved_values={key: value for key, value in values.items() if value is not None})
    write("existing_data_inventory.json", dict(
        policy="READ_ONLY: reuse existing non-null data with its original units, source and validity; only measure gaps",
        files=files))
    hashes = {name: sha(RTL/name) for name in (
        "attention_online_merge_fp32.sv", "attention_context_4dim_lane.sv", "attention_head_16ctx_4dim_eval.sv")}
    write("fused_attention_16x4.template.json", dict(
        schema="yrr-fused-attention-16x4/v1", status="PENDING",
        scope="single_head_fp32_including_local_kv_registers_excluding_external_memory_and_leakage",
        parameters=dict(HEAD_DIM=128, TILE_SIZE=32, CONTEXT_PARALLEL=16, MAX_CONTEXT=1152),
        clock_ns=None,
        validation={key:False for key in ("official_dw_numeric_pass", "full_top_mapped", "no_blackboxes", "setup_pass", "hold_pass")},
        provenance=dict(rtl_sha256=hashes, tools=None, library=None, pvt=None, reports=[], activity_policy=None),
        area_um2=None, sequential_area_um2=None, register_bits=None, leakage_mw=None,
        profiles={str(n):dict(cycles=None, kv_load_cycles=None, dynamic_pj=None, report=None) for n in range(1,1153)}))
    write("measurement_requests.json", dict(
        schema="yrr-missing-measurements-request/v1",
        existing_data_policy="Never overwrite existing sources; write new results and field/source mapping separately",
        workloads=[dict(prompt_tokens=1024,output_tokens=128),dict(prompt_tokens=128,output_tokens=1024)],
        attention=dict(causal_prefill=True, decode_forwards="output_tokens-1",
            required_contexts=list(range(1,1152)), additional_baseline_contexts=[1152],
            default_cycle_formula="48*ceil(N/512)+ceil(N/32)+3; structural check only, not timing closure",
            context_boundary_checks=[1,31,32,33,511,512,513,1023,1024,1025,1151,1152],
            reference_seed=20261023, extra_activity_seeds=[20261024,20261025],
            internal_dtype="FP32", storage_dtype="MXFP4: 17 bytes/32 elements",
            parallel_heads=16, tiles_per_head=64, gqa_read_sharing=False),
        missing_scope_groups=[
            "fused Attention single-head exact-context profiles and full-top area/STA/leakage",
            "MXFP4/FP32 QKV and output bridge (not currently implemented in Attention evaluator)",
            "16-head distribution/interconnect, request bandwidth/II, integrated leakage delta",
            "existing warm GEMV, non-MAC and memory/PHY calibration null fields only; reuse present data"],
        nonmac_lengths=dict(rmsnorm=[128,1024],rope_vector=[128],
                           residual=[1024],swiglu_vector=[1024]),
        nonmac_note="MLP 3072 pointwise vector splits into 3x1024; do NOT split RMSNorm/Softmax independent chunks",
        external_sources="RRAM/FeRAM/SRAM macro/PHY IP numbers need real macro/IP characterization, not standard-cell synthesis of storage RTL"))
    print(f"Prepared inventory/templates/requests in {HERE}")
    print(f"Preserved {len(files)} existing calibration JSON files; no changes to their contents")


if __name__ == "__main__":
    main()
