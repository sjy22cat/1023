from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
records=json.loads((root/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))["files"]
bad=[n for n,h in records.items() if not (root/n).is_file() or hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit("Missing/changed files: "+str(bad))
print("PASS upload SHA256:",len(records),"files")
