# Candidate Evidence Scan

> This automated scan finds leads for manual inspection. It does not assign simulator fidelity levels and must not be cited as proof.

- Repository: `F:\AID\MXFP4\仿真器\SIM-1017\SIM-1017-2\simulator\simulator\SIM-1017`
- Scanned text files: 104
- Per-file size limit: 2 MiB
- Scan time (UTC): 2026-10-19T06:18:24.447393+00:00

## Interpretation Warnings

- Matches are candidate evidence only. Comments and documentation may describe a missing feature, and declarations may be unused; trace the executed call path before assigning A/M/I/C/S/E/V levels.
- Both communication and queue/contention signals were found. This is only a lead for I3: verify that link/router/switch state is executed and affects reported time.
- Composition/overlap signals were found. Inspect every sum/max/pipeline for dependencies, finite buffers, startup/drain, shared-resource occupancy, and mutable-state idempotence.

## Signal Summary

| Signal class | Matching lines |
|---|---:|
| Simulation style | 860 |
| Compute model | 995 |
| Memory model | 23 |
| Interconnect/communication | 11 |
| Queues/arbitration/contention | 183 |
| Host CPU/runtime timing | 12 |
| Accelerator/internal scheduling | 1 |
| Energy/area | 189 |
| Zero/placeholder energy | 0 |
| Validation/calibration | 30 |
| Composition/overlap/mutable state | 233 |
| Host tool parallelism | 0 |

## Candidate Evidence

### Simulation style

- `PACKAGE_SOURCE.json:4` — `"source": "F:\\AID\\MXFP4\\仿真器\\rtl-sim-1015\\simulator-1016\\1016SIM",`
- `PACKAGE_SOURCE.json:5` — `"rtl_reference_source": "F:\\AID\\MXFP4\\仿真器\\rtl-sim-1015\\RTL_v3",`
- `PACKAGE_SOURCE.json:7` — `"included": "Current simulator, configuration, documentation, tests, RTL reference snapshot and latest previous verification examples",`
- `PACKAGE_SOURCE.json:11` — `"compiled RTL sim outputs",`
- `PACKAGE_SOURCE.json:39` — `"RTL_v3/v3/rtl/mx_array.v": "c75a53b4d617fd5993f2c7ae3c412e47d2d9ec14263b636cbe847a2618741eef",`
- `PACKAGE_SOURCE.json:40` — `"RTL_v3/v3/rtl/mx_ctrl.v": "4529467d241c173c2bba2b01b7c1d6c63e8691df85bda3c1650d9a7ad8f6a3c9",`
- `PACKAGE_SOURCE.json:41` — `"RTL_v3/v3/rtl/mx_fmt_defs.vh": "abdef54422b93a11e69ec981131e05bf060de147393022c88e98681d36b000bb",`
- `PACKAGE_SOURCE.json:42` — `"RTL_v3/v3/rtl/mx_fmt_funcs.vh": "31a48d4b74f1d5650e20e749f94d7dd53274746f689b1ef6c7897b45843a2aaa",`
- _Showing 8 of 860 matching lines; raise `--max-evidence` if needed._

### Compute model

- `README_SIM-1017.md:45` — `各 tile → 32 PE/tile → 32 MAC lane/PE，本地 lane enable / zero / TAG mask`
- `README_SIM-1017.md:48` — `物理阵列为 32×32 tile，共 32,768 PE、1,048,576 路 MAC。每个 MC 服务一列的 32 个 tile，共享一套总控。单 channel 数据为 **128 bit payload + 8 bit E8M0 scale**；这是 32 个 MXFP4 元素的一组，合计 17 B。32 路并行不改变单路宽度。`
- `README_SIM-1017.md:52` — `预判 block skip 只看 E8M0 scale：'Esum=(Wscale-127)+(Xscale-127)'，按输出求 'EMXmax'，当 'EMXmax-Esum >= T' 时跳过。它发生在 input payload 读取、广播和 MAC 之前。'mx_skip_threshold_bits=null' 表示未确认阈值、关闭此跳过；不能从已算出的乘积/partial 反推跳过。`
- `README_SIM-1017.md:54` — `TAG/零值门控在本地译码后控制单路 MAC。一个 tile 仍有 PE 需要某组输入时，不能省去共享输入接收；源端全部接收方都跳过才省去源 payload 读取。输入 scale 检查仍发生。**冷启动完整权重装载在 skip 判断之前，不能将 block skip 计为首次权重搬运的节省。**`
- `README_SIM-1017.md:66` — `| 'pe_per_tile'、'tile_k' | 均为 32；后者为每 PE 的 MAC lane 数 |`
- `README_SIM-1017.md:75` — `'clock_ns' 的单位为 ns；其余字段为非负整数 cycles，其中乘法、归约周期要求大于 0。非 MAC 周期另在 'nonmac' 中逐算子/长度表征。应以 VCS handshake/阶段 trace 测周期，以 STA 收敛结果确定可用时钟；不能仅填 SDC 目标频率。`
- `README_SIM-1017.md:127` — `用 VCS 的有效活动窗口、SAIF/VCD 和 PT PX/合格 macro 模型获取动态能量，再除以同窗口的事件数。换算为 'pJ = W × s × 10^12'。扣除独立记录的 leakage/idle，明确时钟网络和控制开销如何归属；不能把同一段能量同时计入 block、MAC、互连、PHY。`
- `README_SIM-1017.md:131` — `| 'pe_mac_pj' | 每次有效 MAC |`
- _Showing 8 of 995 matching lines; raise `--max-evidence` if needed._

### Memory model

- `docs/V3_RRAM_FeRAM混合存储合并说明_20261017.md:158` — `没有新增真实器件测量、DRAM 对照、逐周期存储争用模型或真实模型困惑度结果。`
- `docs/V3_RTL缺项与实现要求.md:21` — `等收到服务器数据后再接入。工艺能耗、面积和 RRAM/FeRAM 相对 DRAM 的收益必须由`
- `docs/V3_RTL缺项与实现要求.md:304` — `限制和相对 DRAM 的收益要等工艺/器件数据。`
- `docs/V3_RTL缺项与实现要求.md:326` — `- 双缓冲页读写互不覆盖；bank conflict、queue stall 和输入带宽不足要可观测。`
- `docs/V3_RTL缺项与实现要求.md:360` — `不能写成芯片实测，也不能据此声称 RRAM/FeRAM 相对 DRAM 的已验证能效提升。`
- `docs/给RTL同事的V3补充模块说明_新手版.md:23` — `Softmax 可以留到后续 RTL 阶段。第一阶段必须把每个样本的 1024 个 logits 完整交给 Python；Python 才能进一步计算稳定 softmax 和语言模型困惑度（PPL）。RRAM/FeRAM 宏、混合 3D 器件和相对 DRAM 的能耗收益也留待获得真实器件数据后校准。`
- `docs/给RTL同事的V3补充模块说明_新手版.md:329` — `- 每 bank conflict/stall、Mem Die queue wait、DMA queue wait、backpressure stall。`
- `docs/给RTL同事的V3补充模块说明_新手版.md:377` — `8. 把每个能耗数字标成实测、库推导、器件推导或假设，并说明计数口径。RRAM/FeRAM 相对 DRAM 的收益要等两种存储器真实数据齐全后再算。`
- _Showing 8 of 23 matching lines; raise `--max-evidence` if needed._

### Interconnect/communication

- `README_SIM-1017.md:360` — `MoE/MLA 的参数解析、权重/KV 容量描述已存在，**当前前向仍会明确返回 NOT_IMPLEMENTED/异常**。'--moe-routing' 不是已实现的专家执行器。不能用稠密近似结果冒充 MoE 的真实权重访问；MLA 容量节省也不等于已实现 MLA 运算。RoPE scaling、soft-capping 等数值近似见报告 'approximations'。`
- `run_llm.py:104` — `ap.add_argument("--moe-routing", metavar="PATH", default=None,`
- `verification/array_report.json:1208` — `"scheduling": "integer shared-resource reservations, buffer ownership, microbatch barriers; no router-level NoC"`
- `verification/array_report.json:30018` — `"partial_interconnect_pj": 327.68,`
- `verification/array_report.json:30037` — `"partial_interconnect_pj": 327.68,`
- `yrr_v3/architecture.py:3` — `This is an architectural event model, not a router-level NoC or a timing CPU.`
- `yrr_v3/architecture.py:334` — `"partial_interconnect_pj": partial_bits*e.partial_link_pj_per_bit,`
- `yrr_v3/architecture.py:443` — `"scheduling": "integer shared-resource reservations, buffer ownership, microbatch barriers; no router-level NoC"},`
- _Showing 8 of 11 matching lines; raise `--max-evidence` if needed._

### Queues/arbitration/contention

- `README_SIM-1017.md:33` — `traces/ # VCS 请求/响应、逐 channel 流量、lane mask、冷/热启动`
- `README_SIM-1017.md:75` — `'clock_ns' 的单位为 ns；其余字段为非负整数 cycles，其中乘法、归约周期要求大于 0。非 MAC 周期另在 'nonmac' 中逐算子/长度表征。应以 VCS handshake/阶段 trace 测周期，以 STA 收敛结果确定可用时钟；不能仅填 SDC 目标频率。`
- `README_SIM-1017.md:96` — `因此若 VCS 给的是一个事务的完整 request→complete 时间，必须先扣除同口径的有效传输服务段，再填写固定开销，并用多个事务长度验证。不能把完整延迟原样填入后又加一次带宽时间。这是测量值的口径归一化；模拟器不根据 RTL 结构推测该开销。`
- `README_SIM-1017.md:107` — `| 'mem_die_queue_depth' | 当前调度器的**总 outstanding 事务槽位数**，不是每 MC 深度；少于 32 会限制同时启动的通道数 |`
- `README_SIM-1017.md:127` — `用 VCS 的有效活动窗口、SAIF/VCD 和 PT PX/合格 macro 模型获取动态能量，再除以同窗口的事件数。换算为 'pJ = W × s × 10^12'。扣除独立记录的 leakage/idle，明确时钟网络和控制开销如何归属；不能把同一段能量同时计入 block、MAC、互连、PHY。`
- `README_SIM-1017.md:226` — `2. 用 VCS 导出请求/响应与活动统计，覆盖冷/热启动、32 路同时请求、错峰返回、背压、不同流量长度、全活跃/零值/lane mask/scale skip。`
- `README_SIM-1017.md:229` — `5. 校验参数后运行，保留输入 JSON 和报告副本，比较模拟调度与 VCS 的事务数、字节、mask、MAC 与周期差异。`
- `calibration/rtl_1017sim/rtl_1017sim_measured.json:10` — `"config_overrides.mem_die_queue_depth": "TOTAL outstanding transaction slots in this scheduler",`
- _Showing 8 of 183 matching lines; raise `--max-evidence` if needed._

### Host CPU/runtime timing

- `README_SIM-1017.md:83` — `| 'host_dma_setup_cycles' | Host DMA descriptor/staging 启动开销 |`
- `README_SIM-1017.md:200` — `Python/NumPy 继续提供数值参考；它不提供非 MAC 性能和能耗。MXFP4 编码、RoPE 正余弦表生成、token 采样/argmax 没有在三个模块中实现，当前属于 Host 参考步骤，成本明确排除。LLM 'execution_scope' 将 'full_system_metrics_complete' 标为 false；性能指标限于已覆盖的加速器服务，不能理解成含 Host 的整机测量。`
- `calibration/rtl_1017sim/rtl_1017sim_measured.json:232` — `"host_dma_setup_cycles": null,`
- `examples/previous_verification/report_hybrid_shape_20261017.json:1764` — `"host_latency_excluded": true,`
- `examples/previous_verification/report_hybrid_smoke_20261017.json:1764` — `"host_latency_excluded": true,`
- `tests/test_v3_hybrid_memory.py:72` — `assert traffic["host_latency_excluded"] is True`
- `verification/hybrid_report.json:1764` — `"host_latency_excluded": true,`
- `yrr_v3/architecture.py:3` — `This is an architectural event model, not a router-level NoC or a timing CPU.`
- _Showing 8 of 12 matching lines; raise `--max-evidence` if needed._

### Accelerator/internal scheduling

- `docs/V3时序与RTL边界.md:6` — `shared-resource schedule:`

### Energy/area

- `PACKAGE_SOURCE.json:76` — `"yrr_v3/area.py": "0d3d26aca9c869ec250d3dae970b70457521602d88f991757071f4fa2078478f",`
- `PACKAGE_SOURCE.json:114` — `"Prefer bundled RTL/synthesis/technology paths",`
- `README_SIM-1017.md:29` — `synthesis/ # 展开配置、综合/布局布线面积、层次报告`
- `README_SIM-1017.md:31` — `power/ # PT PX 功耗报告、SAIF/VCD、活动覆盖率、统计窗口`
- `README_SIM-1017.md:125` — `### 3.4 'energy'：事件能耗`
- `README_SIM-1017.md:147` — `### 3.5 'area'：外部面积结果`
- `README_SIM-1017.md:151` — `来自 DC/ICC II/Fusion Compiler 的层次面积报告及 macro 数据。记录是 cell area 还是 die/core area、是否含 SRAM/PHY macro、filler/CTS 等。'logic_die_mm2' 必须大于零；各分项未必能直接相加，需要在 provenance 解释范围。模拟器只展示输入面积，不据此反推走线长度、延迟或能耗。`
- `README_SIM-1017.md:176` — `同名能耗字段必须与 'energy' 一致。'f_max_mhz=1000/clock_ns'、'block_pj_by_mac=macs_per_block×pe_mac_pj' 仅作单位/账目换算，不需填入 JSON。'energy' 的 'ferram_*' 与本章节的 'feram_*' 拼写不同，请保留模板键名。`
- _Showing 8 of 189 matching lines; raise `--max-evidence` if needed._

### Zero/placeholder energy

No candidate matches in scanned files.

### Validation/calibration

- `README_SIM-1017.md:184` — `'format_contract' 记录 RRAM/TAG LUT 版本、zero code、E8M0、32 元素分组、阈值、舍入、饱和与 golden vectors。'validation' 归档逐 channel 请求数/返回字节、请求响应 trace、active/skipped blocks、lane mask、active MAC、饱和计数、冷/热启动 cycles。**这两节目前是验收证据，不会自动覆盖数值模型或重放 trace。**`
- `run_llm.py:196` — `cfg.validate()`
- `validate_parameters.py:1` — `"""Validate externally collected Synopsys results without running inference."""`
- `validate_parameters.py:28` — `print("Validated Synopsys parameter contract: " + str(args.parameters))`
- `calibration/rtl_1017sim/rtl_1017sim_measured.json:205` — `"validation": {`
- `docs/RTL_1017SIM校准与模拟器接入.md:9` — `旧 'export_calibration.py'、'rtl_1017_calibration.json'、'calib/llm_calib.json'、面积和 RTL 推导路径已删除。'format_contract/validation' 用于证据归档，不自动替换数值行为或重放 trace；参数校验不能替代 STA/RTL 等价验收。`
- `tests/hardware_fixture.py:1` — `"""Explicit synthetic test data. These numbers are NOT hardware measurements."""`
- `tests/test_v3_scale_skip.py:147` — `V3Config(mx_skip_threshold_bits=threshold).validate()`
- _Showing 8 of 30 matching lines; raise `--max-evidence` if needed._

### Composition/overlap/mutable state

- `README_SIM-1017.md:110` — `| 'input_double_buffer'、'logits_double_buffer' | JSON 布尔值；实际双缓冲选项 |`
- `check_rtl.py:114` — `WS = np.zeros((M, max(1, K // 32)), dtype=np.uint8)`
- `check_rtl.py:125` — `XS = np.zeros((1, max(1, K // 32)), dtype=np.uint8)`
- `check_rtl.py:147` — `flag = "" if d < 1e-3 * max(1.0, abs(py)) else " <== 不符"`
- `check_rtl.py:163` — `s_rtl = sum(g["softmax"].values())`
- `run_llm.py:146` — `cores=max(1, args.cores),`
- `run_llm.py:149` — `n_runs=max(1, args.n_runs),`
- `RTL_v3/v3/rtl/mx_reduce.v:85` — `// 把 a、b 左移到 max(ea,eb) 后相加；移位饱和时置粘滞。`
- _Showing 8 of 233 matching lines; raise `--max-evidence` if needed._

### Host tool parallelism

No candidate matches in scanned files.

## Required Manual Follow-up

1. Start at the reported latency/energy writer and trace each matched parameter into the executed equations or event loop.
2. Classify A/M/I/C/S/E/V independently; use `unknown` when the executed path is unclear.
3. Separate offline DSE, accelerator scheduling, serving policy, and host CPU execution.
4. Test repeated-evaluation idempotence and worker-count invariance.
5. Check split-K/channel/tensor-parallel reductions and all shared-resource overlap assumptions.
6. Align validation ground truth with the exact prediction unit before accepting end-to-end claims.
