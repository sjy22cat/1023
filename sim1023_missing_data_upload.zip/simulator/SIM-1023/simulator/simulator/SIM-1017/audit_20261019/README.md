# 本次审查材料

日期：2026-10-19。未修改提交的仿真器或 RTL。

- `regression.log`：实际执行当前 67 项 Python 回归，全部通过。
- `scanner.md`：审计技能的自动源码线索扫描；不是正确性证明。
- `probe_review.py`：独立审查探针，可重复运行。
- `probe.log` / `probe_results.json`：实际 Python 数值、事件和指标反例；所有硬件价格均为合成测试数据，不是物理测量。
- `source_inventory.json`：实际审查的关键源码、测试与脚本的 SHA256。
- `run_pending.log` / `validate_parameters_pending.log`：当前默认正式入口拒绝 PENDING 模板的日志。
- `tb_audit_ctrl.sv`：DONE / start 接收边界反例。
- `tb_audit_stale_skip.sv`：无复位连续任务时，被 skip 的 PE 旧 partial 泄漏反例。

本机没有可运行的 Icarus / Verilator / 新思工具。**两个新增 TB 尚未编译或执行**。它们是交给 RTL 同事复核的反例，不是伪造的已通过/已失败仿真结果。Python 中的 RTL 特例计算也明确标为方程推导。

从模拟器主目录运行：

```powershell
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONDONTWRITEBYTECODE='1'
python -B tests/run_current.py
python -B audit_20261019/probe_review.py
```

微码算法检查从权威 `nonmac_microcode.vh` 读取指令，使用独立 FP32 指令解释器运行；它验证算法、索引和计数，不验证 DW 舍入逐位等价、流水调度、综合时序或功耗。

## 服务器运行两个 RTL 反例

下面命令供已安装 Icarus 的 Linux 环境使用，工作目录为提交根目录 `SIM-1017-2`。路径中的重复 `RTL/RTL` 和 `simulator/simulator` 与此次交付一致。输出都写入审查目录。

```sh
audit=simulator/simulator/SIM-1017/audit_20261019
rtl=RTL/RTL/RTL_1017SIM
iverilog -g2012 -Wall -s tb_audit_ctrl -o "$audit/audit_ctrl.vvp" \
    "$rtl/rtl/mx_global_ctrl_1017.v" "$audit/tb_audit_ctrl.sv"
vvp "$audit/audit_ctrl.vvp"
```

当前控制代码按静态路径预期触发 `AUDIT BUG: start while !busy in DONE was discarded`。修复后应正常完成。

第二个反例需要完整 top 的依赖。以下显式采用同事提供的测试 DW 模型，只验证逻辑，不构成实测或 DW 等价证明：

```sh
audit=simulator/simulator/SIM-1017/audit_20261019
rtl=RTL/RTL/RTL_1017SIM
iverilog -g2012 -Wall -DMX_SIM_INIT -DNONMAC_TEST_DW -I "$rtl/rtl" \
    -s tb_audit_stale_skip -o "$audit/audit_stale_skip.vvp" \
    "$rtl/tb/nonmac_tb_math.sv" "$rtl/tb/nonmac_test_dw.sv" \
    "$rtl"/rtl/*.v "$rtl"/rtl/*.sv "$audit/tb_audit_stale_skip.sv"
vvp "$audit/audit_stale_skip.vvp"
```

第二次任务 row0 正确应为 mantissa=8192、exponent=-8，即 32。按当前代码寄存器保持规则预计得到 64 并触发断言。可以在 VCS 中使用相同 TB，改用授权 DW 库及相应编译选项。两个 TB 都应先由 RTL 同事在其工具上编译检查，再纳入固定回归。
