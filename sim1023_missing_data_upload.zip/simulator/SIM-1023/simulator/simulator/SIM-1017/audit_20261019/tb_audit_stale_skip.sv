`timescale 1ns/1ps
// Audit counterexample. Not executed on the review machine (no HDL tools).
// Run against the submitted top, all RTL dependencies, and the same DW/scratch
// setup as run_tb.ps1. No force, no edits to the design, no reset between jobs.
module tb_audit_stale_skip;
  localparam ROWS=2, BLOCKS=2, LW=128, AW=1;
  reg clk=0; always #5 clk=~clk;
  reg rst_n=0,start=0,host_we=0,host_block=0;
  reg [7:0] host_scale=127;
  wire [1:0] mem_req;
  wire [1:0] mem_addr;
  reg [1:0] pending=0,mem_valid=0;
  reg [1:0] pending_addr=0;
  reg [255:0] mem_data=0;
  reg [15:0] mem_scale=0;
  wire done,busy,result_valid;
  wire [3:0] phase;
  wire [63:0] result;
  wire [21:0] exponent;
  wire [3:0] skip;
  integer ch;
  yrr_1017_top #(.MC_COUNT(2),.TILE_ROWS(1),.TILE_COLS(2),.PE_PER_TILE(2),
    .TILE_K(32),.AW(AW),.ACCW(20),.RESULT_W(32),.MX_SKIP_THRESHOLD_BITS(4)) dut(
    .clk(clk),.rst_n(rst_n),.i_start(start),.i_metadata_valid(1'b1),
    .i_host_we(host_we),.i_host_block(host_block),.i_host_payload({32{4'h2}}),
    .i_host_scale(host_scale),.i_input_lane_enable({64{1'b1}}),
    .o_mem_req(mem_req),.o_mem_addr(mem_addr),.i_mem_valid(mem_valid),
    .i_mem_rdata(mem_data),.i_mem_rscale(mem_scale),
    .o_done(done),.o_busy(busy),.o_phase(phase),.o_block_skip(skip),
    .o_result(result),.o_result_exponent(exponent),.o_result_valid(result_valid),
    .i_nonmac_cmd_valid(1'b0),.i_nonmac_from_reduce(1'b0),.i_nonmac_op(5'd0),
    .i_nonmac_len(11'd0),.i_nonmac_a(32'd0),.i_nonmac_b(32'd0),.i_nonmac_c(32'd0),
    .i_nonmac_d(32'd0),.i_nonmac_epsilon(32'd0),.i_nonmac_tag(32'd0),
    .i_nonmac_ready(1'b1),.i_nonmac_mem_ready(1'b1),
    .i_nonmac_mem_rsp_valid(1'b0),.i_nonmac_mem_rdata(32'd0));
  always @(posedge clk) begin
    mem_valid <= 0;
    if(!rst_n) pending <= 0;
    else for(ch=0;ch<2;ch=ch+1) begin
      if(mem_req[ch]) begin
        pending[ch]<=1;pending_addr[ch]<=mem_addr[ch];
      end
      if(pending[ch]) begin
        pending[ch]<=0;mem_valid[ch]<=1;
        mem_data[ch*LW+:LW]<={32{4'h2}};
        // W scales: row0=[127,127], row1=[127,117].
        mem_scale[ch*8+:8]<=((ch==1)&&pending_addr[ch])?8'd117:8'd127;
      end
    end
  end
  task line(input bit block_id,input [7:0] scale);
    begin
      @(negedge clk);host_block=block_id;host_scale=scale;host_we=1;
      @(negedge clk);host_we=0;
    end
  endtask
  task launch;
    begin
      wait(phase==0);@(negedge clk);start=1;
      @(negedge clk);start=0;
    end
  endtask
  initial begin
    repeat(3) @(negedge clk);rst_n=1;
    line(0,127);line(1,127);launch();wait(done);
    $display("AUDIT first job row0: mantissa=%0d exponent=%0d",$signed(result[31:0]),$signed(exponent[10:0]));
    @(negedge clk);wait(phase==0);
    // Second job: row0 block0 must skip, while row1 still needs block0.
    line(0,117);line(1,127);launch();wait(done);#1;
    if(skip!==4'b0001) $fatal(1,"audit setup expected skip mask 0001, got %b",skip);
    $display("AUDIT second job row0: mantissa=%0d exponent=%0d; expected 8192*2^-8=32",
      $signed(result[31:0]),$signed(exponent[10:0]));
    if($signed(result[31:0])!==32'sd8192 || $signed(exponent[10:0])!==-11'sd8)
      $fatal(1,"AUDIT BUG: skipped PE contributed stale first-job partial (current RTL equations predict 64 instead of 32)");
    $display("PASS: skipped PE contributes zero across consecutive jobs");$finish;
  end
  initial begin #100000; $fatal(1,"audit stale-skip timeout"); end
endmodule
