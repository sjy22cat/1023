`timescale 1ns/1ps
// Audit counterexample. Not executed on the review machine (no HDL tools).
// Compile this file with the submitted mx_global_ctrl_1017.v only.
module tb_audit_ctrl;
  reg clk=0; always #5 clk=~clk;
  reg rst_n=0,start=0;
  wire wreq,calc,done,busy;
  wire [3:0] phase;
  wire [31:0] cycles;
  integer requests=0, calculations=0;
  mx_global_ctrl_1017 #(.MC_COUNT(2),.TILE_ROWS(1),.PE_PER_TILE(2),.BLOCKS(2)) dut(
    .clk(clk),.rst_n(rst_n),.i_start(start),.i_metadata_valid(1'b1),
    .i_all_mc_ready(1'b1),.i_all_phy_valid(1'b1),.i_gsram_rvalid(1'b1),
    .i_channel_data_move_en(2'b11),.i_reduce_valid(1'b1),
    .o_weight_req(wreq),.o_calc_en(calc),.o_phase(phase),.o_done(done),
    .o_busy(busy),.o_cycle_count(cycles));
  always @(posedge clk) if(rst_n) begin
    if(wreq) requests=requests+1;
    if(calc) calculations=calculations+1;
  end
  initial begin
    repeat(3) @(negedge clk); rst_n=1;
    @(negedge clk);start=1;@(negedge clk);start=0;
    wait(done); #1;
    $display("AUDIT first command: requests=%0d calc_phases=%0d cycles=%0d",requests,calculations,cycles);
    // DONE advertises busy=0. A one-cycle start here is a legal earliest retry
    // under the current documented busy/start interface, but is discarded.
    @(negedge clk);
    if(busy) $fatal(1,"audit setup expected !busy in DONE");
    start=1;
    @(negedge clk); start=0;
    repeat(4) @(negedge clk);
    if(phase==0 && requests==2)
      $fatal(1,"AUDIT BUG: start while !busy in DONE was discarded");
    $display("PASS: earliest idle start accepted"); $finish;
  end
  initial begin #100000; $fatal(1,"audit control timeout"); end
endmodule
