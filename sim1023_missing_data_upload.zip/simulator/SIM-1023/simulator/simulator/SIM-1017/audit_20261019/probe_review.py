"""Read-only review probes. Synthetic prices are NOT physical measurements.

Run from the simulator directory: python -B audit_20261019/probe_review.py
The microcode interpreter checks algorithms only, not Verilog scheduling, DW
equivalence, cycle counts or power. RTL equations below are transcriptions,
not results from an HDL simulator. Submitted sources are never modified.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SUBMISSION = ROOT.parents[2]
RTL = SUBMISSION / "RTL/RTL/RTL_1017SIM"
OUT = Path(__file__).resolve().parent

from tests.hardware_fixture import synthetic_dataset, synthetic_prices
from yrr_v3 import V3Config, SimulatorSession, run_v3
from yrr_v3.llm.schedule import SimContext
from yrr_v3.llm.config import LlmConfig, ModelOverride
from yrr_v3.llm.inference import run_llm


def microcode_checks():
    """Execute the submitted instruction TABLE with independent FP32 math."""
    table = (RTL / "rtl/nonmac_microcode.vh").read_text(encoding="utf-8")
    pattern = (r"9'd(\d+): begin inst_op=5'd(\d+); rd=4'd(\d+); "
               r"ra=4'd(\d+); rb=4'd(\d+); rc=4'd(\d+); imm=32'h([0-9a-fA-F]+);")
    instructions = {int(pc): (int(op), int(rd), int(ra), int(rb), int(rc), int(imm, 16))
                    for pc, op, rd, ra, rb, rc, imm in re.findall(pattern, table)}
    entries = {int(op): int(pc) for op, pc in
               re.findall(r"5'd(\d+): entry=9'd(\d+)", table)}
    assert len(instructions) == 217 and len(entries) == 23

    def bits(x):
        return int(np.asarray(x, dtype=np.float32).view(np.uint32))

    def fp(x):
        return np.asarray(x, dtype=np.uint32).view(np.float32).item()

    def execute(opcode, x, gamma=None, beta=None):
        n = len(x)
        mem = np.zeros(8192, dtype=np.float32)
        mem[:n] = x
        mem[2048:2048+n] = 1 if gamma is None else gamma
        mem[3072:3072+n] = 0 if beta is None else beta
        regs = np.zeros(16, dtype=np.float32)
        regs[11], regs[12], regs[15] = 1e-5, 1, n
        pc, idx, reads, writes = entries[opcode], 0, 0, 0
        for _ in range(100000):
            op, rd, ra, rb, rc, imm = instructions[pc]
            a, b, c = regs[ra], regs[rb], regs[rc]
            if op == 0:
                return mem[4096:4096+n].copy(), reads, writes
            addr = ((imm & 0x1c00) + (idx >> 1) + ((n >> 1) if imm & 1 else 0)
                    if opcode == 24 and op in (12, 13) else
                    imm + ((idx >> 1) if op == 17 else idx))
            if op in (12, 17):
                regs[rd] = mem[addr]
                reads += 1
            elif op == 13:
                mem[addr] = a
                writes += 1
            elif op == 14:
                idx = 0
            elif op == 15:
                idx += imm
            elif op == 16:
                pc = imm if idx < n else pc + 1
                continue
            elif op == 18:
                idx += rd
                pc = imm if idx < n else pc + 1
                continue
            else:
                with np.errstate(all="ignore"):
                    if op == 1: value = a + b
                    elif op == 2: value = a - b
                    elif op == 3: value = a * b
                    elif op == 4: value = a / b
                    elif op == 5: value = np.exp(a)
                    elif op == 6: value = np.sqrt(a)
                    elif op == 7:
                        ai, bi = bits(a), bits(b)
                        value = (b if ai >> 31 else a) if (ai >> 31) != (bi >> 31) else (
                            (a if ai < bi else b) if ai >> 31 else (a if ai > bi else b))
                    elif op == 8: value = a
                    elif op == 9: value = fp(bits(a) | 0x80000000)
                    elif op == 10: value = b if bits(a) >> 31 else c
                    elif op == 11: value = fp(imm)
                    else: raise AssertionError(op)
                regs[rd] = value
            pc += 1
        raise AssertionError("microcode did not terminate")

    rng = np.random.default_rng(19)
    checks = []
    for n in (1, 2, 8, 64, 1024):
        x = rng.normal(size=n).astype(np.float32)
        gamma = rng.uniform(.5, 1.5, size=n).astype(np.float32)
        beta = rng.normal(size=n).astype(np.float32)
        for op in (16, 17, 18):
            y, reads, writes = execute(op, x, gamma, beta)
            xd = x.astype(np.float64)
            if op == 16:
                ref = np.exp(xd-xd.max()); ref /= ref.sum()
                expected_counts = (3*n, 2*n)
            elif op == 17:
                ref = xd / np.sqrt(np.mean(xd*xd)+1e-5) * gamma
                expected_counts = (3*n, n)
            else:
                z = xd-xd.mean()
                ref = z / np.sqrt(np.mean(z*z)+1e-5) * gamma + beta
                expected_counts = (5*n, n)
            err = float(np.max(np.abs(y-ref)))
            assert (reads, writes) == expected_counts
            assert np.allclose(y, ref, rtol=2e-5, atol=2e-5)
            checks.append(dict(opcode=op, length=n, max_abs_error=err, reads=reads, writes=writes))
        if n % 2 == 0:
            co = np.full(n, .8, np.float32)
            si = np.full(n, .6, np.float32)
            y, reads, writes = execute(24, x, co, si)
            a, b = x[:n//2], x[n//2:]
            ref = np.concatenate((a*.8-b*.6, a*.6+b*.8))
            assert np.allclose(y, ref, rtol=2e-5, atol=2e-5)
            checks.append(dict(opcode=24, length=n, max_abs_error=float(np.max(np.abs(y-ref))),
                               reads=reads, writes=writes))
    return dict(scope="instruction-table/FP32 algorithm checks, NOT HDL or DW simulation", cases=checks)


def main():
    results = {"scope": "audit-only, synthetic parameter fixtures; no PPA measurements"}
    ds = synthetic_dataset()
    cfg = V3Config(enable_softmax=False, enable_mx_block_skip=False,
                   ideal_mem_die=False, mem_die_bytes_per_cycle=17)
    operands = dict(weight_payload=np.full((1024, 1024), 2, np.uint8),
                    weight_scale=np.full((1024, 32), 127, np.uint8),
                    input_payload=np.full((1, 1024), 2, np.uint8),
                    input_scale=np.full((1, 32), 127, np.uint8))
    session = SimulatorSession()
    cold = run_v3(cfg, dataset=ds, session=session, **operands)
    warm = run_v3(cfg, dataset=ds, session=session, **operands)
    # Exact transcription for the special all-ones vector from mx_pe/reduce:
    # fp4_int(2)=2; product int=4; E3=0; M10=4<<6=256.
    rtl_pe_m = 32 * 256
    rtl_total_m = 32 * rtl_pe_m
    rtl_value = np.ldexp(float(rtl_total_m), -8)
    results["finite_width_mismatch"] = dict(
        operand="W=X=1, FP4 code=2, E8M0=127, M=K=1024",
        fp64_reference=float(cold.logits_reference[0, 0]),
        python_logit=float(cold.logits_hardware[0, 0]),
        python_saturations=cold.report["finite_width"]["saturation_count"],
        rtl_equation_logit=float(rtl_value),
        evidence_scope="Python executed; RTL value calculated from submitted equations, NOT HDL simulated")
    results["schedule_and_weight_requests"] = dict(
        python_cold_requests=sum(d["read_requests"] for d in cold.report["mem_dies"]),
        python_warm_requests=sum(d["read_requests"] for d in warm.report["mem_dies"]),
        rtl_requests_per_start_from_loop=1024*32,
        python_array_events=[dict(start=e.start_cycle, end=e.end_cycle, **e.metadata)
                             for e in cold.trace if e.operation == "array_mac"],
        rtl_calc_columns_per_matrix=32,
        rtl_peak_simultaneous_pe=32*32,
        rtl_peak_simultaneous_mac=32*32*32)

    small = run_v3(V3Config(m=32, k=32), dataset=ds)
    nonmac_busy = sum(e.end_cycle-e.start_cycle for e in small.trace if e.resource == "FP32 non-MAC")
    results["softmax_utilization"] = dict(reported=small.report["cycles"]["softmax_utilization"],
        nonmac_reserved_cycles=nonmac_busy, total_cycles=small.report["cycles"]["critical_path"],
        fraction_for_reserved_nonmac=nonmac_busy/small.report["cycles"]["critical_path"])
    no_soft = run_v3(V3Config(m=32, k=32, batch=3, enable_softmax=False), dataset=ds)
    arrays = [(e.metadata["vector_id"], e.start_cycle, e.end_cycle)
              for e in no_soft.trace if e.operation == "array_mac"]
    logits = [(e.metadata["vector_id"], e.start_cycle, e.end_cycle)
              for e in no_soft.trace if e.operation == "logits_write"]
    results["matrix_serialization_without_softmax"] = dict(
        vector_starts=no_soft.report["cycles"]["vector_start_cycles"],
        array_events=arrays, logits_write_events=logits)

    # Reproduce the actual numerical attention helper path with a future value.
    ctx = SimContext.__new__(SimContext)
    ctx.forward, ctx.pos = "numeric", 0
    q = np.ones((2, 1), np.float32)
    k = np.array([[0.0], [10.0]], np.float32)
    score = ctx._scores(q, k, 2, 1.0)
    probability = ctx._sm(score)
    future_v = np.array([[0.0], [1.0]], np.float32)
    attn = ctx._pvo(probability, future_v, 1)
    results["prefill_causality"] = dict(score=score.tolist(), probabilities=probability.tolist(),
        first_token_attention_output=float(attn[0, 0]), causal_expected=0.0,
        scope="run_llm SimContext helpers; independent HF run_ppl uses its own causal model")
    ctx.kv = np.tile(np.arange(4, dtype=np.float32).reshape(1, 1, 1, 4, 1), (1, 2, 1, 1, 1))
    results["sliding_window_kv"] = dict(total_context=4, window=2,
        actual=ctx._kv_view(0, 0, 0, 2).ravel().tolist(), expected=[2.0, 3.0],
        scope="schedule._attention passes ctx_eff to _kv_view, which always slices from position zero")

    repeated = []
    for count in (1, 2):
        r = run_llm(LlmConfig(prompt_tokens=2, max_new_tokens=3, n_runs=count,
            model=ModelOverride(hidden=32, layers=1, heads=1, kv_heads=1,
                                head_dim=32, intermediate=32, vocab=512)), prices=synthetic_prices())
        marks = r.report["throughput"]["segment_marks"]
        repeated.append(dict(n_runs=count, reported_gen_tokens=r.report["throughput"]["gen_tokens"],
            actual_generated_across_runs=count*len(r.generated_ids),
            e2e_cycles=sum(m["ttft"]["cycles_by_cores"]["1"] + m["decode"]["cycles_by_cores"]["1"] for m in marks),
            clock_free=r.report["throughput"]["clock_free"]["1"]))
    results["repeated_run_metrics"] = repeated

    # Metadata manifest shipped in this submission still describes an old tree.
    manifest = json.loads((ROOT / "PACKAGE_SOURCE.json").read_text(encoding="utf-8"))
    missing, changed = [], []
    for relative, expected in manifest["source_files_sha256"].items():
        p = ROOT / relative
        if not p.is_file(): missing.append(relative)
        elif hashlib.sha256(p.read_bytes()).hexdigest() != expected: changed.append(relative)
    results["shipped_source_manifest"] = dict(date=manifest["date"], missing=missing, changed=changed)
    results["nonmac_microcode"] = microcode_checks()
    source_hashes = {}
    for tree in (ROOT / "yrr_v3", ROOT / "tests", RTL / "rtl", RTL / "tb", RTL / "synopsys"):
        for p in sorted(tree.rglob("*")):
            if p.is_file() and p.suffix in (".py", ".v", ".sv", ".vh", ".tcl"):
                source_hashes[p.relative_to(SUBMISSION).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    for p in (ROOT/"run.py", ROOT/"run_llm.py", ROOT/"run_ppl.py", ROOT/"yrr_v3/rtl_dataset.py"):
        source_hashes[p.relative_to(SUBMISSION).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    (OUT/"source_inventory.json").write_text(json.dumps(source_hashes, indent=2), encoding="utf-8")
    (OUT / "probe_results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    for name, value in results.items():
        print(name, json.dumps(value, ensure_ascii=False))
    for script in ("run.py", "validate_parameters.py"):
        run = subprocess.run([sys.executable, "-B", str(ROOT/script)], cwd=ROOT,
                             capture_output=True, encoding="utf-8", errors="replace")
        (OUT/(script.replace(".py", "")+"_pending.log")).write_text(run.stdout+run.stderr, encoding="utf-8")
        assert run.returncode != 0 and "PENDING" in run.stderr


if __name__ == "__main__":
    main()
