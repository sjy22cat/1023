# 历史示例结果

这些 JSON/日志来自此前软件和占位参数，仅保留追溯用途，不是当前 Synopsys measured 数据。请按 [README_SIM-1017.md](../../README_SIM-1017.md) 准备实测参数后重新生成报告，勿从本目录复制价格或性能数字。
