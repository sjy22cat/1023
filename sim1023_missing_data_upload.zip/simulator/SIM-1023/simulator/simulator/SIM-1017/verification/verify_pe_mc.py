"""Reproducible full-array behavior/activity checks with local component data."""
from pathlib import Path
import json
import sys
import time
import tracemalloc
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from yrr_v3 import V3Config,V3Datasheet,run_v3


def main():
    runs=[]
    tracemalloc.start()
    for batch in (1,2,8,32):
        tracemalloc.reset_peak()
        start=time.perf_counter()
        r=run_v3(V3Config(batch=batch,enable_softmax=False),dataset=V3Datasheet.from_component_json())
        a,mc=r.report['architecture'],r.report['rram_mc']
        assert (a['tiles'],a['total_pe'],mc['controllers'])==(1024,32768,32768)
        assert mc['read_requests']==batch*32768
        assert mc['physical_read_bits']==batch*32768*128
        assert r.report['errors']['max_abs']==0
        entry=dict(batch=batch,seconds=time.perf_counter()-start,
            tracemalloc_peak_bytes=tracemalloc.get_traced_memory()[1],
            tiles=a['tiles'],pe=a['total_pe'],mc=mc['controllers'],
            read_requests=mc['read_requests'],physical_read_bits=mc['physical_read_bits'],
            max_abs_error=r.report['errors']['max_abs'],saturations=r.report['finite_width']['saturation_count'])
        runs.append(entry)
        print(entry,flush=True)
        if batch==1:
            (ROOT/'verification/mc_fullscale_report_20261019.json').write_text(
                json.dumps(r.report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
            r.export_rram_mc_control(ROOT/'verification/mc_fullscale_control_20261019.npz')
        del r
    (ROOT/'verification/mc_fullscale_validation_20261019.json').write_text(
        json.dumps(dict(measurement='Python wall time and tracemalloc peak; not hardware timing',runs=runs),indent=2),encoding='utf-8')


if __name__=='__main__':
    main()
