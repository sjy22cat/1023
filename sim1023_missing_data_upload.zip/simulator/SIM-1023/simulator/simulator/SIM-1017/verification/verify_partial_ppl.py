"""Torch Linear finite adapter smoke, not a pretrained-model perplexity result."""
from pathlib import Path
import sys
import json
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from yrr_v3.llm.ppl import LinearQuantization
from yrr_v3.characterization import default_component_path

torch.manual_seed(17)
layer=torch.nn.Linear(64,32,bias=False).eval()
x=torch.randn(2,64)
original=layer.forward
with LinearQuantization(layer,'dense_mxfp4'):
    expected=layer(x).detach().numpy()
with LinearQuantization(layer,'finite_mxfp4',parameters=default_component_path()) as adapter:
    actual=layer(x).detach().numpy()
    stats=dict(adapter.stats)
assert np.allclose(expected,actual,rtol=0,atol=1e-6)
assert stats['rram_mc_reads']==128
assert layer.forward==original
record=dict(scope='synthetic Torch Linear adapter only; no pretrained model PPL claimed',
    max_abs_vs_dense_mxfp4=float(np.max(np.abs(expected-actual))),activity=stats)
(ROOT/'verification/mc_ppl_adapter_20261019.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(record)
