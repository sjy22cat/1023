"""Full-scale accelerator boundary checks; no measured non-MAC values invented."""
from dataclasses import replace
from pathlib import Path
import json
import sys
import time
import tracemalloc

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from yrr_v3 import V3Config, V3Datasheet, run_v3, format_report


def main():
    ds = V3Datasheet.from_component_json()
    runs = []
    tracemalloc.start()
    for batch in (1, 2, 8, 32):
        tracemalloc.reset_peak()
        start = time.perf_counter()
        result = run_v3(V3Config(batch=batch), dataset=ds)
        r = result.report
        assert result.softmax_output.shape == (batch,1024)
        assert r["errors"]["max_abs"] == 0
        np.testing.assert_allclose(result.softmax_output.sum(axis=1), 1, rtol=1e-6)
        assert r["rram_mc"]["read_requests"] == batch*32768
        assert r["nonmac"]["parallel_lanes"] == 1024
        assert r["energy"]["softmax_pj"] is None
        assert not r["evaluation_scope"]["host_included"]
        assert not r["evaluation_scope"]["dma_included"]
        assert r["capacity"]["dma_staging_bytes"] == 0
        assert not any("dma" in e.resource.lower() or "host" in e.resource.lower() for e in result.trace)
        runs.append(dict(batch=batch, seconds=time.perf_counter()-start,
            python_tracemalloc_peak_bytes=tracemalloc.get_traced_memory()[1],
            max_abs_error=r["errors"]["max_abs"], softmax_max_abs_error=r["errors"]["softmax_max_abs"],
            micro_batch=r["capacity"]["micro_batch"], allocated_global_sram_bytes=r["capacity"]["allocated_global_sram_bytes"],
            read_requests=r["rram_mc"]["read_requests"]))
        print(runs[-1], flush=True)
        if batch == 1:
            (ROOT/"verification/accelerator_scope_fullscale_report_20261019.json").write_text(
                json.dumps(r,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
            (ROOT/"verification/accelerator_scope_fullscale_report_20261019.txt").write_text(format_report(result),encoding="utf-8")
            # TEST ONLY unit prices verify multiplication/parallel latency.
            unit = json.loads(json.dumps(ds.nonmac_parallel))
            unit.update(status="USER_SUPPLIED", source="TEST_ONLY scaling validation; not hardware data", unit_area_um2=3)
            unit["operations"]["softmax"].update(unit_dynamic_pj=2.5,latency_cycles=7)
            synthetic = run_v3(V3Config(batch=1),dataset=replace(ds,nonmac_parallel=unit))
            assert synthetic.report["energy"]["softmax_pj"] == 2560
            assert synthetic.report["cycles"]["softmax"] == 7
            assert synthetic.report["area"]["components"]["nonmac_parallel_1024"]["total_um2"] == 3072
            assert np.array_equal(result.softmax_output,synthetic.softmax_output)
            assert np.array_equal(result.logits_hardware,synthetic.logits_hardware)
            del synthetic
        del result
    tracemalloc.stop()
    (ROOT/"verification/accelerator_scope_fullscale_validation_20261019.json").write_text(json.dumps(
        dict(scope="Full-scale functional/activity and cost-scaling validation; Python wall time/memory are not hardware performance",
             real_nonmac_characterization="PENDING", synthetic_cost_check="TEST_ONLY unit 2.5pJ, 3um2, latency7; vector 2560pJ, 3072um2, latency7",
             runs=runs),indent=2,allow_nan=False),encoding="utf-8")


if __name__ == "__main__":
    main()
