"""Offline causal perplexity. No model/data download is performed."""
import argparse
import json
from pathlib import Path
from yrr_v3.llm.ppl import run_local_benchmark
from yrr_v3 import default_1017_measured_path
from yrr_v3.characterization import default_component_path


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--checkpoint",required=True)
    p.add_argument("--text",required=True,help="held-out UTF-8 text, e.g. WikiText-2 test split")
    p.add_argument("--modes",nargs="+",default=["fp32","dense_mxfp4","finite_mxfp4"])
    p.add_argument("--context",type=int,default=2048)
    p.add_argument("--stride",type=int,default=512)
    p.add_argument("--max-tokens",type=int)
    p.add_argument("--parameters", "--rtl-1017-calibration", dest="parameters",
                   default=str(default_component_path()),
                   help="finite_mxfp4 hardware inputs, including partial width and scale-skip threshold")
    p.add_argument("--no-tag-skip",action="store_true",
                   help="disable TAG-FP zero-value PE gating in finite_mxfp4")
    p.add_argument("--no-block-skip",action="store_true",
                   help="disable pre-PE MX scale-only block gating in finite_mxfp4")
    p.add_argument("--device",default="cpu")
    p.add_argument("--json",required=True)
    a=p.parse_args()
    try:
        r=run_local_benchmark(a.checkpoint,a.text,modes=a.modes,context=a.context,stride=a.stride,
                          max_tokens=a.max_tokens,device=a.device,parameters=a.parameters,
                          enable_tag_skip=not a.no_tag_skip,
                          enable_mx_block_skip=not a.no_block_skip)
    except (OSError, ValueError, TypeError) as exc:
        p.error(str(exc))
    Path(a.json).write_text(json.dumps(r,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    for name,mode in r["modes"].items():
        delta=mode.get("comparison_to_fp32",{}).get("delta_perplexity")
        comparison="" if delta is None else f", delta_vs_fp32={delta:+.6g}"
        print(f"{name}: PPL={mode['perplexity']}, scored_tokens={mode['valid_token_count']}{comparison}")


if __name__=="__main__":
    main()
