"""Validate externally collected Synopsys results without running inference."""
import argparse
from yrr_v3.rtl_dataset import (default_1017_measured_path, load_1017_calibration,
    STRUCTURE_FIELDS, CONFIG_FIELDS, TIMING_CONFIG, ENERGY_FIELDS, AREA_FIELDS)
from yrr_v3.characterization import default_component_path, SCHEMA as COMPONENT_SCHEMA, read_components
import json
from pathlib import Path
from yrr_v3.config import HOST_DMA_CONFIG_FIELDS, HOST_DMA_ENERGY_FIELDS
from yrr_v3.parallel_nonmac import load_parallel


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parameters", default=str(default_component_path()))
    parser.add_argument("--list-required", action="store_true")
    parser.add_argument("--nonmac-parameters", help="optional 1024-lane non-MAC unit-cost JSON")
    args = parser.parse_args()
    if args.list_required:
        from yrr_v3.llm.config import LlmPrices
        groups = dict(structure=STRUCTURE_FIELDS, config_overrides=CONFIG_FIELDS-HOST_DMA_CONFIG_FIELDS,
            timing=set(TIMING_CONFIG.values())-{"host_dma_setup_cycles"}, energy=ENERGY_FIELDS-HOST_DMA_ENERGY_FIELDS,
            area=set(AREA_FIELDS)-{"dma_mm2"},
            llm_hardware={"mem_die_bytes", "mem_die_count", "rram_capacity_bytes", "feram_capacity_bytes"},
            provenance={"rtl_revision", "tool_versions", "pvt", "clock_constraint", "activity_window", "reports", "energy_scope"},
            llm_prices=set(LlmPrices.__dataclass_fields__) - {"provenance", "f_max_mhz", "block_pj_by_mac", "nonmac"})
        for section, names in groups.items():
            print(section + ": " + ", ".join(sorted(names)))
        print("nonmac: implementation, max_vector_length, clock_ns, scope, rtl_revision, dw_version, scratch_implementation, activity_policy, reports, profiles.<op>.<length>, reduce_staging.<length> (cycles/dynamic_pj/read_count/write_count/report)")
        print("Also required: structure.mc_count=32768; mc_mapping=mc_id=tile_id*pe_per_tile+pe_id. External channels are independent.")
        print("Host/DMA are excluded; their legacy fields are optional. Current component path uses parallel non-MAC unit*1024 estimates.")
        return
    try:
        raw=json.loads(Path(args.parameters).read_text(encoding="utf-8-sig"))
        if raw.get("schema")==COMPONENT_SCHEMA:
            raw=read_components(args.parameters)
            print("Validated PARTIAL component file; this does not certify complete timing/energy.")
            print("PHY unit: "+str(raw['phy_energy_unit']))
            print("Missing: "+"; ".join(raw['missing']))
            nonmac = load_parallel(args.nonmac_parameters)
            print("Non-MAC: 1024 parallel FP32 lanes; unit*1024 area/energy estimate, per-vector latency.")
            print("Non-MAC source: "+nonmac['source'])
            print("Host/DMA/provisioning costs and DMA buffer capacity: excluded.")
            return
        load_1017_calibration(args.parameters)
        if args.nonmac_parameters:
            load_parallel(args.nonmac_parameters)
    except (OSError, ValueError, TypeError) as exc:
        parser.error(str(exc))
    print("Validated Synopsys parameter contract: " + str(args.parameters))
    print("Numeric/schema checks passed. Source-report authenticity and RTL equivalence require engineering review.")


if __name__ == "__main__":
    main()
