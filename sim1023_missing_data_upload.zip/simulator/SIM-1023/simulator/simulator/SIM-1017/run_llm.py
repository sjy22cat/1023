#!/usr/bin/env python3
"""SIM-1017 的 Qwen3-0.6B 完整推理模型 —— 命令行入口。

把 logic die 上的近存加速器当作**一个 core**，容量从 measured JSON 读取，两者用
PHY + Hybrid Bonding 互连，跑 Qwen3-0.6B 的**完整推理**（prompt → 生成 token → 文本），
权重与激活都走 MXFP4（**W4A4**）。

当前 LLM 使用单 core 串行聚合账本；MC 并行协议不在此入口逐拍重放。

    python run_llm.py                          # 本次口径：128 → 1024，1 次推理
    python run_llm.py --smoke                  # 秒级冒烟：8 → 4，1 层小模型
    python run_llm.py --prompt "你好" --max-new-tokens 16
    python run_llm.py --billing unit           # 换成对照计费口径
    python run_llm.py --weights D:/qwen3-0.6b  # 用真实 safetensors（纯 numpy 解析）
    # measured 参数统一从 calibration/rtl_1017sim/rtl_1017sim_measured.json 读取

报告里有两段新评估：**吞吐率（token/s）** 与 **能量效率（J/token）**，各给 TTFT / decode /
端到端三个粒度。它们只读取统一 Synopsys measured JSON ——
缺数据时在加载阶段拒绝运行，不拿 RTL 或 Python 估算值凑数。新思数据到手后更新
`calibration/rtl_1017sim/rtl_1017sim_measured.json` 即可。

功能边界、报告字段与参数方法见 README_SIM-1017.md。
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from yrr_v3 import default_1017_measured_path                         # noqa: E402
from yrr_v3.llm import (LlmConfig, ModelOverride, format_report,  # noqa: E402
                        run_llm, setup_console, write_json)
from yrr_v3.llm.arch import resolve_model, zoo_entry                      # noqa: E402
from yrr_v3.llm.capacity import CapacityError                            # noqa: E402
from yrr_v3.llm.compare import as_json as compare_json                   # noqa: E402
from yrr_v3.llm.compare import compare as compare_models                 # noqa: E402
from yrr_v3.llm.report import format_compare                             # noqa: E402
from yrr_v3.llm.config import bind_hardware_config                       # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="YRR SIM-1017 near-memory accelerator — Qwen3-0.6B full inference (1 core, MXFP4 W4A4)")
    # ---- 规模 ----
    ap.add_argument("--cores", type=int, default=1, metavar="N",
                    help="compute core 数。**默认 1（本次口径）：全串行**；"
                         ">1 只在报告的 cores 对照列里体现摊薄，不作为调度依据")
    ap.add_argument("--prompt-tokens", type=int, default=128, metavar="S",
                    help="上下文输入 token 数。默认 128")
    ap.add_argument("--max-new-tokens", type=int, default=1024, metavar="T",
                    help="输出 token 数。默认 1024")
    ap.add_argument("--n-runs", type=int, default=1, metavar="N",
                    help="推理次数。默认 1")
    # ---- 计费 ----
    ap.add_argument("--billing", choices=("whole_block", "unit"), default="whole_block",
                    help="计费口径。**默认 whole_block（本次口径）**：不足 1024x1024 的块"
                         "也按一整块 [1024,1024]x[1024,1024] 的乘加开销计。"
                         "unit = 按实际 MAC 数计的对照口径。报告里两者始终并列")
    # ---- 新思（Synopsys）单价投放口 ----
    ap.add_argument("--rtl-1017-calibration", "--parameters", metavar="PATH",
                    default=str(default_1017_measured_path()),
                    help="Synopsys measured JSON（默认 calibration/rtl_1017sim/rtl_1017sim_measured.json）")
    ap.add_argument("--no-act-quant", action="store_true",
                    help="**不做激活量化**（退化成 W4A16 对照）：此时每个算子边界都不再过 "
                         "MXFP4 往返，只剩权重是 4 bit。默认关（= W4A4，本次口径）")
    ap.add_argument("--attention-impl", choices=("unfused", "fused_16x4"), default="unfused",
                    help="Legacy pair-serial or 16 context rows x 4 dimension columns/head")
    ap.add_argument("--attention-calibration", metavar="PATH", default=None,
                    help="Independent measured fused Attention JSON; preserves --parameters")
    ap.add_argument("--kv-shadow", choices=("fp32", "codebook", "none"), default="fp32",
                    help="Host KV shadow; none is available for --forward shape")
    # ---- 权重与分词 ----
    ap.add_argument("--weights", metavar="DIR", default=None,
                    help="真实 Qwen3 checkpoint 目录（*.safetensors，纯 numpy 解析）。"
                         "默认在模拟器内按 Qwen3 初始化尺度生成（带种子可复现）")
    ap.add_argument("--weight-cache", choices=("full", "none"), default="full",
                    help="full（默认）= fp32 数值影子常驻（~2.4 GB，快）；"
                         "none = 每次现场反量化（省内存、慢很多）")
    ap.add_argument("--seed", type=int, default=1, help="生成权重的种子。默认 1")
    ap.add_argument("--tokenizer", metavar="DIR", default=None,
                    help="真实 Qwen 分词器目录（vocab.json + merges.txt）。"
                         "默认用可逆的占位分词器（UTF-8 字节 + 偏移）")
    # ---- 采样 ----
    ap.add_argument("--prompt", default=None,
                    help="输入 prompt 文本。默认一段中文说明文字")
    ap.add_argument("--temperature", type=float, default=0.0,
                    help="采样温度。**默认 0 = 贪心**（可复现）")
    ap.add_argument("--sample-seed", type=int, default=0, help="温度采样时的种子")
    # ---- 模型与架构族（0.6B–20B，受「权重 + KV 装得下」约束）----
    ap.add_argument("--model", metavar="REF", default=None,
                    help="跑哪个模型：config.json 路径 | 目录 | 动物园名（--list-models）"
                         " | json:{...} | HF repo id（需 huggingface_hub，本机没有时会"
                         "**干净报错并指名缺哪个包**，绝不静默换模型）")
    ap.add_argument("--family", metavar="NAME", default=None,
                    help="覆盖族探测（只在读原始 config.json 时有意义；动物园条目自带族名，"
                         "再给 --family 会被拒）")
    ap.add_argument("--forward", choices=("auto", "numeric", "shape"), default="auto",
                    help="前向模式。auto（默认）= 按模型规模与 prompt 长度自动判："
                         "Qwen3-0.6B 判到 numeric（今天的行为逐位不变），"
                         "1.7B 以上判到 shape。shape = 只走形状与计费、数值一律跳过 —— "
                         "**账目是形状的纯函数**，故账目逐字段与 numeric 相同（自检钉住），"
                         "只是快得多")
    ap.add_argument("--max-ctx", type=int, default=None, metavar="N",
                    help="上下文总长（prompt + 生成）。装不下就出明细并拒绝（exit 2）；"
                         "实际上界 = min(die 装得下的最大 ctx, 模型声明的位置数)")
    ap.add_argument("--moe-routing", metavar="PATH", default=None,
                    help="MoE 路由直方图投放口（JSON）。默认均匀路由（每个专家都被计费，"
                         "是权重访存的**最坏情形**）。第三段生效")
    ap.add_argument("--list-models", action="store_true",
                    help="打印模型动物园（名字、族、形状、参数量、@本次 ctx 是否装得下）后退出")
    ap.add_argument("--compare", metavar="REF[,REF..]", default=None,
                    help="一次跑多个模型（逗号分隔，取值同 --model），并排出对照表 + "
                         "对照 JSON。**每一行都走同一个 run_llm**，故与单独跑逐字段一致")
    # ---- 输出 ----
    ap.add_argument("--json", metavar="PATH", default=None,
                    help="把完整 report 写成 JSON")
    ap.add_argument("--trace", metavar="PATH", default=None,
                    help="把聚合后的 op trace 写成 JSON")
    ap.add_argument("--trace-limit", type=int, default=4096, metavar="N",
                    help="trace 行数上限（超出则把尾部合并成一行）。默认 4096")
    ap.add_argument("--quiet", action="store_true", help="只打印最终结果，不打印完整报告")
    # ---- 冒烟 ----
    ap.add_argument("--smoke", action="store_true",
                    help="秒级冒烟：S=8、T=4、1 层、hidden=128 的小模型（走同一条代码路径）")
    return ap


def config_from_args(args: argparse.Namespace) -> LlmConfig:
    if args.smoke:
        model = ModelOverride(hidden=128, layers=1, heads=4, kv_heads=2,
                              head_dim=32, intermediate=256, vocab=512)
        prompt_tokens, max_new = 8, 4
    else:
        model = None
        prompt_tokens, max_new = args.prompt_tokens, args.max_new_tokens
    if args.max_ctx is not None:
        if args.max_ctx <= prompt_tokens:
            raise SystemExit(f"--max-ctx {args.max_ctx} 必须大于 prompt "
                             f"{prompt_tokens}（max-ctx = prompt + 生成）")
        max_new = args.max_ctx - prompt_tokens
    spec = None
    if args.model:
        if args.smoke:
            raise SystemExit("--model 与 --smoke 不能同时给：--smoke 是手搭的小模型覆盖，"
                             "--model 是完整的形状与族")
        spec = resolve_model(args.model, args.family)
    return LlmConfig(
        cores=max(1, args.cores),
        prompt_tokens=prompt_tokens,
        max_new_tokens=max_new,
        n_runs=max(1, args.n_runs),
        billing=args.billing,
        rtl_1017_calibration_path=args.rtl_1017_calibration,
        attention_impl=args.attention_impl,
        attention_calibration_path=args.attention_calibration,
        kv_shadow=args.kv_shadow,
        quantize_activations=not args.no_act_quant,
        weights=args.weights,
        weight_cache=args.weight_cache,
        seed=args.seed,
        temperature=args.temperature,
        sample_seed=args.sample_seed,
        tokenizer=args.tokenizer,
        trace_limit=args.trace_limit,
        forward=args.forward,
        model_spec=spec,
        moe_routing=args.moe_routing,
        model=model,
    )


def list_models(cfg: LlmConfig) -> None:
    """打印模型动物园，并**现场算一次容量门**（装不装得下由当前 ctx 决定，不是写死的）。"""
    from yrr_v3.llm import capacity
    from yrr_v3.llm.arch import zoo_names

    print("以下容量为设计默认值的参考，未读取实测参数；正式推理会重新检查容量。")
    print(f"模型动物园（--model 取这些名字即可；容量按本次 ctx = "
          f"{cfg.prompt_tokens} + {cfg.max_new_tokens} 与 "
          f"{cfg.mem_die_bytes / (1 << 30):g} GiB die 现算）")
    print(f"  {'名字':22s} {'族':12s} {'L':>3s} {'H':>5s} {'V':>7s} "
          f"{'参数 M':>8s} {'权重':>9s} {'摆放':>9s} {'占用%':>7s} {'装得下':>7s}")
    for n in zoo_names():
        spec = zoo_entry(n)
        b = capacity.budget(spec, cfg)
        print(f"  {n:22s} {spec.family:12s} {spec.layers:3d} {spec.hidden:5d} "
              f"{spec.vocab:7d} {b.params_elements / 1e6:8,.0f} "
              f"{b.weights_bytes / (1 << 30):8.2f}G {b.total_bytes / (1 << 30):8.2f}G "
              f"{b.used_pct:6.2f}% {'是' if b.fits else '**否**':>7s}"
              + ("" if b.fits else f"  卡在 {b.limited_by}"))
    print("\n  MXFP4 = 0.53125 B/参数（0.5 payload + 1/32 E8M0 尺度）。"
          "是否装得下同时取决于共享总容量、RRAM 权重/激活容量与 FeRAM Q/KV 容量；"
          "未配置的单池上限标为待补（见报告 [3a]/[17]）。")


def main() -> None:  # noqa: C901
    setup_console()
    parser = build_parser()
    args = parser.parse_args()
    cfg = config_from_args(args)
    cfg.validate()

    if args.list_models:
        list_models(cfg)
        return

    try:
        cfg = bind_hardware_config(cfg)
    except (OSError, ValueError, TypeError) as exc:
        parser.error(str(exc))

    if args.compare:
        run_compare(args, cfg)
        return

    t0 = time.time()
    print(f"[run_llm] cores={cfg.cores}  MEM die={cfg.mem_die_bytes / (1 << 30):g} GiB"
          f"  prompt={cfg.prompt_tokens} -> new={cfg.max_new_tokens}"
          f"  n_runs={cfg.n_runs}  billing={cfg.billing}"
          f"  {'W4A4' if cfg.quantize_activations else 'W4A16'}"
          f"  model={args.model or ('--smoke 小模型' if args.smoke else 'Qwen3-0.6B（默认）')}"
          f"  forward={args.forward}"
          f"  weights={'safetensors' if cfg.weights else f'generated(seed={cfg.seed})'}",
          flush=True)
    print("[run_llm] 建模型与权重…", flush=True)

    def progress(msg: str) -> None:
        print(f"[run_llm]{msg}", flush=True)

    try:
        result = run_llm(cfg, prompt=args.prompt, progress=progress,
                         verbose=not args.quiet)
    except CapacityError as e:
        # 只捕容量门：打印明细（含「顶不住的是哪一项」「最大能到多少」）后 exit(2)。
        # 其余异常一律照抛 —— 对照表宁可断，不可错。
        print(f"\n[run_llm] 装不下，已拒绝（未分配任何数组）：\n{e}", flush=True)
        if args.json:
            Path(args.json).write_text(json.dumps(
                {"status": "OVER_CAPACITY", "capacity_budget": e.budget.as_dict()},
                indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"明细 -> {args.json}")
        sys.exit(2)
    rep = result.report

    print()
    if args.quiet:
        en, la = rep["energy"], rep["latency"]
        th, ef = rep.get("throughput"), rep.get("efficiency")
        print(f"生成 {len(result.generated_ids)} 个 token")
        print(f"  generated_ids[:32] = {result.generated_ids[:32]}")
        print(f"  text = {result.generated_text[:200]!r}")
        print(f"  能耗（整块口径） = {en['total_whole_block_pj']:,.0f} pJ"
              f"    （unit 口径 {en['total_unit_pj']:,.0f} pJ）")
        print(f"  时间（1 core 串行） = {la['cycles_serial_1core']:,.0f} 拍"
              f" = {la['ns_serial_1core']:,.0f} ns")
        # 新思标定参数缺失时，吞吐率与能量效率会报告缺口（见 README_LLM.md）
        if th is not None and ef is not None:
            pv = rep["provenance"]
            one = (th["per_core"] or {}).get("1")
            tps = "（缺新思数据）" if one is None else f"1 core 端到端 {one['e2e_tok_s']:.4g}"
            jt = ef["by_billing"][ef["billing"]]["per_token_j"]
            jts = "（缺新思数据）" if jt is None else f"{ef['billing']} 口径端到端 {jt['e2e']:.4g}"
            print(f"  吞吐率 token/s      = {tps}")
            print(f"  能量效率 J/token    = {jts}")
            print(f"  单价来源门          = {pv['status']}"
                  f"（需要 {pv['n_required']} 项，缺 {pv['n_missing']} 项；"
                  f"投放口 {pv['calib_file']}）")
    else:
        print(format_report(rep))

    if args.json:
        write_json(result, args.json)
        print(f"report -> {args.json}")
    if args.trace:
        Path(args.trace).write_text(
            json.dumps(rep["trace"], indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"trace  -> {args.trace}（{len(rep['trace'])} 行）")
    print(f"[run_llm] 墙钟 {time.time() - t0:.1f} s", flush=True)


def run_compare(args: argparse.Namespace, cfg: LlmConfig) -> None:
    """`--compare`：一次跑多个模型。

    规模（prompt / 生成 / 计费 / die）在所有行上**完全相同**，逐行只换形状与族 ——
    否则并排的数字不可比。每行都由 `compare.rows_for` 调**同一个** `run_llm()`。
    """
    refs = [s.strip() for s in args.compare.split(",") if s.strip()]
    if not refs:
        raise SystemExit("--compare 至少要给一个模型引用")
    t0 = time.time()
    print(f"[compare] {len(refs)} 个模型，共同规模 prompt={cfg.prompt_tokens} → "
          f"生成 {cfg.max_new_tokens}，billing={cfg.billing}，"
          f"die={cfg.mem_die_bytes / (1 << 30):g} GiB", flush=True)

    def progress(msg: str) -> None:
        print(f"[compare]{msg}", flush=True)

    cmp = compare_models(refs, cfg, args.family, progress=progress)
    for line in format_compare(cmp):
        print(line)
    print(f"[compare] 墙钟 {time.time() - t0:.1f} s", flush=True)

    if args.json:
        payload = compare_json(cmp)
        Path(args.json).write_text(
            json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"对照 JSON -> {args.json}")


if __name__ == "__main__":
    main()
