"""Import user RTL measurements without turning missing costs into zeros."""
import argparse
import json
from pathlib import Path
from yrr_v3.characterization import import_workbook, default_component_path

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("workbook")
    ap.add_argument("--phy-unit", choices=("bit","128bit"), required=True)
    ap.add_argument("--output", default=str(default_component_path()))
    args = ap.parse_args()
    data = import_workbook(args.workbook,phy_unit=args.phy_unit)
    data["clarifications"] = {"phy":"User confirmed 1.56518495 pJ per 128 bit on 2026-10-19"} if args.phy_unit=="128bit" else {}
    Path(args.output).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(args.output)
