"""Result objects and the single SIM-1017 behavioral entry point."""
from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any
import numpy as np

from .config import V3Config
@dataclass
class TraceEvent:
    start_cycle: int
    end_cycle: int
    resource: str
    operation: str
    bytes: int = 0
    bits: int = 0
    tile_group: int = -1
    bank: int = -1
    die_id: int = -1
    batch_id: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MxControlTrace:
    max_exponent: int
    alignment_distance: list[int]
    valid_mask: list[bool]
    zero_mask: list[bool]
    data_move_en: bool
    calc_en: bool
    reduction_stage: int
    decision_source: str = "post-PE reduction arithmetic"
    esum: list[int] = field(default_factory=list)
    max_exponent_per_output: list[int] = field(default_factory=list)
    block_skip_mask: list[bool] = field(default_factory=list)
    compute_mask: list[bool] = field(default_factory=list)
    threshold_bits: int | None = None
    vector_id: int = 0


@dataclass
class V3Result:
    config: V3Config
    logits_reference: np.ndarray
    logits_hardware: np.ndarray
    softmax_output: np.ndarray | None
    weight_payload: np.ndarray
    weight_scale: np.ndarray
    input_payload: np.ndarray
    input_scale: np.ndarray
    tile_partials: np.ndarray
    mx_control: list[MxControlTrace]
    trace: list[TraceEvent]
    report: dict[str, Any]
    weight_rram_payload: np.ndarray | None = None
    input_tag_payload: np.ndarray | None = None

    def export_trace_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps([e.__dict__ for e in self.trace], indent=2), encoding="utf-8")

    def export_rtl_vectors(self, path: str | Path) -> None:
        vectors = {
            "weight_payload": self.weight_payload, "weight_scale": self.weight_scale,
            "input_payload": self.input_payload, "input_scale": self.input_scale,
            "tile_partials": self.tile_partials, "logits": self.logits_hardware,
        }
        if self.weight_rram_payload is not None:
            vectors["weight_rram_payload"] = self.weight_rram_payload
        if self.input_tag_payload is not None:
            vectors["input_tag_payload"] = self.input_tag_payload
        if hasattr(self, "partial_mantissas"):
            vectors["partial_mantissas"] = self.partial_mantissas
            vectors["partial_exponents"] = self.partial_exponents
        if self.softmax_output is not None:
            vectors["softmax_output"] = self.softmax_output
        for name in ("mx_esum", "mx_emax", "mx_distance", "mx_skip_mask", "mx_compute_mask",
                     "mc_ids", "mc_element_enable_mask"):
            if hasattr(self, name):
                vectors[name] = getattr(self, name)
        np.savez(path, **vectors)

    def export_tile_partials(self, path: str | Path) -> None:
        np.savez(path, values=self.tile_partials,
                 mantissas=getattr(self, "partial_mantissas", np.array([])),
                 exponents=getattr(self, "partial_exponents", np.array([])))

    def export_rram_mc_control(self, path: str | Path) -> None:
        np.savez(path, mc_ids=self.mc_ids, element_enable_mask=self.mc_element_enable_mask,
                 scale_block_skip=self.mx_skip_mask, scale_compute=self.mx_compute_mask,
                 die_id=np.int32(self.report["active_die"]),
                 payload_word_bits=np.int32(128), mask_lane0_is_lsb=np.bool_(True))

    def export_mx_control(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps([e.__dict__ for e in self.mx_control], indent=2), encoding="utf-8")


def _bf16_round(x: np.ndarray) -> np.ndarray:
    a = np.asarray(x, dtype=np.float32)
    bits = a.view(np.uint32)
    rounded = bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)
    return (rounded & np.uint32(0xFFFF0000)).view(np.float32)


def run_v3(cfg: V3Config | None = None, **kwargs) -> V3Result:
    from .behavior import run
    return run(V3Config() if cfg is None else cfg, **kwargs)
