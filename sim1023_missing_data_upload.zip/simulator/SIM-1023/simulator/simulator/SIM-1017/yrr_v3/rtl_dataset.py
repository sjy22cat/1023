"""Strict external Synopsys characterization. No Verilog parsing or estimates.

Hardware parameters are read from the package-relative measured JSON, never
from RTL source, technology macros, gate counts, or fallback snapshots.
"""
from __future__ import annotations
from dataclasses import dataclass, field, fields, replace, asdict
import json
import math
from pathlib import Path
from typing import Any
from .config import EnergyParams, V3Config, HOST_DMA_CONFIG_FIELDS, HOST_DMA_ENERGY_FIELDS

SCHEMA = "sim-1017-synopsys-measured/v3-pe-mc"
WORKLOAD_FIELDS = frozenset({"m", "n", "k", "batch", "workload", "seed", "layer_id",
    "layer_die_map", "weights_resident", "model_host_io", "enable_softmax",
    "enable_tag_skip", "enable_mx_block_skip", "latency_source", "energy"})
STRUCTURE_CONFIG = {"tile_rows": "tile_rows", "tile_k": "tile_k", "pe_per_tile": "pe_per_tile",
    "physical_tile_rows": "tile_rows", "physical_tile_cols": "tile_cols",
    "mem_die_channels": "mem_die_channels", "gsram_banks": "gsram_banks",
    "gsram_payload_bits": "payload_bits", "gsram_scale_bits": "scale_bits"}
TIMING_CONFIG = {"clock_ns": "clock_ns", "mem_die_latency": "mc_request_to_response_cycles",
    "pe_mul_cycles": "pe_mul_cycles", "pe_acc_cycles": "pe_acc_cycles",
    "broadcast_cycles": "broadcast_cycles", "sa_pipeline_levels": "reduction_cycles",
    "dma_latency": "host_dma_setup_cycles", "mx_control_cycles": "mx_control_cycles",
    "tag_decode_cycles": "tag_decode_cycles", "gsram_read_cycles": "gsram_payload_read_cycles",
    "gsram_scale_read_cycles": "gsram_scale_read_cycles", "gsram_write_latency": "gsram_write_latency_cycles"}
# Every other hardware field must be supplied, so a V3Config default cannot
# silently become a characterized latency, capacity, throughput, or mode.
HARDWARE_FIELDS = frozenset(f.name for f in fields(V3Config)) - WORKLOAD_FIELDS
CONFIG_FIELDS = HARDWARE_FIELDS - STRUCTURE_CONFIG.keys() - TIMING_CONFIG.keys()
ENERGY_FIELDS = frozenset(f.name for f in fields(EnergyParams)) - {"provenance", "sources"}
STRUCTURE_FIELDS = frozenset(STRUCTURE_CONFIG.values()) | {"mc_count", "gsram_depth", "gsram_pages"}
AREA_FIELDS = ("logic_die_mm2", "global_controller_mm2", "mc_unit_mm2", "mc_total_mm2",
    "phy_total_mm2", "tile_total_mm2", "gsram_mm2", "dma_mm2", "reduction_mm2", "nonmac_mm2")


def default_1017_measured_path() -> Path:
    return Path(__file__).resolve().parents[1] / "calibration" / "rtl_1017sim" / "rtl_1017sim_measured.json"


def _number(value, path, *, positive=False, integer=False):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise ValueError(f"{path} must be a finite nonnegative number (no null/fallback)")
    if positive and value <= 0:
        raise ValueError(f"{path} must be positive")
    if integer and type(value) is not int:
        raise ValueError(f"{path} must be an integer")
    return value


def load_1017_calibration(path=None, *, require_complete=True) -> dict[str, Any]:
    p = Path(path) if path is not None else default_1017_measured_path()
    if not p.is_file():
        raise FileNotFoundError(f"Synopsys parameters missing: {p}; see README_SIM-1017.md")
    data = json.loads(p.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or data.get("schema") != SCHEMA:
        from .characterization import SCHEMA as COMPONENT_SCHEMA
        if isinstance(data,dict) and data.get("schema")==COMPONENT_SCHEMA:
            raise ValueError("PARTIAL component data are supported by run.py and finite PPL; run_llm requires complete LLM/non-MAC calibration and does not yet consume per-PE data-dependent read masks")
        raise ValueError(f"schema must be {SCHEMA}; old inferred exports are unsupported")
    if not require_complete:  # inspection/templates only; never used to run
        return data
    if data.get("status") != "MEASURED":
        raise ValueError(f"Synopsys parameters are {data.get('status')!r}: fill {p} before running")
    for section in ("structure", "timing", "config_overrides", "energy", "area", "llm_prices", "llm_hardware", "provenance"):
        if not isinstance(data.get(section), dict):
            raise ValueError(f"required object: {section}")
    st, ti, hw = data["structure"], data["timing"], data["config_overrides"]
    for name in STRUCTURE_FIELDS:
        _number(st.get(name), f"structure.{name}", positive=True, integer=True)
    if (st["mc_count"], st["mem_die_channels"], st["tile_rows"], st["tile_cols"],
            st["pe_per_tile"], st["tile_k"], st["payload_bits"], st["scale_bits"]) != (32768,32,32,32,32,32,128,8):
        raise ValueError("SIM-1017 requires 32768 PE-local MCs, independent 32 external channels, 32x32 tiles")
    if st.get("mc_mapping") != "mc_id=tile_id*pe_per_tile+pe_id":
        raise ValueError("MC contract requires mc_id=tile_id*pe_per_tile+pe_id; old MC c mapping unsupported")
    # Host/DMA fields in historical files are optional and never priced.
    data["timing"].setdefault("host_dma_setup_cycles", 0)
    for name in CONFIG_FIELDS & HOST_DMA_CONFIG_FIELDS:
        hw.setdefault(name, getattr(V3Config(), name))
    for name in HOST_DMA_ENERGY_FIELDS:
        data["energy"][name] = 0.0
    data["area"].setdefault("dma_mm2", 0.0)
    for key in TIMING_CONFIG.values():
        if key == "host_dma_setup_cycles":
            continue
        _number(ti.get(key), f"timing.{key}", positive=key in ("clock_ns", "pe_mul_cycles", "reduction_cycles"),
                integer=key != "clock_ns")
    required_missing = sorted(k for k in CONFIG_FIELDS if k not in hw or (hw[k] is None and k != "mx_skip_threshold_bits"))
    if required_missing:
        raise ValueError("missing hardware config: " + ", ".join(required_missing))
    unknown = set(hw) - CONFIG_FIELDS
    if unknown:
        raise ValueError("config_overrides has duplicate/unknown fields: " + ", ".join(sorted(unknown)))
    defaults = V3Config()
    for name in CONFIG_FIELDS:
        if name in HOST_DMA_CONFIG_FIELDS:
            continue
        value, default = hw[name], getattr(defaults, name)
        if name == "mx_skip_threshold_bits" and value is None:
            continue
        if type(default) is bool:
            if type(value) is not bool:
                raise ValueError(f"config_overrides.{name} must be a JSON boolean")
        elif type(default) is int or name == "mx_skip_threshold_bits":
            _number(value, f"config_overrides.{name}", integer=True)
    for name in ENERGY_FIELDS:
        _number(data["energy"].get(name), f"energy.{name}")
    if set(data["energy"]) != ENERGY_FIELDS:
        raise ValueError("energy contains unsupported or missing keys")
    for name in AREA_FIELDS:
        if name == "dma_mm2":
            continue
        _number(data["area"].get(name), f"area.{name}", positive=name == "logic_die_mm2")
    provenance = data["provenance"]
    for name in ("rtl_revision", "tool_versions", "pvt", "clock_constraint", "activity_window", "reports", "energy_scope"):
        if not provenance.get(name):
            raise ValueError(f"provenance.{name} is required for traceability")
    cfg = V3Config(**_config_values(data), energy=EnergyParams(**data["energy"]))
    cfg.validate()
    if cfg.ideal_mem_die or cfg.mem_die_channels != 32:
        raise ValueError("measured SIM-1017 requires nonideal 32-channel mode")
    for key in ("mem_die_bytes", "mem_die_count", "rram_capacity_bytes", "feram_capacity_bytes"):
        _number(data["llm_hardware"].get(key), "llm_hardware."+key, positive=True, integer=True)
    lh = data["llm_hardware"]
    if lh["rram_capacity_bytes"]+lh["feram_capacity_bytes"] > lh["mem_die_bytes"]:
        raise ValueError("RRAM+FeRAM capacities exceed the LLM aggregate Mem Die capacity")
    _validate_llm_prices(data)
    from .nonmac import validate_nonmac
    validate_nonmac(data.get("nonmac"), ti["clock_ns"])
    if data["nonmac"]["rtl_revision"] != provenance["rtl_revision"]:
        raise ValueError("nonmac.rtl_revision disagrees with provenance.rtl_revision")
    return data


def _config_values(data):
    values = dict(data["config_overrides"])
    values.update({dst: data["structure"][src] for dst, src in STRUCTURE_CONFIG.items()})
    values.update({dst: data["timing"][src] for dst, src in TIMING_CONFIG.items()})
    values["latency_source"] = "measured"
    values.update({k: getattr(V3Config(), k) for k in HOST_DMA_CONFIG_FIELDS})
    return values


def _validate_llm_prices(data):
    from .llm.config import LlmPrices
    raw = data["llm_prices"]
    required = set(LlmPrices.__dataclass_fields__) - {"provenance", "f_max_mhz", "block_pj_by_mac", "nonmac"}
    if set(raw) != required:
        raise ValueError("llm_prices keys mismatch; missing=" + str(sorted(required-set(raw))) + "; unknown=" + str(sorted(set(raw)-required)))
    for key in required:
        _number(raw[key], "llm_prices."+key, positive=key in ("clock_ns", "block_cycles", "macs_per_block", "phy_bpc"),
                integer=key in ("block_cycles", "macs_per_block", "phy_bpc"))
    if raw["macs_per_block"] != 1024**2 or raw["phy_bpc"] != 128:
        raise ValueError("LLM block must be one 1024x1024 GEMV and PHY 128 bits/channel")
    if raw["clock_ns"] != data["timing"]["clock_ns"]:
        raise ValueError("LLM clock disagree with hardware characterization")
    for name in ENERGY_FIELDS & raw.keys():
        if raw[name] != data["energy"][name]:
            raise ValueError(f"llm_prices.{name} disagrees with energy.{name}")


def calibration_config_overrides(path=None) -> dict[str, Any]:
    return _config_values(load_1017_calibration(path))


@dataclass(frozen=True)
class RtlStructure:
    """Structure recorded by the external elaboration/characterization run."""
    tile_rows: int
    tile_cols: int
    pe_per_tile: int
    tile_k: int
    gsram_banks: int
    gsram_depth: int
    gsram_pages: int
    mc_lat: int
    phy_stages: int
    bpc: int

    @property
    def total_pe(self):
        return self.tile_rows*self.tile_cols*self.pe_per_tile


@dataclass(frozen=True)
class V3Datasheet:
    name: str
    energy: EnergyParams
    mem_die_latency: int
    provenance: dict[str, str]
    source_path: str | None = None
    structure: RtlStructure | None = None
    rtl_params: dict = field(default_factory=dict)  # full immutable-by-convention JSON snapshot
    area: dict = field(default_factory=dict)
    config_values: dict = field(default_factory=dict)
    production: bool = False
    components: dict = field(default_factory=dict)
    nonmac_parallel: dict = field(default_factory=dict)
    interconnect: dict = field(default_factory=dict)

    @classmethod
    def from_component_json(cls, path=None):
        from .characterization import read_components, component_config, default_component_path
        from .parallel_nonmac import load_parallel
        p = Path(path) if path is not None else default_component_path()
        raw = read_components(p)
        e = EnergyParams(provenance="partial-workbook; unknown components remain null")
        return cls("workbook-20261019-per-PE-MC", e, 0, {}, str(p.resolve()),
                   config_values=component_config(raw), components=raw,
                   nonmac_parallel=load_parallel())

    def with_nonmac_parameters(self, path):
        """Load a user-supplied 1024-lane replication estimate."""
        from .parallel_nonmac import load_parallel
        return replace(self, nonmac_parallel=load_parallel(path))

    def with_interconnect_parameters(self, path):
        """Opt in to a sourced topology estimate; it never becomes measured RTL."""
        from .interconnect import load_interconnect
        return replace(self, interconnect=load_interconnect(path))

    @classmethod
    def from_parameters(cls, path=None):
        from .characterization import SCHEMA as COMPONENT_SCHEMA, default_component_path
        p = Path(path) if path is not None else default_component_path()
        data = json.loads(p.read_text(encoding="utf-8-sig"))
        return cls.from_component_json(p) if data.get("schema") == COMPONENT_SCHEMA else cls.from_1017_calibration(p)

    @classmethod
    def from_1017_calibration(cls, path=None):
        raw = load_1017_calibration(path)
        p = Path(path) if path is not None else default_1017_measured_path()
        ti, st = raw["timing"], raw["structure"]
        src = f"measured:{p.resolve()}"
        e = EnergyParams(**raw["energy"], provenance="synopsys-measured",
                         sources={k: src for k in ENERGY_FIELDS})
        structure = RtlStructure(**{k: st[k] for k in ("tile_rows", "tile_cols", "pe_per_tile", "tile_k", "gsram_banks", "gsram_depth", "gsram_pages")},
            mc_lat=ti["mc_request_to_response_cycles"], phy_stages=ti.get("phy_latency_cycles", 0), bpc=128)
        return cls("synopsys-measured-1017", e, ti["mc_request_to_response_cycles"], e.sources,
            str(p.resolve()), structure, raw, dict(raw["area"]), _config_values(raw), True)

    def bind_config(self, cfg):
        """Apply every hardware input while retaining workload/skip experiment settings."""
        if self.components:
            values = {**self.config_values, "model_host_io":False}
            # Partial characterization exposes the selected macro as the
            # default capacity, while still allowing explicit capacity
            # sensitivity experiments. A caller changing the V3 default is an
            # experiment input, not an accidental override of the macro PPA.
            if cfg.global_sram_bytes != V3Config().global_sram_bytes:
                values["global_sram_bytes"] = cfg.global_sram_bytes
            return replace(cfg, **values, energy=self.energy)
        if not self.production:
            return replace(cfg, **{**self.config_values, "model_host_io":False}, energy=self.energy)  # explicit synthetic fixtures only
        return replace(cfg, **{**self.config_values, "model_host_io":False}, energy=self.energy)

    def tag(self, name):
        return self.provenance.get(name, "test-fixture").split(":", 1)[0]

    def source_summary(self):
        return f"{self.name} <- {self.source_path}"
