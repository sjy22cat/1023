from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class PeRramControl:
    """One PE-local 128-bit word; 32 enables correspond to FP4 elements.

    This is a behavior interface, not a declaration of analog RRAM ports.
    payload read is suppressed when element_enable_mask == 0.
    """
    mc_id: int = 0
    tile_id: int = 0
    pe_id: int = 0
    element_enable_mask: int = 0
    block_skip: bool = False
    valid: bool = True
    ready: bool = True
    cycle: int = 0
    die_id: int = 0
    batch_id: int = 0
    k_block: int = 0
    tag: str = ""


@dataclass
class PhyWord:
    valid: bool = True
    ready: bool = True
    cycle: int = 0
    tag: str = ""
    tile_id: int = -1
    die_id: int = -1
    batch_id: int = 0
    k_block: int = -1
    payload: Any = None
    scale: int = 0


@dataclass
class MemDieRequest:
    die_id: int
    layer_id: int
    tile_row: int
    tile_k: int
    address: int
    nbytes: int
    tag: str
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tile_id: int = -1
    batch_id: int = 0
    k_block: int = -1


@dataclass
class MemDieResponse:
    die_id: int
    tag: str
    payload: Any
    scale: int
    ready_cycle: int
    valid: bool = True
    ready: bool = True
    cycle: int = 0
    tile_id: int = -1
    batch_id: int = 0
    k_block: int = -1


@dataclass
class TileWeightLoad:
    tile_id: int
    die_id: int
    payload: Any
    scale: Any
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    batch_id: int = 0
    k_block: int = -1


@dataclass
class TileInputBlock:
    tile_id: int
    batch_id: int
    k_block: int
    payload: Any
    scale: int
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    die_id: int = -1


@dataclass
class PeMacResult:
    tile_id: int
    pe_id: int
    batch_id: int
    k_block: int
    value: float
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    die_id: int = -1


@dataclass
class TilePartial:
    tile_id: int
    batch_id: int
    k_block: int
    pe_values: Any
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    die_id: int = -1


@dataclass
class MxControl:
    max_exponent: int
    alignment_distance: list[int]
    valid_mask: list[bool]
    zero_mask: list[bool]
    data_move_en: bool
    calc_en: bool
    reduction_stage: int
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    tile_id: int = -1
    die_id: int = -1
    batch_id: int = 0
    k_block: int = -1
    esum: Any = None
    max_exponent_per_output: Any = None
    block_skip_mask: Any = None
    compute_mask: Any = None
    threshold_bits: int | None = None
    decision_source: str = "E8M0 scales only; before broadcast/PE"


@dataclass
class ReductionPacket:
    batch_id: int
    output_row: int
    value: float
    stage: int
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    tile_id: int = -1
    die_id: int = -1
    k_block: int = -1


@dataclass
class DmaDescriptor:
    src_addr: int = 0
    dst_addr: int = 0
    length: int = 0
    stride: int = 0
    buffer_id: int = 0
    die_id: int = 0
    tile_group: int = 0
    batch_id: int = 0
    tag: str = ""
    status: str = "queued"
    error: str = ""
    valid: bool = True
    ready: bool = True
    cycle: int = 0
    tile_id: int = -1
    k_block: int = -1


@dataclass
class SoftmaxPacket:
    batch_id: int
    lane: int
    value: float
    cycle: int = 0
    valid: bool = True
    ready: bool = True
    tag: str = ""
    tile_id: int = -1
    die_id: int = -1
    k_block: int = -1


def object_dict(obj: Any) -> dict[str, Any]:
    return asdict(obj)
