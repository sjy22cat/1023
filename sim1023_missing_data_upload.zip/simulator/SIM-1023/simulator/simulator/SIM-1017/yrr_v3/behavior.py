"""Executed V3 numerical path. No device/RTL calibration is implied."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Callable
import hashlib
import numpy as np
from . import formats as fmt
from .config import V3Config
from .model import V3Result, MxControlTrace, _bf16_round
from .rtl_dataset import V3Datasheet
from .mx_controller import decide_scale_blocks


@dataclass
class FormatBehavior:
    """Replace these callables with server RTL-derived behavior when available.

    Zero metadata is obtained through decode, never guessed from code bit fields.
    Shared E8M0 is passed separately and is never TAG/A5 recoded.
    """
    weight_encode: Callable = fmt.mxfp4_to_rram_fp4
    weight_decode: Callable = fmt.decode_rram_fp4
    input_encode: Callable = fmt.mxfp4_to_tag_fp
    input_decode: Callable = fmt.decode_tag_fp
    name: str = "workbook-reference behavior (replaceable; no RTL implementation)"


@dataclass
class SimulatorSession:
    """Persistent tile weight ownership across calls; one layer resident at a time."""
    resident_key: str | None = None
    calls: int = 0

    def clear(self):
        self.resident_key = None


def _inputs(cfg, rng, payload, scale, values, shape):
    pk = cfg.tile_cols * 32
    if payload is not None:
        if scale is None or values is not None:
            raise ValueError("payload requires scale and cannot be combined with values")
        p0, s0 = np.asarray(payload), np.asarray(scale)
        if p0.shape not in (shape, shape[:-1] + (pk,)) or s0.shape != shape[:-1] + (cfg.tile_cols,):
            raise ValueError(f"payload/scale shapes must be {shape} (or padded K={pk}) and {shape[:-1] + (cfg.tile_cols,)}")
        if np.any(p0 != np.floor(p0)) or np.any((p0 < 0) | (p0 > 15)):
            raise ValueError("MXFP4 payload must contain integer codes 0..15")
        if np.any(s0 != np.floor(s0)) or np.any((s0 < 0) | (s0 > 254)):
            raise ValueError("E8M0 must be 0..254; 255 is NaN and not a finite inference scale")
        p = np.zeros(shape[:-1] + (pk,), np.uint8)
        p[..., :cfg.k] = p0[..., :cfg.k]
        return p, s0.astype(np.uint8)
    if scale is not None:
        raise ValueError("scale requires payload")
    x = rng.normal(size=shape) if values is None else np.asarray(values, np.float64)
    if x.shape != shape or not np.isfinite(x).all():
        raise ValueError(f"values must be finite with shape {shape}")
    padded = np.zeros(shape[:-1] + (pk,), np.float64)
    padded[..., :cfg.k] = x
    return fmt.encode_mxfp4(padded)


def _shift(a, distance):
    """Vector integer shift toward zero; large exponent gaps become zero."""
    d = np.minimum(np.maximum(distance, 0), 62).astype(np.int64)
    return np.sign(a) * np.right_shift(np.abs(a), d)


def _sat(a, bits):
    lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    out = np.clip(a, lo, hi)
    return out, int(np.count_nonzero(a != out))


def _sum_lanes(q, bits):
    count = 0
    while q.shape[-1] > 1:
        if q.shape[-1] % 2:
            q = np.concatenate((q, np.zeros(q.shape[:-1] + (1,), dtype=q.dtype)), -1)
        q, n = _sat(q[..., ::2] + q[..., 1::2], bits)
        count += n
    return q[..., 0], count


def run(cfg: V3Config, *, dataset="auto", weight_payload=None, weight_scale=None,
        input_payload=None, input_scale=None, weights=None, inputs=None,
        format_behavior: FormatBehavior | None = None, session: SimulatorSession | None = None,
        ferram_read_bytes=0, ferram_write_bytes=0, ferram_live_bytes=None):
    ds = V3Datasheet.from_parameters() if dataset is None or dataset == "auto" else dataset
    if not isinstance(ds, V3Datasheet):
        raise TypeError("dataset must be a Synopsys measured V3Datasheet")
    cfg = ds.bind_config(cfg)
    cfg.validate(allow_partial_energy=bool(ds.components))
    adapter = format_behavior or FormatBehavior()
    rng = np.random.default_rng(cfg.seed)
    shape = (cfg.batch, cfg.k) if cfg.workload == "gemv" else (cfg.batch, cfg.n, cfg.k)
    wp, ws = _inputs(cfg, rng, weight_payload, weight_scale, weights, (cfg.m, cfg.k))
    xp, xs = _inputs(cfg, rng, input_payload, input_scale, inputs, shape)
    # This pass is deliberately before format conversion and multiplication.
    # Its function signature accepts scales only: no E3/M10 can feed back
    # into block gates. All K blocks, including zero payloads, participate.
    rows, cols = (cfg.m + cfg.pe_per_tile - 1) // cfg.pe_per_tile, cfg.tile_cols
    nv = cfg.batch * (cfg.n if cfg.workload == "gemm" else 1)
    xsflat = xs.reshape(nv, cols)
    decisions = [decide_scale_blocks(ws, xsflat[v],
                    threshold_bits=cfg.mx_skip_threshold_bits,
                    enable=cfg.enable_mx_block_skip, metadata_available=cfg.mx_metadata_available)
                 for v in range(nv)]
    wr, xt = adapter.weight_encode(wp), adapter.input_encode(xp)
    raw_w = np.asarray(adapter.weight_decode(wr, 127), np.float64)
    raw_x = np.asarray(adapter.input_decode(xt, 127), np.float64)
    if raw_w.shape != wp.shape or raw_x.shape != xp.shape or not np.isfinite(raw_w).all() or not np.isfinite(raw_x).all():
        raise ValueError("format behavior must return finite value arrays with unchanged shape")
    xflat = raw_x.reshape(nv, cols, 32)
    wblocks = raw_w.reshape(cfg.m, cols, 32)
    xsflat = xsflat.astype(np.int32)
    valid_lanes = np.arange(cols * 32).reshape(cols, 32) < cfg.k
    # FP64 reference is decoded external MXFP4, independent of format adapters.
    wd = fmt.decode_fp4(wp, np.repeat(ws, 32, -1))[..., :cfg.k]
    xd = fmt.decode_fp4(xp, np.repeat(xs, 32, -1)).reshape(nv, cols * 32)[..., :cfg.k]
    ref = xd @ wd.T
    out = np.zeros((nv, cfg.m), np.float64)
    partials = np.zeros((nv, rows, cols, cfg.pe_per_tile), np.float64)
    mantissas = np.zeros_like(partials, np.int64)
    exponents = np.zeros((nv, rows, cfg.pe_per_tile), np.int32)
    controls, stage_stats = [], []
    # M10 has 8 fractional bits. Additional accumulator bits are guard bits,
    # after reserving log2(32) growth bits for the PE's lane sum.
    guard = max(0, cfg.partial_bits - 10 - int(np.ceil(np.log2(cfg.tile_k))))
    frac = 8 + guard
    sats = active_macs = tag_zeros = shift_bits = 0
    active_each, source_masks, receiver_masks, active_pe_blocks = [], [], [], []
    tag_enabled = cfg.enable_tag_skip and cfg.tag_metadata_available
    from .pe_memory import plan_reads
    read_plans, pe_work_blocks = [], []
    for v in range(nv):
        decision = decisions[v]
        compute = decision.compute
        read_plans.append(plan_reads(cfg, compute, xflat[v] != 0))
        # Skipped PE blocks produce no products, lane sums or saturations.
        prod = np.zeros_like(wblocks)
        np.multiply(wblocks, xflat[v][None, :, :], out=prod, where=compute[..., None])
        nz = (prod != 0) & valid_lanes[None, :, :]
        e = np.floor(np.log2(np.maximum(np.abs(prod), np.finfo(np.float64).tiny))).astype(np.int32)
        # FP4 products span [0.25,36]: numerical exponents [-2,5], exactly
        # eight codes (E3 wire code = exponent + 2). Wider block exponents
        # are controller metadata and must not be wrapped to three bits.
        if np.any(nz & ((e < -2) | (e > 5))):
            raise ValueError("format adapter values exceed the FP4 product E3 range [-2,5]")
        em = np.max(np.where(nz, e, -10000), axis=-1)
        has = np.any(nz, -1)
        em = np.where(has, em, 0)
        m10 = np.trunc(np.ldexp(prod, 8 - e)).astype(np.int64)
        m10 = np.where(nz, m10, 0)
        # Each product first aligns to block E3max before the PE lane sum.
        aligned_lanes = _shift(m10 << guard, em[..., None] - e)
        block_q, n = _sum_lanes(aligned_lanes, cfg.partial_bits)
        sats += n
        # Post-PE NUMERICAL alignment is distinct from the pre-PE scale
        # controller. E3 can affect this exponent but can never change gates.
        etotal = em + decision.esum
        emax = np.max(np.where(has, etotal, -10000), axis=1)
        emax = np.where(np.any(has, 1), emax, 0)
        distance = np.maximum(0, emax[:, None] - etotal)
        q = _shift(block_q, distance)
        lane_activity = nz if tag_enabled else np.broadcast_to(valid_lanes, prod.shape)
        pe_work_blocks.append(int(np.any(lane_activity & compute[..., None], axis=-1).sum()))
        mac_count = int(np.count_nonzero(lane_activity & compute[..., None]))
        active_macs += mac_count
        active_each.append(mac_count)
        tag_zeros += int(np.count_nonzero(compute[..., None] & valid_lanes[None, :, :] & ~nz)) if tag_enabled else 0
        q = np.where(compute, q, 0)
        q, n = _sat(q, cfg.partial_bits)
        sats += n
        shift_bits += int(np.sum(np.where(compute, np.minimum(distance, cfg.partial_bits), 0)))
        # Source suppression requires the block to be unnecessary at ALL rows.
        receiver = np.zeros((rows, cols), bool)
        for r in range(rows):
            a, z = r * cfg.pe_per_tile, min(cfg.m, (r + 1) * cfg.pe_per_tile)
            receiver[r] = np.any(compute[a:z], 0)
            partials[v, r, :, :z-a] = np.ldexp(q[a:z].T.astype(np.float64), emax[a:z][None, :] - frac)
            mantissas[v, r, :, :z-a] = q[a:z].T
            exponents[v, r, :z-a] = emax[a:z]
        source = np.any(receiver, 0)
        source_masks.append(source)
        receiver_masks.append(receiver)
        active_pe_blocks.append(int(np.count_nonzero(compute)))
        # The pre-PE trace explicitly contains ONLY scale-derived metadata.
        controls.append(MxControlTrace(int(np.max(decision.emax)), decision.distance.ravel().tolist(),
                                      np.ones_like(compute).ravel().tolist(), decision.skip.ravel().tolist(),
                                      bool(np.any(source)), bool(np.any(compute)), -1,
                                      decision_source="E8M0 scales only; before broadcast/PE",
                                      esum=decision.esum.ravel().tolist(),
                                      max_exponent_per_output=decision.emax.tolist(),
                                      block_skip_mask=decision.skip.ravel().tolist(),
                                      compute_mask=compute.ravel().tolist(),
                                      threshold_bits=cfg.mx_skip_threshold_bits, vector_id=v))
        cur = q
        depth = 0
        while cur.shape[1] > 1:
            nin = cur.shape[1]
            if cfg.reduction_style == "serial":
                sums, n = _sat(cur[:, :1] + cur[:, 1:2], cfg.partial_bits)
                nxt = np.concatenate((sums, cur[:, 2:]), 1)
                adds = cfg.m
            else:
                if nin % 2:
                    cur = np.concatenate((cur, np.zeros((cfg.m, 1), np.int64)), 1)
                nxt, n = _sat(cur[:, ::2] + cur[:, 1::2], cfg.partial_bits)
                adds = cfg.m * (nin // 2)
            sats += n
            stage_stats.append({"vector_id": v, "stage": depth, "input_partials_per_output": nin,
                                "add_count": adds, "valid_count": cfg.m * nin,
                                "zero_count": int(np.count_nonzero(cur == 0)),
                                "alignment_distance": [0], "shift_bits": 0,
                                "output_exponent_range": [int(emax.min()), int(emax.max())]})
            controls.append(MxControlTrace(int(emax.max()), [0], [True],
                                          [not np.any(nxt)], bool(np.any(nxt)), True, depth,
                                          vector_id=v))
            cur, depth = nxt, depth + 1
        out[v] = np.ldexp(cur[:, 0].astype(np.float64), emax - frac)
    with np.errstate(over="ignore"):
        hw = _bf16_round(out) if cfg.output_format == "bf16" else out.astype(np.float32)
    if not np.isfinite(hw).all():
        raise FloatingPointError("FP32/BF16 output overflow; choose finite scales or a wider output reference")
    output_shape = (cfg.batch, cfg.m) if cfg.workload == "gemv" else (cfg.batch, cfg.n, cfg.m)
    hw, ref = hw.reshape(output_shape), ref.reshape(output_shape)
    sm = fmt.stable_softmax(hw) if cfg.enable_softmax else None
    die = cfg.layer_die_map.get(cfg.layer_id, cfg.layer_id % 2)
    h = hashlib.sha256(wp.tobytes() + ws.tobytes() + str((cfg.layer_id, die, adapter.name, cfg.weight_supply_mode)).encode()).hexdigest()
    warm = bool(session and cfg.weights_resident and session.resident_key == h)
    from .architecture import evaluate
    report, trace = evaluate(cfg, ds, source_masks, receiver_masks, active_each, active_pe_blocks,
                             warm=warm, ferram_read_bytes=ferram_read_bytes,
                             ferram_write_bytes=ferram_write_bytes, ferram_live_bytes=ferram_live_bytes,
                             shift_bits=shift_bits, read_plans=read_plans, pe_work_blocks=pe_work_blocks,
                             pe_block_masks=[d.compute for d in decisions])
    report["finite_width"] = {"partial_bits": cfg.partial_bits, "m10_fraction_bits": 8,
        "accumulator_guard_bits": guard, "accumulator_fraction_bits": frac,
        "product_e3_numerical_range": [-2, 5], "product_e3_wire_bias": 2,
        "partial_exponent": "expanded controller metadata, no 3-bit wrap",
        "emx_rule": "post-PE numerical reduction: Eblock=E3max+Esum; Ereduce_max=max(nonzero Eblock) per output; never used by block gating",
        "right_shift": "toward-zero", "overflow": "signed saturation", "saturation_count": sats,
        "skip_rule": "pre-PE only: d=scale_EMXmax-Esum; skip iff d>=explicit threshold; no E3/M10 or payload inspection",
        "reduction_style": cfg.reduction_style, "reduction_stages": stage_stats}
    report["skip"].update(tag_zero_elements=tag_zeros, active_blocks=sum(active_pe_blocks),
                         skipped_blocks=nv * cfg.m * cols - sum(active_pe_blocks),
                         mx_block_skip=decisions[0].enabled, requested=cfg.enable_mx_block_skip,
                         status=decisions[0].status, threshold_bits=cfg.mx_skip_threshold_bits,
                         decision_inputs=["E8M0_IN", "E8M0_W"],
                         esum_rule="Esum=(E8M0_IN-127)+(E8M0_W-127); raw-code sums give identical distances",
                         emax_scope="maximum Esum over K blocks independently for each output/PE row; zero payloads included",
                         comparison="d >= threshold_bits", e3_m10_used_for_decision=False,
                         gate_granularity="one output/PE x one K block",
                         alignment_distance_min=int(min(d.distance.min() for d in decisions)),
                         alignment_distance_max=int(max(d.distance.max() for d in decisions)))
    fref, fhw = ref.astype(np.float32), hw.astype(np.float32)
    # Monotone integer encoding for ULP distances, including sign changes.
    def ordered(a):
        b = a.view(np.uint32).astype(np.int64)
        return np.where((b & 0x80000000) != 0, 0x100000000-b, b+0x80000000)
    finite = np.isfinite(fref)
    report["errors"] = {"max_abs": float(np.max(np.abs(ref-hw))),
        "mean_abs": float(np.mean(np.abs(ref-hw))),
        "max_relative": float(np.max(np.abs(ref-hw)/np.maximum(np.abs(ref), 1e-12))),
        "max_fp32_ulp": int(np.max(np.abs(ordered(fref[finite])-ordered(fhw[finite])))) if finite.any() else None,
        "reference": "FP64 matmul of external MXFP4 decoded payload and E8M0 scales",
        "softmax_max_abs": float(np.max(np.abs(fmt.stable_softmax(ref)-sm))) if sm is not None else None}
    report["format"] = {"behavior": adapter.name, "weight_storage": "RRAM-FP behavior interface",
                        "activation_compute": "TAG-FP behavior interface", "shared_scale": "E8M0 unchanged",
                        "rtl_equivalence": "pending server RTL vectors; existing RTL arithmetic differs"}
    report["config"] = asdict(cfg)
    result = V3Result(cfg, ref, hw, sm, wp, ws, xp, xs, partials.reshape(
        (cfg.batch, rows, cols, cfg.pe_per_tile) if cfg.workload == "gemv" else
        (cfg.batch, cfg.n, rows, cols, cfg.pe_per_tile)), controls, trace, report, wr, xt)
    result.partial_mantissas = mantissas
    result.partial_exponents = exponents
    result.mx_esum = np.stack([d.esum for d in decisions])
    result.mx_emax = np.stack([d.emax for d in decisions])
    result.mx_distance = np.stack([d.distance for d in decisions])
    result.mx_skip_mask = np.stack([d.skip for d in decisions])
    result.mx_compute_mask = np.stack([d.compute for d in decisions])
    result.mc_ids = read_plans[0].mc_ids
    result.mc_element_enable_mask = np.stack([p.element_enable_mask for p in read_plans])
    if session:
        session.resident_key = h if cfg.weights_resident else None
        session.calls += 1
    return result
