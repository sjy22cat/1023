"""PE-local RRAM controllers. No product or weight-value feedback into reads."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass
class PeReadPlan:
    mc_ids: np.ndarray
    element_enable_mask: np.ndarray  # [output, K-block], uint32 (lane 0 = LSB)
    read_words: int
    skipped_words: int
    scale_skipped_words: int
    tag_skipped_words: int
    enabled_elements: int
    physical_read_bits: int
    physical_groups: int
    partial_words: int


def plan_reads(cfg, scale_compute, input_nonzero):
    """TAG(input)==0 makes the corresponding weight unnecessary BEFORE read.

    Weight zero cannot suppress its own RRAM read without separately supplied
    resident metadata, so this function deliberately takes no weight values.
    """
    m, nc = scale_compute.shape
    valid = (np.arange(nc*32).reshape(nc,32) < cfg.k)
    elem = valid & (input_nonzero if cfg.enable_tag_skip and cfg.tag_metadata_available else True)
    enables = scale_compute[...,None] & elem[None,:,:]
    packed = np.sum(enables.astype(np.uint32) << np.arange(32,dtype=np.uint32),axis=-1,dtype=np.uint32)
    read = np.any(enables,axis=-1)
    group = cfg.rram_read_granularity_bits//4
    groups = np.any(enables.reshape(m,nc,32//group,group),axis=-1)
    physical_groups = int(groups.sum())
    row = np.arange(m)[:,None]
    col = np.arange(nc)[None,:]
    ids = ((row//cfg.pe_per_tile)*cfg.physical_tile_cols+col)*cfg.pe_per_tile + row%cfg.pe_per_tile
    nread = int(read.sum())
    lane_counts = enables.sum(-1)
    return PeReadPlan(ids, packed, nread, m*nc-nread,
        int((~scale_compute).sum()), int((scale_compute & ~read).sum()),
        int(enables.sum()), physical_groups*cfg.rram_read_granularity_bits,
        physical_groups, int(((lane_counts>0)&(lane_counts<32)).sum()))
