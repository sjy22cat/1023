"""Resource-reservation timing, traffic, capacity and disjoint energy accounting.

This is an architectural event model, not a router-level NoC or a timing CPU.
All events use integer half-open cycle intervals [start,end).
"""
from __future__ import annotations
from dataclasses import fields
from collections import defaultdict
from math import ceil, log2
import numpy as np
from .config import EnergyParams, HOST_DMA_CONFIG_FIELDS, HOST_DMA_ENERGY_FIELDS
from .nonmac import command_cost, staging_cost
from .model import TraceEvent
from .interfaces import MemDieRequest, MemDieResponse, object_dict
from .characterization import multiply as price, cost, area_report, sram_layout
from .parallel_nonmac import validate_parallel, command_cost as parallel_cost, area_report as parallel_area


class Reservations:
    def __init__(self):
        self.events = []
        self.calendar = defaultdict(list)

    def reserve(self, resource, operation, ready, duration, *, bytes=0, bits=0, batch_id=0,
                die_id=-1, tile_group=-1, metadata=None):
        start = int(ready)
        duration = int(duration)
        for a, z in sorted(self.calendar[resource]):
            if start + duration <= a:
                break
            if start < z:
                start = z
        if duration:
            self.calendar[resource].append((start, start+duration))
        event = TraceEvent(start, start+duration, resource, operation, int(bytes), int(bits),
                           tile_group=tile_group, die_id=die_id, batch_id=batch_id,
                           metadata={"dependency_ready_cycle": int(ready),
                                     "resource_wait_cycles": start-int(ready), **(metadata or {})})
        self.events.append(event)
        return event

    def reserve_pipeline(self, resource, operation, ready, latency, issue_cycles, **kwargs):
        """Reserve an injection slot; dependencies see the pipeline exit.

        A five-stage dedicated network with II=1 accepts another complete
        vector next cycle. Calendar intervals represent issue capacity;
        event intervals represent flight latency, so overlapping is intended.
        """
        if latency < 0 or issue_cycles < 1:
            raise ValueError("pipeline latency/issue interval invalid")
        if latency == 0:
            return self.reserve(resource, operation, ready, 0, **kwargs)
        event = self.reserve(resource, operation, ready, issue_cycles, **kwargs)
        event.end_cycle = event.start_cycle + latency
        event.metadata.update(pipelined=True, latency_cycles=latency,
                              initiation_interval_cycles=issue_cycles,
                              resource_busy_scope="injection slots; multiple vectors may be in flight")
        return event


def _align(x, n=32):
    return ceil(x/n)*n


def _timing_model(cfg, ds):
    measured = bool(ds.production)
    if cfg.latency_source in ("rtl", "measured") and not measured and ds.structure is None:
        raise ValueError("measured timing requires a V3Datasheet with characterization")
    source = "partial-workbook" if ds.components else "measured" if measured else "test-fixture"
    origin = f"{source}:{ds.source_path or 'explicit synthetic test inputs'}"
    return {
        "source": source, "rtl_used": False,
        "mem_die_latency": int(cfg.mem_die_latency), "mem_die_latency_source": origin,
        "mem_die_latency_used": cfg.weight_supply_mode=="tile_cache",
        "mc_read_cycles":cfg.mc_read_cycles,"phy_read_cycles":cfg.phy_read_cycles,
        "broadcast_cycles": int(cfg.broadcast_cycles), "broadcast_cycles_source": origin,
        "compute_cycles": int(cfg.pe_mul_cycles + cfg.pe_acc_cycles), "compute_cycles_source": origin,
        "reduction_cycles_source": origin, "mx_control_cycles": int(cfg.mx_control_cycles),
        "mx_control_cycles_source": origin, "tag_decode_cycles": int(cfg.tag_decode_cycles),
        "tag_decode_cycles_source": origin,
    }


def evaluate(cfg, ds, source_masks, receiver_masks, active_each, active_blocks, *, warm,
             ferram_read_bytes, ferram_write_bytes, ferram_live_bytes, shift_bits, read_plans, pe_work_blocks,
             pe_block_masks=None):
    timing = _timing_model(cfg, ds)
    mem_die_latency = timing["mem_die_latency"]
    broadcast_cycles = timing["broadcast_cycles"]
    nr = ceil(cfg.m/cfg.pe_per_tile)
    nc, nv = cfg.tile_cols, len(source_masks)
    network = None
    if ds.interconnect:
        from .interconnect import estimate_interconnect
        if pe_block_masks is None:
            raise ValueError("topology model requires scale-only PE-block masks")
        network = estimate_interconnect(cfg, ds.interconnect, receiver_masks, pe_block_masks)
        broadcast_cycles = max(v["broadcast"]["latency_cycles"] for v in network["vectors"])
        timing.update(broadcast_cycles=broadcast_cycles,
                      broadcast_cycles_source=network["source"],
                      interconnect_model=network["model"],
                      broadcast_initiation_interval_cycles=ds.interconnect["broadcast_issue_cycles"],
                      reduction_initiation_interval_cycles=ds.interconnect["reduction_issue_cycles"])
    die = cfg.layer_die_map.get(cfg.layer_id, cfg.layer_id % 2)
    lanes = min(cfg.gsram_banks, cfg.source_lanes, nc)
    if cfg.broadcast_style == "serial":
        lanes = 1
    source_counts = [int(np.count_nonzero(s)) for s in source_masks]
    receiver_counts = [int(np.count_nonzero(s)) for s in receiver_masks]
    src, recv = sum(source_counts), sum(receiver_counts)
    inbytes, logbytes = nc*17, cfg.m*4
    outbytes = cfg.m*(4 if cfg.output_format == "fp32" else 2)
    softbytes = cfg.m*4 if cfg.enable_softmax else 0
    weight_bytes = cfg.m*nc*17
    tile_w_logic_bits = cfg.tile_k*cfg.pe_per_tile*5 + cfg.pe_per_tile*8
    tile_w_phys = _align(ceil(tile_w_logic_bits/8))
    tile_i_logic_bits = cfg.tile_k*5+8
    tile_i_phys = _align(ceil(tile_i_logic_bits/8))
    parallel = ds.nonmac_parallel
    if parallel:
        validate_parallel(parallel, cfg.clock_ns)
    # Non-MAC local workspace is separate from Global SRAM I/O buffers.
    workspace = (parallel.get("local_workspace_bytes") if parallel else 8192*4) if cfg.enable_softmax else 0
    input_copies = 2 if cfg.input_double_buffer else 1
    log_copies = 2 if cfg.logits_double_buffer else 1
    per_vector_capacity = inbytes*input_copies + (logbytes+softbytes)*log_copies
    available = cfg.global_sram_bytes
    micro = min(nv, cfg.max_micro_batch, available//per_vector_capacity)
    if micro < 1:
        raise ValueError(f"Global SRAM cannot fit one vector: need {per_vector_capacity} bytes, have {cfg.global_sram_bytes}")
    for name, v in (("ferram_read_bytes", ferram_read_bytes), ("ferram_write_bytes", ferram_write_bytes)):
        if int(v) != v or v < 0:
            raise ValueError(f"{name} must be a nonnegative integer")
    fr, fw = int(ferram_read_bytes), int(ferram_write_bytes)
    if (fr or fw) and not cfg.ferram_enabled:
        raise ValueError("FeRAM traffic supplied while FeRAM is disabled")
    if ferram_live_bytes is not None and not 0 <= ferram_live_bytes <= cfg.ferram_kv_capacity_bytes:
        raise ValueError("FeRAM live allocation exceeds capacity")
    sched = Reservations()
    per_pe_rram = cfg.weight_supply_mode == "rram_per_pe"
    runtime_read_words = sum(p.read_words for p in read_plans) if per_pe_rram else 0
    runtime_read_bits = sum(p.physical_read_bits for p in read_plans) if per_pe_rram else 0
    runtime_skip_words = sum(p.skipped_words for p in read_plans) if per_pe_rram else 0
    # Independent controller initiation times; the external channel count is
    # intentionally not used for these PE-local vertical reads.
    mc_next_issue = np.zeros(cfg.mc_count, dtype=np.int64)
    mc_vector_ready = []
    requests, responses = [], []
    cold_bytes = 0
    weight_ready = 0
    loads = 0
    weight_cycles = []
    # Queue entry holds one outstanding transaction through its response.
    queue_free = [0]*cfg.mem_die_queue_depth

    def load_weights(ready, index):
        nonlocal cold_bytes, loads
        loads += 1
        cold_bytes += weight_bytes
        done, first = ready, None
        for r in range(nr):
            nrow = min(cfg.pe_per_tile, cfg.m-r*cfg.pe_per_tile)
            for c in range(nc):
                size = nrow*17
                tag = f"L{cfg.layer_id}_load{index}_r{r}_k{c}"
                qi = min(range(len(queue_free)), key=queue_free.__getitem__)
                qr = ready if cfg.ideal_mem_die else max(ready, queue_free[qi])
                ch = c % cfg.mem_die_channels
                resource = f"Mem Die {die} channel {ch}"
                if cfg.ideal_mem_die and cfg.ferram_channel_mode != "shared":
                    # Independent vertical links to every tile: one cold
                    # latency for the whole array, no artificial 1024-cycle loop.
                    resource = f"Mem Die {die} tile {r*nc+c}"
                    duration = mem_die_latency
                else:
                    duration = mem_die_latency+ceil(size/cfg.mem_die_bytes_per_cycle)
                    if cfg.ferram_channel_mode == "shared":
                        resource = "Mem shared channel"
                ev = sched.reserve(resource, "weight_load", qr, duration, bytes=size, bits=size*8,
                                   die_id=die, tile_group=r*nc+c,
                                   metadata={"layer_id": cfg.layer_id, "k_block": c,
                                             "ideal_vertical_links": cfg.ideal_mem_die,
                                             "queue_wait_cycles": qr-ready})
                queue_free[qi] = ev.end_cycle
                req = MemDieRequest(die, cfg.layer_id, r, c, (r*nc+c)*cfg.pe_per_tile*17,
                                    size, tag, ev.start_cycle, tile_id=r*nc+c,
                                    batch_id=0, k_block=c)
                requests.append(req)
                responses.append(MemDieResponse(die, tag, None, 0, ev.end_cycle,
                                                cycle=ev.end_cycle, tile_id=r*nc+c,
                                                batch_id=0, k_block=c))
                first = ev.start_cycle if first is None else min(first, ev.start_cycle)
                done = max(done, ev.end_cycle)
        weight_cycles.append([first or ready, done])
        return done

    if not per_pe_rram and not warm and cfg.weights_resident:
        weight_ready = load_weights(0, 0)

    # Explicit FeRAM transaction workload. Live occupancy is separate from
    # cumulative traffic; without a supplied live size capacity is unknown.
    kv_read_end = 0
    if fr:
        rname = "Mem shared channel" if cfg.ferram_channel_mode == "shared" else "FeRAM read"
        ev = sched.reserve(rname, "kv_read", 0,
                           cfg.ferram_kv_read_latency+ceil(fr/cfg.ferram_kv_read_bytes_per_cycle),
                           bytes=fr, bits=fr*8)
        kv_read_end = ev.end_cycle

    input_free, logits_free = [0]*input_copies, [0]*log_copies
    vector_ends, vector_starts, array_starts, first_load = [], [], [], None
    gate = 0
    red_depth = ceil(log2(nc)) if cfg.reduction_style == "tree" else nc-1
    red_cycles = (cfg.sa_pipeline_levels or red_depth) if nc > 1 else 0
    nonmac = ds.rtl_params.get("nonmac", {})
    if parallel and cfg.enable_softmax:
        from .nonmac import NonmacCost
        soft_cost = parallel_cost(parallel, "softmax", cfg.m, allow_pending=True)
        # Input adaptation/local scratch are included in the supplied complete
        # function cost. Do not add legacy serial-engine staging a second time.
        stage_cost = NonmacCost(cfg.m)
    elif ds.components and cfg.enable_softmax:
        from .nonmac import NonmacCost
        # Numerical softmax still executes. Missing physical measurements do
        # not get substituted with one of the older alternatives in the file.
        soft_cost = NonmacCost(cfg.m, pj=None, reads=3*cfg.m, writes=2*cfg.m)
        stage_cost = NonmacCost(cfg.m, pj=None, writes=cfg.m)
    else:
        soft_cost = command_cost(nonmac, "softmax", cfg.m) if cfg.enable_softmax else None
        stage_cost = staging_cost(nonmac, cfg.m) if cfg.enable_softmax else None
    soft_cycles = soft_cost.cycles + stage_cost.cycles if soft_cost else 0
    prefetch_each = []

    rtl_command_free = 0
    for v in range(nv):
        if v and v % micro == 0:
            gate = max(vector_ends[-micro:])
        ib, ob = v % input_copies, v % log_copies
        # A shared non-MAC vector engine conservatively completes one command
        # before the next matrix starts. The new 1024-lane architecture has no
        # supplied initiation interval or inter-vector overlap calibration yet.
        ready = max(gate, input_free[ib], rtl_command_free)
        vector_starts.append(ready)
        bid = v if cfg.workload == "gemv" else v//cfg.n
        # Scales are always inspected, even when payload is suppressed.
        # Weight scales reside alongside the resident Tile weights; their
        # local metadata accesses are separately reported below.
        scale_cycles = ceil(nc/lanes)*cfg.gsram_scale_read_cycles
        ev = sched.reserve("Global SRAM", "input_scale_read", ready, scale_cycles,
                           bytes=nc, bits=nc*8, batch_id=bid,
                           metadata={"vector_id": v, "input_buffer": ib,
                                     "scale_only": True, "all_k_blocks": True})
        if not per_pe_rram and not cfg.weights_resident:
            weight_ready = load_weights(max(ready, max(vector_ends, default=0)), v)
        ctrl = sched.reserve("MX controller", "scale_block_decision",
                             max(ev.end_cycle, weight_ready),
                             cfg.mx_control_cycles if cfg.mx_metadata_available else 0,
                             batch_id=bid,
                             metadata={"vector_id": v, "decision_inputs": ["E8M0_IN", "E8M0_W"],
                                       "e3_m10_used": False, "threshold_bits": cfg.mx_skip_threshold_bits,
                                       "enabled": bool(cfg.enable_mx_block_skip and cfg.mx_metadata_available
                                                       and cfg.mx_skip_threshold_bits is not None),
                                       "active_pe_blocks": active_blocks[v],
                                       "weight_scale_metadata_bytes": cfg.m*nc if cfg.mx_metadata_available else 0})
        # K-block modulo-bank mapping: sparse requests to the same bank
        # cannot be collapsed into a fictitious wider source cycle.
        bank_load = np.bincount(np.flatnonzero(source_masks[v]) % cfg.gsram_banks,
                                minlength=cfg.gsram_banks)
        pc = max(ceil(source_counts[v]/lanes), int(bank_load.max()))*cfg.gsram_read_cycles
        prefetch_each.append(pc)
        ev = sched.reserve("Global SRAM", "input_prefetch", ctrl.end_cycle, pc,
                           bytes=source_counts[v]*16, bits=source_counts[v]*128,
                           batch_id=bid, metadata={"vector_id": v, "source_lanes": lanes,
                                                   "payload_only": True, "mx_decision_before_payload": True,
                                                   "input_buffer": ib, "active_banks": min(lanes, source_counts[v])})
        bc_kwargs = dict(bytes=receiver_counts[v]*17, bits=receiver_counts[v]*136,
                         batch_id=bid, metadata={"vector_id": v, "tile_receivers": receiver_counts[v],
                                                "format": "MXFP4 payload + E8M0 scale"})
        if network:
            ev = sched.reserve_pipeline("Broadcast", "input_broadcast", ev.end_cycle,
                 network["vectors"][v]["broadcast"]["latency_cycles"],
                 ds.interconnect["broadcast_issue_cycles"], **bc_kwargs)
        else:
            ev = sched.reserve("Broadcast", "input_broadcast", ev.end_cycle,
                 (broadcast_cycles if cfg.broadcast_style == "wide" else pc) if source_counts[v] else 0,
                 **bc_kwargs)
        ev = sched.reserve("TAG format adapter", "mxfp4_to_tag_fp", ev.end_cycle,
                           cfg.tag_decode_cycles if receiver_counts[v] else 0,
                           batch_id=bid,
                           metadata={"vector_id": v, "after_broadcast": True,
                                     "decoded_elements": receiver_counts[v]*cfg.tile_k,
                                     "zero_mask_scope": "PE-local RRAM read enables and PE lane gating"})
        memory_ready = weight_ready
        if per_pe_rram:
            plan = read_plans[v]
            ids = plan.mc_ids.ravel()
            starts = np.maximum(ev.end_cycle, mc_next_issue[ids])
            # Include skip decisions too: 0.3389 pJ is a real MC decision,
            # rather than free inactivity. Unmapped controllers are idle.
            for wave, start in enumerate(np.unique(starts)):
                mask = starts == start
                wave_ids = ids[mask]
                masks = plan.element_enable_mask.ravel()[mask]
                nread = int(np.count_nonzero(masks))
                mc_ev = sched.reserve(f"PE-local MC wave {v}:{wave}", "rram_pe_control",
                    int(start), cfg.mc_read_cycles, die_id=die, batch_id=bid,
                    metadata={"vector_id":v, "controllers":int(mask.sum()),
                        "read_requests":nread, "skip_decisions":int(mask.sum())-nread,
                        "mc_ids":wave_ids.tolist(), "element_enable_mask":masks.tolist(),
                        "payload_word_bits":128, "element_enable_bits":32,
                        "max_outstanding_per_mc":1,
                        "queue_wait_cycles":int(start)-ev.end_cycle,
                        "external_channels_used":False,
                        "block_gate_source":"E8M0 scale distance only",
                        "element_gate_source":"input TAG zero metadata before weight read"})
                mc_next_issue[wave_ids] = max(int(start)+cfg.mc_issue_cycles,mc_ev.end_cycle)
                end = mc_ev.end_cycle
                if nread:
                    group_bits = cfg.rram_read_granularity_bits
                    wave_bits = sum(int(np.count_nonzero(masks & np.uint32(((1<<(group_bits//4))-1)<<offset)))*group_bits
                                    for offset in range(0,32,group_bits//4))
                    data_ev = sched.reserve(f"PE-local RRAM wave {v}:{wave}", "rram_pe_read",
                        end, cfg.rram_array_read_cycles+cfg.phy_read_cycles,
                        bytes=ceil(wave_bits/8), bits=wave_bits, die_id=die, batch_id=bid,
                        metadata={"vector_id":v, "read_requests":nread,
                            "parallel_local_links":True,
                            "rram_array_cycles":cfg.rram_array_read_cycles,
                            "phy_cycles":cfg.phy_read_cycles})
                    end = data_ev.end_cycle
                    # One outstanding read per local controller. A later
                    # request cannot reuse it while its physical response is
                    # still in flight, even if the nominal issue slot is free.
                    reading_ids=wave_ids[masks!=0]
                    mc_next_issue[reading_ids]=np.maximum(mc_next_issue[reading_ids],end)
                memory_ready = max(memory_ready, end)
            mc_vector_ready.append(memory_ready)
        comp_ready = max(ev.end_cycle, memory_ready, kv_read_end)
        ev = sched.reserve("PE array", "array_mac", comp_ready,
                           timing["compute_cycles"] if active_each[v] else 0,
                           batch_id=bid, metadata={"vector_id": v, "active_mac": active_each[v],
                                                   "active_pe": pe_work_blocks[v],
                                                   "enabled_pe_blocks": active_blocks[v],
                                                   "active_tiles": receiver_counts[v],
                                                   "simultaneous_array_activation": True})
        array_starts.append(ev.start_cycle)
        input_free[ib] = ev.end_cycle
        if ds.components:
            ev = sched.reserve("Tile non-PE", "tile_nonpe_step", ev.end_cycle,
                ceil(cost(ds.components,"tile_nonpe","latency_ns")) if receiver_counts[v] else 0,
                batch_id=bid, metadata={"vector_id":v,"parallel_tiles":receiver_counts[v],
                                       "format_adapters_combined_latency":True})
        red_kwargs = dict(bytes=ceil(active_blocks[v]*cfg.partial_bits/8), bits=active_blocks[v]*cfg.partial_bits,
                          batch_id=bid, metadata={"vector_id": v, "stages": red_depth})
        if network:
            link_cycles = network["vectors"][v]["reduction"]["latency_cycles"]
            ev = sched.reserve_pipeline("MX reduction", "aligned_reduce", ev.end_cycle,
                 red_cycles+link_cycles, ds.interconnect["reduction_issue_cycles"],
                 **red_kwargs)
            ev.metadata.update(arithmetic_cycles=red_cycles, link_cycles=link_cycles,
                               topology="parallel binary reduction trees")
        else:
            ev = sched.reserve("MX reduction", "aligned_reduce", ev.end_cycle, red_cycles, **red_kwargs)
        ev = sched.reserve("Global SRAM", "logits_write", max(ev.end_cycle, logits_free[ob]),
                           cfg.gsram_write_latency+ceil(logbytes/cfg.gsram_write_bytes_per_cycle), bytes=logbytes, bits=logbytes*8,
                           batch_id=bid, metadata={"vector_id": v, "logits_buffer": ob})
        if cfg.enable_softmax:
            if not parallel:
                ev = sched.reserve("FP32 non-MAC", "reduce_to_fp32_scratch", ev.end_cycle,
                                   stage_cost.cycles, bytes=stage_cost.writes*4,
                                   batch_id=bid, metadata={"vector_id":v,"profile":f"reduce_staging/{cfg.m}"})
            ev = sched.reserve("FP32 non-MAC", "stable_softmax", ev.end_cycle, soft_cost.cycles,
                               bytes=(soft_cost.reads+soft_cost.writes)*4,
                                batch_id=bid, metadata={"vector_id": v, "passes":None if parallel else 3,
                                    "implementation":"parallel_fp32_1024" if parallel else "llm_nonmac_fp32",
                                    "parallel_lanes":1024 if parallel else None, "profiles":list(soft_cost.profiles),
                                   "read_count":soft_cost.reads,"write_count":soft_cost.writes,
                                   "source":ds.source_path or "TEST_ONLY"})
            ready_out = ev.end_cycle
        else:
            ready_out = ev.end_cycle
        if cfg.enable_softmax:
            rtl_command_free = ready_out
        logits_free[ob] = ready_out
        vector_ends.append(ready_out)
        if first_load is None:
            first_load = weight_ready
    if fw:
        rname = "Mem shared channel" if cfg.ferram_channel_mode == "shared" else "FeRAM write"
        sched.reserve(rname, "kv_write", max(vector_ends, default=0),
                      cfg.ferram_kv_write_latency+ceil(fw/cfg.ferram_kv_write_bytes_per_cycle),
                      bytes=fw, bits=fw*8)
    trace = sorted(sched.events, key=lambda e: (e.start_cycle, e.end_cycle, e.resource))
    total = max((e.end_cycle for e in trace), default=0)
    occupancy = {r: sum(z-a for a,z in intervals) for r,intervals in sched.calendar.items()}
    scalar_occupancy = {k:v for k,v in occupancy.items() if not k.startswith("Mem Die")}
    mem_active = sum(z-a for a,z in weight_cycles)
    cold = weight_cycles[0][1]-weight_cycles[0][0] if weight_cycles else 0
    array_active = occupancy.get("PE array", 0)
    useful_macs = sum(active_each)
    peak = cfg.pe_count*cfg.tile_k
    logits_reads = 0  # non-MAC scratch traffic is included in measured command profiles
    exp_bytes = 0
    sram_reads = src*16 + nc*nv + (logbytes*nv*logits_reads if cfg.enable_softmax else 0) + exp_bytes
    sram_writes = logbytes*nv
    partial_bits = sum(active_blocks)*cfg.partial_bits
    regbits = recv*tile_i_logic_bits
    e = ds.energy
    e.validate(allow_missing=bool(ds.components))
    adds = cfg.m*(nc-1)*nv
    dynamic = {
        "mem_die_read_pj": price(cold_bytes+runtime_read_bits/8,e.rram_read_pj_per_byte),
        "hybrid_bond_phy_pj": price(cold_bytes*8+runtime_read_bits,e.hybrid_bond_pj_per_bit),
        "mc_read_pj": price(runtime_read_words,e.mc_read_pj),
        "mc_skip_pj": price(runtime_skip_words,e.mc_skip_pj),
        "tile_weight_write_pj": price(loads*cfg.m*nc*(32*5+8),e.tile_weight_write_pj_per_bit),
        "gsram_read_pj": price(sram_reads/16,e.gsram_read_pj_per_128b),
        "gsram_write_pj": price(sram_writes/16,e.gsram_write_pj_per_128b),
        "broadcast_pj": price(recv*136,e.broadcast_pj_per_bit),
        "tile_reg_write_pj": price(regbits,e.tile_reg_write_pj_per_bit),
        "pe_mac_pj": price(useful_macs,e.pe_mac_pj),
        "mx_alignment_pj": price(shift_bits,e.alignment_pj_per_bit),
        "mx_control_pj": price(cfg.m*nc*nv if cfg.mx_metadata_available else 0,e.mx_control_pj_per_block),
        "tag_format_decode_pj": price(recv*cfg.tile_k,e.tag_decode_pj_per_element),
        "reduction_pj": price(adds,e.reduction_add_pj),
        "partial_interconnect_pj": price(partial_bits,e.partial_link_pj_per_bit),
        "fp32_conversion_pj": price(cfg.m*nv if not cfg.enable_softmax else 0,e.fp32_conversion_pj),
        "softmax_pj": price(nv,soft_cost.pj) if soft_cost else 0.0,
        "nonmac_staging_pj": price(nv,stage_cost.pj) if stage_cost else 0.0,
        "ferram_read_pj": price(fr,e.ferram_read_pj_per_byte),
        "ferram_write_pj": price(fw,e.ferram_write_pj_per_byte),
    }
    if ds.components:
        # Whole-module operations, never multiplied once again by 32 lanes.
        records = ds.components["records"]
        pe_steps = sum(pe_work_blocks)
        dynamic.update(mc_read_pj=price(runtime_read_words,cost(ds.components,"mc","read_pj")),
            mc_skip_pj=price(runtime_skip_words,cost(ds.components,"mc","skip_pj")),
            pe_mac_pj=price(pe_steps,cost(ds.components,"PE_ALL")),
            mx_control_pj=price(cfg.m*nv if cfg.mx_metadata_available else 0,cost(ds.components,"mx_scale32")),
            tag_format_decode_pj=price(recv,cost(ds.components,"mxfp4_to_tagfp4_32")),
            weight_format_decode_pj=price(runtime_read_words,cost(ds.components,"rfp4_to_tagfp4_32")),
            # Tile non-PE already includes its local alignment/control; do
            # not add generic per-bit alignment/register prices a second time.
            tile_nonpe_pj=price(recv,cost(ds.components,"tile_nonpe")),
            tile_reg_write_pj=0.0, mx_alignment_pj=0.0,
            reduction_pj=price(cfg.m*nv if nc>1 else 0,cost(ds.components,"bf16_align_add32")),
            fp32_conversion_pj=0.0 if nc>1 else None)
        unit = ds.components["phy_energy_unit"]
        dynamic["hybrid_bond_phy_pj"] = price(runtime_read_bits/(128 if unit=="128bit" else 1),
                                               cost(ds.components,"phy") if unit else None)
        # Count whole SRAM macro accesses, including the 8-bit sideband.
        # Logits pack 4 FP32 values in each 128-bit payload word. The selected
        # macro pair is part of the characterization contract; never reuse the
        # historical 1024-row price when a 128-row macro is selected.
        sram = sram_layout(ds.components)
        payload = records[sram["payload_macro"]]
        scale = records[sram["scale_macro"]]
        dynamic["gsram_read_pj"] = (src*128*payload["read_pj_per_bit"] +
            nc*nv*8*scale["read_pj_per_bit"])
        # Writes are charged per 128-bit payload word. The final word is
        # physically written at full macro width, so ceil() is intentional.
        dynamic["gsram_write_pj"] = ceil(logbytes/16)*nv*128*payload["write_pj_per_bit"]
        dynamic["weight_scale_metadata_pj"] = None if cfg.mx_metadata_available else 0.0
        if cfg.rram_read_granularity_bits < 128:
            # Digital link still carries one 128-bit masked response word;
            # do not assume wire/MC energy scales with enabled RRAM columns.
            dynamic["hybrid_bond_phy_pj"] = price(runtime_read_words*(128 if unit=="bit" else 1),cost(ds.components,"phy") if unit else None)
        dynamic["softmax_external_sram_pj"] = None if cfg.enable_softmax else 0.0
    if network:
        # Replaces generic link costs. Existing arithmetic/Tile/register/PHY
        # module prices are preserved and never charged as router activity.
        dynamic["broadcast_pj"] = network["totals"]["broadcast"]["dynamic_pj"]
        dynamic["partial_interconnect_pj"] = network["totals"]["reduction"]["dynamic_pj"]
    missing_energy = [k for k,v in dynamic.items() if v is None]
    known_dynamic = float(sum(v for v in dynamic.values() if v is not None))
    energy = {**dynamic, "components_pj": dynamic,
              "known_dynamic_pj":known_dynamic, "missing_components":missing_energy,
              "total_dynamic_pj":None if missing_energy else known_dynamic,
              "leakage_pj":price(total,e.leakage_pj_per_cycle)}
    energy["total_pj"] = None if missing_energy or energy["leakage_pj"] is None else known_dynamic+energy["leakage_pj"]
    energy.update(batch=cfg.batch, vectors=nv, total_pj_per_vector=None if energy["total_pj"] is None else energy["total_pj"]/nv,
                  pj_per_mac_total=None if energy["total_pj"] is None else energy["total_pj"]/(cfg.m*cfg.k*nv), leakage_busy_cycles=total)
    provenance = {}
    for f in fields(EnergyParams):
        if f.name in ("provenance", "sources") or f.name in HOST_DMA_ENERGY_FIELDS:
            continue
        detail = e.sources.get(f.name, getattr(ds, "provenance", {}).get(f.name, e.provenance or "placeholder/assumption"))
        category = "measured" if detail.startswith("measured:") else "technology-derived" if detail.startswith(("derived:", "rtl:")) else "user-supplied" if detail.startswith("user-supplied") else "placeholder/assumption"
        provenance[f.name] = {"value": getattr(e, f.name), "category": category, "detail": detail}
    uncertain = [k for k,v in provenance.items() if v["category"] == "placeholder/assumption"]
    # A compact dependency-chain view is retained for consumers that need
    # stage names. The reservation trace and critical_path remain the
    # authoritative overlapped schedule.
    logits_write_cycles = cfg.gsram_write_latency+ceil(logbytes / cfg.gsram_write_bytes_per_cycle)
    dependency_path = {
        "input_scale_read": ceil(nc/lanes)*cfg.gsram_scale_read_cycles,
        "mx_control": cfg.mx_control_cycles if cfg.mx_metadata_available else 0,
        "input_prefetch": max(prefetch_each, default=0),
        "input_broadcast": broadcast_cycles if cfg.broadcast_style == "wide" else max(prefetch_each, default=0),
        "tag_format_decode": cfg.tag_decode_cycles,
        "array_mac": timing["compute_cycles"],
        "reduction": red_cycles + (max(v["reduction"]["latency_cycles"] for v in network["vectors"]) if network else 0),
        "logits_write": logits_write_cycles,
        "softmax": soft_cycles,
        "total": total,
        "note": "stage values are a dependency-chain view; shared-resource overlap is represented by critical_path and trace events",
    }
    report = {
        "nonmac": {"implementation":"llm_nonmac_fp32", "scope":nonmac.get("scope"),
            "matrix_command_serialization": True,
            "parameter_source": ds.source_path or "TEST_ONLY",
            "profiles": list(soft_cost.profiles+stage_cost.profiles) if soft_cost else [],
            "scratch_read_count": (None if parallel else nv*soft_cost.reads) if soft_cost else 0,
            "scratch_write_count": (None if parallel else nv*(soft_cost.writes+stage_cost.writes)) if soft_cost else 0,
            "scratch_bytes": workspace, "numeric_reference":"Python functional reference, not timing/power"},
        "model_version": "3.5-parallel-interconnect", "prediction_unit": "one accelerator GEMV/GEMM invocation",
        "evaluation_scope": {"boundary":"inputs already in Global SRAM and weights provisioned in RRAM; results available on accelerator",
            "host_included":False, "dma_included":False, "weight_provisioning_included":False},
        "architecture": {"tiles": cfg.tile_count, "tile_rows": cfg.physical_tile_rows,
            "tile_cols": cfg.physical_tile_cols, "logical_tile_rows": nr, "logical_tile_cols": nc,
            "total_pe": cfg.pe_count, "pe_per_tile": cfg.pe_per_tile, "macs_per_compute_cycle": peak,
            "mc_count":cfg.mc_count, "mc_per_pe":1, "mc_payload_bits":128,
            "external_mem_channels":cfg.mem_die_channels,
            "weight_supply_mode":cfg.weight_supply_mode,
            "macs_per_vector": cfg.m*cfg.k, "macs_total": cfg.m*cfg.k*nv,
            "valid_macs": useful_macs, "batch": cfg.batch, "vectors": nv, "workload": cfg.workload},
        "bandwidth": {"gsram_payload_source_bits_per_cycle": lanes*128,
            "gsram_scale_source_bits_per_cycle": lanes*8,
            "nominal_source_payload_bits_per_cycle": cfg.gsram_banks*128,
            "nominal_source_scale_bits_per_cycle": cfg.gsram_banks*8,
            "broadcast_payload_bits_per_cycle": nr*nc*128,
            "broadcast_scale_bits_per_cycle": nr*nc*8,
            "active_source_payload_bits": src*128, "active_source_scale_bits": nc*nv*8,
            "active_broadcast_payload_bits": recv*128, "active_broadcast_scale_bits": recv*8,
            "effective_source_lanes": lanes, "prefetch_cycles": max(prefetch_each, default=0),
            "bank_conflict_stall_cycles": 0,
            "source_lane_stall_cycles": sum(max(0,p-1) for p in prefetch_each),
            "scope": "32 lanes refer to distinct K blocks; broadcast bits describe simultaneous Tile receivers, not source bandwidth",
            "bank_mapping": "K block modulo bank count, conflict-free issue groups; reduced banks require extra prefetch cycles"},
        "traffic": {"input_bytes_per_sample": inbytes, "fp32_logits_bytes_per_sample": logbytes,
            "output_bytes_per_sample": outbytes, "softmax_bytes_per_sample": softbytes,
            "input_bytes_total": inbytes*nv,
            "output_bytes_total": outbytes*nv, "global_sram_bank_read_bytes": src*16+nc*nv,
            "global_sram_payload_read_bytes": src*16, "global_sram_scale_sideband_bytes": nc*nv,
            "mx_input_scale_read_bytes": nc*nv,
            "mx_weight_scale_metadata_read_bytes": cfg.m*nc*nv if cfg.mx_metadata_available else 0,
            "pe_input_block_deliveries": sum(active_blocks),
            "pe_input_payload_delivered_bits": sum(active_blocks)*128,
            "pe_weight_payload_read_equivalent_bytes": sum(active_blocks)*16,
            "tag_decoded_elements": recv*cfg.tile_k,
            "global_sram_all_read_bytes": sram_reads, "global_sram_all_write_bytes": sram_writes,
            "tile_input_bytes": recv*17, "broadcast_bytes": recv*17,
            "broadcast_replication_bytes": recv*17, "tile_input_buffer_write_bytes": ceil(regbits/8),
            "partial_bytes": ceil(partial_bits/8), "partial_bits": partial_bits,
            "weight_external_bytes": cold_bytes,
            "rram_runtime_payload_read_bits":runtime_read_bits,
            "rram_runtime_payload_read_bytes":ceil(runtime_read_bits/8),
            "rram_runtime_response_slot_bits":runtime_read_words*128,
            "per_batch": {"source_payload_bits": src*128, "source_scale_bits": nc*nv*8,
                          "broadcast_payload_bits": recv*128, "broadcast_scale_bits": recv*8}},
        "skip": {"tag_element_skip": cfg.enable_tag_skip and cfg.tag_metadata_available,
            "mx_block_skip": bool(cfg.enable_mx_block_skip and cfg.mx_metadata_available and cfg.mx_skip_threshold_bits is not None),
            "active_source_blocks": src, "active_tile_receivers": recv,
            "tag_skip_scope": "input TAG zeros gate PE-local weight read enables before RRAM read; decoded weight zeros gate PE MAC only; no source traffic reduction",
            "mx_skip_scope": "scale-only PE-block gate before broadcast/decoder/PE; source payload suppressed only when every receiver skips; scale reads always counted",
            "metadata_cost": "input scale scan and resident metadata accesses counted; controller/decoder event prices loaded from selected dataset",
            "shared_input_scope": "Tile input is shared by PE_PER_TILE PEs; Tile receive suppressed only if every PE there skips; source payload suppressed only if all Tile receivers skip"},
        "cycles": {"critical_path": total, "end_to_end_cycles": total, "compute": timing["compute_cycles"],
            "timing_model": timing,
            "reduction": red_cycles, "softmax": soft_cycles, "prefetch": max(prefetch_each, default=0),
            "weight_cold_start": cold, "steady_state_batch": max(0,total-cold),
            "rram_mc_response_ready_cycles":mc_vector_ready,
            "queue_wait": sum(e.metadata["resource_wait_cycles"]+e.metadata.get("queue_wait_cycles",0) for e in trace),
            "compute_utilization": useful_macs/max(1,total*peak),
            "compute_activity_fraction": useful_macs/(cfg.m*cfg.k*nv),
            "array_busy_fraction": array_active/max(1,total),
            "broadcast_utilization": occupancy.get("Broadcast",0)/max(1,total),
            "softmax_utilization": occupancy.get("FP32 non-MAC",0)/max(1,total),
            "occupancy": scalar_occupancy,
            "resource_busy_cycles": occupancy,
            "overlap_cycles": max(0,sum(sum(z-a for a,z in intervals) for r,intervals in sched.calendar.items() if not r.startswith("Mem Die"))-max(0,total-cold)),
            "dependency_path": dependency_path,
            "pipelined": {"cycles_per_vector": total/nv, "fill_cycles": vector_ends[0],
                "steady_state_path": (vector_ends[-1]-vector_ends[0])/(nv-1) if nv>1 else vector_ends[0],
                "bottleneck_resource": max(scalar_occupancy, key=scalar_occupancy.get) if scalar_occupancy else "none"},
            "vector_start_cycles": vector_starts, "vector_end_cycles": vector_ends,
            "array_start_cycles": array_starts,
            "scheduling": "integer shared-resource reservations, buffer ownership, microbatch barriers; no router-level NoC"},
        "latency": {"clock_ns": cfg.clock_ns, "f_max_mhz": 1000/cfg.clock_ns,
            "complete_characterization":False if ds.components else ds.production,
            "uncharacterized": ["RRAM array latency", "broadcast/interconnect latency"]+
                (["softmax/staging latency"] if cfg.enable_softmax else []) if ds.components else [],
            "interpretation":"configured architectural schedule; partial module latencies, not validated end-to-end silicon timing" if ds.components else "configured architectural schedule",
            "timing_source": timing["source"],
            "end_to_end_ns": total*cfg.clock_ns,
            "known_schedule_ns": total*cfg.clock_ns,
            "dependency_path_ns": {k: (v*cfg.clock_ns if isinstance(v, (int, float)) else v)
                                     for k, v in dependency_path.items()},
            "pipelined_ns": {"per_vector": total/nv*cfg.clock_ns},
            "clock_source": timing["compute_cycles_source"]},
        "throughput": {"vectors_per_second": nv/(max(1,total)*cfg.clock_ns*1e-9),
            "macs_per_second": cfg.m*cfg.k*nv/(max(1,total)*cfg.clock_ns*1e-9)},
        "capacity": {"global_sram_bytes": cfg.global_sram_bytes, "fits_global_sram": True,
            "micro_batch": micro, "micro_batch_count": ceil(nv/micro),
            "input_buffer_demand_bytes": inbytes*micro*input_copies,
            "logits_ping_pong_bytes": logbytes*micro*log_copies,
            "softmax_output_buffer_bytes": softbytes*micro*log_copies,
            "softmax_workspace_bytes": workspace, "softmax_materialize_exp": None if parallel else True,
            "softmax_max_sum_register_bytes": (None if parallel else 8) if cfg.enable_softmax else 0,
            "softmax_logits_reads": logits_reads if cfg.enable_softmax else 0,
            "softmax_output_writes": 1 if cfg.enable_softmax else 0,
            "dma_descriptor_bytes": 0, "dma_status_bytes": 0, "dma_staging_bytes": 0,
            "allocated_global_sram_bytes": micro*per_vector_capacity,
            "allocated_global_sram_scope":"inference working-set reservation; excludes unused physical macro rows and E8M0 sideband",
            "nonmac_workspace_scope":"engine-local; included in non-MAC area/cost, not Global SRAM allocation",
            "tile_weight_logic_bits": tile_w_logic_bits, "tile_weight_logic_bytes": ceil(tile_w_logic_bits/8),
            "tile_weight_physical_bytes": tile_w_phys if not per_pe_rram else 0,
            "tile_weight_capacity_scope":"legacy A5 cache capacities below are comparison only; RRAM-per-PE does not allocate a persistent Tile weight cache" if per_pe_rram else "resident Tile A5 cache",
            "rram_weight_payload_bytes":cfg.m*nc*16,
            "rram_weight_scale_metadata_bytes":cfg.m*nc,
            "rram_response_slot_logical_bytes":cfg.mc_count*16 if per_pe_rram else 0,
            "rram_response_slot_scope":"one transient 128-bit response per MC; physical register/array implementation area not characterized",
            "tile_weight_single_buffer_bytes": tile_w_phys if not per_pe_rram else 0,
            "tile_weight_double_buffer_bytes": tile_w_phys*2 if not per_pe_rram else 0,
            "array_weight_physical_bytes": tile_w_phys*cfg.tile_count if not per_pe_rram else 0,
            "array_weight_external_mxfp4_bytes": weight_bytes,
            "array_weight_behavior_a5_bytes": ceil(tile_w_logic_bits/8)*cfg.tile_count,
            # Legacy alias: external MXFP4 payload+scale bytes, not A5 cache.
            "array_weight_rtl_bytes": weight_bytes,
            "array_weight_double_buffer_bytes": tile_w_phys*cfg.tile_count*2 if not per_pe_rram else 0,
            "tile_input_logic_bits": tile_i_logic_bits, "tile_input_logic_bytes": ceil(tile_i_logic_bits/8),
            "tile_input_physical_bytes": tile_i_phys, "tile_input_double_buffer_bytes": tile_i_phys*2,
            "array_input_physical_bytes": tile_i_phys*cfg.tile_count*input_copies,
            "tile_partial_logic_bits": cfg.pe_per_tile*cfg.partial_bits,
            "tile_partial_logic_bytes": ceil(cfg.pe_per_tile*cfg.partial_bits/8),
            "tile_partial_physical_bytes": _align(ceil(cfg.pe_per_tile*cfg.partial_bits/8)),
            "tile_partial_fp32_bytes": cfg.pe_per_tile*4, "tile_count": cfg.tile_count},
        "mem_dies": [{"die_id": d, "active": d==die and (loads>0 or runtime_read_words>0),
            "weight_bytes": cold_bytes+ceil(runtime_read_bits/8) if d==die else 0,
            "runtime_rram_payload_bytes":ceil(runtime_read_bits/8) if d==die else 0,
            "weight_payload_bytes": loads*cfg.m*nc*16+ceil(runtime_read_bits/8) if d==die else 0,
            "weight_scale_bytes": loads*cfg.m*nc if d==die else 0,
            "read_requests": len(requests)+runtime_read_words if d==die else 0,
            "response_count": len(responses)+runtime_read_words if d==die else 0,
            "active_cycles": (sum(e.end_cycle-e.start_cycle for e in trace if e.operation=="rram_pe_read") if per_pe_rram else mem_active) if d==die else 0,
            "active_cycles_scope":"sum of parallel wave service intervals; may overlap" if per_pe_rram else "load intervals",
            "cold_start_cycles": cold if d==die else 0,
            "steady_state_batch_reads": runtime_read_words if per_pe_rram and d==die else 0 if cfg.weights_resident else max(0,loads-1),
            "resident_location":"RRAM" if per_pe_rram else "Tile cache",
            "resident_after_cold_start": cfg.weights_resident and d==die} for d in range(2)],
        "mem_die_protocol": {"requests": [object_dict(q) for q in requests],
            "responses": [object_dict(q) for q in responses], "interface": "two homogeneous request/response interfaces",
            "runtime_protocol":"PE-local parallel MC waves in trace; mc_ids and 32-bit mc_element_enable_mask in exported vectors; legacy request list covers Tile cache loads only"},
        "rram_mc": {"mode":cfg.weight_supply_mode,"controllers":cfg.mc_count,"controllers_per_pe":1,
            "mapping":"mc_id=(tile_row*physical_tile_cols+k_block)*pe_per_tile+pe_id",
            "payload_word_bits":128,"scale_sideband_bits":8,"element_enable_bits":32,
            "participating_controllers_per_vector":cfg.m*nc,
            "read_requests":runtime_read_words,"skip_decisions":runtime_skip_words,
            "scale_block_skips":sum(p.scale_skipped_words for p in read_plans) if per_pe_rram else 0,
            "tag_all_zero_skips":sum(p.tag_skipped_words for p in read_plans) if per_pe_rram else 0,
            "partial_read_words":sum(p.partial_words for p in read_plans) if per_pe_rram else 0,
            "enabled_elements":sum(p.enabled_elements for p in read_plans) if per_pe_rram else 0,
            "physical_read_bits":runtime_read_bits,"physical_read_granularity_bits":cfg.rram_read_granularity_bits,
            "response_slot_bits":runtime_read_words*128,
            "mc_read_cycles":cfg.mc_read_cycles,"mc_initiation_interval":cfg.mc_issue_cycles,
            "max_outstanding_per_mc":1,
            "timing_assumption":"controller interval and single-outstanding response constraint; Sheet1 provides latency but no separate measured II",
            "external_channels_used_for_local_reads":False,
            "scale_metadata":"pre-existing E8M0 metadata; not obtained by reading gated 128-bit payload",
            "partial_cost_assumption":"active MC/PE words charged at full measured word/PE step; no unmeasured linear energy savings"},
        "ferram": {"enabled": cfg.ferram_enabled, "mode": "kv_traffic" if fr or fw else "no_kv_traffic",
            "read_bytes": fr, "write_bytes": fw, "kv_capacity_bytes": cfg.ferram_kv_capacity_bytes,
            "capacity_used_bytes": ferram_live_bytes, "capacity_status": "checked" if ferram_live_bytes is not None else "live allocation not supplied",
            "channel_mode": cfg.ferram_channel_mode,
            "scope": "explicit transaction workload; GEMV does not generate model KV traffic automatically"},
        "host_io": {"counted":False, "status":"excluded by user scope", "input_bytes":0, "output_bytes":0,
            "axi_beats":0, "descriptors":0, "descriptor_pool_capacity":0, "descriptor_setup_cycles":0,
            "host_round_trips":0, "completion_notifications":0, "descriptor_objects":[]},
        "energy": energy, "energy_provenance": "placeholder/assumption present" if uncertain else "all units sourced",
        "energy_provenance_detail": provenance, "energy_claim_ready": not uncertain,
        "uncalibrated_energy_parameters": uncertain,
        "dataset": {"name": ds.name, "source_path": ds.source_path, "rtl_source_path": getattr(ds,"rtl_source_path",None),
            "summary": ds.source_summary(), "rtl_params": getattr(ds,"rtl_params",{}),
            "parameter_status": "PARTIAL" if ds.components else "MEASURED" if ds.production else "TEST_ONLY"},
        "weights_resident": cfg.weights_resident, "weights_warm_at_entry": warm, "active_die": die,
        "area": {"status": "MEASURED" if ds.production else "TEST_ONLY",
                 "source": ds.source_path, **ds.area},
        "inactive_config_fields": {"n": "shape only in gemv" if cfg.workload=="gemv" else "consumed",
            **{k:"legacy input ignored; Host/DMA excluded from accelerator evaluation" for k in HOST_DMA_CONFIG_FIELDS},
            **({k:"Tile-cache load path only; PE-local RRAM reads use independent MC timing" for k in
                ("mem_die_latency","mem_die_channels","mem_die_bytes_per_cycle","mem_die_queue_depth","ideal_mem_die")}
               if per_pe_rram else {})},
    }
    if ds.components:
        report["area"] = area_report(ds.components,cfg)
        report["characterization"] = {k:v for k,v in ds.components.items() if k!="original_sheets"}
        sram = sram_layout(ds.components)
        payload = ds.components["records"][sram["payload_macro"]]
        scale = ds.components["records"][sram["scale_macro"]]
        payload_capacity = (sram["bank_count"] * sram["pages_per_bank"] *
                            sram["depth_words"] * payload["width_bits"] // 8)
        scale_capacity = (sram["bank_count"] * sram["pages_per_bank"] *
                          sram["depth_words"] * scale["width_bits"] // 8)
        report["global_sram"] = {
            "payload_macro": sram["payload_macro"],
            "scale_macro": sram["scale_macro"],
            "depth_words": sram["depth_words"],
            "bank_count": sram["bank_count"],
            "pages_per_bank": sram["pages_per_bank"],
            "payload_capacity_bytes": payload_capacity,
            "scale_capacity_bytes": scale_capacity,
            "physical_capacity_bytes": payload_capacity + scale_capacity,
            "configured_payload_bytes": cfg.global_sram_bytes,
            "configured_payload_capacity_status": (
                "matches_selected_macro_pair" if cfg.global_sram_bytes == payload_capacity
                else "explicit_override; does not change selected macro geometry"),
            "payload_read_pj_per_bit": payload["read_pj_per_bit"],
            "payload_write_pj_per_bit": payload["write_pj_per_bit"],
            "scale_read_pj_per_bit": scale["read_pj_per_bit"],
            "scale_write_pj_per_bit": scale["write_pj_per_bit"],
            "payload_access_latency_ns": sram["payload_access_ns"],
            "scale_access_latency_ns": sram["scale_access_ns"],
            "access_latency_status": "assumption" if (sram["payload_timing_assumed"] or
                                                        sram["scale_timing_assumed"]) else "characterized",
            "capacity_scope": "payload budget excludes the E8M0 sideband; sideband is reported separately",
            "physical_capacity_is_not_working_set": True,
        }
        report["energy_claim_ready"] = False
        report["energy_provenance"] = "Sheet1 component characterization; partial total, conservative full-step billing for partially active words"
        report["energy_provenance_detail"] = {name:dict(category="user-supplied", source=rec["source"],
            workbook_sha256=ds.components["workbook_sha256"], values={k:v for k,v in rec.items() if k!="original"})
            for name,rec in ds.components["records"].items()}
        report["uncalibrated_energy_parameters"] = missing_energy + (["leakage_pj"] if energy["leakage_pj"] is None else [])
        report["cycles"]["timing_model"]["source"] = "partial-workbook"
        report["nonmac"]["measurement_status"] = "PENDING" if cfg.enable_softmax else "disabled"
        report["nonmac"]["matrix_command_serialization"] = cfg.enable_softmax
        report["host_rram_provisioning"] = dict(included_in_inference=False,
            scope="weight image is pre-existing; provisioning costs excluded",
            weight_payload_words=cfg.m*nc, payload_bytes=cfg.m*nc*16, scale_bytes=cfg.m*nc)
    elif ds.area:
        # Historical whole-Logic-Die area includes the characterized DMA block.
        report["area"].pop("dma_mm2", None)
        report["area"]["logic_die_mm2"] = ds.area["logic_die_mm2"]-ds.area.get("dma_mm2",0)
        report["area"]["scope"] = "Logic Die excluding DMA; historical total minus supplied DMA area"
    if parallel:
        rec = parallel["operations"].get("softmax", {})
        pending_timing = cfg.enable_softmax and rec.get("latency_cycles") is None
        report["nonmac"].update(implementation="parallel_fp32_1024", scope=parallel["scope"],
            parallel_lanes=1024, billed_lanes_per_wave=1024,
            active_elements_per_vector=cfg.m, function_calls=nv if cfg.enable_softmax else 0,
            measurement_status=("PENDING" if soft_cost.pj is None or pending_timing else "USER_SUPPLIED_ESTIMATE") if cfg.enable_softmax else "disabled",
            unit_dynamic_pj=rec.get("unit_dynamic_pj"), unit_area_um2=parallel.get("unit_area_um2"),
            vector_latency_cycles=rec.get("latency_cycles"), parameter_source=parallel["source"],
            matrix_command_serialization=cfg.enable_softmax,
            cost_rule="energy=unit_pj*1024*executed_vector_calls; area=unit_area*1024 once; latency=vector_latency per parallel wave",
            scratch_access_status="covered by complete-function unit allocation; traffic details not supplied")
        report["latency"]["uncharacterized"] = [s for s in report["latency"]["uncharacterized"] if s!="softmax/staging latency"]
        if pending_timing:
            report["latency"]["uncharacterized"].append("parallel softmax vector latency")
        if cfg.enable_softmax:
            report["latency"]["uncharacterized"].append("parallel non-MAC Global SRAM interface latency")
        if pending_timing or not ds.components:
            report["latency"]["complete_characterization"] = False
        nonmac_area = parallel_area(parallel)
        if ds.components:
            report["area"]["components"]["nonmac_parallel_1024"] = nonmac_area
            if nonmac_area["total_um2"] is not None:
                report["area"]["known_component_mm2"] += nonmac_area["total_um2"]/1e6
            report["area"]["excluded"] = [s for s in report["area"]["excluded"] if s!="softmax"]
            if nonmac_area["total_um2"] is None:
                report["area"]["excluded"].append("non-MAC area pending unit characterization")
        else:
            old_nonmac = ds.area.get("nonmac_mm2")
            if ds.area and old_nonmac is not None and nonmac_area["total_um2"] is not None:
                report["area"]["logic_die_mm2"] += nonmac_area["total_um2"]/1e6-old_nonmac
            else:
                report["area"]["logic_die_mm2"] = None
            report["area"]["nonmac_mm2"] = None if nonmac_area["total_um2"] is None else nonmac_area["total_um2"]/1e6
            report["area"]["nonmac_replication"] = nonmac_area
        report["energy_claim_ready"] = False
        report["energy_provenance_detail"]["parallel_nonmac"] = dict(category="user-supplied architectural estimate",
            source=parallel["source"], rule=report["nonmac"]["cost_rule"])
    if network:
        report["interconnect"] = network
        report["energy_claim_ready"] = False
        report["energy_provenance_detail"]["interconnect"] = dict(
            category="technology-derived + architectural assumptions", source=network["source"],
            replaces=["broadcast_pj", "partial_interconnect_pj"])
        report["latency"]["uncharacterized"] = [s for s in report["latency"]["uncharacterized"]
                                                    if s != "broadcast/interconnect latency"]
        report["latency"]["uncharacterized"].append("interconnect physical timing/branch logic/output collection (topology estimate provided)")
        report["cycles"]["reduction"] = dependency_path["reduction"]
        report["cycles"]["scheduling"] += "; dedicated network latency separated from pipelined initiation interval"
        report["energy"]["interconnect_estimated_leakage_pj"] = sum(
            network["vectors"][0][stage]["physical_leakage_w"]*total*cfg.clock_ns*1e3
            for stage in ("broadcast", "reduction"))
        report["energy"]["interconnect_leakage_scope"] = "diagnostic only; whole-device leakage remains unknown; do not add twice"
    return report, trace
