"""Optional geometry-aware dedicated-tree estimate, with BookSim wire costs.

This is an analytical multicast/reduction topology model (I2), NOT BookSim
multicast simulation. The separate finite mesh experiment uses real routers.
No partial values or E3/M10 affect pre-compute broadcast gating.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np

SCHEMA = "sim-1017-interconnect/v1"


def load_interconnect(path):
    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    validate_interconnect(data)
    return data


def validate_interconnect(data):
    if data.get("schema") != SCHEMA or data.get("topology") != "dedicated_binary_trees":
        raise ValueError("unsupported interconnect schema/topology")
    if not data.get("source") or not data.get("limitations"):
        raise ValueError("interconnect requires source and explicit limitations")
    for key in ("clock_ns", "tile_pitch_mm"):
        x = data.get(key)
        if type(x) not in (int, float) or not math.isfinite(x) or x <= 0:
            raise ValueError(f"interconnect.{key} must be finite and positive")
    for key in ("physical_rows", "physical_cols", "broadcast_bits", "partial_bits",
                "broadcast_issue_cycles", "reduction_issue_cycles"):
        x = data.get(key)
        if type(x) is not int or x <= 0:
            raise ValueError(f"interconnect.{key} must be a positive integer")
    for key in ("physical_rows", "physical_cols"):
        if data[key] & (data[key]-1):
            raise ValueError("dedicated trees require power-of-two physical dimensions")
    if data["broadcast_bits"] < 136:
        raise ValueError("broadcast transport must include payload and shared scale")
    for row in data.get("wires", {}).values():
        for key in ("length_mm", "repeater_size", "retiming_stages", "repeater_segments",
                    "wire_pj_per_bit_transfer", "retiming_pj_per_bit_transfer",
                    "leakage_w_per_bit", "gated_clock_pj_per_bit_transfer"):
            x = row.get(key)
            if type(x) not in (int, float) or not math.isfinite(x) or x < 0:
                raise ValueError(f"invalid wire calibration {key}")
        if type(row["retiming_stages"]) is not int or row["retiming_stages"] < 1:
            raise ValueError("wire retiming stages must be a positive integer")
    for size in (data["physical_rows"], data["physical_cols"]):
        for level in range(size.bit_length()-1):
            _wire(data, data["tile_pitch_mm"]*2**level/2)


def _wire(data, length):
    row = data.get("wires", {}).get(f"{length:.8f}")
    if row is None or not math.isclose(row["length_mm"], length, rel_tol=1e-7):
        raise ValueError(f"no BookSim wire calibration for {length:g} mm; rerun calibration rather than extrapolating")
    return row


def _tree(data, leaves, transport_bits):
    # leaves[tree_id, leaf_id]. Leaf centers have one-pitch separation;
    # every parent sits at the midpoint of its children's centers.
    current = np.asarray(leaves, dtype=bool)
    ntrees, size = current.shape
    live_physical = size
    stage = 0
    levels = []
    for depth in range(size.bit_length()-1):
        length = data["tile_pitch_mm"]*2**depth/2
        w = _wire(data, length)
        live = int(current.sum())
        active_bits = live*transport_bits
        levels.append(dict(level_from_leaves=depth+1, length_mm=length,
            active_edges=live, physical_edges=ntrees*live_physical,
            transfer_bits=active_bits, bit_mm=active_bits*length,
            wire_pj=active_bits*w["wire_pj_per_bit_transfer"],
            retiming_pj=active_bits*w["retiming_pj_per_bit_transfer"],
            gated_clock_pj=active_bits*w["gated_clock_pj_per_bit_transfer"],
            physical_leakage_w=ntrees*live_physical*transport_bits*w["leakage_w_per_bit"],
            cycles=w["retiming_stages"]))
        stage += w["retiming_stages"]
        current = current.reshape(ntrees, -1, 2).any(axis=-1)
        live_physical //= 2
    energy = {key: float(sum(row[key] for row in levels))
              for key in ("wire_pj", "retiming_pj", "gated_clock_pj", "bit_mm", "physical_leakage_w")}
    energy["dynamic_pj"] = energy["wire_pj"]+energy["retiming_pj"]+energy["gated_clock_pj"]
    return dict(**energy, levels=levels, latency_cycles=stage if leaves.any() else 0,
                transfer_bits=sum(row["transfer_bits"] for row in levels),
                active_edges=sum(row["active_edges"] for row in levels))


def estimate_interconnect(cfg, data, receiver_masks, pe_block_masks):
    validate_interconnect(data)
    if (cfg.physical_tile_rows, cfg.physical_tile_cols) != (data["physical_rows"], data["physical_cols"]):
        raise ValueError("interconnect physical dimensions differ from simulator")
    if not math.isclose(cfg.clock_ns, data["clock_ns"], rel_tol=1e-9):
        raise ValueError("interconnect wire retiming was calibrated at a different clock")
    if cfg.partial_bits+12 > data["partial_bits"]:
        raise ValueError("partial transport container cannot fit mantissa + assumed 12 metadata bits")
    if cfg.reduction_style != "tree":
        raise ValueError("dedicated binary-tree interconnect requires tree reduction")
    nr, nc = data["physical_rows"], data["physical_cols"]
    noutputs = nr*cfg.pe_per_tile
    vectors = []
    for receivers, pe_mask in zip(receiver_masks, pe_block_masks):
        b = np.zeros((nc, nr), bool)
        b[:receivers.shape[1], :receivers.shape[0]] = receivers.T
        p = np.zeros((noutputs, nc), bool)
        p[:pe_mask.shape[0], :pe_mask.shape[1]] = pe_mask
        vectors.append(dict(broadcast=_tree(data, b, data["broadcast_bits"]),
                            reduction=_tree(data, p, data["partial_bits"])))
    if len(vectors) != len(receiver_masks):
        raise ValueError("every vector requires a PE-block mask")
    totals = {stage: {key: sum(v[stage][key] for v in vectors)
                     for key in ("dynamic_pj", "wire_pj", "retiming_pj", "gated_clock_pj",
                                 "bit_mm", "transfer_bits", "active_edges")}
              for stage in ("broadcast", "reduction")}
    return dict(schema=SCHEMA, status=data["status"], model="analytical geometry-aware dedicated trees",
        source=data["source"], topology=data["topology"], tile_pitch_mm=data["tile_pitch_mm"],
        assumed_square_die_side_mm=nr*data["tile_pitch_mm"],
        clock_ns=data["clock_ns"], physical_rows=nr, physical_cols=nc,
        broadcast_bits=data["broadcast_bits"], partial_bits=data["partial_bits"],
        vectors=vectors, totals=totals, limitations=data["limitations"],
        scheduling="parallel dedicated trees with independently reserved vector injection slots and flight latency; II values are explicit assumptions",
        broadcast_initiation_interval_cycles=data["broadcast_issue_cycles"],
        reduction_initiation_interval_cycles=data["reduction_issue_cycles"],
        clock_gating=data["clock_gating"],
        coverage="tree wires, repeaters, dedicated link pipeline registers and per-transfer gated clocks; excludes arithmetic and Tile endpoint registers",
        precompute_gate="E8M0-only PE-block decisions; column/Tile branches pruned only when no receiver needs them",
        provenance_category="technology-derived + architectural assumptions; no silicon accuracy validation")
