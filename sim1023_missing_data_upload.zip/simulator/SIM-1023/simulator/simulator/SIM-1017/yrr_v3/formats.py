"""Behavior-level data-format interfaces for V3."""
from __future__ import annotations

from typing import Any
import numpy as np

FP4_MAGNITUDES = np.array([0.0, .5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0], dtype=np.float64)
FP4_VALUES = np.concatenate((FP4_MAGNITUDES, -FP4_MAGNITUDES)).astype(np.float64)

# Reference LUT from the supplied workbook. RTL may replace these functions.
MXFP4_TO_RRAM_FP4 = {0x0: 0x0, 0x8: 0x0, 0x1: 0x1, 0x9: 0x2, 0x2: 0x4, 0xA: 0x8,
                     0x3: 0x3, 0xB: 0x5, 0x4: 0x6, 0xC: 0x9, 0x5: 0xA, 0xD: 0xC,
                     0x6: 0xB, 0xE: 0xD, 0x7: 0xE, 0xF: 0xF}
RRAM_FP4_TO_MXFP4 = {}
for _m, _r in MXFP4_TO_RRAM_FP4.items():
    RRAM_FP4_TO_MXFP4.setdefault(_r, _m)
MXFP4_TO_TAG_FP4 = {0x0: 0b00000, 0x8: 0b00000, 0x1: 0b10000, 0x9: 0b11000,
                    0x2: 0b10010, 0xA: 0b11010, 0x3: 0b10011, 0xB: 0b11011,
                    0x4: 0b10100, 0xC: 0b11100, 0x5: 0b10101, 0xD: 0b11101,
                    0x6: 0b10110, 0xE: 0b11110, 0x7: 0b10111, 0xF: 0b11111}
TAG_FP4_TO_MXFP4 = {}
for _m, _t in MXFP4_TO_TAG_FP4.items():
    TAG_FP4_TO_MXFP4.setdefault(_t, _m)
_RRAM_VALUES = np.zeros(16, dtype=np.float64)
_TAG_VALUES = np.zeros(32, dtype=np.float64)
for _m, _r in MXFP4_TO_RRAM_FP4.items():
    _RRAM_VALUES[_r] = FP4_VALUES[_m]
for _m, _t in MXFP4_TO_TAG_FP4.items():
    _TAG_VALUES[_t] = FP4_VALUES[_m]


def _map_codes(x: Any, lut: dict[int, int], width: int) -> np.ndarray:
    a = np.asarray(x, dtype=np.uint8)
    out = np.array(a & ((1 << width) - 1), dtype=np.uint8, copy=True)
    for src, dst in lut.items():
        out[a == src] = dst
    return out


def mxfp4_to_rram_fp4(payload: Any) -> np.ndarray:
    return _map_codes(payload, MXFP4_TO_RRAM_FP4, 4)


def rram_fp4_to_mxfp4(payload: Any) -> np.ndarray:
    return _map_codes(payload, RRAM_FP4_TO_MXFP4, 4)


def mxfp4_to_tag_fp(payload: Any) -> np.ndarray:
    return _map_codes(payload, MXFP4_TO_TAG_FP4, 5)


def tag_fp_to_mxfp4(payload: Any) -> np.ndarray:
    return _map_codes(payload, TAG_FP4_TO_MXFP4, 5)


def decode_rram_fp4(payload: Any, scale: Any = 127) -> np.ndarray:
    p = np.asarray(payload, dtype=np.uint8) & 0xF
    s = np.asarray(scale, dtype=np.uint8)
    return _RRAM_VALUES[p] * np.exp2(s.astype(np.int16) - 127)


def decode_tag_fp(payload: Any, scale: Any = 127) -> np.ndarray:
    p = np.asarray(payload, dtype=np.uint8) & 0x1F
    s = np.asarray(scale, dtype=np.uint8)
    return _TAG_VALUES[p] * np.exp2(s.astype(np.int16) - 127)


def w4_to_a5(w: int) -> int:
    w &= 0xF
    if (w & 7) == 0:
        return (w >> 3) << 4
    return ((w >> 3) << 4) | ((((w >> 1) & 3) + 2) << 1) | (w & 1)


def decode_fp4(payload: Any, scale: Any = 127) -> np.ndarray:
    p = np.asarray(payload, dtype=np.uint8) & 0xF
    s = np.asarray(scale, dtype=np.uint8)
    return FP4_VALUES[p] * np.exp2(s.astype(np.int16) - 127)


def encode_mxfp4(values: Any, *, group_axis: int = -1, group_size: int = 32) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray(values, dtype=np.float64)
    if x.shape[group_axis] % group_size:
        raise ValueError("the quantized axis must be divisible by group_size")
    x = np.moveaxis(x, group_axis, -1)
    groups = x.shape[-1] // group_size
    payload = np.zeros_like(x, dtype=np.uint8)
    scales = np.zeros(x.shape[:-1] + (groups,), dtype=np.uint8)
    for g in range(groups):
        sl = x[..., g * group_size:(g + 1) * group_size]
        mx = np.max(np.abs(sl), axis=-1)
        # Scale the largest finite code (6) to the block maximum.  Keeping
        # log2(6) here is essential: replacing it with the E2 exponent 2
        # changes the selected E8M0 scale by one bin for many values.
        # E8M0=255 is reserved for non-finite values, never a finite scale.
        exp = np.where(mx == 0, 127,
                       np.floor(np.log2(np.maximum(mx, 1e-300) / 6.0)) + 127)
        exp = np.clip(exp, 0, 254).astype(np.uint8)
        scales[..., g] = exp
        scaled = sl / np.exp2(exp.astype(np.int16)[..., None] - 127)
        codes = np.argmin(np.abs(np.abs(scaled)[..., None] - FP4_MAGNITUDES), axis=-1).astype(np.uint8)
        payload[..., g * group_size:(g + 1) * group_size] = codes | ((scaled < 0).astype(np.uint8) * 8)
    return np.moveaxis(payload, -1, group_axis), scales


def fp4_to_e3_m10(payload: Any, scale: Any = 127) -> tuple[np.ndarray, np.ndarray]:
    """Return the behavior-level ``(E3, M10)`` representation.

    ``M10`` is a signed ten-bit two's-complement integer whose binary point is
    eight places from the right.  The previous implementation stored a sign
    flag in bit 9 while leaving the magnitude unchanged; that is a sign/
    magnitude encoding and is not the representation used by the reduction
    model.  Keeping the conversion here canonical makes the Python model and
    future RTL adapter agree on negative values.
    """
    return values_to_e3_m10(decode_fp4(payload, scale))


def values_to_e3_m10(values: Any) -> tuple[np.ndarray, np.ndarray]:
    """Convert decoded behavior-level values to independent E3/M10 fields."""
    v = np.asarray(values, dtype=np.float64)
    sign = np.signbit(v)
    a = np.abs(v)
    e = np.where(a == 0, 0, np.floor(np.log2(np.maximum(a, 1e-300))).astype(np.int32))
    e3 = np.clip(e, -4, 3).astype(np.int8)
    mant = np.rint(np.ldexp(a, 8 - e3)).astype(np.int32)
    mant = np.clip(mant, 0, 0x1FF)
    signed = np.where(sign, -mant, mant)
    # Store signed values in ten-bit two's complement.  Zero has one canonical
    # encoding and therefore does not carry a negative-zero sign.
    m10 = signed & 0x3FF
    m10[a == 0] = 0
    return e3, m10.astype(np.int16)


def e3_m10_value(e3: Any, m10: Any) -> np.ndarray:
    m = np.asarray(m10, dtype=np.int32)
    # Accept both forms exposed by the behavior-level interface: the packed
    # 10-bit two's-complement code (0..1023) and an already sign-extended
    # Python/NumPy integer.  This avoids decoding a negative M10 twice.
    signed = np.where(m < 0, m, np.where((m & 0x200) != 0, m - 0x400, m))
    return signed.astype(np.float64) / 256.0 * np.exp2(np.asarray(e3, dtype=np.int32))


def toward_zero_shift(value: int, distance: int) -> int:
    if distance <= 0:
        return int(value)
    # ``//`` rounds negative values toward -infinity.  Hardware truncates the
    # discarded low bits toward zero, so use a sign-preserving magnitude shift.
    magnitude = abs(int(value)) >> int(distance)
    return -magnitude if int(value) < 0 else magnitude


def signed_saturate(value: int, bits: int) -> tuple[int, bool]:
    lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    clipped = min(hi, max(lo, int(value)))
    return clipped, clipped != value


def retained_bits_zero(value: int, bits: int) -> bool:
    # The rule is about the retained signed value after alignment.  Testing a
    # two's-complement bit mask would classify values such as ``-2**bits`` as
    # zero even though a non-zero contribution was present before saturation.
    return int(value) == 0


def stable_softmax(logits: Any) -> np.ndarray:
    x = np.asarray(logits, dtype=np.float64)
    z = x - np.max(x, axis=-1, keepdims=True)
    e = np.exp(np.clip(z, -745, 80))
    return e / np.sum(e, axis=-1, keepdims=True)
