from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def to_dict(result) -> dict[str, Any]:
    return result.report


def format_report(result) -> str:
    r = result.report
    if r.get("model_version") in ("3.1-behavior-events", "3.2-measured-nonmac", "3.3-per-pe-mc", "3.4-accelerator-parallel-nonmac", "3.5-parallel-interconnect"):
        a,c,b,e = (r[k] for k in ("architecture","cycles","bandwidth","energy"))
        timing = c.get("timing_model", {})
        return "\n".join([
            "Python V3 3.5 MXFP4 near-memory behavioral simulator",
            "evaluation scope: accelerator only; Host/DMA/provisioning costs excluded",
            f"array: {a['tiles']} Tiles, {a['total_pe']} PE, {a['macs_per_compute_cycle']:,} peak MAC/cycle",
            f"workload: {a['workload']}, batch={a['batch']}, vectors={a['vectors']}, {a['macs_total']:,} MAC",
            f"cycles: {c['end_to_end_cycles']} end-to-end, cold weights={c['weight_cold_start']}; average={c['pipelined']['cycles_per_vector']:.3f} cycles/vector",
            f"clock: {r['latency']['clock_ns']:g} ns (architectural input); time={r['latency']['end_to_end_ns']:.3f} ns",
            (f"timing source: {timing.get('source', r['latency'].get('timing_source', 'unknown'))}; " +
             (f"MC={timing.get('mc_read_cycles')} + PHY={timing.get('phy_read_cycles')} cycles, " if not timing.get('mem_die_latency_used',True) else
              f"Mem Die={timing.get('mem_die_latency', 'n/a')} cycles ({timing.get('mem_die_latency_source', 'n/a')}), ") +
             f"compute={timing.get('compute_cycles', 'n/a')} cycles ({timing.get('compute_cycles_source', 'n/a')}), "
             f"broadcast={timing.get('broadcast_cycles', 'n/a')} cycles ({timing.get('broadcast_cycles_source', 'n/a')})"),
            f"array: busy={c['array_busy_fraction']:.4%}, useful MAC/peak*time={c['compute_utilization']:.4%}",
            f"source: {b['gsram_payload_source_bits_per_cycle']} payload + {b['gsram_scale_source_bits_per_cycle']} scale bits/cycle; prefetch={b['prefetch_cycles']} cycles",
            f"Tile receivers: {b['broadcast_payload_bits_per_cycle']} payload + {b['broadcast_scale_bits_per_cycle']} scale bits at full-array delivery",
            f"SRAM: {r['capacity']['allocated_global_sram_bytes']:,}/{r['capacity']['global_sram_bytes']:,} B; microbatch={r['capacity']['micro_batch']}",
            (f"energy: {e['total_pj']:.6f} pJ/run, {e['total_pj_per_vector']:.6f} pJ/vector; {r['energy_provenance']}" if e['total_pj'] is not None else
             f"energy: known component subtotal={e['known_dynamic_pj']:.6f} pJ/run; full total unavailable; {r['energy_provenance']}"),
            "energy components (pJ): " + ", ".join(f"{k}={v:.4f}" if v is not None else f"{k}=UNKNOWN" for k,v in e['components_pj'].items()),
            f"finite arithmetic: {r['finite_width']['partial_bits']} bits, toward-zero, signed saturation; count={r['finite_width']['saturation_count']}",
            (f"MX block skip: {r['skip'].get('status', 'unknown')}; "
             f"Esum/Emax scales only, threshold={r['skip'].get('threshold_bits')}, "
             f"skipped={r['skip'].get('skipped_blocks', 0)} PE blocks; no E3/M10 feedback"),
            f"max abs error={r['errors']['max_abs']:.8g}, max FP32 ULP={r['errors']['max_fp32_ulp']}",
            f"FeRAM mode={r['ferram']['mode']}",
            (f"non-MAC: {r['nonmac']['parallel_lanes']} parallel FP32 lanes; status={r['nonmac']['measurement_status']}; "
             "energy/area=unit*1024, vector latency is not multiplied" if r['nonmac'].get('parallel_lanes') else
             f"non-MAC: legacy complete-command profiles ({r['nonmac']['implementation']})"),
            f"dataset: {r['dataset']['summary']}",
            ("Hardware inputs: partial workbook characterization; unknown energies are null; end-to-end timing is incomplete." if r["dataset"]["parameter_status"]=="PARTIAL" else
             "Hardware inputs: Synopsys measured JSON; results use the architectural scheduler. RTL numerical equivalence requires golden-vector validation." if r["dataset"]["parameter_status"] == "MEASURED" else "Synthetic test inputs; no hardware performance/energy claim."),
            f"RRAM: {r.get('rram_mc', {}).get('controllers')} PE-local MCs; read={r.get('rram_mc', {}).get('read_requests')}, skip={r.get('rram_mc', {}).get('skip_decisions')}; external channels={a.get('external_mem_channels')}",
            (f"interconnect: parallel dedicated trees; first broadcast={timing['broadcast_cycles']} cycles, "
             f"broadcast II={r['interconnect']['broadcast_initiation_interval_cycles']} cycle(s)/vector; geometry/technology estimate, not physical validation"
             if r.get("interconnect") else "interconnect: no topology estimate selected"),
            f"area: {r['area']}",
        ])
    raise ValueError("unsupported historical report format")


def write_json(result, path: str | Path) -> None:
    Path(path).write_text(json.dumps(result.report, indent=2), encoding="utf-8")

