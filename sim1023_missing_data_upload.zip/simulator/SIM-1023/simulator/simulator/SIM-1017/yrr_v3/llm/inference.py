"""驱动：建模型 → prefill → decode → 采样 → 输出；汇总 report / trace。

一次 `run_llm(cfg)` 做的事（严格按用户给定的流程）：

1. **主机**：prompt 文本 → token id → X 写进 MEM die（本模型里 X 就是 embedding 的输出，
   落 MEM 后每层再读回来）；
2. **prefill**：`prompt_tokens` 个 token 过 28 层。因为 `cores = 1`，**没有任何并行度**：
   权重按输出块装载并在这批 token 上常驻，但每个 token 的每个输出块都是**一个独立的
   单位块**，逐个串行；Q/K/V 算完就写回 MEM，注意力逐 `(query, key)` pair 串行，
   S 与注意力矩阵 A 都写回 MEM，再读回来做乘 V / o_proj / FFN；非 MAC 使用实测算子/长度记录。
   Q 用毕即清，K/V 留在 KV cache。
3. **decode**：`max_new_tokens` 步，每步逐层做同样的事（天然逐 token），
   上下文长度 = `prompt_tokens + t`；每步末尾跑 lm_head（149 个输出块）→ 采样 → 下一个 token。
4. **推理次数**：`n_runs` 次（本次 1 次）。每一次都完整重跑 prefill + decode；
   权重早已在 MEM die 上，不重复「装入」。

**输出**：生成的 token id 与解码文本。没有 `tokenizers` 库、运行时不联网，所以默认用
**可逆的占位分词器**（UTF-8 字节 + 偏移），保证「从输入 prompt 到输出结果」这条链路是通的、
可打印的；`--tokenizer <dir>` 指向真实的 Qwen（`vocab.json` + `merges.txt`）时用真 BPE。
**随机权重下输出必然是乱码** —— 这是硬件仿真，不是语言质量评测，README 里明说。
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np

from . import capacity, metrics, mxfp4, provenance
from .arch import ArchParams, ArchSpec, resolve_model
from .arch.families import zoo_entry
from .config import GIB, LlmConfig, LlmPrices, ModelOverride, prices_from_dataset
from ..rtl_dataset import V3Datasheet, default_1017_measured_path
from .cost import Cost, LedgerMark, ceil_div
from .core import Core, GSRAM_BYTES, REGFILE_BYTES
from .memdie import MemDie
from .qwen3 import Qwen3Config, Qwen3Params
from .schedule import SimContext, mx_bytes
from .weights import WeightImage, build_weight_image

DEFAULT_PROMPT = ("近存计算是把计算单元放到存储旁边，用 Hybrid Bonding 把逻辑 die 与 "
                  "MEM die 键合在一起，从而把权重搬运的能量降下来。")


# --------------------------------------------------------------------------
# 分词
# --------------------------------------------------------------------------

class ByteTokenizer:
    """可逆的占位分词器：`token id = offset + UTF-8 字节值`（offset = 256）。

    `decode(encode(t)) == t` 恒成立 —— 这让「输入 prompt → 输出 token → 文本」这条链路
    可以端到端验证，而**不需要**下载真实的 Qwen 词表。它不代表任何真实语义：
    随机权重下解码出来的就是乱码（README 明说）。
    """
    name = "byte-placeholder"
    offset = 256
    pad_id = 0
    vocab_size = 4096
    n_bytes = 256

    def encode(self, text: str) -> list[int]:
        return [self.offset + b for b in text.encode("utf-8")]

    def decode(self, ids: Iterable[int]) -> str:
        hi = self.offset + self.n_bytes
        bs = bytes(int(i) - self.offset for i in ids if self.offset <= int(i) < hi)
        return bs.decode("utf-8", errors="replace")

    def allowed_ids(self, vocab_size: int) -> np.ndarray | None:
        """采样时允许出现的 id。

        占位分词器只能表示 256 个字节值，所以 logits（长度 = 词表大小）里
        **只有 `[offset, offset+256)` 这段是有意义的**。不限制的话 argmax 会取到
        无法解码的 id —— 那样「prompt → 输出文本」这条链路就断了。
        """
        hi = min(self.offset + self.n_bytes, int(vocab_size))
        if hi <= self.offset:
            return None
        return np.arange(self.offset, hi, dtype=np.int64)


# GPT-2 / Qwen 的「字节 → 可打印字符」映射（byte-level BPE 用）
def _bytes_to_unicode() -> dict[int, str]:
    bs = list(range(ord("!"), ord("~") + 1)) + list(range(ord("\xa1"), ord("\xac") + 1)) + \
         list(range(ord("\xae"), ord("\xff") + 1))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return dict(zip(bs, (chr(c) for c in cs)))


_QWEN_PAT = (r"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}|"
             r" ?[^\s\p{L}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+")
_FALLBACK_PAT = (r"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\w]?\w+|\d|"
                 r" ?[^\s\w]+[\r\n]*|\s*[\r\n]+|\s+")
# Qwen3 的特殊 token（截断/补齐时用）
QWEN_IM_START, QWEN_IM_END = 151644, 151645


class QwenBpeTokenizer:
    """真实的 Qwen 字节级 BPE（`vocab.json` + `merges.txt`），纯 Python、无依赖。

    预切分用 Qwen 自己的正则；若本机装了 `regex` 模块就用**原版**模式，
    否则用文档化的近似模式（`\\w` 近似 `\\p{L}\\p{N}`），并在报告里记下用的是哪个。
    """

    def __init__(self, directory: str | Path) -> None:
        d = Path(directory)
        vp = next((p for p in (d / "vocab.json", d / "tokenizer.json") if p.exists()), None)
        vp = d / "vocab.json"
        mp = d / "merges.txt"
        if not vp.exists() or not mp.exists():
            raise FileNotFoundError(f"{d} 下需要 vocab.json 与 merges.txt")
        self.vocab: dict[str, int] = json.loads(vp.read_text(encoding="utf-8"))
        self.ranks: dict[tuple[str, str], int] = {}
        lines = mp.read_text(encoding="utf-8").splitlines()
        for i, line in enumerate(lines):
            if not line or line.startswith("#version"):
                continue
            a, _, b = line.partition(" ")
            self.ranks[(a, b)] = i
        self.b2u = _bytes_to_unicode()
        self.u2b = {v: k for k, v in self.b2u.items()}
        try:
            import regex as _re                      # type: ignore
            self.pat = _re.compile(_QWEN_PAT)
            self.pattern = "qwen-exact(regex)"
        except Exception:
            self.pat = re.compile(_FALLBACK_PAT, re.UNICODE)
            self.pattern = "approx(re; \\w 近似 \\p{L}\\p{N})"
        self.name = "qwen-bpe"
        self.vocab_size = len(self.vocab)
        self.offset = 0
        self.pad_id = self.vocab.get("<|endoftext|>", 0)

    def _bpe(self, token: str) -> list[str]:
        word = list(token)
        if len(word) < 2:
            return word
        while True:
            pairs = [(word[i], word[i + 1]) for i in range(len(word) - 1)]
            cand = [(self.ranks[p], i, p) for i, p in enumerate(pairs) if p in self.ranks]
            if not cand:
                return word
            _, i, p = min(cand)
            word = word[:i] + [p[0] + p[1]] + word[i + 2:]
            if len(word) == 1:
                return word

    def encode(self, text: str) -> list[int]:
        out: list[int] = []
        for chunk in self.pat.findall(text):
            s = "".join(self.b2u[b] for b in chunk.encode("utf-8"))
            for piece in self._bpe(s):
                out.append(self.vocab.get(piece, self.pad_id))
        return out

    def decode(self, ids: Iterable[int]) -> str:
        inv = {v: k for k, v in self.vocab.items()}
        s = "".join(inv.get(int(i), "") for i in ids)
        bs = bytes(self.u2b.get(ch, 0) for ch in s)
        return bs.decode("utf-8", errors="replace")

    def allowed_ids(self, vocab_size: int) -> np.ndarray | None:
        """真实 BPE 词表的每一个 id 都能解码 → 不限制采样。"""
        return None


def make_tokenizer(spec: str | None):
    return QwenBpeTokenizer(spec) if spec else ByteTokenizer()


def allowed_ids_of(tok, vocab_size: int) -> np.ndarray | None:
    """分词器能表示的 id 集合（`None` = 全部可表示）。"""
    fn = getattr(tok, "allowed_ids", None)
    return None if fn is None else fn(vocab_size)


def tokenize_prompt(tok, text: str, n_tokens: int) -> tuple[list[int], str]:
    """把 prompt 文本变成**恰好** `n_tokens` 个 id。

    太长 → 从**左边**按**整字符**截断（保留靠后的上下文，且解码回来是合法文本 ——
    字节级分词器若按位截断会切进一个多字节字符的中间，解出替换符）；
    太短 → 前面补 pad（保证 prompt 的末尾正对着生成的起点）。
    """
    ids = list(tok.encode(text))
    if len(ids) > n_tokens:
        kept: list[str] = []
        used = 0
        for ch in reversed(text):
            b = len(tok.encode(ch))
            if used + b > n_tokens:
                break
            kept.append(ch)
            used += b
        # 整字符截断后可能仍不足 n_tokens（一个字符就跨过预算），后面统一补 pad
        ids = list(tok.encode("".join(reversed(kept)))) if kept else ids[:n_tokens]
    if len(ids) < n_tokens:
        ids = [tok.pad_id] * (n_tokens - len(ids)) + ids
    return ids, tok.decode(ids)


# --------------------------------------------------------------------------
# 结果
# --------------------------------------------------------------------------

@dataclass
class LlmResult:
    report: dict[str, Any]
    config: LlmConfig
    generated_ids: list[int] = field(default_factory=list)
    generated_text: str = ""

    def __getitem__(self, k: str) -> Any:
        return self.report[k]


# --------------------------------------------------------------------------
# 主驱动
# --------------------------------------------------------------------------

def run_llm(cfg: LlmConfig | None = None, *, prices: LlmPrices | None = None,
            prompt: str | None = None, progress: Callable[[str], None] | None = None,
            verbose: bool = False) -> LlmResult:
    """跑一次完整的推理仿真（MXFP4 W4A4，1 core，全串行）。

    模型由 `cfg` 决定：`cfg.model_spec`（`--model` 解析出的 `ArchSpec`）优先，
    其次 `cfg.model`（`ModelOverride`，`--smoke` 用），都没有就是 Qwen3-0.6B 默认。
    """
    cfg = cfg or LlmConfig()
    calibration_path = cfg.rtl_1017_calibration_path or str(default_1017_measured_path())
    rtl_dataset = None
    if prices is None:
        if cfg.calib_path:
            raise ValueError("calib_path is retired; use rtl_1017_calibration_path / --parameters")
        rtl_dataset = V3Datasheet.from_1017_calibration(calibration_path)
        # Workload shape is configurable; installed memory capacities come
        # from the same characterization as latency and energy.
        cfg = replace(cfg, **rtl_dataset.rtl_params["llm_hardware"])
    cfg.validate()
    t_start = time.time()

    spec = _spec(cfg)
    # ---- 容量门：先算账，再分配 ----
    # 顺序不能反：`build_weight_image` 会按形状分配几十 GB 的数组，装不下的配置
    # 应该在**一个数组都没分配**之前就被拒掉，并说清是哪一项顶不下、最大能到多少。
    # 纯解析式（`capacity.py` 不分配任何数组），且与 `MemDie` 用同一个 `mx_bytes`
    # —— 自检 `test_capacity_matches_memdie_placement` 钉住逐字节相等。
    bud0 = capacity.budget(spec, cfg)
    bud = capacity.require(bud0, f"模型 {bud0.spec.family}"
                                f"（L={bud0.spec.layers} H={bud0.spec.hidden} "
                                f"V={bud0.spec.vocab}）")
    # ---- 前向模式：真数值还是形状驱动（账目与模式无关，见 capacity.resolve_forward）----
    fwd = capacity.resolve_forward(spec, cfg)
    if fwd == "shape" and cfg.kv_shadow != "none":
        # 形状驱动下 KV 的数值影子**从不被读**（`WeightImage._numeric` 同理会抛错），
        # 故把口径改成 none：省掉 8 倍的无用分配，并让容量账与真正分配的量一致。
        # 用 `replace` 造**副本**而不是就地赋值 —— `run_llm` 不该改调用者手上的配置对象。
        # 就地改会让同一个 `cfg` 在跑过一次形状驱动之后，再跑一次数值模式时静默带上
        # `kv_shadow="none"`，于是数值报告的 KV 口径与真分配的 8 倍影子对不上。
        cfg = replace(cfg, kv_shadow="none")
    if prices is None:
        pr = prices_from_dataset(dataset=rtl_dataset, phy_bpc=cfg.phy_bpc)
        filled = sorted({r.name for bill in ("whole_block", "unit")
                         for r in provenance.requirements(bill)})
    else:
        # Explicit component-test injection. These prices are never labelled measured.
        pr, filled = prices, []
    cal_info = {"filled": filled, "file_status": "MEASURED" if prices is None else "TEST_ONLY",
                "source": calibration_path if prices is None else None}
    img = build_weight_image(spec, cfg.weights, cfg.seed,
                             "shape" if fwd == "shape" else cfg.weight_cache)
    ctx = SimContext(cfg, pr, spec, img, forward=fwd)

    tok = make_tokenizer(cfg.tokenizer)
    text = DEFAULT_PROMPT if prompt is None else prompt
    prompt_ids, prompt_text = tokenize_prompt(tok, text, cfg.prompt_tokens)
    ctx.tokens = prompt_ids
    # 占位分词器只能解码一部分 id → 采样必须限制在这段里（见 ByteTokenizer.allowed_ids）
    allowed = allowed_ids_of(tok, spec.vocab)

    all_generated: list[int] = []
    per_run: list[dict[str, Any]] = []
    # ---- 账本快照：把一次运行切成 TTFT / decode 两段（供吞吐率与能量效率用）----
    # 快照而不是按阶段名猜归属：`lm_head` 既是"首 token 的那一次"也是"每个 decode 步的
    # 那一次"，看阶段名分不开。取三个点：进入循环前 / 首 token 采出后 / 每轮结束。
    m_prev = ctx.ledger.mark()
    seg_ttft = None
    seg_decode = None
    mark_points: list[dict[str, Any]] = []
    for run_i in range(cfg.n_runs):
        # 每次推理都从零开始：清 KV cache、位置归零、常驻表清空（权重仍躺在 MEM die 上）
        ctx.kv[:] = 0.0
        ctx.pos = 0
        ctx.tokens = prompt_ids
        ctx.core.reset_residency()

        h = ctx.prefill()
        gen: list[int] = []
        if cfg.max_new_tokens > 0:
            # 尾部（final_norm → lm_head → sample）只吃**最后一个位置**：logits 里只有
            # 最后一行会被 sample() 取用，prefill 的其余 127 行是死代码，不该计费。
            logits = ctx.lm_head("lm_head", 0, ctx.final_norm("lm_head", h[-1:]))
            gen.append(ctx.sample(logits, allowed))
        # 首 token 已采出（max_new_tokens == 0 时没有首 token，整段都算 prefill）
        m_first = ctx.ledger.mark()
        for step in range(1, cfg.max_new_tokens):
            h = ctx.decode_step(step, gen[-1])
            logits = ctx.lm_head("lm_head", step, ctx.final_norm("lm_head", h[-1:]))
            gen.append(ctx.sample(logits, allowed))
            if step % 64 == 0 or step + 1 == cfg.max_new_tokens:
                msg = f"    decode {step + 1}/{cfg.max_new_tokens}" \
                      f"（{time.time() - t_start:.1f} s）"
                if progress:
                    progress(msg)
                elif verbose:
                    print(msg, flush=True)
        m_end = ctx.ledger.mark()
        # 各轮的段账累加 —— `n_runs > 1` 时 ledger 是累计的，段账因此天然可加
        d_ttft = m_first - m_prev
        d_decode = m_end - m_first
        seg_ttft = d_ttft if seg_ttft is None else seg_ttft + d_ttft
        seg_decode = d_decode if seg_decode is None else seg_decode + d_decode
        mark_points.append({"run": run_i,
                            "ttft": d_ttft.as_dict(), "decode": d_decode.as_dict()})
        m_prev = m_end
        all_generated = gen
        per_run.append({"run": run_i, "generated": len(gen)})

    gen_text = tok.decode(all_generated)
    elapsed = time.time() - t_start
    report = _build_report(cfg, spec, pr, img, ctx, tok, prompt_text, prompt_ids,
                           all_generated, gen_text, elapsed, per_run,
                           seg_ttft=seg_ttft, seg_decode=seg_decode,
                           cal_info=cal_info, mark_points=mark_points, bud=bud)
    return LlmResult(report=report, config=cfg, generated_ids=all_generated,
                     generated_text=gen_text)


def _spec(cfg: LlmConfig) -> ArchSpec:
    """这次跑哪个模型：`model_spec`（`--model` 解析结果）> `model`（冒烟/覆盖）> 默认。"""
    ms = getattr(cfg, "model_spec", None)
    if isinstance(ms, ArchSpec):
        return ms
    if isinstance(ms, dict):
        # 直接塞一份 HF config.json 的内容也可以（`parse_config` 是唯一入口）
        from .arch import parse_config
        return parse_config(ms)
    if ms is not None:
        raise TypeError(f"model_spec 只能是 ArchSpec / dict / None，得到 {type(ms).__name__}")
    m = cfg.model
    if m is None:
        return ArchSpec()
    return ArchSpec(hidden=m.hidden, layers=m.layers, q_heads=m.heads,
                    kv_heads=m.kv_heads, head_dim=m.head_dim,
                    intermediate=m.intermediate, vocab=m.vocab)


def _spec_title(spec: ArchSpec, cfg: LlmConfig) -> str:
    """报告标题里的模型名 —— **按 spec 的出处算**，呈现层不猜名字。

    * 默认口径（`ArchSpec()` 的 Qwen3-0.6B 形状）逐字给「Qwen3-0.6B」，老报告不变；
    * `--smoke` 的手搭形状沿用「小模型（冒烟配置…）」的旧说法；
    * 动物园条目用它的名字（`llama-3.2-1b` 这类名字本身就是标识）；
    * 其余（本地 config.json / 内联 JSON）给「族名（出处）」或「族名 + 形状」，
      **不猜营销名** —— 猜错比不猜更糟。
    """
    src = str(getattr(spec, "source", "") or "")
    if cfg.model is not None:
        return (f"小模型（冒烟配置：hidden={spec.hidden}, layers={spec.layers}, "
                f"vocab={spec.vocab}）")
    if (spec.family, spec.hidden, spec.layers, spec.vocab) == ("qwen3", 1024, 28, 151936) \
            and src in ("", "builtin:qwen3"):
        return "Qwen3-0.6B"
    if src.startswith("zoo:"):
        return src[4:]
    if src.startswith("file:") or src == "inline-json":
        return f"{spec.family}（{src}）"
    return f"{spec.family}（L={spec.layers} H={spec.hidden} V={spec.vocab:,}）"


def _id_range(ids: np.ndarray | None) -> dict[str, Any]:
    """把「允许采样的 id 集合」写成报告里可读的一小段（一整段 id 可能上万，不整列出来）。"""
    if ids is None:
        return {"restricted": False,
                "note": "词表的每个 id 都能解码 → 不限制采样"}
    return {"restricted": True, "start": int(ids[0]), "stop": int(ids[-1]) + 1,
            "count": int(ids.size),
            "note": "占位分词器只能解码这一段 id，采样被限制在它上面，"
                    "否则生成的 token 无法还原成文本"}


# --------------------------------------------------------------------------
# report
# --------------------------------------------------------------------------

_BILLING_NOTE = (
    "**整块占用计费**（用户口径）：凡是尺寸 ≤1024x1024 的矩阵计算，都按**一整块** "
    "内部满阵列 GEMV 的开销计 —— 阵列整块占用，不看实际利用率。"
    "只有某个维超过 1024 才切块，切出来的块串行完成，最后累加一次。"
    "单位计算不含 Host/DMA、权重装载和 softmax，它们由调度器分别处理；"
    "小形状的 Attention pair 仍付出整块占用代价，"
    "所以报告里**同时**给出对照口径 `unit`（乘加按实际 MAC 数 x pe_mac_pj 计），"
    "两者在同一个 run 里并列，切换只是 LlmConfig.billing 一个字段。"
    "**本次按用户明示：先不管具体数值，重点是行为与数据流。**"
)

_ATTN_NOTE = (
    "注意力按 `(query, key)` **pair 逐个串行**（cores = 1，用户要求一次只做一个矩阵计算）："
    "每个 pair 一次 `1x128 @ 128x1` 单位块，并**重新读一遍 Q_i 与 K_j**（不复用）。"
    "这是「全串行、一个矩阵一个矩阵」的字面后果 —— 若 Q_i 在 j 循环里常驻、"
    "且 GQA 的两个 q_head 共享一次 K/V 读取，这里的访存会降为约 1/4。"
    "S 与注意力矩阵 A 都按**单个结果 + 最小 128 bit 访问**写回 MEM。"
)

# 逐 kind 的注意力补充说明（`attn_note` 的第二段，按 spec 现算）
_ATTN_KIND_NOTE = {
    "mla": "本层是 MLA（低秩 Q/KV + 解耦 rope）：**整块口径下不省块** —— 注意力仍然"
           " pair 逐个走单位块，块数只由 pair 数决定；它省的是 KV 的**字节**"
           "（每位置 `kv_lora_rank + qk_rope_head_dim` 个元素，而不是 `2 x kv_heads x head_dim`）。",
    "sliding": "本层是滑窗注意力：每个 query 只看最近 `window` 个位置，故 pair 数与 "
               "S/A 的行宽都按 `min(ctx, window)` 记。整块口径下它**不省块**"
               "（`M_e <= 1024` 都按一整块付），省的是 pair 数。prefill 内部的因果"
               "斜坡未单独扣除，故这里是**上界**；decode（T=1）时精确。",
    "plain_mha": "本层是普通 MHA（无 qk_norm、无 RoPE 之外的改动）：算子序列与全注意力"
                 "相同，差别在 spec 里的形状与开关。",
    "full": "本层是全注意力（无滑窗）：每个 query 看到全部 `ctx` 个位置。",
}


def _attn_note_of(spec: ArchSpec) -> str:
    """`attn_note` = 通用口径 + 本模型实际生效的注意力种类。"""
    kinds = sorted({spec.attn_kind_of(l) for l in range(spec.layers)})
    tail = " ".join(f"【{k}】{_ATTN_KIND_NOTE[k]}" for k in kinds)
    return f"{_ATTN_NOTE}\n本模型 {spec.layers} 层的种类：{spec.attn_kinds_summary()}。{tail}"


def _build_report(cfg: LlmConfig, spec: ArchSpec, pr: LlmPrices, img: WeightImage,
                  ctx: SimContext, tok, prompt_text: str, prompt_ids: list[int],
                  gen_ids: list[int], gen_text: str, elapsed: float,
                  per_run: list[dict[str, Any]],
                  seg_ttft: LedgerMark | None = None,
                  seg_decode: LedgerMark | None = None,
                  cal_info: dict[str, Any] | None = None,
                  mark_points: list[dict[str, Any]] | None = None,
                  bud: capacity.Budget | None = None) -> dict[str, Any]:
    led = ctx.ledger
    tot = led.totals()
    by_cat = led.by_cat()
    by_phase = led.by_phase()
    by_kind = led.by_kind()
    c = ctx.cost
    apar = ArchParams(spec)

    cycles_serial = led.total_cycles(1)
    ns_serial = cycles_serial * pr.clock_ns
    phy_bits = tot["phy_bytes"] * 8
    ns_at_bpc1 = phy_bits * pr.phy_ps_per_bit / 1000.0
    ns_at_bpc_default = phy_bits / pr.phy_bpc * pr.phy_ps_per_bit / 1000.0

    L, H = spec.layers, spec.hidden
    n_tok_total = cfg.n_runs * (cfg.prompt_tokens + len(gen_ids))
    # 每 token 的算子数**按 spec 现算**：逐层投影矩阵的个数（fused 算一个、MLA 算五个、
    # MoE 的专家矩阵逐层个数不同，故用第 0 层的层内矩阵数作代表）+ QK + PV，再加 lm_head。
    # Qwen3 是 7 + 2 = 9，与文档 §1.1 的公式同口径。
    n_proj = len(apar.layer_matrices(0))
    per_layer_ops = n_proj + 2
    ops_per_token = L * per_layer_ops + 1
    proj_desc = ("、".join(m.name.split(".", 1)[1]
                          for m in apar.layer_matrices(0) if m.name.endswith("_proj"))
                 or f"{n_proj} 个矩阵")

    report: dict[str, Any] = {
        "config": {
            **{k: v for k, v in cfg.__dict__.items() if k not in ("model", "model_spec")},
            "model_override": None if cfg.model is None else vars(cfg.model),
            "model_source": None if getattr(cfg, "model_spec", None) is None
                            else spec.source,
            "mem_die_gib": cfg.mem_die_bytes / GIB,
            "rram_capacity_gib": (None if cfg.rram_capacity_bytes is None
                                  else cfg.rram_capacity_bytes / GIB),
            "feram_capacity_gib": (None if cfg.feram_capacity_bytes is None
                                   else cfg.feram_capacity_bytes / GIB),
            "n_tokens_total": n_tok_total,
            "wall_clock_s": elapsed,
        },
        "model": {
            **spec.as_dict(),
            # 标题用的模型名（按 spec 出处算，见 `_spec_title`）—— 呈现层不猜名字
            "title": _spec_title(spec, cfg),
            "params": apar.accounting(),
            "quant": {"format": "MXFP4", "w_bits": cfg.w_bits, "a_bits": cfg.a_bits,
                      "group_size": cfg.group_size,
                      "activation_quantized": cfg.quantize_activations,
                      "note": "权重与激活都走 MXFP4（W4A4）；累加保持 fp32 —— "
                              "与 RTL 定点加法树是已知差异"},
        },
        # ---- 前向模式：账目与它无关，但读者必须知道这份报告是哪条路跑出来的 ----
        "forward": {
            "mode": ctx.forward,
            "kv_shadow": cfg.kv_shadow,
            "note": capacity.forward_note(spec, cfg, ctx.forward),
        },
        # 近似项 / 结构差异两分表（决策 3）。**必须是报告字段**，不能只写在正文里，
        # 否则 `--compare` 与下游读者都不知道哪些数字是「语义近似」的。
        "approximations": list(spec.approximations),
        "structure_notes": list(spec.structure_notes),
        "cost_primitive": {
            "unit_block": {
                "macs": c.macs_per_block,
                "pj": c.block_pj,
                "cycles": c.block_cycles,
                "unit_pj_by_mac": c.block_unit_pj,
                "note": "单位块 = V3 架构模型的一次内部全阵列 GEMV（1,048,576 MAC），"
                        "权重已装载、无 Host/DMA、无 softmax；指数移位活动基线为 0。"
                        "RRAM 权重装载、Attention softmax 由调度器另计。"
                        "这是结构和已配置单价的估计，实测指标仍受来源门约束。",
            },
            "nonmac": {"implementation":"llm_nonmac_fp32", "scope":pr.nonmac.get("scope"),
                       "source":pr.provenance.get("nonmac"),
                       "profiles_used":sorted({p for r in led.rows() for p in r.nonmac_profiles})},
            "mem": {"rd_pj_per_128b": pr.mem_rd_pj_per_128b, "wr_pj_per_128b": pr.mem_wr_pj_per_128b,
                    "rd_ns": pr.mem_rd_ns, "wr_ns": pr.mem_wr_ns,
                    "feram_rd_pj_per_128b": pr.feram_rd_pj_per_128b,
                    "feram_wr_pj_per_128b": pr.feram_wr_pj_per_128b,
                    "feram_rd_ns": pr.feram_rd_ns,
                    "feram_wr_ns": pr.feram_wr_ns,
                    "note": "RRAM 沿用现有 MEM 参数；FeRAM 参数单独标定，None 表示待填。"
                            "数据集只给一个延迟数；本模型按字面把它当作**每次 128 bit 访问的"
                            "串行化延迟**摊到访问次数上"},
            "phy": {"pj_per_bit": pr.phy_pj_per_bit, "ps_per_bit": pr.phy_ps_per_bit,
                    "bpc": pr.phy_bpc, "hb_latency_ns": pr.hb_latency_ns,
                    "note": "phy_bpc 为 measured JSON 的单 channel payload 宽度；"
                            "phy_ps_per_bit 保留旧名，实际为每个该宽度节拍的 ps。"
                            "LLM 当前使用串行聚合搬运账本，未逐 MC 调度。"},
            "clock_ns": pr.clock_ns, "f_max_mhz": pr.f_max_mhz,
            "provenance": dict(pr.provenance),
        },
        "placement": {
            **ctx.memdie.usage(),
            "weights": img.as_dict(),
            # KV 的形状取自 **spec**（= `MemDie` 里那个 `kv_cache` 分配用的同一个
            # `kv_shape`），不取 `ctx.kv` —— 后者是宿主侧影子，形状驱动模式下不分配，
            # 拿它算会让这两个数在两种模式间不一致（账目本身并不随模式变）。
            "kv_cache_elements": int(np.prod(capacity.kv_shape(spec, ctx.max_ctx))),
            "kv_cache_bytes_fp4": capacity.kv_bytes(spec, ctx.max_ctx),
            "kv_cache_shape": list(capacity.kv_shape(spec, ctx.max_ctx)),
            "note": f"{cfg.mem_die_bytes / GIB:g} GiB 是 RRAM+FeRAM 共享总上限；"
                    "权重/激活在 RRAM，Q/K/V 在 FeRAM。",
        },
        "hybrid_memory": {
            **ctx.memdie.storage_usage(),
            "placement_policy": {
                "host_preload_weights": "rram",
                "runtime_weight_reads": "rram",
                "q_buffer": "feram (reused per layer)",
                "kv_cache": "feram (reserved for max context)",
                "attention_qk_reads": "feram (Q and K)",
                "attention_pv_reads": {"A": "rram", "V": "feram"},
            },
            "parameter_status": {
                "feram_read_energy": ("configured" if pr.feram_rd_pj_per_128b is not None
                                      else "PENDING"),
                "feram_write_energy": ("configured" if pr.feram_wr_pj_per_128b is not None
                                       else "PENDING"),
                "feram_read_latency": ("configured" if pr.feram_rd_ns is not None
                                       else "PENDING"),
                "feram_write_latency": ("configured" if pr.feram_wr_ns is not None
                                        else "PENDING"),
                "host_interface_energy": "excluded_from_inference_evaluation",
                "host_interface_latency": "excluded_from_inference_evaluation",
            },
        },
        # 容量门的**解析式**预算。放这里而不是只写进正文：`--compare` 与
        # 「换多大上下文还装得下」都要**读**它，不能只有人能看见。
        # 能装下时 `capacity.total_bytes` 与上面的 `placement.used_bytes` 逐字节相等
        # （自检 `test_capacity_matches_memdie_placement` 钉住）。
        "capacity": (bud.as_dict() if bud is not None else None),
        "core": {
            **ctx.core.as_dict(),
            "weights_resident": True,
            "resident_granularity": "输出块（1024 行 x K），装载一次、在这批 token 上常驻",
        },
        "phases": by_phase,
        "ops_by_kind": by_kind,
        "energy": {
            "billing": cfg.billing,
            "scope":"accelerator service; measured dynamic profiles plus separately billed leakage; host preprocessing/sampling excluded",
            "complete": (pr.feram_rd_pj_per_128b is not None
                         and pr.feram_wr_pj_per_128b is not None),
            "status": ("complete" if (pr.feram_rd_pj_per_128b is not None
                                       and pr.feram_wr_pj_per_128b is not None)
                       else "PARTIAL: FeRAM array energy pending RTL calibration"),
            "total_whole_block_pj": tot["whole_pj"],
            "total_unit_pj": tot["unit_pj"],
            "ratio_unit_over_whole": (tot["unit_pj"] / tot["whole_pj"]
                                      if tot["whole_pj"] else float("nan")),
            "by_cat": by_cat,
            "accumulate_whole_pj": tot["accum_whole_pj"],
            "per_token_whole_pj": tot["whole_pj"] / max(n_tok_total, 1),
            "per_token_unit_pj": tot["unit_pj"] / max(n_tok_total, 1),
            "total_whole_block_j": tot["whole_pj"] / 1e12,
            "total_unit_j": tot["unit_pj"] / 1e12,
            "note": "两栏是**同一个 run** 的两种计费，不是两次运行。"
                    "本次口径 = whole_block（见 billing_note）。",
        },
        "latency": {
            "host_io_included": False,
            "scope": "accelerator service only; host provisioning/readback, MXFP4 encoding, RoPE table generation and token selection excluded",
            "complete": pr.feram_rd_ns is not None and pr.feram_wr_ns is not None,
            "status": ("complete" if (pr.feram_rd_ns is not None and pr.feram_wr_ns is not None)
                       else "PARTIAL: FeRAM array latency pending RTL calibration; host I/O excluded"),
            "cycles_serial_1core": cycles_serial,
            "ns_serial_1core": ns_serial,
            "s_serial_1core": ns_serial / 1e9,
            "clock_ns": pr.clock_ns,
            "cycles_with_cores": {str(k): led.total_cycles(k) for k in (1, 2, 4, 8, 16)},
            "ns_with_cores": {str(k): led.total_cycles(k) * pr.clock_ns
                              for k in (1, 2, 4, 8, 16)},
            "phy_ns_at_bpc_default": ns_at_bpc_default,
            "phy_ns_at_bpc1": ns_at_bpc1,
            "phy_bpc_ratio": ns_at_bpc1 / ns_at_bpc_default if ns_at_bpc_default else None,
            "steps": {"prefill": cfg.prompt_tokens, "decode": len(gen_ids),
                      "tokens_total": n_tok_total},
            "note": "cores > 1 的那几栏是**上界乐观**的摊薄（可并行 op 按 min(C, count) 除），"
                    "真实调度还要处理依赖与同步；能耗不随 cores 变（C x (work/C) = work）。"
                    "PHY 的两栏是同一个 phy_bytes 在两种链路宽度下的串行化时间。",
        },
        "memory_traffic": ctx.memdie.traffic(),
        "billing_note": _BILLING_NOTE,
        "attn_note": _attn_note_of(spec),
        "call_counts": {
            "operator_invocations_per_token": ops_per_token,
            "operator_invocations_total": ops_per_token * n_tok_total,
            "per_layer_operators": per_layer_ops,
            "formula": f"每 token = {L} 层 x {per_layer_ops} 算子"
                       f"（{proj_desc} 共 {n_proj} 个投影 + QK + PV）"
                       " + 1 次 lm_head —— 与 Instruction/GEMM次数统计.md §1.1 同口径。"
                       "注意这是**位置级的算法计数（结构式）**，不等于账本里的计费次数："
                       "词表投影只对需要采样的位置计费（prefill 传 1 个位置而非 "
                       f"{cfg.prompt_tokens} 个），故账本中 lm_head 的计费位置数 = 生成 token 数。",
            "unit_blocks": tot["blocks"],
            "matmul_events": int(by_cat.get("compute", {}).get("count", 0)),
            "elementwise_elements": int(tot["elements"]),
            "actual_macs": tot["macs"],
            "billed_macs_whole_block": tot["blocks"] * c.macs_per_block,
        },
        "output": {
            "prompt_text": prompt_text,
            "prompt_ids": prompt_ids,
            "prompt_ids_truncated": prompt_ids[:32],
            "generated_ids": gen_ids,
            "generated_ids_head": gen_ids[:32],
            "generated_text": gen_text,
            "tokenizer": {"name": tok.name, "vocab_size": getattr(tok, "vocab_size", None),
                          "pattern": getattr(tok, "pattern", None),
                          "allowed_ids": _id_range(allowed_ids_of(tok, spec.vocab))},
            "sampling": ("greedy(argmax)" if not cfg.temperature
                         else f"temperature={cfg.temperature}"),
            "per_run": per_run,
            "note": "随机权重下输出必然是乱码 —— 这是硬件仿真，不是语言质量评测。"
                    "默认占位分词器保证 decode(encode(t)) == t，链路可端到端验证。",
        },
        "trace": _trace(led, cfg.trace_limit) if cfg.collect_trace else [],
        "errors": _errors(ctx, spec),
    }

    # ---- 吞吐率 / 能量效率 / 单价来源门（三段一起，见 metrics.py 与 provenance.py）----
    # 正式入口已验证统一 measured JSON；显式合成测试价格不提升为 measured。
    if seg_ttft is not None and seg_decode is not None:
        filled = list((cal_info or {}).get("filled") or [])
        report.update(metrics.build(
            ttft=seg_ttft, decode=seg_decode, prices=pr,
            gen_tokens=len(gen_ids), prompt_tokens=cfg.prompt_tokens,
            billing=cfg.billing, cores_list=(1, 2, 4, 8, 16),
            filled=filled, ns_derived_share=led.ns_derived_cycles_share()["ns_derived_share"]))
        report["throughput"]["segment_marks"] = mark_points or []
        report["calib"] = {
            **(cal_info or {}),
            "path": (cal_info or {}).get("source") or None,
            "file": "calibration/rtl_1017sim/rtl_1017sim_measured.json",
            "note": "统一 Synopsys measured 参数文件；所有必需字段在加载阶段已验证，不能用 RTL/derived/fallback 补齐。",
        }
    report["execution_scope"] = {
        "metrics":"accelerator service only; excludes host preprocessing and token selection",
        "nonmac":"measured command profiles; external scratch included, leakage separately billed",
        "numeric_reference":"NumPy computes functional values, never supplies hardware cycles/energy",
        "excluded_host_operations":["MXFP4 encoding/quantization", "RoPE sin/cos table preparation", "token sampling/argmax"],
        "full_system_metrics_complete":False,
        "note":"These host operations have no implementation in the three FP32 modules; no accelerator price is assigned."}
    report["attention_mapping"] = ({"implementation": "unfused", "schedule": "legacy pair-serial"}
                                   if ctx.fused_attention is None else
                                   ctx.fused_attention.as_dict(spec.q_heads))
    if ctx.fused_attention:
        report["attn_note"] = (
            "16 context rows x 4 dimension columns/head; 64 logical tiles/head, up to 16 heads/core. "
            "Causal prefill queries run serially. Q is read once/head/query; K/V once/context/head/query. "
            "Online FP32 softmax and PV keep S/A on chip. GQA KV reads are not shared. "
            "Single-head measurements project parallel compute waves; external transfers remain serial aggregate costs.")
        report["billing_note"] = (
            "Projections/MLP retain existing prices and billing. Fused Attention uses exact single-head dynamic "
            "energy times head/query count; latency times head waves. Local MAC, softmax and KV registers "
            "are included once. Ideal KV load cycles are replaced by separately billed transfers. "
            "Bridge, multihead distribution and leakage delta are PENDING.")
        policy = report["hybrid_memory"]["placement_policy"]
        policy["attention_pv_reads"] = {"A": "local FP32 state, no external spill", "V": "feram"}
        policy["attention_intermediate_S_A"] = "not written to external memory"
        report["cost_primitive"]["fused_attention"] = report["attention_mapping"]
        pending = report["attention_mapping"]["pending"]
        for field in ("energy", "latency"):
            report[field]["complete"] = False
            report[field]["status"] = "PARTIAL: fused Attention integration measurements pending"
            report[field]["attention_pending"] = pending
        # Never promote a single-head measurement to measured full-chip tok/s.
        # Keep the priced subtotal visible as an architectural projection.
        if "throughput" in report:
            th = report["throughput"]
            th["partial_projection_per_core"] = th["per_core"]
            th["per_core"] = None
            th["status"] = "PENDING"
            th["blocked_by"] += pending
            th["blocked_release"] += [dict(name=p, needed_from="integrated Attention characterization") for p in pending]
        if "efficiency" in report:
            ef = report["efficiency"]
            ef["status"] = "PENDING"
            for entry in ef["by_billing"].values():
                entry["partial_projection_per_token_j"] = entry["per_token_j"]
                entry["per_token_j"] = None
                entry["status"] = "PENDING"
                entry["blocked_by"] += pending
        if "provenance" in report:
            pv = report["provenance"]
            missing = [dict(name=p, tier="PENDING", tier_label="external result/RTL missing",
                            source=None, blocks="fused Attention integration",
                            needed_from="integrated RTL, STA and activity power reports") for p in pending]
            pv["status"] = "PARTIAL"
            pv["n_required"] += len(missing)
            pv["n_missing"] += len(missing)
            pv["missing"] += missing
            for metric in pv["by_metric"].values():
                metric["ok"] = False
                metric["n_required"] += len(missing)
                metric["n_missing"] += len(missing)
                metric["missing"] += missing
                metric["required"] += missing
        report["execution_scope"]["attention"] = report["attention_mapping"]
    return report


def _trace(led, limit: int) -> list[dict[str, Any]]:
    """聚合后的 op 记录（`{phase, layer, kind, cat, count, cycles, pj, bytes}`）。

    行数 = 不同 `(phase, layer, kind)` 的个数（≤ 几百），远超上限时只留能耗最大的那些。
    """
    rows = [r.as_dict() | {"whole_j": r.whole_pj / 1e12} for r in led.rows()]
    rows.sort(key=lambda d: -d["whole_pj"])
    if len(rows) > limit:
        kept = rows[:limit]
        rest = rows[limit:]
        kept.append({
            "phase": "MERGED", "layer": -1, "kind": f"其余 {len(rest)} 行合并",
            "cat": "-", "count": sum(r["count"] for r in rest),
            "cycles": sum(r["cycles"] for r in rest),
            "whole_pj": sum(r["whole_pj"] for r in rest),
            "unit_pj": sum(r["unit_pj"] for r in rest),
            "macs": sum(r["macs"] for r in rest), "blocks": sum(r["blocks"] for r in rest),
            "elements": sum(r["elements"] for r in rest),
            "whole_j": sum(r["whole_pj"] for r in rest) / 1e12,
        })
        rows = kept
    return rows


def _errors(ctx: SimContext, spec: ArchSpec) -> dict[str, Any]:
    """MXFP4 往返的量化误差（数值侧的自检量，不是行为断言）。"""
    rng = np.random.default_rng(ctx.cfg.seed)
    x = rng.standard_normal((8, 1024)).astype(np.float32)
    y = mxfp4.quantize_dequantize(x)
    denom = float(np.abs(x).max()) or 1.0
    return {
        "quantizer": "MXFP4（每组 32 个元素一个 E8M0 指数，最近邻到码本 {0,.5,1,1.5,2,3,4,6}）",
        "roundtrip_max_abs_err": float(np.abs(y - x).max()),
        "roundtrip_rel_err": float(np.abs(y - x).max() / denom),
        "note": "与 RTL 的定点加法树是已知差异：本模型的累加保持 fp32。",
        "legacy_encoder_note": "**既有 `model._payload_from_values()` 有两处缺陷**"
                               "（整块共享一个指数、且负值全部丢成 -0.0），本层不使用它，"
                               "见 yrr_v3/llm/mxfp4.py 的模块 docstring 与 tests/test_llm.py。",
    }


def write_json(result: LlmResult, path: str | Path) -> None:
    Path(path).write_text(json.dumps(result.report, indent=2, ensure_ascii=False),
                          encoding="utf-8")
