"""HF `config.json` → `ArchSpec`。

三条纪律（沿用本层既有的「投放口」惯例）：

1. **族探测**走 `model_type`（其次 `architectures`），命中不了就用 `--family` 显式给；
   再命中不了就**报错并列出已知族**，不猜。
2. **必填字段缺失就硬报错并指名缺哪个键**（fail loud）。必填的是
   `hidden_size` / `num_hidden_layers` / `num_attention_heads` / `vocab_size`
   （MoE 还要 `num_experts` + `num_experts_per_tok`，MLA 还要 `kv_lora_rank`）。
   可选字段缺失走**族默认**（fail silent 在这里是安全的：族默认是已知的公开事实）。
3. **未知键只收集不报错**（同 `calib.py`）：真实 `config.json` 里总有几十个
   我们不需要的键（`torch_dtype` / `use_cache` / `bos_token_id` …），
   多出字段不该让解析失败。收集到的键名进 `report["model"]["unknown_keys"]`。

**逐字段别名**（同一语义在不同族/版本的写法）在 `_ALIASES` 里显式列出 ——
不用模糊匹配，因为 `n_head` 与 `num_key_value_heads` 这种名字一模糊就会串味。
"""
from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any

from .families import (alternating_kinds, compose, family_names, normalize_family,
                       preset, zoo_entry, zoo_names)
from .spec import ArchSpec, MlaSpec, MlpSpec, MoeSpec, NormSpec, RopeSpec

# --------------------------------------------------------------------------
# 逐字段别名：目标字段 -> 可接受的 n 个来源键（按优先级）
# --------------------------------------------------------------------------

_REQUIRED = ("hidden_size", "num_hidden_layers", "num_attention_heads", "vocab_size")

_ALIASES: dict[str, tuple[str, ...]] = {
    "hidden_size": ("hidden_size", "n_embd", "d_model", "hidden_dim"),
    "num_hidden_layers": ("num_hidden_layers", "n_layer", "num_layers", "n_layers"),
    "num_attention_heads": ("num_attention_heads", "n_head", "num_heads"),
    "num_key_value_heads": ("num_key_value_heads", "n_head_kv", "num_kv_heads",
                            "multi_query_group_num"),
    "head_dim": ("head_dim",),
    "intermediate_size": ("intermediate_size", "n_inner", "ffn_dim",
                          "ffn_hidden_size", "inter_dim"),
    "vocab_size": ("vocab_size",),
    "rms_norm_eps": ("rms_norm_eps", "layer_norm_eps", "layer_norm_epsilon", "norm_eps"),
    "max_position_embeddings": ("max_position_embeddings", "n_positions", "seq_length",
                                "max_sequence_length"),
    "rope_theta": ("rope_theta", "rotary_emb_base"),
    "partial_rotary_factor": ("partial_rotary_factor", "rotary_pct", "rotary_dim_frac"),
    "rope_scaling_type": ("rope_scaling",),
    "tie_word_embeddings": ("tie_word_embeddings",),
    "attention_bias": ("attention_bias",),
    "qkv_bias": ("qkv_bias", "query_pre_attn_scalar_bias"),
    "mlp_bias": ("mlp_bias",),
    "hidden_act": ("hidden_act", "hidden_activation", "activation_function"),
    "sliding_window": ("sliding_window", "sliding_window_size"),
    "sliding_window_pattern": ("sliding_window_pattern",),
    "layer_types": ("layer_types",),
    "n_experts": ("num_experts", "num_local_experts", "n_routed_experts",
                  "moe_num_experts", "num_experts_per_layer"),
    "top_k": ("num_experts_per_tok", "num_selected_experts", "moe_top_k",
              "num_experts_per_token"),
    "moe_intermediate": ("moe_intermediate_size", "expert_intermediate_size",
                         "moe_inter_dim", "intermediate_size_mlp"),
    "n_shared_experts": ("n_shared_experts", "num_shared_experts"),
    "shared_expert_intermediate": ("shared_expert_intermediate_size",),
    "first_k_dense_replace": ("first_k_dense_replace", "first_k_dense",
                              "num_dense_layers"),
    "shared_expert_gate": ("shared_expert_gate",),
    "kv_lora_rank": ("kv_lora_rank",),
    "q_lora_rank": ("q_lora_rank",),
    "qk_nope_head_dim": ("qk_nope_head_dim",),
    "qk_rope_head_dim": ("qk_rope_head_dim",),
    "v_head_dim": ("v_head_dim",),
    "embed_scale": ("embed_scale",),
    "attention_dropout": ("attention_dropout", "attn_pdrop"),
    "initializer_range": ("initializer_range", "init_std", "initializer_std"),
    "attn_logit_softcapping": ("attn_logit_softcapping",),
    "final_logit_softcapping": ("final_logit_softcapping",),
}

# `hidden_act` 的写法归一（HF 各族用了七八种拼法）
_ACT_ALIASES = {
    "silu": "silu", "swish": "silu", "silu_": "silu",
    "gelu": "gelu", "gelu_new": "gelu_tanh", "gelu_pytorch_tanh": "gelu_tanh",
    "gelu_fast": "gelu_tanh", "gelu_accurate": "gelu", "quick_gelu": "gelu",
    "relu": "relu", "relu2": "relu2", "squared_relu": "relu2",
}


def _pick(d: dict[str, Any], field: str) -> tuple[bool, Any, str | None]:
    """按 `_ALIASES[field]` 的优先级取第一个**存在且非 None** 的键。

    返回 `(是否命中, 值, 命中的键名)`。
    """
    for k in _ALIASES.get(field, (field,)):
        if k in d and d[k] is not None:
            return True, d[k], k
    return False, None, None


# 逐层注意力种类在 config.json 里看不出来的族：**每 period 层一次全注意力**。
# Gemma-2 的 `Gemma2Attention` 用 `layer_idx % 2` 决定，配置里只有 `sliding_window`；
# Gemma-3 有显式的 `sliding_window_pattern: 6`，走 `_ALIASES` 那条路。
_FAMILY_ATTN_PERIOD: dict[str, int] = {"gemma2": 2}


def _unwrap_text_config(d: dict[str, Any]) -> dict[str, Any]:
    """多模态 `config.json`（Gemma-3 等）把语言模型那一份藏在 `text_config` 里。

    顶层没有 `hidden_size` 而同层有 `text_config` 字典时，以 `text_config` 为准，
    并把它缺的 `model_type` / `architectures` 从顶层借过来（顶层常写 `gemma3`、
    内层写 `gemma3_text`）。语言模型那份本来就平铺的模型完全不受影响。
    """
    if "hidden_size" in d or not isinstance(d.get("text_config"), dict):
        return d
    inner = dict(d["text_config"])
    for k in ("model_type", "architectures", "torch_dtype"):
        if k in d and k not in inner:
            inner[k] = d[k]
    return inner


def detect_family(d: dict[str, Any], override: str | None = None) -> str:
    """族探测：`--family` > `model_type` > `architectures[0]`。"""
    if override:
        return normalize_family(override)
    d = _unwrap_text_config(d)
    for key in ("model_type", "model_type_"):
        v = d.get(key)
        if isinstance(v, str) and v.strip():
            try:
                return normalize_family(v)
            except KeyError:
                break
    arch = d.get("architectures")
    if isinstance(arch, list):
        for a in arch:
            if not isinstance(a, str):
                continue
            # "Qwen2ForCausalLM" / "MixtralForCausalLM" -> "qwen2" / "mixtral"
            s = a
            for suffix in ("ForCausalLM", "ForConditionalGeneration", "Model", "LMHeadModel"):
                if s.endswith(suffix):
                    s = s[: -len(suffix)]
            try:
                return normalize_family(s)
            except KeyError:
                continue
    raise KeyError(
        f"无法从 config.json 判定架构族（model_type={d.get('model_type')!r}、"
        f"architectures={arch!r}）。请显式给 `--family`。已知族：{', '.join(family_names())}")


def parse_config(d: dict[str, Any], family: str | None = None,
                 source: str = "") -> ArchSpec:
    """把一份已解析成 dict 的 HF config 变成 `ArchSpec`。"""
    d = _unwrap_text_config(d)
    fam = detect_family(d, family)
    # 族预设全程只取一次：`norm` / `rope` / `mlp` 三处组装都要以它为**底**，
    # 只覆盖文件里真给了的那几个字段。不这么写就会「用文件里的一个键把整个
    # 子结构重置成默认值」—— gemma-2 的 `post_norm` / `phi3` 的 `fused_gate_up`
    # 正是这样被吃掉的，而它们都直接改逐层的算子数。
    base_spec = preset(fam)
    explicit: dict[str, Any] = {}
    notes: list[str] = []

    # ---- 必填：形状 ----
    missing: list[str] = []
    for f in _REQUIRED:
        ok, v, k = _pick(d, f)
        if not ok:
            missing.append(f"{f}（别名：{' / '.join(_ALIASES[f])}）")
        else:
            explicit[f] = int(v)
    if missing:
        raise KeyError("config.json 缺少必填字段：" + "；".join(missing))
    explicit["vocab_size"] = int(explicit["vocab_size"])

    # ---- 可选：形状 ----
    ok, v, k = _pick(d, "num_key_value_heads")
    if ok:
        explicit["kv_heads"] = int(v)
    else:
        explicit["kv_heads"] = explicit["num_attention_heads"]      # MHA
    explicit["q_heads"] = int(explicit.pop("num_attention_heads"))
    explicit["layers"] = int(explicit.pop("num_hidden_layers"))
    explicit["hidden"] = int(explicit.pop("hidden_size"))
    explicit["vocab"] = int(explicit.pop("vocab_size"))

    ok, v, k = _pick(d, "head_dim")
    if ok:
        explicit["head_dim"] = int(v)
        explicit["head_dim_explicit"] = True
    else:
        # 未显式给出：HF 的默认是 `hidden // num_attention_heads`
        explicit["head_dim"] = explicit["hidden"] // explicit["q_heads"]
        explicit["head_dim_explicit"] = False
        notes.append(f"head_dim 未给出，按 HF 默认取 hidden / q_heads "
                     f"= {explicit['hidden']} / {explicit['q_heads']}"
                     f" = {explicit['head_dim']}")

    ok, v, k = _pick(d, "intermediate_size")
    if ok:
        explicit["intermediate"] = int(v)

    # ---- 可选：归一化 / RoPE ----
    norm_kw: dict[str, Any] = {}
    ok, v, k = _pick(d, "rms_norm_eps")
    if ok:
        explicit["rms_eps"] = float(v)          # 权威在 ArchSpec.rms_eps
    ok, v, k = _pick(d, "embed_scale")
    if ok:
        norm_kw["embed_scale"] = bool(v)
    ok, v, k = _pick(d, "attn_logit_softcapping")
    if ok:
        norm_kw["attn_logit_softcap"] = float(v)
    ok, v, k = _pick(d, "final_logit_softcapping")
    if ok:
        norm_kw["final_logit_softcap"] = float(v)
    if norm_kw:
        explicit["norm"] = replace(base_spec.norm, **norm_kw)

    rope_kw: dict[str, Any] = {}
    ok, v, k = _pick(d, "rope_theta")
    if ok:
        explicit["rope_theta"] = float(v)       # 权威在 ArchSpec.rope_theta
    else:
        # 新版 HF 把 theta 放进 `rope_parameters` / `rope_scaling`
        for holder in ("rope_parameters", "rope_scaling"):
            h = d.get(holder)
            if isinstance(h, dict) and h.get("rope_theta") is not None:
                explicit["rope_theta"] = float(h["rope_theta"])
                break
    ok, v, k = _pick(d, "partial_rotary_factor")
    if ok:
        rope_kw["partial_rotary_factor"] = float(v)
    h = d.get("rope_scaling")
    if isinstance(h, dict):
        rtype = h.get("type") or h.get("rope_type")
        if isinstance(rtype, str):
            # `llama3` 是逐频段插值：**只改频率取值、不改任何账目**（RoPE 是乘性的
            # 逐元素算子，账目由 `partial_rotary_factor` 与 theta 决定），故按 theta
            # 语义近似，并在报告里标注；不因此拒绝一份真实 checkpoint。
            rt = {"linear": "linear", "dynamic": "dynamic", "yarn": "yarn",
                  "default": "none", "longrope": "dynamic",
                  "llama3": "none"}.get(rtype.lower())
            if rt is None:
                raise KeyError(f"config.json 的 rope_scaling.type = {rtype!r} 尚未支持"
                               f"（已知：linear / dynamic / yarn / longrope / llama3）")
            rope_kw["scaling"] = rt
            # `factor` 只对真在改频率的 scaling 有意义；归一到 `none`（含 llama3
            # 的近似）时不记，免得规格里留一个「写着 32 却按 none 算」的悬空字段。
            if rt != "none" and h.get("factor") is not None:
                rope_kw["scaling_factor"] = float(h["factor"])
            if rtype.lower() == "llama3":
                notes.append("rope_scaling.type=llama3 按 theta 语义近似："
                             "逐频段插值只改频率取值，不改任何账目"
                             "（RoPE 是乘性逐元素算子）")
    if rope_kw:
        explicit["rope"] = replace(base_spec.rope, **rope_kw)

    # ---- 可选：位置上限 / 绑权重 / bias ----
    ok, v, k = _pick(d, "max_position_embeddings")
    if ok:
        explicit["max_position"] = int(v)
    for field, target in (("tie_word_embeddings", "tie_embeddings"),
                          ("attention_bias", "attention_bias"),
                          ("qkv_bias", "qkv_bias"),
                          ("mlp_bias", "mlp_bias")):
        ok, v, k = _pick(d, field)
        if ok:
            explicit[target] = bool(v)
    ok, v, k = _pick(d, "attention_dropout")
    if ok:
        # 推理时 dropout 恒为恒等，记下来只为报告里能看出它是非零的
        explicit["attention_dropout"] = float(v)
    ok, v, k = _pick(d, "initializer_range")
    if ok:
        # 只影响「模拟器内生成权重」的 std，不影响任何账目
        explicit["initializer_range"] = float(v)
    act_from_file: str | None = None
    ok, v, k = _pick(d, "hidden_act")
    if ok:
        act = _ACT_ALIASES.get(str(v).lower())
        if act is None:
            raise KeyError(f"未知的 hidden_act：{v!r}（已知：{', '.join(sorted(set(_ACT_ALIASES)))}）")
        act_from_file = act

    # ---- 可选：滑窗与逐层注意力种类 ----
    window = None
    ok, v, k = _pick(d, "sliding_window")
    if ok:
        window = int(v) if v else None
        # Qwen2 系的写法：`sliding_window` 照给 4096，但用 `use_sliding_window`
        # 明确关掉（`Qwen2Attention` 里就是 `sliding_window if use_sliding_window
        # else None`）。不读这个开关，Qwen2 / Qwen2.5 / Qwen2-MoE 会被整体算成滑窗。
        if window and d.get("use_sliding_window") is False:
            notes.append("config.json 给了 sliding_window 但 use_sliding_window=false："
                         "按全注意力计（Qwen2 系的写法）")
            window = None
        explicit["sliding_window"] = window
        explicit["default_attn_kind"] = "sliding" if window else "full"
    ok, v, k = _pick(d, "layer_types")
    if ok and isinstance(v, list):
        kinds = tuple(_layer_kind(x) for x in v)
        explicit["layer_attn_kinds"] = kinds
        if "sliding" in kinds and window is None:
            raise KeyError("layer_types 里有滑窗层，但 config.json 没给 sliding_window")
    else:
        ok, v, k = _pick(d, "sliding_window_pattern")
        # Gemma-2 的逐层交替写在建模代码里（`layer_idx % 2`），config.json 里
        # **看不出来**；但它是架构事实、直接决定每层的 pair 数，所以按族的默认周期补上。
        period = int(v) if (ok and window) else (_FAMILY_ATTN_PERIOD.get(fam, 0) if window else 0)
        if period:
            # Gemma 系：每 `pattern` 层一次全注意力，其余滑窗（"layer_types" 的紧凑写法）
            # 展开规则与动物园条目共用 `families.alternating_kinds`，不各写一遍
            explicit["layer_attn_kinds"] = alternating_kinds(explicit["layers"], period)

    # ---- 可选：MLA ----
    mla_hits = {}
    for f in ("kv_lora_rank", "q_lora_rank", "qk_nope_head_dim", "qk_rope_head_dim",
              "v_head_dim"):
        ok, v, k = _pick(d, f)
        if ok:
            mla_hits[f] = int(v)
    if mla_hits:
        if "kv_lora_rank" not in mla_hits:
            raise KeyError("config.json 有 MLA 的部分字段（"
                           f"{', '.join(sorted(mla_hits))}）但缺 kv_lora_rank")
        explicit["mla"] = MlaSpec(**mla_hits)

    # ---- 可选：MoE ----
    moe_hits: dict[str, Any] = {}
    for f in ("n_experts", "top_k", "moe_intermediate", "n_shared_experts",
              "first_k_dense_replace", "shared_expert_gate"):
        ok, v, k = _pick(d, f)
        if ok:
            moe_hits[f] = bool(v) if f == "shared_expert_gate" else int(v)
    if moe_hits:
        need = [f for f in ("n_experts", "top_k") if f not in moe_hits]
        if need:
            raise KeyError("config.json 有 MoE 的部分字段（"
                           f"{', '.join(sorted(moe_hits))}）但缺 "
                           f"{'、'.join(need)}")
        # 共享专家的宽度：单独给了就用，否则由 `shared_expert_width()` 回落到
        # `moe_intermediate`（0 就是「没单独给」）
        ok, v, k = _pick(d, "shared_expert_intermediate")
        if ok:
            moe_hits["shared_intermediate"] = int(v)
            # 给了宽度却没给个数，是 Qwen2-MoE 的写法：它的
            # `Qwen2MoeSparseMoeBlock` 只有**一个** `shared_expert`，宽度就取
            # `shared_expert_intermediate_size`，没有「几个共享专家」这个字段。
            # 不补这一笔就会数出 0 个共享专家 —— 又少算一个完整 FFN。
            moe_hits.setdefault("n_shared_experts", 1)
        explicit["moe"] = MoeSpec(**moe_hits)
        if "intermediate" not in explicit:
            # MoE 模型常只给 moe_intermediate_size；稠密层宽度取它（DeepSeek/Qwen-MoE 惯例）
            explicit["intermediate"] = explicit["moe"].moe_intermediate
            notes.append("config.json 未给 intermediate_size，稠密层宽度取 "
                         "moe_intermediate_size")

    # ---- MLP：单点组装 ----
    # `kind` 由「文件里有没有专家键」与族预设共同决定（文件优先）；`act` / `bias`
    # 同理。**组装只在这一处发生** —— 若在 MoE 分支与别处各写一次 MlpSpec，
    # 文件里的 `mlp_bias` / `hidden_act` 会漏进其中一条路径。
    base_mlp = base_spec.mlp
    if base_mlp.kind == "moe" and not moe_hits and not base_spec.is_moe:
        # 族预设声明是 MoE，文件里却没有任何专家键，**且预设自己也没有专家数**
        # （如 `qwen3_moe`：同一个族下 0.6B 与 30B-A3B 的专家数完全不同，
        # 预设给不出）。多半是拿错了 checkpoint 或 `model_type` 写错了。
        # **不能静默当稠密模型算账** —— 权重字节与每 token 的专家装载量会差
        # 一个量级，而账目看上去仍然自洽。
        raise KeyError(
            f"族 {fam!r} 的预设是 MoE，但 config.json 里没有任何专家键"
            f"（专家数：{' / '.join(_ALIASES['n_experts'])}；"
            f"激活专家数：{' / '.join(_ALIASES['top_k'])}），预设也不含专家数。"
            "若该 checkpoint 确实是稠密模型，请用 `--family` 显式指定稠密族")
    explicit["mlp"] = replace(base_mlp, kind=("moe" if moe_hits else base_mlp.kind),
                              act=(act_from_file or base_mlp.act),
                              bias=explicit.get("mlp_bias", base_mlp.bias))

    # ---- 未用到的键：只收集 ----
    # 表里列的是**本层真正读过**的键；其余（`torch_dtype` / `use_cache` /
    # `bos_token_id` / 各族的私有旋转参数…）一律进 `unknown_keys`。
    # **不预先豁免那些「肯定不会用」的键**：披露的意义就在于让读者看见
    # 这份 config 里有哪些信息被忽略了 —— 预先豁免等于把披露变成一份白名单。
    consumed = {"model_type", "architectures", "rope_parameters",
                "use_sliding_window"}
    for names in _ALIASES.values():
        consumed.update(names)
    unknown = tuple(sorted(k for k in d if k not in consumed))

    spec = compose(fam, explicit, source=source or "hf-config")
    spec = spec.replace(unknown_keys=unknown)
    if notes:
        spec = spec.replace(approximations=spec.approximations + tuple(notes))
    spec.validate()
    return spec


def _layer_kind(v: Any) -> str:
    """HF `layer_types` 的写法 → 本层的注意力种类。"""
    s = str(v).strip().lower()
    if s in ("full_attention", "full", "global_attention", "global"):
        return "full"
    if s in ("sliding_attention", "sliding", "local_attention", "local"):
        return "sliding"
    raise KeyError(f"未知的 layer_types 取值：{v!r}"
                   f"（已知：full_attention / sliding_attention）")


# --------------------------------------------------------------------------
# 入口：把 `--model` 的取值解析成 spec
# --------------------------------------------------------------------------

def load_config(path: str | Path, family: str | None = None) -> ArchSpec:
    """读一个 `config.json` 文件。"""
    p = Path(path)
    d = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(d, dict):
        raise ValueError(f"{p} 的顶层不是 JSON 对象")
    return parse_config(d, family=family, source=f"file:{p}")


def resolve_model(ref: str, family: str | None = None) -> ArchSpec:
    """`--model` 的取值：动物园名 | `config.json` 路径 | `json:{...}` | repo id。

    `huggingface_hub` 在本机不存在，所以 repo-id 这条路径是**死代码**：
    让它**干净报错并指名缺哪个包**，绝不静默回退到别的族（会静默算错账）。
    """
    s = (ref or "").strip()
    if not s:
        raise ValueError("--model 不能为空")

    # (1) 内联 JSON
    if s.startswith("json:"):
        d = json.loads(s[5:])
        if not isinstance(d, dict):
            raise ValueError("--model json: 的顶层必须是 JSON 对象")
        return parse_config(d, family=family, source="inline-json")

    # (2) 动物园名（先查，因为 `qwen3-0.6b` 这种名字也会被当成相对路径）
    try:
        spec = zoo_entry(s)
    except KeyError:
        spec = None
    if spec is not None:
        if family and normalize_family(family) != spec.family:
            raise ValueError(
                f"--model {ref!r} 是动物园条目（族 {spec.family}），"
                f"不能再给 --family {family}。带形状的动物园条目本身就是一个完整的 "
                f"spec，覆盖族名只会让形状与族名对不上。--family 只用于原始 "
                f"config.json（那里需要覆盖 model_type 的探测结果）。")
        spec.validate()
        return spec

    # (3) 本地路径：目录（含 config.json）或直接的 .json
    p = Path(s)
    if p.is_dir():
        p = p / "config.json"
    if p.is_file():
        return load_config(p, family=family)

    # (4) repo id：需要 huggingface_hub —— 本机没有，干净报错
    try:
        import huggingface_hub                                   # noqa: F401
    except ImportError as e:
        raise ImportError(
            f"--model {ref!r} 既不是动物园名（{', '.join(zoo_names())}）、"
            f"也不是本地路径。按 HF repo id 处理需要 `huggingface_hub`，"
            f"本环境未安装：{e}。请改为给出本地 `config.json` 的路径。") from e
    raise FileNotFoundError(
        f"--model {ref!r} 是 repo id 风格。本环境**无网络访问**"
        f"（访问 huggingface.co 会 `read ECONNRESET`，已实测），"
        f"请先手动下载 `config.json` 再用本地路径。")
