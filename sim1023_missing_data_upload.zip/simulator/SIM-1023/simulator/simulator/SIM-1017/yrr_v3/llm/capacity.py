"""容量门：**任何分配之前**的纯解析式预算，回答「这个模型装不装得下」。

用户的口径是「只要权重与 KV 放得下，就能换模型」，所以这句判断必须
（i）先于几十 GB 的 numpy 分配给出，（ii）与 `MemDie` 的记账**逐字节**一致，
（iii）装不下时说清是**哪一项**顶不下、**最大能到多少**。

三条都由「只用一个字节函数」保证：全部走 `mxfp4.mx_bytes()`（与
`MemDie.allocate` / `WeightEntry.nbytes` 同一个函数），本模块**从不**自己算
`payload + scale`，也**不分配任何数组**。自检
`test_capacity_matches_memdie_placement` 钉住 (ii)：装得下时
`Budget.total_bytes == report["placement"]["used_bytes"]` 逐字节相等。

预算的构成（与 `schedule.SimContext._register_memory` 一一对应）
---------------------------------------------------------------
=========  ==================================================  ==========================
项         形状                                                字节
=========  ==================================================  ==========================
`W` 权重   逐层矩阵 + 词表（+ 未绑权重时的 `lm_head`）          `mx_bytes`，非绑只算一份
`N` 归一化 全部归一化向量                                      4 B/元素，fp32 不量化
`S0` 便签  `(q_dim + 2·kv_dim,)` 的 Q/K/V 写回缓冲               `mx_bytes`
`A` 激活   `(prompt_tokens, hidden)` 的层输入                    `mx_bytes`
`K` KV     `(L, 2, kv_heads, ctx, head_dim)`（MLA 见下）         `mx_bytes`
=========  ==================================================  ==========================

`ctx = prompt_tokens + max_new_tokens`（与 `SimContext.max_ctx` 同一定义），
故 `min(S, ctx) == S`，激活项就用 `prompt_tokens`。

MLA 的 KV 不是 per-head 的 K/V，而是 `(L, ctx, kv_lora_rank + qk_rope_head_dim)`
—— 省的是**字节**（DeepSeek-V2-Lite 每 token 1152 B 对稠密同规模的 8192 B）。
整块口径下它**不省块**：注意力仍然 pair 逐个走单位块，块数只由 pair 数决定。

宿主侧还有一份**不在 MEM die 上**的影子（`SimContext.kv` 的 fp32 数组）：
它是片上 4 bit 数据的 8 倍，20B/长上下文下是十几 GB，是真瓶颈之一。
本模块把它单列成 `host_shadow_bytes`，**不计入 `total_bytes`**（否则 (ii) 不成立），
并给出告警阈值与 `kv_shadow` 三档口径。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from . import report as _rep
from .arch.params import ArchParams
from .config import GIB, LlmConfig
from .mxfp4 import GROUP, mx_bytes

# MXFP4 = 4 bit payload + 8 bit E8M0 尺度 / 32 元素 ⇒ 0.53125 B/参数。
# 用 `GROUP` 现算而不是写死 0.53125：改粒度时这个数必须跟着动。
MXFP4_BYTES_PER_PARAM = 0.5 + 1.0 / GROUP

# 宿主侧 fp32 KV 影子的口径：fp32（今天的行为，逐位不变）/ codebook（存 payload+scale，
# 按需反量化，逐位等价）/ none（形状驱动模式，不分配）。
KV_SHADOW_MODES = ("fp32", "codebook", "none")

# 影子超过这个量就告警：它不在 die 的账上，却会先把宿主内存吃光。
KV_SHADOW_WARN_BYTES = 2 * GIB


def kv_shape(spec: Any, ctx: int) -> tuple[int, ...]:
    """KV cache 在 MEM die 上的形状（MLA 与非 MLA 分岔）。

    **这是 KV 形状的唯一出处**：容量门按它算字节，`SimContext` 按它分配数组。
    """
    s = ArchParams(spec).spec
    ctx = int(ctx)
    if s.mla is not None:
        return (s.layers, ctx, s.mla.kv_row)
    return (s.layers, 2, s.kv_heads, ctx, s.head_dim)


def kv_bytes(spec: Any, ctx: int) -> int:
    """KV cache 在 MEM die 上的字节（MXFP4）。"""
    return mx_bytes(kv_shape(spec, ctx))


def kv_shadow_bytes(spec: Any, ctx: int) -> int:
    """宿主侧 fp32 KV 影子的字节（**不在 MEM die 上**）。"""
    n = 1
    for d in kv_shape(spec, ctx):
        n *= int(d)
    return n * 4


class CapacityError(MemoryError):
    """装不下。携带**同一份**预算字典，`main()` 直接打印明细并 `exit(2)`。

    继承 `MemoryError`：库调用方按内存不足处理也对；但这是**解析式**判定，
    发生在任何分配之前，所以比 `MemDie.allocate` 抛出的裸 `MemoryError` 更早、
    更有信息量。后者保留为兜底（长 prefill 的 `act_x` 增长路径）。
    """

    def __init__(self, budget: "Budget", what: str = "") -> None:
        self.budget = budget
        head = f"装不下：{what}" if what else "装不下"
        super().__init__(f"{head}\n{budget.render()}")


@dataclass
class Budget:
    """一次推理的解析式容量预算（纯标量，不含任何数组）。"""

    spec: Any
    capacity_bytes: int
    ctx: int
    prompt_tokens: int
    weights_bytes: int
    norms_bytes: int
    scratch_bytes: int
    act_bytes: int
    kv_bytes: int
    rram_capacity_bytes: int | None
    feram_capacity_bytes: int | None
    rram_used_bytes: int
    feram_used_bytes: int
    total_bytes: int
    kv_bytes_per_token: int
    kv_shadow: str
    host_shadow_bytes: int
    max_ctx_that_fits: int
    max_gen_tokens: int
    max_params_that_fits: int
    limited_by: str
    # 参数量账（与 `ArchParams.accounting()` 同源，`--compare` 要按月并排列出）
    params_elements: int = 0
    active_elements_per_token: int = 0
    warnings: tuple[str, ...] = ()

    # ---------------- 派生 ----------------

    @property
    def fits(self) -> bool:
        return (self.total_bytes <= self.capacity_bytes
                and (self.rram_capacity_bytes is None
                     or self.rram_used_bytes <= self.rram_capacity_bytes)
                and (self.feram_capacity_bytes is None
                     or self.feram_used_bytes <= self.feram_capacity_bytes))

    @property
    def free_bytes(self) -> int:
        free = self.capacity_bytes - self.total_bytes
        if self.rram_capacity_bytes is not None:
            free = min(free, self.rram_capacity_bytes - self.rram_used_bytes)
        if self.feram_capacity_bytes is not None:
            free = min(free, self.feram_capacity_bytes - self.feram_used_bytes)
        return free

    @property
    def used_pct(self) -> float:
        return 100.0 * self.total_bytes / self.capacity_bytes

    @property
    def host_bytes(self) -> int:
        """本轮**实际分配**的宿主内存 = 影子（`none` 档为 0）。"""
        return self.host_shadow_bytes

    @property
    def max_ctx_allowed(self) -> int:
        """`--max-ctx` 的实际上界：die 容量与模型声明的位置数取小。"""
        return min(self.max_ctx_that_fits, int(self.spec.max_position))

    def terms(self) -> list[tuple[str, str, int, str]]:
        """`(键, 名字, 字节, 说明)`，顺序即报告里的呈现顺序。

        键是 ASCII（进 `--json` 与 `--compare` 的机器读面），名字是给人看的中文。
        """
        s = self.spec
        return [
            ("weights", "权重 W", self.weights_bytes,
             f"{s.layers} 层矩阵 + 词表"
             + ("（绑权重，词表只算一份）" if s.tie_embeddings else "（未绑权重，另算 lm_head）")),
            ("norms", "归一化 N", self.norms_bytes, "fp32 不量化，4 B/元素"),
            ("scratch", "Q 暂存 Q", self.scratch_bytes,
             f"当前 prompt 的 Q 暂存 ({self.prompt_tokens}, {s.q_dim})，位于 FeRAM"),
            ("act", "激活 A", self.act_bytes, f"层输入 ({self.prompt_tokens}, {s.hidden})"),
            ("kv", "KV K", self.kv_bytes,
             f"ctx={self.ctx}，{self.kv_bytes_per_token} B/token，"
             + ("MLA 压缩行宽 " + str(s.mla.kv_row) if s.mla is not None
                else f"2x{s.kv_heads}x{s.head_dim}")),
        ]

    def as_dict(self) -> dict[str, Any]:
        """进报告与 `--json` 的扁平字典（**错误路径也用同一份**）。"""
        s = self.spec
        return {
            "capacity_bytes": self.capacity_bytes,
            "capacity_gib": self.capacity_bytes / GIB,
            "rram_capacity_bytes": self.rram_capacity_bytes,
            "feram_capacity_bytes": self.feram_capacity_bytes,
            "rram_used_bytes": self.rram_used_bytes,
            "feram_used_bytes": self.feram_used_bytes,
            "ctx": self.ctx,
            "prompt_tokens": self.prompt_tokens,
            "terms": {k: v for k, _, v, _ in self.terms()},
            "weights_bytes": self.weights_bytes,
            "norms_bytes": self.norms_bytes,
            "scratch_bytes": self.scratch_bytes,
            "act_bytes": self.act_bytes,
            "kv_bytes": self.kv_bytes,
            "kv_bytes_per_token": self.kv_bytes_per_token,
            "total_bytes": self.total_bytes,
            "free_bytes": self.free_bytes,
            "used_pct": self.used_pct,
            "fits": self.fits,
            "limited_by": self.limited_by,
            "max_ctx_that_fits": self.max_ctx_that_fits,
            "max_ctx_allowed": self.max_ctx_allowed,
            "max_gen_tokens": self.max_gen_tokens,
            "max_params_that_fits": self.max_params_that_fits,
            "params_elements": self.params_elements,
            "active_elements_per_token": self.active_elements_per_token,
            "params_millions": self.params_elements / 1e6,
            "mxfp4_bytes_per_param": MXFP4_BYTES_PER_PARAM,
            "kv_shadow": self.kv_shadow,
            "host_shadow_bytes": self.host_shadow_bytes,
            "host_bytes": self.host_bytes,
            "warnings": list(self.warnings),
            "note": "解析式预算，未分配任何数组；装得下时 total_bytes 与 "
                    "placement.used_bytes 逐字节相等（自检钉住）",
            "family": s.family,
        }

    # ---------------- 呈现 ----------------

    def render(self) -> str:
        """人类可读的明细。`CapacityError` 与报告段 `[17]` 共用这一段。"""
        s = self.spec
        w = 12          # 中文名字的显示宽度（「权重 W」= 6）
        out = [
            f"模型 {s.family}：L={s.layers} H={s.hidden} V={s.vocab} "
            f"ctx={self.ctx}（prompt {self.prompt_tokens} + 生成 "
            f"{self.ctx - self.prompt_tokens}）",
            f"容量 {self.capacity_bytes:,} B（{self.capacity_bytes / GIB:.2f} GiB）",
            f"RRAM {self.rram_used_bytes:,} B / "
            f"{self.rram_capacity_bytes if self.rram_capacity_bytes is not None else '未配置'}；"
            f"FeRAM {self.feram_used_bytes:,} B / "
            f"{self.feram_capacity_bytes if self.feram_capacity_bytes is not None else '未配置'}",
            _rep._hr(),
        ]
        for _, label, nbytes, note in self.terms():
            out.append(f"{_rep._pad(label, w, '<')}{nbytes:>16,} B  "
                       f"{_rep._pad(_rep._fmt_bytes(nbytes), 11, '<')}{note}")
        out.append(_rep._hr())
        out.append(f"{_rep._pad('合计', w, '<')}{self.total_bytes:>16,} B  "
                   f"{_rep._pad(_rep._fmt_bytes(self.total_bytes), 11, '<')}"
                   f"占 {self.used_pct:.2f}%  "
                   f"{'装得下' if self.fits else '**装不下**'}"
                   f"（余 {self.free_bytes:,} B）")
        if not self.fits:
            over = -self.free_bytes
            out.append(f"{_rep._pad('超出', w, '<')}{over:>16,} B  "
                       f"{_rep._pad(_rep._fmt_bytes(over), 11, '<')}"
                       f"顶不住的是「{self.limited_by}」")
        out += [
            f"{_rep._pad('最大 ctx', w, '<')}{self.max_ctx_that_fits:,}"
            f"（受 {self.limited_by} 限制；模型声明 {s.max_position:,}，"
            f"故 --max-ctx 上界 {self.max_ctx_allowed:,}）",
            f"{_rep._pad('最大生成', w, '<')}{self.max_gen_tokens:,} token"
            f"（= 最大 ctx − prompt {self.prompt_tokens}）",
            f"{_rep._pad('最大参数', w, '<')}{self.max_params_that_fits / 1e6:,.1f} M"
            "（按 RRAM 权重容量与总容量计算；FeRAM KV 空间独立核算）",
            f"{_rep._pad('宿主影子', w, '<')}{self.host_shadow_bytes:>16,} B  "
            f"{_rep._pad(_rep._fmt_bytes(self.host_shadow_bytes), 11, '<')}"
            f"口径 {self.kv_shadow}（**不在 die 上**）",
        ]
        out += [f"告警：{t}" for t in self.warnings]
        return "\n".join(out)


def budget(spec: Any, cfg: LlmConfig | None = None, *, ctx: int | None = None) -> Budget:
    """算一次预算。`spec` 可以是 `ArchSpec` 或 `Qwen3Config`（自动补齐）。

    `ctx` 默认取 `cfg.prompt_tokens + cfg.max_new_tokens`（与 `SimContext.max_ctx`
    同一定义）；显式给出时用来问「换成这个上下文还装得下吗」。
    """
    cfg = cfg or LlmConfig()
    p = ArchParams(spec)
    s = p.spec

    W = p.matrix_bytes()
    N = p.norm_bytes()
    # Q is a reusable FeRAM scratch; K/V live in the separately reserved KV pool.
    S0 = mx_bytes((cfg.prompt_tokens, s.q_dim))
    A = mx_bytes((cfg.prompt_tokens, s.hidden))
    ctx_eff = (cfg.prompt_tokens + cfg.max_new_tokens) if ctx is None else int(ctx)
    K = kv_bytes(s, ctx_eff)
    R = W + N + A
    F = S0 + K
    total = W + N + S0 + A + K

    # ---- 最大 ctx：`kv_bytes(s, ctx)` 对 ctx **单调不减**，故指数探测 + 二分 ----
    # 闭式（`room // 每 token 字节`）会偏小：`kv_bytes(s, 1)` 把单个位置向上取整到
    # 整块，是高估，于是闭式给的 m 只是下界。旧做法是从那里**逐 1 往上爬**到装不下
    # 为止 —— 结果正确，但 0.6B/16 GiB 那档要爬 55 万步（整个动物园跑一遍要好几分钟）。
    # 单调性使二分成为同一个答案：找最大的 m 使 `kv_bytes(s, m) <= room`，与逐 1 爬
    # 到的正是同一个数，而步数是 O(log)。
    room = cfg.mem_die_bytes - R - S0
    if cfg.feram_capacity_bytes is not None:
        room = min(room, cfg.feram_capacity_bytes - S0)
    if cfg.rram_capacity_bytes is not None and R > cfg.rram_capacity_bytes:
        room = -1
    per_tok = kv_bytes(s, 1)
    m = 0
    if per_tok > 0 and room > 0 and kv_bytes(s, 1) <= room:
        hi = 1
        while kv_bytes(s, hi) <= room:          # 指数探测：hi 是「装不下」的那一侧
            hi *= 2
        lo = hi // 2                            # 此时 kv_bytes(lo) <= room < kv_bytes(hi)
        while lo + 1 < hi:
            mid = (lo + hi) // 2
            if kv_bytes(s, mid) <= room:
                lo = mid
            else:
                hi = mid
        m = lo

    rram_fits = cfg.rram_capacity_bytes is None or R <= cfg.rram_capacity_bytes
    feram_fits = cfg.feram_capacity_bytes is None or F <= cfg.feram_capacity_bytes
    total_fits = total <= cfg.mem_die_bytes
    if total_fits and rram_fits and feram_fits:
        # 装得下：还能不能再长，取决于先撞哪个 —— KV 长到模型声明的位置数，
        # 还是权重本来就把 die 占满了。
        limited_by = "kv_cache" if m < int(s.max_position) else "weights"
    elif not rram_fits:
        limited_by = "weights/activations in RRAM"
    elif not feram_fits:
        limited_by = "Q/KV cache in FeRAM"
    else:
        limited_by = "weights" if (W + N + S0 + A) > cfg.mem_die_bytes else "kv_cache"

    # KV 影子的**有效**口径。形状驱动模式一个字节都不分配，所以这里必须报 `none`：
    # 否则同一份报告里 `config.kv_shadow == "none"` 而 `capacity.kv_shadow == "fp32"`、
    # `host_shadow_bytes` 报出几 MB 从不存在的内存 —— 两处自相矛盾，且容量门会为一个
    # 根本没发生的分配给出告警。判定与 `run_llm` 用同一个 `resolve_forward`。
    shadow_mode = getattr(cfg, "kv_shadow", "fp32")
    if resolve_forward(s, cfg) == "shape":
        shadow_mode = "none"
    if shadow_mode == "fp32":
        shadow = kv_shadow_bytes(s, ctx_eff)
    elif shadow_mode == "codebook":
        shadow = K                     # 存 (payload, scale)，逐位等价
    elif shadow_mode == "none":
        shadow = 0
    else:
        raise ValueError(f"kv_shadow 只能是 {' / '.join(KV_SHADOW_MODES)}，"
                         f"得到 {shadow_mode!r}")

    warns: list[str] = []
    if shadow_mode == "fp32" and shadow > KV_SHADOW_WARN_BYTES:
        warns.append(
            f"宿主侧 fp32 KV 影子 {_rep._fmt_bytes(shadow)}（{shadow / GIB:.2f} GiB）"
            f"已超过阈值 {KV_SHADOW_WARN_BYTES / GIB:.0f} GiB —— 它**不在** MEM die 的 "
            f"账上，却会先把宿主内存吃光。改 `kv_shadow=\"codebook\"`（存 payload+scale，"
            f"逐位等价）或 `\"none\"`（形状驱动模式，不分配）可去掉这 8 倍")
    if not total_fits:
        warns.append(f"超容 {_rep._fmt_bytes(-(cfg.mem_die_bytes - total))}，"
                     f"顶不住的是「{limited_by}」")
    if not rram_fits:
        warns.append(f"RRAM 超容 {_rep._fmt_bytes(R - int(cfg.rram_capacity_bytes or 0))}")
    if not feram_fits:
        warns.append(f"FeRAM 超容 {_rep._fmt_bytes(F - int(cfg.feram_capacity_bytes or 0))}")

    return Budget(
        spec=s, capacity_bytes=cfg.mem_die_bytes, ctx=ctx_eff,
        prompt_tokens=cfg.prompt_tokens, weights_bytes=W, norms_bytes=N,
        scratch_bytes=S0, act_bytes=A, kv_bytes=K,
        rram_capacity_bytes=cfg.rram_capacity_bytes,
        feram_capacity_bytes=cfg.feram_capacity_bytes,
        rram_used_bytes=R, feram_used_bytes=F, total_bytes=total,
        kv_bytes_per_token=per_tok, kv_shadow=shadow_mode, host_shadow_bytes=shadow,
        max_ctx_that_fits=m, max_gen_tokens=max(0, m - cfg.prompt_tokens),
        max_params_that_fits=max(0, int(min(
            cfg.mem_die_bytes - N - S0 - A - K,
            ((cfg.rram_capacity_bytes - N - A)
             if cfg.rram_capacity_bytes is not None else cfg.mem_die_bytes)
        ) / MXFP4_BYTES_PER_PARAM)),
        limited_by=limited_by,
        params_elements=p.accounting()["total_elements"],
        active_elements_per_token=p.active_elements_per_token(),
        warnings=tuple(warns))


def require(b: Budget, what: str = "") -> Budget:
    """装不下就抛 `CapacityError`（带同一份预算字典），否则原样返回。"""
    if not b.fits:
        raise CapacityError(b, what)
    return b


# --------------------------------------------------------------------------
# 前向模式：真数值还是形状驱动
# --------------------------------------------------------------------------

FORWARD_MODES = ("auto", "numeric", "shape")

# `auto` 判据（模块常量，自检可以强制）：宿主内存的两项决定能不能走数值模式。
# 权重的 fp32 影子是 4 B/参数，而它在 die 上只占 `MXFP4_BYTES_PER_PARAM` B/参数，
# 故影子 ≈ 矩阵字节的 `4 / 0.53125 = 7.53` 倍；再加上 KV 的 fp32 影子。
#   Qwen3-0.6B  ≈ 2.55 GiB（数值可行，默认配置就是这条路 —— 今天的结果逐位不变）
#   Qwen3-1.7B  ≈ 7.3 GiB（转形状驱动）
#   Llama-3.1-8B ≈ 32 GiB（必须形状驱动）
AUTO_NUMERIC_MAX_HOST_BYTES = 3 * GIB
# 数值模式的中间量是 `(T, out)` 的 fp32 数组，与批量 GEMM 的墙钟一起随 prompt 增长；
# 只是速度问题，不是容量问题，故单独一个上限而不是塞进上面那个字节判据。
AUTO_NUMERIC_MAX_PROMPT_TOKENS = 2048

# 数值模式每参数的宿主内存倍率（fp32 影子 / die 上 4 bit）。
FP32_OVER_MXFP4 = 4.0 / MXFP4_BYTES_PER_PARAM


def numeric_host_bytes(spec: Any, cfg: LlmConfig) -> int:
    """数值模式要的宿主内存：权重 fp32 影子 + KV 的 fp32 影子（都不在 die 上）。"""
    p = ArchParams(spec)
    ctx = cfg.prompt_tokens + cfg.max_new_tokens
    return int(p.matrix_bytes() * FP32_OVER_MXFP4) + kv_shadow_bytes(p.spec, ctx)


def resolve_forward(spec: Any, cfg: LlmConfig | None = None) -> str:
    """定这次跑哪条前向：`"numeric"`（真数值）还是 `"shape"`（形状驱动快跑）。

    **账目是形状的纯函数**（`blocks()` 与单位块单价都与模型无关，KV 大小与生成
    token 数也都由形状决定，循环里没有 EOS 早停），所以跳过真实矩阵乘**不改变任何
    账目数字** —— 这一点由等价性自检逐字段钉住（见 `tests/test_llm.py`）。

    三条规则，顺序即优先级：

    1. `cfg.forward` 显式给 `"numeric"` / `"shape"` 时照办（用户说了算）；
    2. `cfg.model` 非空（`--smoke` 与形状覆盖路径）**一律数值** —— 既有自检
       （数 `quantize_dequantize` 的调用、读 `ctx.kv`）依赖真数值；
    3. 其余按宿主内存与 prompt 长度自动回退，阈值见上面的模块常量。
    """
    cfg = cfg or LlmConfig()
    mode = getattr(cfg, "forward", "auto")
    if mode not in FORWARD_MODES:
        raise ValueError(f"forward 只能是 {' / '.join(FORWARD_MODES)}，得到 {mode!r}")
    if mode != "auto":
        return mode
    if cfg.model is not None:
        return "numeric"
    if cfg.prompt_tokens > AUTO_NUMERIC_MAX_PROMPT_TOKENS:
        return "shape"
    if numeric_host_bytes(spec, cfg) > AUTO_NUMERIC_MAX_HOST_BYTES:
        return "shape"
    return "numeric"


def forward_note(spec: Any, cfg: LlmConfig, mode: str) -> str:
    """为什么选了这个模式（进报告，供人核对阈值判到了哪一边）。"""
    host = numeric_host_bytes(spec, cfg)
    why = {
        "numeric": f"数值模式（宿主内存 {_rep._fmt_bytes(host)} ≤ "
                   f"{_rep._fmt_bytes(AUTO_NUMERIC_MAX_HOST_BYTES)}，"
                   f"prompt {cfg.prompt_tokens} ≤ {AUTO_NUMERIC_MAX_PROMPT_TOKENS}）",
        "shape": f"形状驱动（宿主内存 {_rep._fmt_bytes(host)}，"
                 f"prompt {cfg.prompt_tokens}）",
    }[mode]
    tail = ("账目是形状的纯函数，两种模式的账目逐字段相等"
            "（自检 `test_shape_and_numeric_agree` 钉住）；"
            "只有 `output.generated_ids` 与 `config.wall_clock_s` 允许不同。")
    if getattr(cfg, "forward", "auto") != "auto":
        why = f"由 `forward=\"{cfg.forward}\"` 显式指定"
    elif cfg.model is not None:
        why = "由 `cfg.model`（冒烟 / 形状覆盖）强制数值模式"
    return f"{why}。{tail}"
