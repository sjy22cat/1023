"""MEM die 逻辑放置模型：分开的 RRAM / FeRAM 容量池与读写账。

这是行为级地址/容量模型，不是物理存储分配器：张量数值实体仍是普通 numpy 数组；
`MemDie` 为每个张量记录介质、池内偏移、容量占用和读写流量。FeRAM 单价未配置时明确保留为 pending。

容量单位按 **GiB**（`16 GiB = 17,179,869,184 B`）。报告里同时给十进制 GB
（`16e9 B`，小 6.9%）作对照，因为「16GB」这个说法两种读法都常见。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Literal

import numpy as np

from . import mxfp4
from .config import GIB
from .cost import Cost, Transfer

Role = Literal["weight", "kv_cache", "activation", "embedding", "scratch", "host_io"]
Medium = Literal["rram", "feram"]


@dataclass
class TensorRecord:
    """MEM die 上的一个张量：占多少字节、是什么角色、数值实体在哪。"""
    name: str
    shape: tuple[int, ...]
    role: Role
    payload_bytes: int = 0
    scale_bytes: int = 0
    raw_bytes: int = 0            # 非 MXFP4 的原始宽度（如 fp32 的 norm 权重）
    offset: int = 0
    nbytes: int = 0               # = payload + scale + raw
    fp4: bool = True
    note: str = ""
    medium: Medium = "rram"

    @property
    def elements(self) -> int:
        n = 1
        for d in self.shape:
            n *= int(d)
        return n

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name, "shape": list(self.shape), "role": self.role,
            "medium": self.medium, "offset": self.offset,
            "nbytes": self.nbytes, "payload_bytes": self.payload_bytes,
            "scale_bytes": self.scale_bytes, "raw_bytes": self.raw_bytes,
            "fp4": self.fp4, "note": self.note,
        }


def _shape_elems(shape: Iterable[int]) -> int:
    n = 1
    for d in shape:
        n *= int(d)
    return n


class MemDie:
    """一颗含 RRAM/FeRAM 两个逻辑地址池的 MEM die。"""

    def __init__(self, capacity_bytes: int = 16 * GIB, cost: Cost | None = None,
                 core_count: int = 1, *, rram_capacity_bytes: int | None = None,
                 feram_capacity_bytes: int | None = None) -> None:
        self.capacity_bytes = int(capacity_bytes)
        self.medium_capacity_bytes: dict[Medium, int | None] = {
            "rram": None if rram_capacity_bytes is None else int(rram_capacity_bytes),
            "feram": None if feram_capacity_bytes is None else int(feram_capacity_bytes),
        }
        if self.capacity_bytes <= 0:
            raise ValueError("capacity_bytes must be positive")
        for medium, capacity in self.medium_capacity_bytes.items():
            if capacity is not None and capacity <= 0:
                raise ValueError(f"{medium}_capacity_bytes must be positive")
        self.cost = cost
        self.core_count = core_count
        self.tensors: dict[str, TensorRecord] = {}
        self._order: list[str] = []
        # 累计账（四段分开）
        self.rd_bytes = 0
        self.wr_bytes = 0
        self.phy_bytes = 0
        self.gsram_bytes = 0
        self.mem_rd_pj = 0.0
        self.mem_wr_pj = 0.0
        self.phy_pj = 0.0
        self.gsram_pj = 0.0
        self.regfile_pj = 0.0
        self.ns = 0.0
        self.rd_bytes_by_medium: dict[Medium, int] = {"rram": 0, "feram": 0}
        self.wr_bytes_by_medium: dict[Medium, int] = {"rram": 0, "feram": 0}
        self.host_read_bytes_by_medium: dict[Medium, int] = {"rram": 0, "feram": 0}
        self.host_write_bytes_by_medium: dict[Medium, int] = {"rram": 0, "feram": 0}
        self.pending_bytes: dict[str, int] = {}
        self.array_cost_by_medium = self._empty_array_costs()

    @staticmethod
    def _empty_array_costs():
        return {m: {k: 0.0 for k in ("read_pj", "write_pj", "host_read_pj",
                                      "host_write_pj", "inference_ns")}
                for m in ("rram", "feram")}

    # ---------------- 容量 ----------------

    def used_bytes(self, medium: Medium | None = None) -> int:
        if medium is None:
            return sum(t.nbytes for t in self.tensors.values())
        return sum(t.nbytes for t in self.tensors.values() if t.medium == medium)

    def free_bytes(self, medium: Medium | None = None) -> int | None:
        if medium is None:
            return self.capacity_bytes - self.used_bytes()
        capacity = self.medium_capacity_bytes[medium]
        return None if capacity is None else capacity - self.used_bytes(medium)

    def _offset_for(self, medium: Medium, nbytes: int) -> int:
        cursor = 0
        records = sorted((t for t in self.tensors.values() if t.medium == medium),
                         key=lambda t: t.offset)
        for rec in records:
            if cursor + nbytes <= rec.offset:
                return cursor
            cursor = max(cursor, rec.offset + rec.nbytes)
        return cursor

    def allocate(self, name: str, shape: Iterable[int], role: Role, *,
                 fp4: bool = True, raw_bits: int = 32, note: str = "",
                 reclaimable: bool = True, medium: Medium = "rram") -> TensorRecord:
        """登记一个张量占用的字节。

        * `fp4=True`：按 MXFP4 存 —— payload 4 bit/元素 + E8M0 8 bit/32 元素。
        * `fp4=False`：按 `raw_bits` 存（norm 权重、RoPE 表这类不量化的东西）。
        * `reclaimable=False`：常驻不回收（权重、embedding）。
        """
        shape = tuple(int(d) for d in shape)
        n = _shape_elems(shape)
        if fp4:
            pb = mxfp4.payload_bytes(shape)
            sb = mxfp4.scale_bytes(shape)
            rb = 0
        else:
            pb = sb = 0
            rb = (n * raw_bits + 7) // 8
        if medium not in ("rram", "feram"):
            raise ValueError(f"未知存储介质 {medium!r}")
        if name in self.tensors:
            raise KeyError(f"张量重名：{name}")
        rec = TensorRecord(name=name, shape=shape, role=role, payload_bytes=pb,
                           scale_bytes=sb, raw_bytes=rb, nbytes=pb + sb + rb,
                           offset=self._offset_for(medium, pb + sb + rb),
                           fp4=fp4, note=note, medium=medium)
        pool_capacity = self.medium_capacity_bytes[medium]
        pool_used = self.used_bytes(medium)
        if pool_capacity is not None and pool_used + rec.nbytes > pool_capacity:
            raise MemoryError(
                f"{medium.upper()} 容量不足：{name} 需要 {rec.nbytes:,} B，"
                f"剩余 {pool_capacity - pool_used:,} B / 共 {pool_capacity:,} B")
        if rec.nbytes > self.free_bytes():
            raise MemoryError(
                f"MEM die 容量不足：{name} 需要 {rec.nbytes:,} B，"
                f"剩余 {self.free_bytes():,} B / 共 {self.capacity_bytes:,} B")
        self.tensors[name] = rec
        self._order.append(name)
        return rec

    def free(self, name: str) -> int:
        """回收一个张量（Q 用毕即清、每步的 logits 等）。返回释放的字节数。"""
        rec = self.tensors.pop(name, None)
        if rec is None:
            return 0
        self._order.remove(name)
        return rec.nbytes

    def by_role(self) -> dict[str, dict[str, int]]:
        out: dict[str, dict[str, int]] = {}
        for t in self.tensors.values():
            a = out.setdefault(t.role, {"tensors": 0, "nbytes": 0,
                                        "payload_bytes": 0, "scale_bytes": 0,
                                        "raw_bytes": 0})
            a["tensors"] += 1
            a["nbytes"] += t.nbytes
            a["payload_bytes"] += t.payload_bytes
            a["scale_bytes"] += t.scale_bytes
            a["raw_bytes"] += t.raw_bytes
        return out

    def usage(self) -> dict[str, Any]:
        used = self.used_bytes()
        return {
            "capacity_bytes": self.capacity_bytes,
            "capacity_gib": self.capacity_bytes / GIB,
            "capacity_decimal_gb": self.capacity_bytes / 1e9,
            "used_bytes": used,
            "used_pct": 100.0 * used / self.capacity_bytes,
            "free_bytes": self.free_bytes(),
            "by_role": self.by_role(),
            "largest": sorted((t.as_dict() for t in self.tensors.values()),
                              key=lambda d: -d["nbytes"])[:12],
        }

    def storage_usage(self) -> dict[str, Any]:
        """Separate capacity and occupancy for each physical memory pool."""
        by_medium: dict[str, Any] = {}
        for medium in ("rram", "feram"):
            cap = self.medium_capacity_bytes[medium]
            used = self.used_bytes(medium)
            by_medium[medium] = {
                "capacity_bytes": cap,
                "capacity_configured": cap is not None,
                "used_bytes": used,
                "free_bytes": None if cap is None else cap - used,
                "used_pct": None if cap is None else 100.0 * used / cap,
                "tensors": [t.as_dict() for t in self.tensors.values()
                            if t.medium == medium],
            }
        configured = all(self.medium_capacity_bytes[m] is not None
                         for m in ("rram", "feram"))
        return {
            "total_capacity_bytes": self.capacity_bytes,
            "total_used_bytes": self.used_bytes(),
            "total_free_bytes": self.free_bytes(),
            "capacity_status": "configured" if configured else "per_medium_capacity_pending",
            "by_medium": by_medium,
        }

    # ---------------- 读 / 写（只出账，不动数值） ----------------

    def reset(self) -> None:
        """把四段累计账清零（跑多次推理时用）。**不动张量表。**"""
        self.rd_bytes = self.wr_bytes = 0
        self.phy_bytes = self.gsram_bytes = 0
        self.mem_rd_pj = self.mem_wr_pj = 0.0
        self.phy_pj = self.gsram_pj = self.regfile_pj = 0.0
        self.ns = 0.0
        self.rd_bytes_by_medium = {"rram": 0, "feram": 0}
        self.wr_bytes_by_medium = {"rram": 0, "feram": 0}
        self.host_read_bytes_by_medium = {"rram": 0, "feram": 0}
        self.host_write_bytes_by_medium = {"rram": 0, "feram": 0}
        self.pending_bytes.clear()
        self.array_cost_by_medium = self._empty_array_costs()

    def charge(self, t: Transfer) -> Transfer:
        """把一次搬运记进四段账（`Core` 每出一笔账都调它）。

        四段是**并列的通道**，不是一次划分：一次「权重装载」同时过 MEM 阵列、
        跨 PHY、落 GSRAM、写寄存器堆，四栏都该 +。
        """
        if t.kind == "mem_read":
            self.rd_bytes += t.nbytes
            self.mem_rd_pj += t.mem_pj
            if t.medium is not None:
                self.rd_bytes_by_medium[t.medium] += t.nbytes
                if t.origin == "host":
                    self.host_read_bytes_by_medium[t.medium] += t.nbytes
        elif t.kind == "mem_write":
            self.wr_bytes += t.nbytes
            self.mem_wr_pj += t.mem_pj
            if t.medium is not None:
                self.wr_bytes_by_medium[t.medium] += t.nbytes
                if t.origin == "host":
                    self.host_write_bytes_by_medium[t.medium] += t.nbytes
        for component in t.pending_components:
            self.pending_bytes[component] = self.pending_bytes.get(component, 0) + t.nbytes
        if t.medium is not None and t.kind in ("mem_read", "mem_write"):
            costs = self.array_cost_by_medium[t.medium]
            direction = "read" if t.kind == "mem_read" else "write"
            costs[f"{direction}_pj"] += t.mem_pj
            if t.origin == "host":
                costs[f"host_{direction}_pj"] += t.mem_pj
            else:
                costs["inference_ns"] += t.mem_ns
        if t.phy_traversed:
            self.phy_bytes += t.nbytes
        if t.gsram_traversed:
            self.gsram_bytes += t.nbytes
        self.phy_pj += t.phy_pj
        self.gsram_pj += t.gsram_pj
        self.regfile_pj += t.regfile_pj
        self.ns += t.ns
        return t

    def record_host_write(self, nbytes: int, medium: Medium = "rram") -> None:
        """Record pre-inference host provisioning without charging its latency.

        Only the on-die array write energy is counted when available. Host-link
        energy is pending because that interface has no supplied parameters.
        """
        n = int(nbytes)
        if n < 0:
            raise ValueError("host write size must be non-negative")
        self.wr_bytes += n
        self.wr_bytes_by_medium[medium] += n
        self.host_write_bytes_by_medium[medium] += n
        if self.cost is not None and n:
            t = self.cost.mem_write(n, via_phy=False, gsram=False,
                                    medium=medium, origin="host")
            self.mem_wr_pj += t.mem_pj
            self.array_cost_by_medium[medium]["write_pj"] += t.mem_pj
            self.array_cost_by_medium[medium]["host_write_pj"] += t.mem_pj
            for component in t.pending_components:
                self.pending_bytes[component] = self.pending_bytes.get(component, 0) + n

    def record_host_read(self, nbytes: int, medium: Medium = "rram") -> None:
        """Record host reads without charging them to inference latency."""
        n = int(nbytes)
        if n < 0:
            raise ValueError("host read size must be non-negative")
        self.rd_bytes += n
        self.rd_bytes_by_medium[medium] += n
        self.host_read_bytes_by_medium[medium] += n
        if self.cost is not None and n:
            t = self.cost.mem_read(n, via_phy=False, gsram=False,
                                   medium=medium, origin="host")
            self.mem_rd_pj += t.mem_pj
            self.array_cost_by_medium[medium]["read_pj"] += t.mem_pj
            self.array_cost_by_medium[medium]["host_read_pj"] += t.mem_pj
            for component in t.pending_components:
                self.pending_bytes[component] = self.pending_bytes.get(component, 0) + n

    def read(self, name_or_bytes: str | int, nbytes: int | None = None, *,
             regfile: bool = False, phy_bpc: int | None = None,
             medium: Medium | None = None) -> Transfer:
        """从 MEM die 读。写寄存器堆时 `regfile=True`（权重装载）。"""
        n = self._resolve(name_or_bytes, nbytes)
        if medium is None:
            medium = self.tensors[name_or_bytes].medium if isinstance(name_or_bytes, str) else "rram"
        return self.charge(self.cost.mem_read(n, phy_bpc=phy_bpc, regfile=regfile,
                                              medium=medium))

    def write(self, name_or_bytes: str | int, nbytes: int | None = None, *,
              phy_bpc: int | None = None, medium: Medium | None = None) -> Transfer:
        """写回 MEM die。"""
        n = self._resolve(name_or_bytes, nbytes)
        if medium is None:
            medium = self.tensors[name_or_bytes].medium if isinstance(name_or_bytes, str) else "rram"
        return self.charge(self.cost.mem_write(n, phy_bpc=phy_bpc, medium=medium))

    def _resolve(self, name_or_bytes: str | int, nbytes: int | None) -> int:
        if isinstance(name_or_bytes, str):
            if name_or_bytes not in self.tensors:
                raise KeyError(f"MEM die 上没有张量 {name_or_bytes}")
            n = self.tensors[name_or_bytes].nbytes
            return n if nbytes is None else min(n, int(nbytes))
        return int(name_or_bytes) if nbytes is None else int(nbytes)

    def traffic(self) -> dict[str, Any]:
        """四段分开的访存/互连账。"""
        return {
            "read_bytes": self.rd_bytes,
            "write_bytes": self.wr_bytes,
            "total_bytes": self.rd_bytes + self.wr_bytes,
            "read_gib": self.rd_bytes / GIB,
            "write_gib": self.wr_bytes / GIB,
            "phy_bytes": self.phy_bytes,
            "gsram_bytes": self.gsram_bytes,
            "pj": {
                "mem_read": self.mem_rd_pj,
                "mem_write": self.mem_wr_pj,
                "phy": self.phy_pj,
                "gsram": self.gsram_pj,
                "regfile": self.regfile_pj,
            },
            "ns": self.ns,
            "by_medium": {
                medium: {
                    "read_bytes": self.rd_bytes_by_medium[medium],
                    "write_bytes": self.wr_bytes_by_medium[medium],
                    "host_read_bytes": self.host_read_bytes_by_medium[medium],
                    "host_write_bytes": self.host_write_bytes_by_medium[medium],
                    "inference_read_bytes": (self.rd_bytes_by_medium[medium]
                                              - self.host_read_bytes_by_medium[medium]),
                    "inference_write_bytes": (self.wr_bytes_by_medium[medium]
                                               - self.host_write_bytes_by_medium[medium]),
                    "array_cost_known": dict(self.array_cost_by_medium[medium]),
                    "total_bytes": (self.rd_bytes_by_medium[medium]
                                    + self.wr_bytes_by_medium[medium]),
                }
                for medium in ("rram", "feram")
            },
            "pending_cost_bytes": dict(self.pending_bytes),
            "host_latency_excluded": True,
            "energy_scope": "array_cost_known includes host provisioning separately; inference ledger excludes host provisioning; missing prices are in pending_cost_bytes",
            "note": "四段分开记：MEM 阵列 / PHY 跨 Die（含 HB）/ 逻辑 Die 的 GSRAM 中转 / "
                    "权重寄存器堆写入。**不合并**，这样『PHY 的 1.44 pJ/bit 把总量顶起来』"
                    "是可归因的。",
        }
