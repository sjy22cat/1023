"""多模型对照（`--compare`）：一次跑多个模型，并排一张表 + 一份可机器读的 JSON。

**每一行都走同一个 `run_llm()`** —— 不另写驱动器、不复制粘贴计算式。这样
「对照行」与「单独跑一遍」在构造上就不可能不一致（自检
`test_compare_rows_match_standalone_runs` 钉住这一点）。

装不下的模型**不进 `run_llm`**：容量门是纯解析式的，先算账、标一行
`OVER_CAPACITY` 并把明细带上，省掉几十 GB 的无用分配。第三段才实现的前向
（MoE / MLA）同理标 `NOT_IMPLEMENTED`，把「为什么没跑」写进表里而不是静默跳过。

除容量与未实现这两类之外**不吞异常**：解析不了的名字、形状不符的 spec 直接抛 ——
对照表宁可断，不可错。
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Iterable

from . import capacity
from .arch import ArchParams, resolve_model
from .config import LlmConfig
from .inference import run_llm

# 行状态
OK = "ok"
OVER_CAPACITY = "OVER_CAPACITY"
NOT_IMPLEMENTED = "NOT_IMPLEMENTED"

# 对照行的**列定义**：`(键, 中文表头, 取值函数, 对齐)`。
# 取值函数收一个「行字典」，返回已经格式化好的字符串（呈现层不碰原始数据）。
COLUMNS: tuple[tuple[str, str, str], ...] = (
    ("model", "模型", "ref"),
    ("family", "族", "family"),
    ("params", "参数 M", "params"),
    ("active", "激活 M/token", "active"),
    ("shape", "L/H/V", "shape"),
    ("attn", "注意力", "attn"),
    ("mlp", "MLP", "mlp"),
    ("weights", "权重", "weights"),
    ("kv", "KV@ctx", "kv"),
    ("placement", "摆放", "placement"),
    ("used_pct", "占用%", "used_pct"),
    ("unit_blocks", "单位块", "unit_blocks"),
    ("macs", "MACs", "macs"),
    ("whole_j", "整块 J", "whole_j"),
    ("unit_j", "单位 J", "unit_j"),
    ("cycles", "拍数", "cycles"),
    ("tok_s", "token/s", "tok_s"),
    ("j_per_token", "J/token", "j_per_token"),
    ("fits", "装得下", "fits"),
)


def _attn_short(spec: Any) -> str:
    """注意力种类的**紧凑**写法（对照表的列要窄；报告的 [2] 段用 spec 的完整说法）。"""
    kinds: dict[str, int] = {}
    for l in range(spec.layers):
        kinds[spec.attn_kind_of(l)] = kinds.get(spec.attn_kind_of(l), 0) + 1
    if len(kinds) == 1:
        k = next(iter(kinds))
        return k if k != "sliding" else f"sliding@{spec.sliding_window}"
    return " + ".join(f"{k}x{n}" for k, n in sorted(kinds.items()))


@dataclass
class CompareRow:
    """对照表的一行：**先**是容量与形状事实，**再**（跑得动时）是账目。"""

    ref: str
    status: str
    spec: Any
    budget: capacity.Budget
    report: dict[str, Any] | None = None
    detail: str = ""

    # ---------------- 列的取值 ----------------

    def cell(self, key: str) -> str:
        from . import report as _rep
        s, b = self.spec, self.budget
        if key == "model":
            return self.ref
        if key == "family":
            return s.family
        if key == "params":
            return f"{b.params_elements / 1e6:,.0f}"
        if key == "active":
            ap = b.active_elements_per_token
            return f"{ap / 1e6:,.0f}" if ap != b.params_elements else "—"
        if key == "shape":
            return f"{s.layers}/{s.hidden}/{s.vocab // 1000}k"
        if key == "attn":
            return _attn_short(s)
        if key == "mlp":
            return s.mlp.kind
        if key == "weights":
            return _rep._fmt_bytes(b.weights_bytes)
        if key == "kv":
            return _rep._fmt_bytes(b.kv_bytes)
        if key == "placement":
            return _rep._fmt_bytes(b.total_bytes)
        if key == "used_pct":
            return f"{b.used_pct:.2f}%"
        if key == "fits":
            return "是" if b.fits else "**否**"
        if self.report is None:
            return "—"
        r = self.report
        if key == "unit_blocks":
            return f"{r['call_counts']['unit_blocks']:,}"
        if key == "macs":
            return f"{r['call_counts']['actual_macs']:,}"
        if key == "whole_j":
            return _rep._fmt_energy(r["energy"]["total_whole_block_pj"])
        if key == "unit_j":
            return _rep._fmt_energy(r["energy"]["total_unit_pj"])
        if key == "cycles":
            return f"{r['latency']['cycles_serial_1core']:,.0f}"
        if key == "tok_s":
            one = ((r.get("throughput") or {}).get("per_core") or {}).get("1")
            return "—" if one is None else f"{one['e2e_tok_s']:.4g}"
        if key == "j_per_token":
            ef = r.get("efficiency") or {}
            if not ef:
                return "—"
            v = ef["by_billing"][ef["billing"]]["per_token_j"]
            return "—" if v is None else f"{v['e2e']:.4g}"
        raise KeyError(key)

    def values(self) -> list[str]:
        return [self.cell(k) for k, _, _ in COLUMNS]

    def as_dict(self) -> dict[str, Any]:
        """机器读面：原始数值（不格式化），含近似项清单。"""
        s, b = self.spec, self.budget
        d: dict[str, Any] = {
            "model": self.ref,
            "status": self.status,
            "detail": self.detail,
            "family": s.family,
            "source": s.source,
            "shape": {"layers": s.layers, "hidden": s.hidden, "vocab": s.vocab,
                      "q_heads": s.q_heads, "kv_heads": s.kv_heads,
                      "head_dim": s.head_dim, "intermediate": s.intermediate},
            "attn_kinds": s.attn_kinds_summary(),
            "attn_kinds_short": _attn_short(s),
            "mlp_kind": s.mlp.kind,
            "params_elements": b.params_elements,
            "active_elements_per_token": b.active_elements_per_token,
            "capacity": b.as_dict(),
            "approximations": list(s.approximations),
            "structure_notes": list(s.structure_notes),
        }
        if self.report is not None:
            r = self.report
            ef = r.get("efficiency") or {}
            one = ((r.get("throughput") or {}).get("per_core") or {}).get("1")
            jt = (None if not ef else
                  (ef["by_billing"][ef["billing"]]["per_token_j"] or {}).get("e2e"))
            d["ledger"] = {
                "unit_blocks": r["call_counts"]["unit_blocks"],
                "actual_macs": r["call_counts"]["actual_macs"],
                "total_whole_block_pj": r["energy"]["total_whole_block_pj"],
                "total_unit_pj": r["energy"]["total_unit_pj"],
                "cycles_serial_1core": r["latency"]["cycles_serial_1core"],
                "ns_serial_1core": r["latency"]["ns_serial_1core"],
                "used_bytes": r["placement"]["used_bytes"],
            }
            d["metrics"] = {
                "e2e_tok_s": (None if one is None else one["e2e_tok_s"]),
                "j_per_token": jt,
            }
        return d


def rows_for(refs: Iterable[str], cfg: LlmConfig | None = None,
             family: str | None = None, *, prices=None,
             progress=None) -> list[CompareRow]:
    """逐个体算预算、能跑就跑，返回对照行。

    `cfg` 是**共同**规模（prompt / 生成 / 计费口径…），逐行只换 `model_spec`；
    `collect_trace` 一律关掉（对照表不读 trace，开着只是白占内存）。
    """
    cfg = cfg or LlmConfig()
    if prices is None:
        from .config import bind_hardware_config
        cfg = bind_hardware_config(cfg)
    cfg = replace(cfg, collect_trace=False)
    out: list[CompareRow] = []
    for ref in refs:
        spec = resolve_model(ref, family)
        p = ArchParams(spec)
        # 预算用**共同** cfg 算（与真正要跑的配置同一个），容量与形状事实因此可比。
        bud = capacity.budget(spec, cfg)
        row = CompareRow(ref=ref, status=OK, spec=p.spec, budget=bud)
        if not bud.fits:
            row.status = OVER_CAPACITY
            row.detail = (f"权重 + KV 装不下：需要 {bud.total_bytes:,} B，"
                          f"超出 {(-bud.free_bytes):,} B，顶不住的是「{bud.limited_by}」")
        else:
            try:
                res = run_llm(replace(cfg, model_spec=p.spec), prices=prices,
                              progress=progress)
            except NotImplementedError as e:
                row.status = NOT_IMPLEMENTED
                row.detail = str(e)
            else:
                row.report = res.report
        out.append(row)
    return out


def compare(refs: Iterable[str], cfg: LlmConfig | None = None,
            family: str | None = None, *, prices=None,
            progress=None) -> dict[str, Any]:
    """一次跑多个模型 → `{"rows": [...], "notes": [...], "approximations": {...}}`。

    进报告段 `[18]`；`report.format_compare()` 只负责把这里的原始值排版。
    """
    cfg = cfg or LlmConfig()
    if prices is None:
        from .config import bind_hardware_config
        cfg = bind_hardware_config(cfg)
    rows = rows_for(refs, cfg, family, prices=prices, progress=progress)
    notes = [
        "每一行都走同一个 `run_llm()` —— 对照行与单独跑一遍在构造上就不可能不一致。",
        f"共同规模：prompt {cfg.prompt_tokens} token + 生成 {cfg.max_new_tokens} token，"
        f"billing={cfg.billing}，MEM die {cfg.mem_die_bytes / (1 << 30):g} GiB。",
        "「激活 M/token」是均匀路由下一个 token 真正读到的参数量（稠密模型与总参数相等，"
        "故显示「—」）；整块口径下每个被激活的专家每 token 都要把权重过一遍，"
        "所以 MoE 的权重访存由专家主导。",
        f"装不下的模型不进 `run_llm`（容量门是纯解析式的）："
        f"{sum(1 for r in rows if r.status == OVER_CAPACITY)} 个被拒。"
        "第三段才实现的前向列 `NOT_IMPLEMENTED`，不静默跳过。",
        f"MXFP4 = {capacity.MXFP4_BYTES_PER_PARAM:g} B/参数"
        f"（0.5 payload + 1/32 E8M0 尺度）；是否装得下由实测配置的容量门判断。",
    ]
    approx = {r.ref: list(r.spec.approximations) for r in rows if r.spec.approximations}
    return {"rows": rows, "notes": notes, "approximations": approx,
            "config": {"prompt_tokens": cfg.prompt_tokens,
                       "max_new_tokens": cfg.max_new_tokens,
                       "billing": cfg.billing,
                       "mem_die_bytes": cfg.mem_die_bytes}}


def as_json(cmp_result: dict[str, Any]) -> dict[str, Any]:
    """把 `compare()` 的结果转成可 `json.dump` 的字典（无 numpy 标量、无 spec 对象）。

    每行带一份 `cells`（**已排版好的文本**）：报告段 [18] 与 `--json` 因此共用同一份
    呈现结果，不会出现「打印一份、存盘另一份」。
    """
    return {
        "config": cmp_result["config"],
        "notes": list(cmp_result["notes"]),
        "approximations": cmp_result["approximations"],
        "rows": [{**r.as_dict(), "cells": r.values()} for r in cmp_result["rows"]],
    }


__all__ = ["COLUMNS", "CompareRow", "OK", "OVER_CAPACITY", "NOT_IMPLEMENTED",
           "compare", "rows_for", "as_json"]
