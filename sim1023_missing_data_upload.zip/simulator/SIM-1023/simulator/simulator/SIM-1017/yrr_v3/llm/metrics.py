"""吞吐率（token/s）与能量效率（J/token）—— **只认新思（Synopsys）单价**。

用户口径（本次任务的硬要求）：
  * 要两个评估：推理**吞吐率**（每秒生成多少 token）与**能量效率**（生成一个 token 多少焦耳）；
  * 三个粒度都要：**TTFT**（首 token 延迟）、**decode 阶段**、**端到端**；
  * 正式运行的全部硬件输入来自统一 Synopsys measured JSON；加载器拒绝缺项。
    显式注入的组件测试价格不算 measured，指标保持 PENDING。

所以本模块的形状是「**有数就出数，没数就出一张缺口表**」，而不是「先算出来再打折」：
  * `throughput.per_core` / `efficiency.per_token_j` 为 `None` 时，表示**还缺新思数据**；
    同级的 `blocked_by` / `blocked_release` 会逐项说清缺哪个单价、要哪个新思工具或报告；
  * 同时给一栏 `clock_free`（用**拍数**而非秒表示的吞吐），因为它不依赖 `clock_ns`，
    在新思时钟到位之前仍有参考价值 —— 但它**也不是纯结构量**：搬运段的拍数本身是由 ns
    换算的，所以那一栏里明确标出这个占比（`ns_derived_share`），不含糊过去。

指标定义
--------
一次运行 = prefill（`P` 个 prompt token）+ 生成 `T` 个 token。账本被两个快照切三段：

    run 开始 ──► 首 token 采出 ──► 结束
      └─ TTFT ─┘   └── decode ──┘

  * `TTFT`   = prefill 全部 + 第 1 次 lm_head + 采样
  * `decode` = 其余 `T-1` 步（每步 1 个 token 的前向 + lm_head + 采样）
  * `e2e`    = TTFT + decode

用快照（`cost.LedgerMark`）而不是按阶段名去猜归属：`lm_head` 既是"首 token 的那一次"
也是"每个 decode 步的那一次"，光看阶段名分不开。快照直接钉住"首 token 出来时的账目"。

| 指标 | 粒度 | 公式 |
|---|---|---|
| token/s | TTFT | `1 / TTFT_s`（首 token 延迟的倒数） |
| | decode | `T / decode_s` |
| | 端到端 | `T / (TTFT_s + decode_s)` |
| J/token | decode | `decode_J / T` |
| | 端到端 | `(TTFT_J + decode_J) / T` |

两条**会被误当成 bug** 的性质，报告与 README 里都明写：
  * **J/token 与 core 数无关** —— `C x (work/C) = work`，能耗是守恒的；
  * **token/s 随 core 数变** —— 拍数按 `min(C, count)` 摊薄（上界乐观，见 `Ledger.total_cycles`）。
"""
from __future__ import annotations

from typing import Any, Iterable, Sequence

from . import provenance
from .cost import LedgerMark

# 单位块/单价的 pJ -> J
_PJ_PER_J = 1e12
# ns -> s
_NS_PER_S = 1e9

DEFAULT_CORES: tuple[int, ...] = (1, 2, 4, 8, 16)

_THROUGHPUT_DEF = (
    "TTFT = prefill 全部 + 第 1 次 lm_head + 采样；"
    "decode = 其余 T-1 步；e2e = TTFT + decode。"
    "三个粒度都由账本快照切出（不按阶段名猜归属），所以 T=0 与 n_runs>1 也成立。"
)
_EFFICIENCY_DEF = (
    "J/token 按**生成了几个 token** 计（分母是 T，不含 prompt）："
    "decode = decode 段能耗 / T；e2e = 整段能耗 / T。"
    "TTFT 段没有「每 token」的说法，它给的是**首 token 的能耗**（J，不是 J/token）。"
)
_CORE_NOTE = (
    "能耗与 core 数**无关**（C x (work/C) = work，守恒），所以 J/token 只有一个数、"
    "不带 core 维度；而 token/s 随 core 数变，按 cores 列表逐列给出 —— "
    "这不是 bug，是两种量的性质不同。cores > 1 是**上界乐观**的摊薄。"
)
_NOTE_TAIL = (
    "Hardware inputs come from the unified Synopsys measured JSON. "
    "Runtime totals are architectural projections from those measured inputs; component-test prices are marked TEST_ONLY."
)


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------

def _sec(cycles: float, clock_ns: float) -> float:
    return cycles * clock_ns / _NS_PER_S


def _div(a: float, b: float) -> float | None:
    """除法：分母为 0 时给 `None`（而不是 inf/nan —— 报告里要读得懂）。"""
    return (a / b) if b else None


def _blocked(reqs: Sequence[provenance.PriceReq],
             filled: Iterable[str]) -> list[dict[str, Any]]:
    """挑出**不是**新思档的单价，逐条写清"缺什么、要哪个工具"。

    字段与 `provenance.PriceReq.as_dict()` 对齐（含 `blocks`），这样报告的两张缺口表
    （`metrics` 的 `blocked_release` 与 `audit` 的 `missing`）读法一致。
    """
    out: list[dict[str, Any]] = []
    for rr in provenance.resolve(reqs, filled):
        if not rr.is_synopsys:
            out.append({"name": rr.name, "tier": rr.tier,
                        "tier_label": provenance.TIER_LABEL[rr.tier],
                        "source": rr.source, "needed_from": rr.needed_from,
                        "blocks": rr.blocks, "note": rr.note})
    return out


def _gate(reqs: Sequence[provenance.PriceReq],
          filled: Iterable[str]) -> tuple[bool, list[dict[str, Any]]]:
    blocked = _blocked(reqs, filled)
    return (not blocked), blocked


# --------------------------------------------------------------------------
# 吞吐率
# --------------------------------------------------------------------------

def throughput(*, ttft: LedgerMark, decode: LedgerMark, prices,
               gen_tokens: int, prompt_tokens: int = 0,
               billing: str = "whole_block", cores_list: Sequence[int] = DEFAULT_CORES,
               filled: Iterable[str] = (),
               ns_derived_share: float | None = None) -> dict[str, Any]:
    """吞吐率：TTFT / decode / 端到端三个粒度，按 core 数逐列。

    `ttft` / `decode` 是**已经相减过的净账**（`LedgerMark`），不是绝对快照。
    缺新思时钟或搬运延迟时，`per_core` 为 `None`，只给不受时钟影响的 `clock_free`。
    """
    reqs = provenance.requirements_for("throughput", billing)
    ok, blocked = _gate(reqs, filled)
    clock_ns = float(getattr(prices, "clock_ns", 0.0))
    T = int(gen_tokens)
    keys = [str(k) for k in cores_list]

    # 拍数（不受任何单价影响，先算出来 —— clock_free 栏要用）
    cyc: dict[str, dict[str, float]] = {
        k: {"ttft": ttft.cycles_by_cores.get(k, 0.0),
            "decode": decode.cycles_by_cores.get(k, 0.0),
            "e2e": ttft.cycles_by_cores.get(k, 0.0) + decode.cycles_by_cores.get(k, 0.0)}
        for k in keys
    }

    # ---- clock_free：用拍数表示的吞吐（不依赖 clock_ns）----
    clock_free: dict[str, Any] = {}
    for k in keys:
        c = cyc[k]
        clock_free[k] = {
            "ttft_cycles": c["ttft"], "decode_cycles": c["decode"], "e2e_cycles": c["e2e"],
            # *每 1e6 拍*产出多少 token —— 比"每拍"好读，量级也不至于小到看不清
            "ttft_tokens_per_1e6_cycles": _div(1e6, c["ttft"]),
            "decode_tokens_per_1e6_cycles": _div(T * 1e6, c["decode"]),
            "e2e_tokens_per_1e6_cycles": _div(T * 1e6, c["e2e"]),
        }
    clock_free["ns_derived_share"] = ns_derived_share
    clock_free["caveat"] = (
        "这一栏只把秒换成了拍，**并不等于**「与新思无关」：搬运段（MEM / PHY / HB）的拍数"
        "本身是 ceil((mem_ns + phy_ns + hb_ns) / clock_ns) 换算来的，仍依赖时钟与三段延迟。"
        "`ns_derived_share` 就是这部分拍数占总拍数的比例 —— 读这一栏时要连着它一起读。"
    )
    clock_free["structural_note"] = (
        "真正与时钟无关的只有**结构量**拍数：阵列块 block_cycles 与 GSRAM 访问次数。"
    )

    # ---- per_core：只认新思；缺就不出数 ----
    per_core: dict[str, Any] | None = None
    if ok:
        per_core = {}
        for k in keys:
            c = cyc[k]
            ttft_s = _sec(c["ttft"], clock_ns)
            dec_s = _sec(c["decode"], clock_ns)
            e2e_s = ttft_s + dec_s
            per_core[k] = {
                "ttft_s": ttft_s, "decode_s": dec_s, "e2e_s": e2e_s,
                "ttft_tok_s": _div(1.0, ttft_s),          # 首 token 延迟的倒数
                "decode_tok_s": _div(T, dec_s),
                "e2e_tok_s": _div(T, e2e_s),
                "tokens_per_s_per_core_note":
                    "e2e 与 decode 都是**按生成 token 数**计；TTFT 只出 1 个 token，"
                    "所以它的 token/s 就是 1/TTFT_s（延迟的倒数，便于看首字快慢）",
            }

    return {
        "status": "APPLIED" if ok else "PENDING",
        "gated_by": "统一 Synopsys measured JSON",
        "blocked_by": [b["name"] for b in blocked],
        "blocked_release": blocked,
        "gen_tokens": T,
        "prompt_tokens": int(prompt_tokens),
        "billing": billing,
        "clock_ns": clock_ns,
        "per_core": per_core,
        "clock_free": clock_free,
        "definition": _THROUGHPUT_DEF,
        "core_note": _CORE_NOTE,
        "note": _NOTE_TAIL,
    }


# --------------------------------------------------------------------------
# 能量效率
# --------------------------------------------------------------------------

def efficiency(*, ttft: LedgerMark, decode: LedgerMark, prices,
               gen_tokens: int, billing: str = "whole_block",
               filled: Iterable[str] = ()) -> dict[str, Any]:
    """能量效率：decode 与端到端的 J/token（外加首 token 的 J）。

    两种计费口径（`whole_block` / `unit`）**各自单独过门** —— 因为 `unit` 口径不读
    整块能耗本身（它按实际 MAC 数计，只用 PE 与归约两个 §8 实测单价），缺口比
    `whole_block` 少一项。所以两个口径的状态可能不同，这里分别给。
    """
    T = int(gen_tokens)
    out: dict[str, dict[str, Any]] = {}

    for bill in ("whole_block", "unit"):
        reqs = provenance.requirements_for("efficiency", bill)
        ok, blocked = _gate(reqs, filled)
        ttft_pj = ttft.whole_pj if bill == "whole_block" else ttft.unit_pj
        dec_pj = decode.whole_pj if bill == "whole_block" else decode.unit_pj
        e2e_pj = ttft_pj + dec_pj

        out[bill] = {
            "status": "APPLIED" if ok else "PENDING",
            "blocked_by": [b["name"] for b in blocked],
            "blocked_release": blocked,
            # 未通过来源检查的组件测试账目不提升为正式效率指标。
            "energy_j": {"ttft": ttft_pj / _PJ_PER_J, "decode": dec_pj / _PJ_PER_J,
                         "e2e": e2e_pj / _PJ_PER_J},
            # 效率指标：过门才有
            "per_token_j": (None if not ok else {
                "decode": _div(dec_pj, _PJ_PER_J * T),
                "e2e": _div(e2e_pj, _PJ_PER_J * T),
                "first_token_j": ttft_pj / _PJ_PER_J,   # 不是"每 token"，是首 token 那一下
            }),
        }

    return {
        "status": out[billing]["status"],
        "billing": billing,
        "gen_tokens": T,
        "by_billing": out,
        "core_invariant": True,
        "definition": _EFFICIENCY_DEF,
        "core_note": _CORE_NOTE,
        "note": _NOTE_TAIL,
    }


# --------------------------------------------------------------------------
# 总入口
# --------------------------------------------------------------------------

def build(*, ttft: LedgerMark, decode: LedgerMark, prices,
          gen_tokens: int, prompt_tokens: int = 0,
          billing: str = "whole_block", cores_list: Sequence[int] = DEFAULT_CORES,
          filled: Iterable[str] = (), ns_derived_share: float | None = None
          ) -> dict[str, Any]:
    """算出报告里的 `throughput` / `efficiency` / `provenance` 三段。

    `ttft` / `decode` 必须是**净账**（相邻快照相减的结果）。用 `LedgerMark.__sub__` 得到。
    """
    return {
        "throughput": throughput(
            ttft=ttft, decode=decode, prices=prices, gen_tokens=gen_tokens,
            prompt_tokens=prompt_tokens, billing=billing,
            cores_list=cores_list, filled=filled, ns_derived_share=ns_derived_share),
        "efficiency": efficiency(
            ttft=ttft, decode=decode, prices=prices, gen_tokens=gen_tokens,
            billing=billing, filled=filled),
        "provenance": provenance.audit(prices, billing=billing, filled=filled),
    }
