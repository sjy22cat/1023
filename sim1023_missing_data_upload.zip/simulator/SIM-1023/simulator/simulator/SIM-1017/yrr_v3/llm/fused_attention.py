"""Independent measured profiles for the FP32 16-context x 4-dimension evaluator.

Existing hardware prices are read-only. A missing profile never falls back to
the old pair-serial price, an interpolated energy, or a nominal 1 GHz result.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

SCHEMA = "yrr-fused-attention-16x4/v1"
SCOPE = "single_head_fp32_including_local_kv_registers_excluding_external_memory_and_leakage"
PARAMETERS = dict(HEAD_DIM=128, TILE_SIZE=32, CONTEXT_PARALLEL=16, MAX_CONTEXT=1152)
RTL_FILES = ("attention_online_merge_fp32.sv", "attention_context_4dim_lane.sv",
             "attention_head_16ctx_4dim_eval.sv")


def _number(value, name, *, positive=False, integer=False):
    if (isinstance(value, bool) or not isinstance(value, (float, int))
            or not math.isfinite(value) or value < 0 or (positive and value == 0)
            or (integer and int(value) != value)):
        raise ValueError(f"fused attention: invalid/missing {name}")
    return value


class FusedAttentionProfiles:
    def __init__(self, data: dict, *, source: str, clock_ns: float, head_dim: int):
        if data.get("schema") != SCHEMA or data.get("status") != "MEASURED":
            raise ValueError("fused attention requires MEASURED profiles; pending data cannot price inference")
        if (data.get("scope") != SCOPE or data.get("parameters") != PARAMETERS
                or any(type(data["parameters"][k]) is not int for k in PARAMETERS)):
            raise ValueError("fused attention: incompatible scope/RTL parameters")
        if head_dim != PARAMETERS["HEAD_DIM"]:
            raise ValueError("fused_16x4 requires HEAD_DIM=128; no small-model scaling")
        period = _number(data.get("clock_ns"), "clock_ns", positive=True)
        if not math.isclose(period, clock_ns, rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError("fused attention and existing hardware clocks differ; characterize a common clock")
        checks = data.get("validation", {})
        if any(checks.get(k) is not True for k in
               ("official_dw_numeric_pass", "full_top_mapped", "no_blackboxes",
                "setup_pass", "hold_pass")):
            raise ValueError("fused attention: official numeric/full-top mapping/setup/hold checks must pass")
        provenance = data.get("provenance", {})
        for name in ("tools", "library", "pvt", "reports", "activity_policy"):
            if not provenance.get(name):
                raise ValueError(f"fused attention: missing provenance.{name}")
        hashes = provenance.get("rtl_sha256", {})
        if not isinstance(hashes, dict):
            raise ValueError("fused attention: missing RTL SHA256 map")
        for name in RTL_FILES:
            value = hashes.get(name, "")
            if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise ValueError(f"fused attention: missing RTL SHA256 for {name}")
        records = data.get("profiles")
        if not isinstance(records, dict) or not records:
            raise ValueError("fused attention: no exact context profiles")
        for key, record in records.items():
            if not isinstance(key, str) or not key.isdecimal():
                raise ValueError(f"fused attention: invalid context {key}")
            n = int(key)
            if str(n) != key or not 1 <= n <= PARAMETERS["MAX_CONTEXT"]:
                raise ValueError(f"fused attention: invalid context {key}")
            if not isinstance(record, dict):
                raise ValueError(f"fused attention: missing record for N={key}")
            cycles = _number(record.get("cycles"), f"N={n}.cycles", positive=True, integer=True)
            loads = _number(record.get("kv_load_cycles"), f"N={n}.kv_load_cycles", integer=True)
            if loads != (n + 31)//32 or cycles <= loads:
                raise ValueError(f"fused attention: N={n} requires ideal one-tile/handshake load window")
            _number(record.get("dynamic_pj"), f"N={n}.dynamic_pj", positive=True)
            if not record.get("report"):
                raise ValueError(f"fused attention: missing N={n} report")
        self.data, self.source = data, source
        self.used = set()

    @classmethod
    def load(cls, path, *, clock_ns, head_dim):
        if not path:
            raise ValueError("fused_16x4 needs --attention-calibration with measured data")
        p = Path(path)
        return cls(json.loads(p.read_text(encoding="utf-8-sig")),
                   source=str(p.resolve()), clock_ns=clock_ns, head_dim=head_dim)

    def profile(self, n):
        record = self.data["profiles"].get(str(n))
        if record is None:
            raise ValueError(f"fused attention: missing measured N={n}; run the requested context sweep (no interpolation)")
        self.used.add(str(n))
        return record

    def bill(self, ledger, phase, layer, n, heads, queries=1):
        record = self.profile(n)
        waves = (heads + 15)//16
        row = ledger.row(phase, layer, "attn_fused_16x4")
        row.count += heads * queries
        # All head units execute concurrently; all external traffic is billed
        # separately with the simulator's existing serial aggregate transfer model.
        row.cycles += (record["cycles"] - record["kv_load_cycles"]) * waves * queries
        energy = record["dynamic_pj"] * heads * queries
        row.whole_pj += energy
        row.unit_pj += energy  # Includes MAC + softmax + local storage once.
        row.macs += 2 * n * 128 * heads * queries
        row.elements += n * heads * queries
        row.origin = self.source
        row.pending_components.update(("attention_mxfp4_fp32_bridge",
                                       "attention_multihead_distribution",
                                       "attention_array_leakage_delta"))

    def as_dict(self, heads):
        return dict(implementation="fused_16x4", context_rows=16, dimension_columns=4,
                    logical_tiles_per_head=64, array_tile_rows=32, array_tile_columns=32,
                    concurrent_heads=16, head_waves=(heads+15)//16,
                    source=self.source, profiles_used=sorted(self.used, key=int),
                    measurement_status="ARCHITECTURAL_PROJECTION_FROM_SINGLE_HEAD_MEASUREMENTS",
                    prefill="causal: query t uses context pos+t+1; queries serialized",
                    kv_sharing="independent reads per Q head; GQA broadcast not implemented",
                    timing="compute waves plus existing serial transfers; no overlap; KV load time=max(ideal handshakes, transfers)",
                    area="FP32 evaluator area is separate; cannot add it to MXFP4 array area and claim MAC reuse",
                    pending=["MXFP4/FP32 bridge", "16-head distribution and shared-memory scheduling",
                             "integrated-array leakage", "physical MXFP4 multi-column RTL integration"])


def required_contexts(prompt_tokens, output_tokens):
    """Causal prefill plus output_tokens-1 decode forwards; final output has no forward."""
    if prompt_tokens < 1 or output_tokens < 0:
        raise ValueError("prompt_tokens >= 1 and output_tokens >= 0 required")
    return list(range(1, prompt_tokens + max(output_tokens - 1, 0) + 1))
