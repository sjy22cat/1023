"""模拟器张量名 ↔ HF `state_dict` 张量名。

替代 `weights.py::_hf_name_map`（原表只认 Qwen3 的九个名字）。**表驱动、不猜**：
每个名字要么在表里，要么**硬报错并列出该张量**；绝不做子串模糊匹配
（`gate` 会同时命中 `gate_proj` 与 `mlp.gate.weight`，模糊匹配必然串味）。

命名的族差异分三类，逐类建模：

1. **同义不同名**：Mixtral 的专家 FFN 用 `w1/w2/w3`（`w1` 是 gate、`w3` 是 up、
   `w2` 是 down），Phi-2 的 FFN 用 `fc1/fc2`（`fc1` 是 up、`fc2` 是 down）。
2. **容器名不同**：Mixtral 的专家挂在 `block_sparse_moe` 下而不是 `mlp` 下。
3. **多一层复数**：DeepSeek-V3 用 `mlp.shared_experts.*`，Qwen3-MoE 用
   `mlp.shared_expert.*`（少一个 s）。

**本模块未对真实 checkpoint 验证过**：本环境无网络（访问 huggingface.co 报
`read ECONNRESET`，已实测），拿不到任何真实 `state_dict`。表里的名字来自各族的
公开命名，首次接真 checkpoint 时**必须复验** —— 这也是 `hf_to_sim()` 在找不到
名字时硬报错（而不是跳过）的原因：失败要响，不要静默少读一个张量。
"""
from __future__ import annotations

from .spec import ArchSpec

# --------------------------------------------------------------------------
# 顶层张量
# --------------------------------------------------------------------------

_TOP = {
    "embed_tokens": "model.embed_tokens.weight",
    "lm_head": "lm_head.weight",
    "model.norm": "model.norm.weight",
}

# 每层的属性名（`L00.` 之后的最后一段 -> `model.layers.0.` 之后的路径）
_ATTN = {
    "q_proj": "self_attn.q_proj.weight",
    "k_proj": "self_attn.k_proj.weight",
    "v_proj": "self_attn.v_proj.weight",
    "o_proj": "self_attn.o_proj.weight",
    "qkv_proj": "self_attn.qkv_proj.weight",          # Phi-3 的 fused QKV
    "q_norm": "self_attn.q_norm.weight",
    "k_norm": "self_attn.k_norm.weight",
    # MLA（DeepSeek-V2 系）
    "q_a_proj": "self_attn.q_a_proj.weight",
    "q_b_proj": "self_attn.q_b_proj.weight",
    "kv_a_proj_with_mqa": "self_attn.kv_a_proj_with_mqa.weight",
    "kv_b_proj": "self_attn.kv_b_proj.weight",
    "q_a_layernorm": "self_attn.q_a_layernorm.weight",
    "kv_a_layernorm": "self_attn.kv_a_layernorm.weight",
}

_NORM = {
    "input_layernorm": "input_layernorm.weight",
    "post_attention_layernorm": "post_attention_layernorm.weight",
    "pre_feedforward_layernorm": "pre_feedforward_layernorm.weight",
    "post_feedforward_layernorm": "post_feedforward_layernorm.weight",
}

# 稠密 FFN 的「一段名 -> 属性名」，按族分岔（默认即 Qwen/Llama 的写法）
_MLP_DENSE = {
    "default": {"gate_proj": "gate_proj", "up_proj": "up_proj",
                "down_proj": "down_proj", "gate_up_proj": "gate_up_proj"},
    "phi": {"up_proj": "fc1", "down_proj": "fc2"},
}

# 专家 FFN 的容器名与每段名
_MOE_CONTAINER = {
    "default": "mlp",              # Qwen3-MoE / Qwen2-MoE / DeepSeek / OLMoE
    "mixtral": "block_sparse_moe",
}
_MOE_EXPERTS = {
    "default": {"gate_proj": "gate_proj", "up_proj": "up_proj", "down_proj": "down_proj"},
    "mixtral": {"gate_proj": "w1", "up_proj": "w3", "down_proj": "w2"},
}
_MOE_ROUTER = {"default": "gate", "mixtral": "gate"}
# 共享专家的容器：Qwen3-MoE 是 `shared_expert`，DeepSeek-V3 是 `shared_experts`
_MOE_SHARED = {"default": "shared_expert", "deepseek_v3": "shared_experts"}
_MOE_SHARED_GATE = {"default": "shared_expert_gate"}


def _moe_flavor(spec: ArchSpec) -> str:
    """专家命名风格：`mixtral`（w1/w3/w2 + block_sparse_moe）或 `default`。"""
    return "mixtral" if spec.family in ("mixtral",) else "default"


def _dense_flavor(spec: ArchSpec) -> str:
    """稠密 FFN 命名风格：`phi`（`fc1` / `fc2`，无 gate）或 `default`。

    **phi3 不在其中**：Phi-3 虽然同属 Phi 系，但 FFN 是 `gate_up_proj`（fused
    SwiGLU），与 Phi-1/2 的 `fc1` / `fc2` 不是一回事 —— 按族名前缀一刀切会读错张量。
    """
    return "phi" if spec.family == "phi" else "default"


def _shared_flavor(spec: ArchSpec) -> str:
    return "deepseek_v3" if spec.family in ("deepseek_v3",) else "default"


# --------------------------------------------------------------------------
# 入口
# --------------------------------------------------------------------------

def hf_name(sim_name: str, spec: ArchSpec) -> str:
    """模拟器张量名 → HF 张量名。

    `L07.q_proj` → `model.layers.7.self_attn.q_proj.weight`；
    `L07.experts.003.up_proj` → `model.layers.7.mlp.experts.3.up_proj.weight`。
    """
    if sim_name in _TOP:
        return _TOP[sim_name]
    if not sim_name.startswith("L") or "." not in sim_name:
        raise KeyError(f"不认识的模拟器张量名：{sim_name!r}")
    head, rest = sim_name.split(".", 1)
    try:
        layer = int(head[1:])
    except ValueError:
        raise KeyError(f"不认识的模拟器张量名：{sim_name!r}") from None
    prefix = f"model.layers.{layer}."

    # 专家：`experts.{e}.{段}`
    if rest.startswith("experts."):
        _, e, seg = rest.split(".", 2)
        flav = _moe_flavor(spec)
        seg_hf = _MOE_EXPERTS[flav].get(seg)
        if seg_hf is None:
            raise KeyError(f"不认识的专家段名：{seg!r}"
                           f"（已知：{', '.join(sorted(_MOE_EXPERTS[flav]))}）")
        return f"{prefix}{_MOE_CONTAINER[flav]}.experts.{int(e)}.{seg_hf}.weight"

    # 共享专家：`shared.{s}.{段}`
    if rest.startswith("shared."):
        _, s, seg = rest.split(".", 2)
        seg_hf = _MOE_EXPERTS[_moe_flavor(spec)].get(seg)
        if seg_hf is None:
            raise KeyError(f"不认识的共享专家段名：{seg!r}")
        return f"{prefix}{_MOE_CONTAINER[_moe_flavor(spec)]}." \
               f"{_MOE_SHARED[_shared_flavor(spec)]}.{int(s)}.{seg_hf}.weight"

    if rest == "router":
        return f"{prefix}{_MOE_CONTAINER[_moe_flavor(spec)]}." \
               f"{_MOE_ROUTER[_moe_flavor(spec)]}.weight"
    if rest == "shared_gate":
        return f"{prefix}{_MOE_CONTAINER[_moe_flavor(spec)]}." \
               f"{_MOE_SHARED_GATE['default']}.weight"

    if rest in _ATTN:
        return prefix + _ATTN[rest]
    if rest in _NORM:
        return prefix + _NORM[rest]
    dense = _MLP_DENSE[_dense_flavor(spec)]
    if rest in dense:
        return f"{prefix}mlp.{dense[rest]}.weight"
    raise KeyError(f"不认识的模拟器张量名：{sim_name!r}")


def layer_tensor_names(spec: ArchSpec, layer: int) -> dict[str, str]:
    """第 `layer` 层「模拟器名 → HF 名」，顺序与 `ArchParams` 给出的清单一致。"""
    from .params import ArchParams                      # 延迟导入：避免环

    p = ArchParams(spec)
    out: dict[str, str] = {}
    for m in p.layer_matrices(layer):
        out[m.name] = hf_name(m.name, spec)
    for nm, _ in p.layer_norms(layer):
        out[nm] = hf_name(nm, spec)
    return out


def hf_to_sim(spec: ArchSpec) -> dict[str, str]:
    """整模型「HF 名 → 模拟器名」（`weights.py` 读 checkpoint 时用）。

    重名即报错：两个模拟器张量映射到同一个 HF 张量说明表写错了。
    """
    from .params import ArchParams

    p = ArchParams(spec)
    out: dict[str, str] = {}
    names = [m.name for m in p.matrices()] + [p.final_norm()[0]]
    for l in range(spec.layers):
        names += [nm for nm, _ in p.layer_norms(l)]
    for sim in names:
        hf = hf_name(sim, spec)
        if hf in out and out[hf] != sim:
            raise KeyError(f"HF 张量名 {hf!r} 同时对应 {out[hf]!r} 与 {sim!r}")
        out[hf] = sim
    return out


def sim_to_hf(spec: ArchSpec) -> dict[str, str]:
    """`hf_to_sim` 的反向表（同一份构造，键值互换）。"""
    return {v: k for k, v in hf_to_sim(spec).items()}
