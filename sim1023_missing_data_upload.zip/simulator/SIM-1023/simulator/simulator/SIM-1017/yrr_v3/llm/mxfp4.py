"""MXFP4（W4A4）量化 / 反量化。

**只复用** `yrr_v3.formats` 的码本与解码器（`FP4_VALUES` / `decode_fp4`）；
`yrr_v3/model.py` 的 `_payload_from_values()` **一行不改**，但本层**不复用它**，
原因见下面的「与既有编码器的两处差异」。本文件给的是**正确的 MXFP4**，且是向量化的
（`_payload_from_values` 是逐 group 的 Python 循环，对 151936x1024 的词表要跑 486 万个
group，慢到不可用）。

量化规则（MX 规范 / 数据集口径）：
  * 每 `group = 32` 个元素共享一个 **E8M0** 指数（无符号，bias 127）；
  * 指数 `exp = clip(floor(log2(amax / 6)) + 127, 0, 254)`，`amax = 0` 时取 127；
    E8M0=255 保留给非有限值，不能作为有限推理 scale；
  * 尾数是 **MXFP4 码本** `{0, .5, 1, 1.5, 2, 3, 4, 6}` 上的最近邻（`argmin |·|`，
    并列取**先出现**的那个，与 `np.argmin` 同口径）；
  * 符号位单独一位（码值 `idx | 8` 表示负）。

与既有编码器 `model._payload_from_values()` 的两处差异（**它有两处缺陷，不能继承**）
------------------------------------------------------------------------------------
自检 `tests/test_llm.py::test_legacy_encoder_has_two_defects` 把这个差异**钉死**，
也顺手记录既有实现的行为：

1. **共享指数的粒度**。既有实现取 `mx = max(|block|)`，而 `block` 是
   `values[..., g*32:(g+1)*32]` —— 这是**整个块**（含所有行）的最大值，于是
   **一列 32 个元素的所有行共用一个指数**（`out_scale[..., g] = exp` 只写一个标量）。
   真正的 MXFP4 要求**每个 32 元素组各有一个指数**。当张量只有一行时两者等价；
   多行时既有实现会把幅值小的那些行整行压成 0。实测：两行各 32 个元素、第一行全
   1000.0、第二行全 1.0，既有实现给两行同一个指数 134，第二行解码回来**整行 0.0**；
   本实现第二行是 0.75（= 1.5 x 2^-1）。
2. **负值全部丢成 -0.0**。既有实现写的是
   `argmin(|scaled - |codebook||)` —— 比的是**带符号**的 `scaled`，而码本全为非负，
   所以任何负值的最近邻都落在码本第 0 项（0.0），再补上符号位 → **-0.0**。
   实测：`rng.normal(0,1,(4,32))` 里 59 个负值，解码回来**一个负值都没有**，
   且 `scale` 形状是 `(4, 1)`、4 行只取到 1 个不同的指数（两条缺陷同时出现）。
   单个例子：`[2.041, -2.556, 0.418, -0.568]` → payload `[7 8 3 8]`、指数 125，
   解码 `[1.5, -0.0, 0.375, -0.0]`。

后果：既有 V3 模型的数值通路等于「只保留正半轴」。对**性能/能耗/面积**模型无影响
（它只用错值算 `errors.max_abs`），但**对真实 LLM 推理是致命的** —— 一半的权重与
激活会被清零，softmax 的输入全是非正数。故本层自己实现，并在
`README_LLM.md`「与既有实现的两处差异」里写明。**没有修改 `model.py`**：
现有 45 项自检与 `check_rtl.py` 逐位交叉验证仍覆盖旧行为。
"""
from __future__ import annotations

import numpy as np

from ..formats import FP4_VALUES, decode_fp4

GROUP = 32
MAGNITUDES = np.asarray(FP4_VALUES[:8], dtype=np.float32)   # {0,.5,1,1.5,2,3,4,6}
# 码本单调，所以「最近邻 + 并列取先出现」等价于**数一数有几个中点在 a 左边**。
# 这比 (...,8) 的距离矩阵快一个量级，且逐位等价 —— 自检
# `test_quantizer_matches_rowwise_reference` 用一份朴素实现（逐组 float64、逐元素
# `argmin`）钉住这点。
_MIDPOINTS = (MAGNITUDES[:-1].astype(np.float64) + MAGNITUDES[1:].astype(np.float64)) / 2.0
# 小数（`>=` 的比较阈值）用 **float32**：{1/4, 3/4, 5/4, 7/4, 5/2, 7/2, 5} 全都是
# 二进制精确值，float32 与 float64 下逐位相同，所以这个窄化不改变任何结果。
_MID32 = _MIDPOINTS.astype(np.float32)

# 工作集上限（元素个数）。1<<22 个 = 16 MiB / 份 float32 临时量，安全。
_CHUNK_ELEMS = 1 << 22


def _ceil_div(a: int, b: int) -> int:
    return -(-int(a) // int(b))


def payload_bytes(shape, group: int = GROUP) -> int:
    """一段张量的 MXFP4 **payload** 字节数（4 bit / 元素）。"""
    n = 1
    for d in shape:
        n *= int(d)
    return _ceil_div(n, 2)


def scale_bytes(shape, group: int = GROUP) -> int:
    """一段张量的 E8M0 **尺度**字节数（8 bit / 32 元素）。"""
    if not shape:
        return 1
    n = 1
    for d in shape[:-1]:
        n *= int(d)
    return n * _ceil_div(int(shape[-1]), group)


def mx_bytes(shape, group: int = GROUP) -> int:
    """一段张量在 MEM die 上的 MXFP4 **总**字节（payload + 尺度）。

    这是全层唯一的字节口径：`WeightEntry.nbytes`、容量门的每一项都用它，
    避免两处各写一遍 `payload + scale` 而慢慢分歧。
    """
    return payload_bytes(shape, group) + scale_bytes(shape, group)


def quantize(x: np.ndarray, group: int = GROUP) -> tuple[np.ndarray, np.ndarray]:
    """`x` → `(payload, scale)`。

    * `payload` 与 `x` **同形状**，`uint8`，只用低 4 位；
      最后一个维不是 `group` 整数倍时，**尾部按 0 补齐**后量化、再裁回原形状
      （补 0 不影响任何真实元素的码值，因为 exp 由整组的 amax 决定，而 amax 不变）。
    * `scale` 形状 = `x.shape[:-1] + (ceil(last/group),)`，`uint8` E8M0。

    精度口径（**两条都是必须的，自检逐位钉住**）：

    1. **指数在 float64 里算。** `np.log2` 在 float32 下会在 2 的整数次幂附近差一个
       ULP，`floor` 就会掉一档。`amax` 本身是 float32 的精确值（float32 → float64
       无损），所以 `float64` 这一步只作用在很小的 `(rows, ng, 1)` 上。
    2. **尾数选择在 float32 里做**（与阵列的定点通路同宽）。这一步**不损失任何精度**：
       `2**(127-exp)` 是**精确的 2 的幂**（float32 下 2^-149..2^127 都可精确表示），
       而「乘以一个 2 的幂」只改阶码、不动尾数，所以 `blk32 * inv32` 是**无舍入**的，
       与 `blk64 / exp2(exp-127)` 逐位相同；中点是二进制精确值，比较也逐位相同。
    """
    x = np.asarray(x)
    orig = x.shape
    if x.ndim == 0:
        x = x.reshape(1)
    lead, last = x.shape[:-1], x.shape[-1]
    ng = _ceil_div(last, group)
    pad = ng * group - last
    zeros = np.zeros(lead + (pad,), dtype=np.float32)
    xp = np.concatenate([x.astype(np.float32, copy=False), zeros], axis=-1) if pad \
        else x.astype(np.float32, copy=False)

    rows = int(np.prod(lead)) if lead else 1
    g = xp.reshape(rows, ng, group)

    payload = np.empty((rows, ng, group), dtype=np.uint8)
    scale = np.empty((rows, ng), dtype=np.uint8)
    m0 = _MID32[0]

    step = max(1, _CHUNK_ELEMS // (ng * group))
    for s in range(0, rows, step):
        e = min(rows, s + step)
        blk = g[s:e]                                     # (r, ng, group) float32
        amax = np.max(np.abs(blk), axis=-1, keepdims=True).astype(np.float64)
        with np.errstate(divide="ignore", invalid="ignore"):
            raw = np.floor(np.log2(amax / 6.0)) + 127.0
        exp = np.where(amax == 0.0, 127.0, np.clip(raw, 0.0, 254.0))
        scale[s:e] = exp[..., 0].astype(np.uint8)
        # 除以 2**(exp-127) 换成乘 2**(127-exp)：乘一个精确的 2 的幂是无舍入的
        scaled = blk * np.exp2(127.0 - exp).astype(np.float32)
        a = np.abs(scaled)
        # 最近邻 = 数出「小于 a 的中点个数」；并列取先出现的码值
        best = (a >= m0).view(np.uint8).copy()           # 1 字节/元素，7 趟
        for c in _MID32[1:]:
            best += (a >= c)
        best |= (scaled < 0).view(np.uint8) << np.uint8(3)
        payload[s:e] = best

    pay = payload.reshape(lead + (ng * group,))[..., :last] if pad else payload.reshape(orig)
    return pay.reshape(orig), scale.reshape(lead + (ng,)) if lead else scale.reshape((ng,))


def dequantize(payload: np.ndarray, scale: np.ndarray, group: int = GROUP,
               out_dtype=np.float32) -> np.ndarray:
    """`(payload, scale)` → fp32 数值（复用 `formats.decode_fp4`）。

    分块做，避免 `scale.repeat(32)` 把 151936x1024 的张量膨胀成 622 MiB 的临时量。
    """
    p = np.asarray(payload)
    s = np.asarray(scale, dtype=np.uint8)
    orig = p.shape
    last = orig[-1] if orig else 1
    ng = _ceil_div(last, group)
    rows = int(np.prod(orig[:-1])) if orig[:-1] else 1

    pf = p.reshape(rows, last)
    sf = s.reshape(rows, ng) if s.size else np.full((rows, ng), 127, dtype=np.uint8)
    if ng * group != last:
        # 最后一维不是 group 的整数倍：补到整数倍再解码（补位不影响真实元素，
        # 因为它的尺度就是同组那个尺度），解完再裁回原宽度。
        pad = ng * group - last
        pf = np.concatenate([pf, np.zeros((rows, pad), dtype=pf.dtype)], axis=-1)
    out = np.empty((rows, ng * group), dtype=out_dtype)
    step = max(1, _CHUNK_ELEMS // (ng * group))
    for a in range(0, rows, step):
        b = min(rows, a + step)
        wide = sf[a:b].repeat(group, axis=-1)
        out[a:b] = decode_fp4(pf[a:b], wide).astype(out_dtype)
    return out[:, :last].reshape(orig)


def quantize_dequantize(x: np.ndarray, group: int = GROUP) -> np.ndarray:
    """一次「量化 → 反量化」往返（W4A4 里每个算子边界都要做的那一步）。"""
    p, s = quantize(x, group)
    return dequantize(p, s, group)
