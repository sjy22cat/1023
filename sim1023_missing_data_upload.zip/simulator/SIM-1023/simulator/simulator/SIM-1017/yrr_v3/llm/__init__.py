"""SIM-1017 的模型推理、形状账本与质量评估接口。

硬件容量/单价只从统一 Synopsys measured JSON 读取。
LLM 搬运当前按串行聚合账本建模，功能与限制见 README_SIM-1017.md。
"""

from . import metrics, provenance
from .config import GIB, LlmConfig, LlmPrices, ModelOverride, prices_from_dataset
from .cost import Cost, Ledger, LedgerMark, OpRow, blocks
from .core import Core
from .inference import (ByteTokenizer, LlmResult, QwenBpeTokenizer, allowed_ids_of,
                        make_tokenizer, run_llm, write_json)
from .memdie import MemDie, TensorRecord
from .metrics import efficiency, throughput
from .provenance import PriceReq, audit, requirements, tier_of
from .qwen3 import Qwen3Config, Qwen3Params
from .report import format_report, print_report, setup_console
from .schedule import SimContext
from .weights import WeightImage, build_weight_image, load_qwen3_safetensors
from .ppl import evaluate_perplexity, run_local_benchmark, LinearQuantization

__all__ = [
    "GIB", "LlmConfig", "LlmPrices", "ModelOverride", "prices_from_dataset",
    "Cost", "Ledger", "LedgerMark", "OpRow", "blocks",
    "Core", "MemDie", "TensorRecord",
    "Qwen3Config", "Qwen3Params",
    "SimContext", "WeightImage", "build_weight_image", "load_qwen3_safetensors",
    "ByteTokenizer", "QwenBpeTokenizer", "make_tokenizer", "allowed_ids_of",
    "LlmResult", "run_llm", "write_json",
    "format_report", "print_report", "setup_console",
    # 吞吐率（token/s）与能量效率（J/token）：只认新思单价的来源门与投放口
    "metrics", "provenance",
    "efficiency", "throughput",
    "PriceReq", "audit", "requirements", "tier_of",
]
