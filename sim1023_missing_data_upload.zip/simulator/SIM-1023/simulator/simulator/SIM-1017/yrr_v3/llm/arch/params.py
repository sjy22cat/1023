"""`ArchParams`：一个模型的**张量清单**（名字 + 形状），是形状与名字的唯一权威。

`Qwen3Params` 是它在 Qwen3 预设下的特例 —— 对默认 spec，`layer_matrices()` /
`layer_norms()` / `matrices()` / `accounting()` 的**名字、顺序、数值全部逐字相同**
（自检 `test_arch_params_reproduces_qwen3_params` 钉住这一点），因此既有 14 处调用点
与 596.04992 M 的账不用改。

`ArchSpec` 可以传 `Qwen3Config`：`ArchSpec` 的前 11 个字段与它同名同序同默认，
构造时自动补上架构族的默认值（见 `_coerce`）。

分派只有两处，都按 kind：

* 注意力：`mla` 走低秩投影 + 解耦 rope；其余（`full` / `sliding` / `plain_mha`）
  走 q/k/v/o，其中 `fused_qkv` 合成一个 `qkv_proj`。
* FFN：`is_moe_layer(l)` 为真时走「专家 + 路由 + 共享专家」；否则走稠密
  （`gated` 走 gate/up/down，`plain` 走 up/down，`fused_gate_up` 合成 `gate_up_proj`）。

**这里只管名字与形状，不管数值**（数值实体在 `weights.WeightImage`）
**也不管记账**（账目在 `schedule.SimContext`）。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..mxfp4 import mx_bytes
from ..qwen3 import MatrixSpec, Qwen3Config

# `MatrixSpec` 就是本层的张量描述类型；再给一个更中性的别名供外部引用
TensorSpec = MatrixSpec

# 归一化向量的字节口径：fp32 不量化（与 `weights.WeightImage.total_bytes` 一致）
_NORM_BYTES_PER_ELEMENT = 4

_DENSE_11 = ("hidden", "layers", "q_heads", "kv_heads", "head_dim", "intermediate",
             "vocab", "rms_eps", "rope_theta", "tie_embeddings", "max_position")


def _coerce(spec: Any) -> Any:
    """`ArchSpec` 直接用；`Qwen3Config`（或任何有那 11 个字段的对象）补齐成 `ArchSpec`。

    这样 `ArchParams(Qwen3Config())` 与 `ArchParams(ArchSpec())` 等价 ——
    既有调用点在 段二 的改造过程中不必一次性全改。
    """
    from .spec import ArchSpec

    if isinstance(spec, ArchSpec):
        return spec
    if isinstance(spec, Qwen3Config) or all(hasattr(spec, k) for k in _DENSE_11):
        return ArchSpec(**{k: getattr(spec, k) for k in _DENSE_11})
    raise TypeError(f"ArchParams 需要 ArchSpec 或 Qwen3Config，得到 {type(spec).__name__}")


class ArchParams:
    """全模型的张量清单（**不持有数值**）。"""

    def __init__(self, spec: Any) -> None:
        self.spec = _coerce(spec)
        self.spec.validate()
        # 兼容旧属性名：`Qwen3Params.cfg`
        self.cfg = self.spec

    # ---------------- 注意力 ----------------

    def _mla_qk_head_dim(self) -> int:
        s = self.spec
        return s.mla.qk_nope_head_dim + s.mla.qk_rope_head_dim       # type: ignore[union-attr]

    def _attn_matrices(self, p: str) -> list[MatrixSpec]:
        s = self.spec
        if s.attn_kind_of(int(p[1:])) == "mla":
            m = s.mla
            assert m is not None
            qk_head = self._mla_qk_head_dim()
            out = []
            if m.q_lora_rank:
                out.append(MatrixSpec(f"{p}.q_a_proj", m.q_lora_rank, s.hidden, "weight"))
                out.append(MatrixSpec(f"{p}.q_b_proj", s.q_heads * qk_head,
                                      m.q_lora_rank, "weight"))
            else:
                out.append(MatrixSpec(f"{p}.q_proj", s.q_heads * qk_head, s.hidden,
                                      "weight"))
            out.append(MatrixSpec(f"{p}.kv_a_proj_with_mqa", m.kv_row, s.hidden, "weight"))
            out.append(MatrixSpec(f"{p}.kv_b_proj",
                                  s.kv_heads * (m.qk_nope_head_dim + m.v_head_dim),
                                  m.kv_lora_rank, "weight"))
            out.append(MatrixSpec(f"{p}.o_proj", s.hidden, s.q_heads * m.v_head_dim,
                                  "weight"))
            return out
        if s.fused_qkv:
            return [MatrixSpec(f"{p}.qkv_proj", s.q_dim + 2 * s.kv_dim, s.hidden,
                               "weight", note="fused：q | k | v 合成一个矩阵"),
                    MatrixSpec(f"{p}.o_proj", s.hidden, s.q_dim, "weight")]
        return [
            MatrixSpec(f"{p}.q_proj", s.q_dim, s.hidden, "weight"),
            MatrixSpec(f"{p}.k_proj", s.kv_dim, s.hidden, "weight"),
            MatrixSpec(f"{p}.v_proj", s.kv_dim, s.hidden, "weight"),
            MatrixSpec(f"{p}.o_proj", s.hidden, s.q_dim, "weight"),
        ]

    # ---------------- FFN ----------------

    def _dense_ffn_matrices(self, p: str) -> list[MatrixSpec]:
        """稠密层的 FFN。MoE 模型里 `first_k_dense_replace` 之前的那几层走这里
        （DeepSeek / Qwen-MoE 的稠密层是普通 SwiGLU）。"""
        s = self.spec
        i = s.dense_ffn_intermediate()
        kind = "gated" if s.mlp.kind == "moe" else s.mlp.kind
        if kind == "plain":
            return [MatrixSpec(f"{p}.up_proj", i, s.hidden, "weight"),
                    MatrixSpec(f"{p}.down_proj", s.hidden, i, "weight")]
        if s.mlp.fused_gate_up:
            return [MatrixSpec(f"{p}.gate_up_proj", 2 * i, s.hidden, "weight",
                               note="fused：gate | up 合成一个矩阵"),
                    MatrixSpec(f"{p}.down_proj", s.hidden, i, "weight")]
        return [MatrixSpec(f"{p}.gate_proj", i, s.hidden, "weight"),
                MatrixSpec(f"{p}.up_proj", i, s.hidden, "weight"),
                MatrixSpec(f"{p}.down_proj", s.hidden, i, "weight")]

    def _moe_matrices(self, p: str) -> list[MatrixSpec]:
        s = self.spec
        moe = s.moe
        out = [MatrixSpec(f"{p}.router", moe.n_experts, s.hidden, "weight",
                          note="路由器：每个 token 对全部专家打分")]
        e_inter = moe.moe_intermediate
        for e in range(moe.n_experts):
            out.append(MatrixSpec(f"{p}.experts.{e:03d}.gate_proj", e_inter, s.hidden,
                                  "weight"))
            out.append(MatrixSpec(f"{p}.experts.{e:03d}.up_proj", e_inter, s.hidden,
                                  "weight"))
            out.append(MatrixSpec(f"{p}.experts.{e:03d}.down_proj", s.hidden, e_inter,
                                  "weight"))
        sw = s.shared_expert_width()
        for sh in range(moe.n_shared_experts):
            out.append(MatrixSpec(f"{p}.shared.{sh:03d}.gate_proj", sw, s.hidden, "weight"))
            out.append(MatrixSpec(f"{p}.shared.{sh:03d}.up_proj", sw, s.hidden, "weight"))
            out.append(MatrixSpec(f"{p}.shared.{sh:03d}.down_proj", s.hidden, sw, "weight"))
        if moe.shared_expert_gate:
            out.append(MatrixSpec(f"{p}.shared_gate", 1, s.hidden, "weight",
                                  note="共享专家的标量门"))
        return out

    # ---------------- 每层 ----------------

    def layer_matrices(self, layer: int) -> list[MatrixSpec]:
        """第 `layer` 层要过阵列的全部矩阵。

        **Qwen3 下与 `Qwen3Params.layer_matrices` 逐字相同**（7 个投影，
        `o_proj` 仍是 `q_dim -> hidden`，不是方阵）。
        """
        s = self.spec
        if not (0 <= layer < s.layers):
            raise IndexError(f"层号越界：{layer}（共 {s.layers} 层）")
        p = f"L{layer:02d}"
        return self._attn_matrices(p) + (
            self._moe_matrices(p) if s.is_moe_layer(layer) else self._dense_ffn_matrices(p))

    def layer_norms(self, layer: int) -> list[tuple[str, int]]:
        """第 `layer` 层的归一化向量（名字 + 元素数）。

        **顺序对 Qwen3 是 `[input, post_attention, q_norm, k_norm]`**，与
        `Qwen3Params.layer_norms` 逐字相同；族差异（无 qk_norm、Gemma 的 4 个 norm、
        MLA 的 `q_a/kv_a_layernorm`）追加在后面。
        """
        s = self.spec
        p = f"L{layer:02d}"
        out = [(f"{p}.input_layernorm", s.hidden),
               (f"{p}.post_attention_layernorm", s.hidden)]
        if s.norm.qk_norm:
            out.append((f"{p}.q_norm", s.head_dim))
            out.append((f"{p}.k_norm", s.head_dim))
        if s.norm.post_norm:
            # Gemma-2/3：子层输出先归一化再相加，每层多两个 FFN norm
            out.append((f"{p}.pre_feedforward_layernorm", s.hidden))
            out.append((f"{p}.post_feedforward_layernorm", s.hidden))
        if s.mla is not None:
            if s.mla.q_lora_rank:
                out.append((f"{p}.q_a_layernorm", s.mla.q_lora_rank))
            out.append((f"{p}.kv_a_layernorm", s.mla.kv_lora_rank))
        return out

    # ---------------- 词表与最终归一化 ----------------

    def embedding(self) -> MatrixSpec:
        return MatrixSpec("embed_tokens", self.spec.vocab, self.spec.hidden, "embedding",
                          note="与 lm_head 绑权重（tie_word_embeddings=true），只存一份")

    def final_norm(self) -> tuple[str, int]:
        return ("model.norm", self.spec.hidden)

    def lm_head(self) -> MatrixSpec:
        """`lm_head` 的形状。

        绑权重时（`tie_embeddings=true`）它就是 `embed_tokens`，**不重复占容量**；
        未绑时（Llama-3.1、Qwen2.5-7B 等）它是一份独立的 `vocab x hidden` 矩阵，
        由 `extra_matrices()` 带进容量账 —— 词表矩阵往往占全模型的三成，
        漏掉它会把容量算错一个量级。
        """
        s = self.spec
        if s.tie_embeddings:
            return MatrixSpec("lm_head", s.vocab, s.hidden, "embedding",
                              note="= embed_tokens（绑权重）")
        return MatrixSpec("lm_head", s.vocab, s.hidden, "weight",
                          note="未绑权重，单独占一份容量")

    def extra_matrices(self) -> list[MatrixSpec]:
        """不绑权重时那份额外的 `lm_head`（绑权重时为空）。"""
        return [] if self.spec.tie_embeddings else [self.lm_head()]

    # ---------------- 全模型 ----------------

    def matrices(self) -> list[MatrixSpec]:
        """全模型的矩阵 = 逐层矩阵 + （未绑权重时的）`lm_head`。"""
        out: list[MatrixSpec] = []
        for l in range(self.spec.layers):
            out += self.layer_matrices(l)
        return out + self.extra_matrices()

    def all_norms(self) -> list[tuple[str, int]]:
        out: list[tuple[str, int]] = []
        for l in range(self.spec.layers):
            out += self.layer_norms(l)
        return out + [self.final_norm()]

    # ---------------- 字节 ----------------

    def matrix_bytes(self) -> int:
        """矩阵部分的字节（MXFP4）。

        **词表矩阵算在内**：`matrices()` 只给逐层矩阵与未绑权重时的 `lm_head`，
        `embed_tokens` 由 `embedding()` 单独给出（绑权重时它就是唯一的词表矩阵，
        未绑时另有一份 `lm_head`）。漏掉它 0.6B 会少 82.7 MB、8B 会少 0.82 GB。
        """
        return sum(mx_bytes(m.shape) for m in self.matrices() + [self.embedding()])

    def norm_bytes(self) -> int:
        """归一化向量的字节（fp32 不量化）。"""
        return sum(n * _NORM_BYTES_PER_ELEMENT for _, n in self.all_norms())

    def weight_bytes(self) -> int:
        """权重在 MEM die 上的字节 = 矩阵 + 归一化。

        与 `weights.WeightImage.total_bytes()` 同一口径（同一个 `mx_bytes`），
        但**不分配任何数值** —— 容量门要在几十 GB 的分配之前就给出结论。

        矩阵与归一化**分开**给出（`matrix_bytes` / `norm_bytes`）：容量门的预算表
        把两者列成两行，两边各算一次就会把 0.6B 的 262,144 B 归一化算重。
        """
        return self.matrix_bytes() + self.norm_bytes()

    # ---------------- 账 ----------------

    def layer_elements(self, layer: int) -> int:
        """第 `layer` 层的参数量（只数矩阵）。"""
        return sum(m.elements for m in self.layer_matrices(layer))

    def accounting(self) -> dict[str, Any]:
        """参数量账。

        **Qwen3 默认 spec 下与 `Qwen3Params.accounting()` 逐键相同**；
        MoE 模型额外附几个键（专家占比、每 token 激活量），稠密模型一个键都不多。
        """
        s = self.spec
        per_layer = self.layer_elements(0)
        norm_per_layer = sum(n for _, n in self.layer_norms(0))
        emb = self.embedding().elements
        proj_total = sum(self.layer_elements(l) for l in range(s.layers)) + \
            sum(m.elements for m in self.extra_matrices())
        norm_total = sum(n for _, n in self.all_norms())
        total = proj_total + emb + norm_total
        d: dict[str, Any] = {
            "proj_elements": proj_total,
            "embedding_elements": emb,
            "norm_elements": norm_total,
            "total_elements": total,
            "total_params_millions": total / 1e6,
            "note": "与 Instruction/GEMM次数统计.md §1.1 的 596.0 M 对照"
                    "（含绑权重的词表只算一次）",
            "per_layer_elements": per_layer,
        }
        if s.is_moe:
            n_moe = sum(1 for l in range(s.layers) if s.is_moe_layer(l))
            per_expert = self._expert_elements()
            expert_total = n_moe * s.moe.n_experts * per_expert
            d.update(
                moe_layers=n_moe,
                dense_layers=s.layers - n_moe,
                per_expert_elements=per_expert,
                expert_elements=expert_total,
                expert_share=(expert_total / total if total else 0.0),
                active_elements_per_token=self.active_elements_per_token(),
                moe_note="专家合计占全部参数的比例；整块口径下每个被激活的专家"
                         "每 token 都要把权重过一遍，故权重访存由专家主导",
            )
        if norm_per_layer * s.layers + s.hidden != norm_total:
            d["norm_note"] = "各层归一化向量数不同（逐层交替或 MoE 稠密层），已逐层求和"
        return d

    def _expert_elements(self) -> int:
        """单个专家的 gate+up+down 参数量。"""
        s = self.spec
        i = s.moe.moe_intermediate
        return 3 * i * s.hidden

    def active_elements_per_token(self) -> int:
        """一个 token 真正读到的参数量（均匀路由下 = 总量 − 未激活专家）。

        共享专家**每个 token 都做**，故不扣。
        """
        s = self.spec
        if not s.is_moe:
            return sum(m.elements for m in self.matrices()) + \
                sum(n for _, n in self.all_norms()) + self.embedding().elements
        n_moe = sum(1 for l in range(s.layers) if s.is_moe_layer(l))
        idle = n_moe * (s.moe.n_experts - s.moe.top_k) * self._expert_elements()
        total = (sum(self.layer_elements(l) for l in range(s.layers))
                 + sum(m.elements for m in self.extra_matrices())
                 + self.embedding().elements + sum(n for _, n in self.all_norms()))
        return total - idle
