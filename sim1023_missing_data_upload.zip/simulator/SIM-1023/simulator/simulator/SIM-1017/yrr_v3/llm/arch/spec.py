"""`ArchSpec`：一个 decoder-only 模型的**声明式**架构描述（形状 + 族 + 每层种类）。

**为什么是声明式 spec 而不是逐族子类**：HF `config.json` 解析出来的天然是**数据**；
容量门、报告、`--compare` 都要通用地读这个结构（权重字节、KV 字节、逐层注意力种类）。
spec 上直读，子类上要反射。而架构族本身只是一份**预设**（`families.py`），
分派表很小：注意力 4 种 kind、MLP 3 种 kind。

`ArchSpec` 的前 11 个字段与 `qwen3.Qwen3Config` **同名、同序、同默认**，
因此它是后者的**严格超集** —— `Qwen3Config(...)` 的既有调用点一字不改即可构造出
`ArchSpec`，而 `report["model"]` 里被断言的那几个键（`hidden` / `layers` / `vocab` /
`params` / `quant`）读法不变。

**本文件只放形状与种类，不放任何数值**：张量清单在 `params.py`，HF 字段名在 `hf.py`，
族预设在 `families.py`。
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any

# --------------------------------------------------------------------------
# 枚举式的种类名（用字符串而不是 Enum：它们要进 JSON 报告）
# --------------------------------------------------------------------------

ATTN_KINDS = ("full", "sliding", "mla", "plain_mha")
MLP_KINDS = ("gated", "plain", "moe")
NORM_KINDS = ("rmsnorm", "layernorm")
ROPE_SCALINGS = ("none", "linear", "dynamic", "yarn")


@dataclass(frozen=True)
class NormSpec:
    """归一化的**结构**：种类、摆放、以及几个逐族的开关。

    `eps` **不在这里** —— 它是 `ArchSpec.rms_eps`（`Qwen3Config` 的 11 个字段之一）。
    同一个量只有一处权威，否则从 `config.json` 解出的 eps 会与那一处静默分歧。
    """
    kind: str = "rmsnorm"            # "rmsnorm" | "layernorm"
    post_norm: bool = False          # Gemma-2/3：子层输出**先归一化再相加**
    qk_norm: bool = True             # 每 head 的 q_norm / k_norm（对 head_dim 做归一化）
    embed_scale: bool = False        # Gemma：embedding 输出乘 `sqrt(hidden)`
    final_logit_softcap: float | None = None    # Gemma-2：final logit soft-capping
    attn_logit_softcap: float | None = None     # Gemma-2：attention logit soft-capping


@dataclass(frozen=True)
class RopeSpec:
    """RoPE 的**结构**：部分旋转比例与长度外推方案。

    `theta` 不在这里 —— 它是 `ArchSpec.rope_theta`（同上，单一权威）。
    """
    partial_rotary_factor: float = 1.0   # 只旋转前 `factor * head_dim` 维（Phi-3 = 0.4）
    scaling: str = "none"                # "none" | "linear" | "dynamic" | "yarn"
    scaling_factor: float = 1.0
    note: str = ""

    @property
    def rotary_dim(self) -> float:
        """参与旋转的维数（可能是小数，调用方自行取整）。"""
        return self.partial_rotary_factor


@dataclass(frozen=True)
class MlaSpec:
    """MLA（DeepSeek-V2 系）：低秩 Q/KV 投影 + 解耦的 rope 分量。

    `None` 表示该模型不用 MLA。**KV cache 的字节与稠密族完全不同**：
    `(L, 2, kv_heads, ctx, head_dim)` → `(L, ctx, kv_lora_rank + qk_rope_head_dim)`。
    """
    q_lora_rank: int | None = None
    kv_lora_rank: int = 512
    qk_nope_head_dim: int = 128
    qk_rope_head_dim: int = 64
    v_head_dim: int = 128

    @property
    def kv_row(self) -> int:
        """每个位置在压缩 KV cache 里占的元素数。"""
        return self.kv_lora_rank + self.qk_rope_head_dim


@dataclass(frozen=True)
class MoeSpec:
    """MoE：专家数、激活专家数、共享专家、以及前若干层的稠密替换。

    `first_k_dense_replace` 层用**稠密** FFN（`intermediate`），其余层用专家 FFN
    （`moe_intermediate`）—— 这是 DeepSeek/Qwen-MoE 的通行做法，且它改变**账目结构**
    （两类层的权重形状与装载次数都不同），所以必须建模，不能当数值近似。
    """
    n_experts: int = 0
    top_k: int = 0
    moe_intermediate: int = 0
    n_shared_experts: int = 0
    first_k_dense_replace: int = 0
    shared_expert_gate: bool = False
    router_jitter: float = 0.0
    # 共享专家的 FFN 宽度；0 = 与 `moe_intermediate` 同宽（绝大多数族的实情）
    shared_intermediate: int = 0

    @property
    def is_moe(self) -> bool:
        return self.n_experts > 0 and self.top_k > 0


@dataclass(frozen=True)
class MlpSpec:
    """FFN：种类、激活函数、有无 bias、是否 fused 的 gate-up。"""
    kind: str = "gated"           # "gated"(SwiGLU) | "plain" | "moe"
    act: str = "silu"             # "silu" | "gelu" | "gelu_tanh" | "relu2"
    bias: bool = False
    # Phi-3：`gate_up_proj` 一个矩阵管 gate 与 up。**这是账目结构差异**：
    # 一次 `ceil(2I/1024)` 与两次 `ceil(I/1024)` 不等价（`I` 非 1024 整数倍时）。
    fused_gate_up: bool = False


@dataclass(frozen=True)
class ArchSpec:
    """一个模型的完整架构描述。

    前 11 个字段 = `Qwen3Config` 的公开面（超集关系，见模块 docstring）。
    """

    # ---------------- Qwen3Config 的 11 个字段（同名 / 同序 / 同默认） ----------------
    hidden: int = 1024
    layers: int = 28
    q_heads: int = 16
    kv_heads: int = 8
    head_dim: int = 128
    intermediate: int = 3072
    vocab: int = 151936
    rms_eps: float = 1e-6
    rope_theta: float = 1e6
    tie_embeddings: bool = True
    max_position: int = 40960

    # ---------------- 架构族扩展 ----------------
    family: str = "qwen3"
    qkv_bias: bool = False
    o_bias: bool = False
    mlp_bias: bool = False
    attention_bias: bool = False
    head_dim_explicit: bool = True     # False = 由 hidden / q_heads 推得
    # Phi-3：`qkv_proj` 一个矩阵管 q/k/v。同上，是账目结构差异。
    fused_qkv: bool = False

    norm: NormSpec = field(default_factory=NormSpec)
    rope: RopeSpec = field(default_factory=RopeSpec)
    mlp: MlpSpec = field(default_factory=MlpSpec)
    moe: MoeSpec = field(default_factory=MoeSpec)
    mla: MlaSpec | None = None

    # 逐层注意力种类：长度必须等于 `layers`；`None` = 全是 `default_attn_kind`
    layer_attn_kinds: tuple[str, ...] | None = None
    default_attn_kind: str = "full"
    sliding_window: int | None = None
    attention_dropout: float = 0.0
    initializer_range: float = 0.02

    # 族差异分两类，各自成表（决策 3 的两分法）：
    #   approximations —— **未建模 / 只按语义近似**的东西，读者据此判断结果的适用范围；
    #   structure_notes —— **已建模的账目结构差异**的叙述，便于人核对建的是什么。
    # 把「已建模」的条目混进 `approximations` 会让人以为它没建模，故分开。
    structure_notes: tuple[str, ...] = ()
    approximations: tuple[str, ...] = ()

    # 解析时收集到的未知键（沿用 calib.py 的惯例：只收集、不报错）
    unknown_keys: tuple[str, ...] = ()
    source: str = "builtin:qwen3"

    # ---------------- 派生量（与 Qwen3Config 逐字相同） ----------------

    @property
    def q_dim(self) -> int:
        return self.q_heads * self.head_dim          # 2048

    @property
    def kv_dim(self) -> int:
        return self.kv_heads * self.head_dim         # 1024

    @property
    def gqa_group(self) -> int:
        return self.q_heads // self.kv_heads         # 2

    @property
    def attn_scale(self) -> float:
        import math
        return 1.0 / math.sqrt(self.head_dim)

    @property
    def is_moe(self) -> bool:
        return self.moe.is_moe

    @property
    def kv_row_elements(self) -> int:
        """一个位置在 KV cache 里占的元素数（MLA 与非 MLA 分岔）。"""
        if self.mla is not None:
            return self.mla.kv_row
        return 2 * self.kv_heads * self.head_dim

    @property
    def base_attn_kind(self) -> str:
        """未逐层指定时**实际生效**的注意力种类。

        MLA 优先：只要 spec 带 `mla`，那些标着 `full` 的层实际走的是 MLA ——
        DeepSeek-V2/V3 全层 MLA，没有「同一模型里 MLA 与普通全注意力混用」的族。
        这条规则放在这里（而不是只在解析时把 `default_attn_kind` 改成 `mla`），
        是为了让动物园条目、直接构造的 `ArchSpec`、解析出的 spec 三条路径同一条规则。
        """
        if self.mla is not None and self.default_attn_kind == "full":
            return "mla"
        return self.default_attn_kind

    def attn_kind_of(self, layer: int) -> str:
        """第 `layer` 层的注意力种类。"""
        if self.layer_attn_kinds is not None:
            k = self.layer_attn_kinds[layer]
            if k == "full" and self.mla is not None:
                return "mla"
            return k
        return self.base_attn_kind

    def is_moe_layer(self, layer: int) -> bool:
        """该层用专家 FFN 还是稠密 FFN（`first_k_dense_replace` 之前是稠密）。"""
        return self.is_moe and layer >= self.moe.first_k_dense_replace

    def dense_ffn_intermediate(self) -> int:
        """稠密层的 FFN 宽度（非 MoE 模型即 `intermediate`）。"""
        return self.intermediate

    def shared_expert_width(self) -> int:
        """共享专家的 FFN 宽度（未单独给出时与 `moe_intermediate` 同宽）。

        **不做模块级缓存**：宽度是**单个文件**的事实，按族缓存会让先解析的
        一份 config 污染同族后解析的另一份（后者缺这个键时静默继承前者的值）。
        """
        if not self.is_moe:
            return 0
        return self.moe.shared_intermediate or self.moe.moe_intermediate

    # ---------------- 校验 ----------------

    def validate(self) -> None:
        if self.q_heads % self.kv_heads:
            raise ValueError("q_heads 必须是 kv_heads 的整数倍（GQA）")
        if self.head_dim % 2:
            raise ValueError("head_dim 必须是偶数（RoPE 对半旋转）")
        if self.hidden <= 0 or self.layers <= 0:
            raise ValueError("hidden / layers 必须为正")
        if self.vocab <= 0:
            raise ValueError("vocab 必须为正")
        if self.intermediate <= 0 and not self.is_moe:
            raise ValueError("intermediate 必须为正")
        if self.base_attn_kind not in ATTN_KINDS:
            raise ValueError(f"未知的注意力种类：{self.default_attn_kind!r}"
                             f"（可选 {ATTN_KINDS}）")
        if self.layer_attn_kinds is not None:
            if len(self.layer_attn_kinds) != self.layers:
                raise ValueError(
                    f"layer_attn_kinds 长度 {len(self.layer_attn_kinds)} "
                    f"≠ layers {self.layers}")
            for k in self.layer_attn_kinds:
                if k not in ATTN_KINDS:
                    raise ValueError(f"未知的注意力种类：{k!r}")
        if self.mlp.kind not in MLP_KINDS:
            raise ValueError(f"未知的 MLP 种类：{self.mlp.kind!r}（可选 {MLP_KINDS}）")
        # `mlp.kind == "moe"` 与 `is_moe` 必须同时成立，否则账目结构自相矛盾
        # （声明按 MoE 记账却没有专家数，或反之声明有专家数却按稠密记账）
        if self.mlp.kind == "moe" and not self.is_moe:
            raise ValueError("mlp.kind = 'moe' 但 moe.n_experts / top_k 未给出")
        if self.is_moe and self.mlp.kind != "moe":
            raise ValueError(f"给出了专家数，但 mlp.kind = {self.mlp.kind!r}（应为 'moe'）")
        if self.norm.kind not in NORM_KINDS:
            raise ValueError(f"未知的归一化种类：{self.norm.kind!r}")
        if self.rope.scaling not in ROPE_SCALINGS:
            raise ValueError(f"未知的 RoPE 外推方案：{self.rope.scaling!r}")
        if not (0.0 < self.rope.partial_rotary_factor <= 1.0):
            raise ValueError("partial_rotary_factor 必须落在 (0, 1]")
        if self.is_moe:
            if self.moe.n_experts <= 0:
                raise ValueError("MoE：n_experts 必须为正")
            if not (0 < self.moe.top_k <= self.moe.n_experts):
                raise ValueError("MoE：top_k 必须落在 (0, n_experts]")
            if self.moe.moe_intermediate <= 0 and self.moe.n_shared_experts <= 0:
                raise ValueError("MoE：moe_intermediate 必须为正（除非只有共享专家）")
            if not (0 <= self.moe.first_k_dense_replace <= self.layers):
                raise ValueError("MoE：first_k_dense_replace 必须落在 [0, layers]")
            if self.moe.shared_intermediate < 0:
                raise ValueError("MoE：shared_intermediate 不能为负（0 = 与 moe_intermediate 同宽）")
        if self.sliding_window is not None and self.sliding_window <= 0:
            raise ValueError("sliding_window 必须为正")
        if "sliding" in (self.layer_attn_kinds or ()) and self.sliding_window is None:
            raise ValueError("有层用滑窗注意力，但 sliding_window 未给出")
        if self.fused_qkv and self.default_attn_kind == "mla":
            raise ValueError("MLA 的张量布局与 fused QKV 不兼容")
        if self.mlp.fused_gate_up and self.mlp.kind != "gated":
            raise ValueError("fused_gate_up 只在 gated（SwiGLU/GeGLU）FFN 上有意义")

    def replace(self, **kw: Any) -> "ArchSpec":
        """派生一个改了几个字段的副本（frozen 的常规用法）。"""
        return replace(self, **kw)

    # ---------------- 报告 ----------------

    def as_dict(self) -> dict[str, Any]:
        """进 `report["model"]`。前 11 个键与 `Qwen3Config.as_dict()` 完全一致。"""
        d: dict[str, Any] = {
            "hidden": self.hidden, "layers": self.layers, "q_heads": self.q_heads,
            "kv_heads": self.kv_heads, "head_dim": self.head_dim,
            "intermediate": self.intermediate, "vocab": self.vocab,
            "rms_eps": self.rms_eps, "rope_theta": self.rope_theta,
            "tie_embeddings": self.tie_embeddings, "max_position": self.max_position,
            "q_dim": self.q_dim, "kv_dim": self.kv_dim,
            "gqa_group": self.gqa_group, "attn_scale": self.attn_scale,
        }
        d.update(
            family=self.family,
            hidden_act=self.mlp.act,
            attn_kinds=self.attn_kinds_summary(),
            default_attn_kind=self.base_attn_kind,
            sliding_window=self.sliding_window,
            attention_bias=self.attention_bias or self.qkv_bias or self.o_bias,
            mlp={"kind": self.mlp.kind, "act": self.mlp.act, "bias": self.mlp.bias,
                 "fused_gate_up": self.mlp.fused_gate_up},
            fused_qkv=self.fused_qkv,
            norm={"kind": self.norm.kind, "eps": self.rms_eps,
                  "post_norm": self.norm.post_norm, "qk_norm": self.norm.qk_norm,
                  "embed_scale": self.norm.embed_scale},
            rope={"theta": self.rope_theta,
                  "partial_rotary_factor": self.rope.partial_rotary_factor,
                  "scaling": self.rope.scaling,
                  "scaling_factor": self.rope.scaling_factor},
            moe=(None if not self.is_moe else {
                "n_experts": self.moe.n_experts, "top_k": self.moe.top_k,
                "moe_intermediate": self.moe.moe_intermediate,
                "n_shared_experts": self.moe.n_shared_experts,
                "first_k_dense_replace": self.moe.first_k_dense_replace,
                "shared_expert_gate": self.moe.shared_expert_gate,
                "shared_intermediate": self.shared_expert_width(),
            }),
            mla=(None if self.mla is None else {
                "q_lora_rank": self.mla.q_lora_rank,
                "kv_lora_rank": self.mla.kv_lora_rank,
                "qk_nope_head_dim": self.mla.qk_nope_head_dim,
                "qk_rope_head_dim": self.mla.qk_rope_head_dim,
                "v_head_dim": self.mla.v_head_dim,
            }),
            kv_row_elements=self.kv_row_elements,
            structure_notes=list(self.structure_notes),
            approximations=list(self.approximations),
            source=self.source,
            unknown_keys=list(self.unknown_keys),
            note="形状与逐层注意力种类是**账目结构**的决定量；只改数值的族差异"
                 "列在 approximations 里，按语义近似。",
        )
        return d

    def attn_kinds_summary(self) -> str:
        """注意力种类的紧凑摘要。

        逐层交替（Gemma 系）时不按「一段一段」列 —— 26 层交替会画出 26 段，
        读不出来。改按**周期**描述：先求最小周期 `p`（`kinds[i] == kinds[i+p]`），
        再给出各 kind 的层数。
        """
        if self.layer_attn_kinds is None:
            k = self.base_attn_kind
            if k == "sliding":
                return f"sliding(window={self.sliding_window}) x {self.layers}"
            return f"{k} x {self.layers}"
        kinds = self.layer_attn_kinds
        n = len(kinds)
        counts: dict[str, int] = {}
        for k in kinds:
            counts[k] = counts.get(k, 0) + 1
        body = " + ".join(f"{k} x {v}" for k, v in sorted(counts.items()))
        if len(counts) > 1:
            period = next((q for q in range(1, n + 1)
                           if all(kinds[i] == kinds[i + q] for i in range(n - q))), n)
            body += f"（每 {period} 层一循环）"
        if "sliding" in counts and self.sliding_window is not None:
            body += f"（滑窗 {self.sliding_window}）"
        return body

    # ---------------- 族预设的便捷构造 ----------------

    @classmethod
    def qwen3(cls, **kw: Any) -> "ArchSpec":
        return cls(family="qwen3", **kw)
