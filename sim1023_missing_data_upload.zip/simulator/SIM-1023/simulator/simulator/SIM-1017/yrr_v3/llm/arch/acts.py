"""FFN 的激活函数表（`mlp.act` 的取值 → 前向原语）。

`silu` 直接复用 `qwen3.silu`（Qwen3 / Llama / Mistral / Phi-3 / DeepSeek 都用它，
默认口径**逐位不变**）；其余几个按 HF 的语义补上，只为让非 Qwen3 族在数值模式下
也能真的跑通 —— 形状驱动模式下数值根本不参与记账，所以它们不影响任何账目数字。

成本由对应 RTL 算子的实测长度记录决定。切换激活会改变硬件成本；
没有对应 RTL 的激活（例如精确 GELU）由成本层明确拒绝，不能借用别的算子单价。
"""
from __future__ import annotations

from math import erf, sqrt

import numpy as np

from ..qwen3 import FP32, silu

__all__ = ["ACT_FNS", "act_fn", "gelu", "gelu_tanh", "relu2"]

# numpy 没有 erf 的向量化实现，用 `math.erf` 逐元素转（`frompyfunc` 不经过 Python 循环）。
_ERF = np.frompyfunc(erf, 1, 1)


def gelu(x: np.ndarray) -> np.ndarray:
    """精确 GELU（`erf` 形式）。"""
    xf = np.asarray(x, dtype=FP32)
    e = _ERF(xf / FP32(sqrt(2.0))).astype(FP32)
    return (FP32(0.5) * xf * (FP32(1.0) + e)).astype(FP32)


def gelu_tanh(x: np.ndarray) -> np.ndarray:
    """`gelu_pytorch_tanh`（HF 的 `hidden_activation` 常取这个，Gemma 系即此）。"""
    xf = np.asarray(x, dtype=FP32)
    c = FP32(sqrt(2.0 / np.pi))
    return (FP32(0.5) * xf
            * (FP32(1.0) + np.tanh(c * (xf + FP32(0.044715) * xf ** 3)))).astype(FP32)


def relu2(x: np.ndarray) -> np.ndarray:
    """`relu(x)^2`（`hidden_act` 写 `relu2` / `squared_relu` 的族）。"""
    xf = np.asarray(x, dtype=FP32)
    return np.square(np.maximum(xf, FP32(0.0)), dtype=FP32)


ACT_FNS = {
    "silu": silu,
    "gelu": gelu,
    "gelu_pytorch_tanh": gelu_tanh,
    "gelu_tanh": gelu_tanh,
    "relu2": relu2,
}


def act_fn(name: str):
    """取激活函数；不认识就**硬报错并列出可选项**（不静默套 silu）。"""
    fn = ACT_FNS.get(name)
    if fn is None:
        raise KeyError(f"不认识的激活函数 {name!r}（可选：{', '.join(sorted(ACT_FNS))}）")
    return fn
