"""逐 op 调度：prefill（`cfg.prompt_tokens`）/ decode（`cfg.max_new_tokens`）
的**完整串行操作序列**。两个数都由配置决定，本层没有任何地方写死 128 / 1024 ——
默认口径是 `S=128 → T=1024`，`S=1024 → T=128` 同样跑得通（容量账见 `README_LLM.md` §7）。

这里是**唯一真相来源**：op 的发出与数值的计算写在同一段代码里，所以
「账上记的操作」与「实际算的操作」不可能漂移。数值按**批量 numpy** 一次算完
（数学等价），账目按**逐 token / 逐 pair / 逐块串行**记 —— 这就是用户确认的
「账目串行、数值等价批量」。

关键后果（README_LLM.md 也写）：因为 **`cores = 1`，没有任何并行度**，
所以 prefill 也没法并行 —— 权重按输出块装载并在这批 token 上常驻，
但每个 token 的每个输出块都是**一个独立的单位块**，逐个串行。

存储口径（一句话）：**写回 MEM die 的中间结果一律按 MXFP4 存**
（payload 4 bit/元素 + E8M0 8 bit/32 元素）；写回粒度 = **该次单位块矩阵计算产生的那个结果**
（逐 token 的 Q/K/V 向量、逐 pair 的 S 与 A）。读取则按用户描述的「一次一对」，
**不复用**（每个 pair 重新读 Q_i 与 K_j）—— 这是「全串行、一个矩阵一个矩阵」的字面后果，
报告里的 `billing_note` 会把这个倍数写明。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator

import numpy as np

from . import mxfp4
from .arch.acts import act_fn
from .arch.params import ArchParams
from .capacity import kv_shape, resolve_forward
from .config import GIB, LlmConfig, LlmPrices
from .core import Core, GSRAM_BYTES, REGFILE_BYTES
from .cost import Cost, Ledger, ceil_div
from .memdie import MemDie
from .qwen3 import FP32, apply_rope, rmsnorm, rope_tables, softmax
from .weights import WeightImage
from .fused_attention import FusedAttentionProfiles, required_contexts

ELEM_BYTES_FP32 = 4


def mx_bytes(shape) -> int:
    """一段张量按 MXFP4 存的字节数（payload + E8M0 尺度）。

    **只是 `mxfp4.mx_bytes` 的别名** —— 字节口径全层只有一处实现
    （`capacity.py` 也算同一份，否则容量门与 `MemDie` 会慢慢分歧）。
    """
    return mxfp4.mx_bytes(shape)


# --------------------------------------------------------------------------
# 仿真上下文
# --------------------------------------------------------------------------

class SimContext:
    """一次 LLM 推理仿真的全部状态：单价、账本、MEM die、core、KV cache、权重。

    `spec` 是一个 `ArchSpec`（也接受 `Qwen3Config`，自动补齐成 `ArchSpec`）——
    **形状与逐层种类都从它读**，代码里不再有 Qwen3 的常数。`forward` 决定走真数值
    还是形状驱动（见 `capacity.resolve_forward`）。
    """

    def __init__(self, cfg: LlmConfig, prices: LlmPrices, spec: Any,
                 img: WeightImage, forward: str | None = None) -> None:
        cfg.validate()
        self.cfg = cfg
        self.prices = prices
        self.params = ArchParams(spec)
        self.spec = self.params.spec
        # 兼容旧属性名（`Qwen3Config` 时代的调用点写的是 `qcfg`）
        self.qcfg = self.spec
        self.fused_attention = (FusedAttentionProfiles.load(
            cfg.attention_calibration_path, clock_ns=prices.clock_ns, head_dim=self.spec.head_dim)
            if cfg.attention_impl == "fused_16x4" else None)
        if self.fused_attention:
            if not np.isclose(self.spec.attn_scale, 1.0 / np.sqrt(128), rtol=1e-7, atol=0):
                raise ValueError("fused_16x4 RTL supports only attention scale 1/sqrt(128)")
            # Fail before traffic/allocation if the requested run is underpriced.
            for n in required_contexts(cfg.prompt_tokens, cfg.max_new_tokens):
                if str(n) not in self.fused_attention.data["profiles"]:
                    raise ValueError(f"fused attention: missing measured N={n}; complete exact context profiles first")
        self.img = img
        if self.spec.norm.kind != "rmsnorm":
            raise NotImplementedError(
                f"归一化种类 {self.spec.norm.kind!r}（{self.spec.family}）前向还没接，"
                f"属第三段；本轮支持 rmsnorm（Qwen/Llama/Mistral/Phi/DeepSeek 都是它）")
        self.forward = forward or resolve_forward(self.spec, cfg)
        if self.forward not in ("numeric", "shape"):
            raise ValueError(f"forward 只能是 numeric / shape，得到 {self.forward!r}")
        if self.forward == "shape" and not img.shape_only:
            raise ValueError("forward=\"shape\" 需要 shape-only 的权重映像"
                             "（build_weight_image(..., cache=\"shape\")）")

        self.cost = Cost.from_prices(prices)
        self.ledger = Ledger(leakage_pj_per_cycle=prices.leakage_pj_per_cycle)
        self.memdie = MemDie(
            cfg.mem_die_bytes, self.cost, cfg.cores,
            rram_capacity_bytes=cfg.rram_capacity_bytes,
            feram_capacity_bytes=cfg.feram_capacity_bytes)
        self.core = Core(self.cost, self.ledger, prices, cores=cfg.cores,
                         regfile_bytes=REGFILE_BYTES, gsram_bytes=GSRAM_BYTES,
                         phy_bpc=cfg.phy_bpc, memdie=self.memdie)

        self.max_ctx = cfg.prompt_tokens + cfg.max_new_tokens
        # KV cache 的**数值影子**：形状由 `capacity.kv_shape` 给出（MLA 与非 MLA 分岔，
        # 与容量门同一处出处），默认 [层, K/V, kv_head, 位置, head_dim]，fp32。
        # 里面存的是**已经量化到 MXFP4 码本再解回来的值**（写入时就量化，见
        # `attn_block` 的 `kv_quant`），所以它就是「MEM die 上那 4 bit 数据」的
        # 逐位等价形态 —— 与 `weights.py` 的 fp32 影子同理：只影响速度，不影响口径。
        #
        # `kv_shadow="none"` 是**形状驱动模式专用**：那条路上数值从不被读
        # （`WeightImage._numeric` 主动抛错就是这件事的证明），所以不必分配。
        # `"codebook"` 要存 (payload, scale) 再按需反量化，数值面还没接（第三段）。
        if cfg.kv_shadow == "none":
            self.kv = np.zeros((0,), dtype=FP32)
        elif cfg.kv_shadow == "codebook":
            raise NotImplementedError(
                "kv_shadow=\"codebook\" 需要 KV 的『存码值、按需反量化』读写两缝，"
                "属第三段；本轮用 \"fp32\"（逐位不变）或 \"none\"（形状驱动模式）")
        else:
            self.kv = np.zeros(kv_shape(self.spec, self.max_ctx), dtype=FP32)
        self.pos = 0                       # 已写入 KV cache 的位置数
        self.tokens: list[int] = []        # 已处理的 token id（含 prompt）

        self._register_memory()

    # ---------------- 容量登记 ----------------

    def _register_memory(self) -> None:
        """Place weights in RRAM and Q/K/V capacity in FeRAM before inference."""
        md = self.memdie
        host_preloads: list[tuple[str, int]] = []
        for name in self.img.matrix_names():
            e = self.img.entries[name]
            rec = md.allocate(name, e.shape,
                              "embedding" if name == "embed_tokens" else "weight",
                              fp4=True, medium="rram",
                              note="host-preloaded before inference")
            host_preloads.append((name, rec.nbytes))
        for nm, n in self.img.norm_items():
            rec = md.allocate(nm, (int(n),), "weight", fp4=False, raw_bits=32,
                              note="归一化权重，不量化；推理前主机写入 RRAM",
                              medium="rram")
            host_preloads.append((nm, rec.nbytes))
        md.allocate("kv_cache", kv_shape(self.spec, self.max_ctx),
                    "kv_cache", fp4=True, note="MXFP4 KV cache；按最大上下文预留 FeRAM",
                    medium="feram")
        md.allocate("q_buffer", (self.cfg.prompt_tokens, self.spec.q_dim),
                    "scratch", fp4=True,
                    note="当前层 Q 的 MXFP4 暂存；跨层复用 FeRAM 空间",
                    medium="feram")
        # 每层的激活 X（一个 token 或一批 token）
        md.allocate("act_x", (self.cfg.prompt_tokens, self.spec.hidden), "activation",
                    fp4=True, note="当前层输入 X（从 RRAM 读入 / 写回）",
                    medium="rram")
        # Capacity is validated for the complete placement before any host
        # provisioning traffic is recorded. Its latency is outside inference.
        for name, nbytes in host_preloads:
            self.core.host_store(name, nbytes, medium="rram")

    # ---------------- 取值缝（数值 vs 形状驱动） ----------------

    @property
    def shape_only(self) -> bool:
        """形状驱动模式：数值从不参与记账。"""
        return self.forward == "shape"

    def _norm(self, name: str) -> np.ndarray | None:
        """归一化权重：形状驱动模式返回 `None`（`rmsnorm` 接受 `None`，就是不做缩放）。"""
        if self.shape_only:
            return None
        return self.img.norm(name)

    def _mm(self, x: np.ndarray, name: str) -> np.ndarray:
        """矩阵乘 `x @ W^T`；形状驱动模式返回同形状的零阵（**块数不受数值影响**）。"""
        if self.shape_only:
            out, _inn = self.img.entry_shape(name)
            return np.zeros((x.shape[0], out), dtype=FP32)
        return (x @ self.img.get(name).T).astype(FP32)

    def _kv_view(self, layer: int, slot: int, h_kv: int, ctx: int):
        """KV cache 的一段 `(ctx, head_dim)`；形状驱动模式没有数组，返回 `None`。"""
        if self.shape_only:
            return None
        return self.kv[layer, slot, h_kv, :ctx, :]

    def _kv_store(self, layer: int, slot: int, t: np.ndarray, T: int) -> None:
        """把本步的 K/V 以 **MXFP4 码值**追加进 KV cache（形状驱动模式不写）。"""
        if self.shape_only:
            return
        tq = mxfp4.quantize_dequantize(t) if self.cfg.quantize_activations else t
        self.kv[layer, slot, :, self.pos:self.pos + T, :] = np.swapaxes(tq, 0, 1)

    def _scores(self, xq: np.ndarray, kq, ctx: int, scale: float) -> np.ndarray:
        """`S = Q·K^T * scale`；形状驱动模式返回 `(T, ctx)` 的零阵。"""
        if self.shape_only:
            return np.zeros((xq.shape[0], ctx), dtype=FP32)
        return (xq @ kq.T).astype(FP32) * FP32(scale)

    def _sm(self, s: np.ndarray) -> np.ndarray:
        """softmax（逐 query 行）；形状驱动模式返回零阵。"""
        if self.shape_only:
            return np.zeros_like(s)
        return softmax(s, axis=-1)

    def _pvo(self, a: np.ndarray, vq, D: int) -> np.ndarray:
        """`A·V`；形状驱动模式返回 `(T, D)` 的零阵。"""
        if self.shape_only:
            return np.zeros((a.shape[0], D), dtype=FP32)
        return (a @ vq).astype(FP32)

    # ---------------- 小工具 ----------------

    def aquant(self, phase: str, layer: int, kind: str, x: np.ndarray) -> np.ndarray:
        """激活量化（W4A4 的 A4 那一半）：每个算子边界都做一次。

        量化/反量化只作为 Host 功能参考；FP32 非 MAC RTL 没有 MXFP4 编码器。
        **计费与取值分开**：记账无条件发生，形状驱动模式下跳过取值变换
        （对全零数组做量化往返没有意义）。量化是 Host 数值参考步骤，
        三个 FP32 模块没有 MXFP4 编码器，报告明确排除其硬件成本。
        """
        n = int(np.prod(x.shape))
        if self.shape_only or not self.cfg.quantize_activations:
            return x
        return mxfp4.quantize_dequantize(x)

    def _wbytes(self, name: str, rows: int, inn: int) -> int:
        return mx_bytes((rows, inn))

    # ---------------- 线性层（矩阵计算 + 权重常驻 + 逐 token 单位块） ----------------

    def linear(self, phase: str, layer: int, kind: str, x: np.ndarray, name: str, *,
               tag: str = "", write_output: bool = True) -> np.ndarray:
        """`y = x @ W^T`。

        **切块按用户规则**：输出维与 K 维**各自**超过 1024 就切，切出来的块逐个串行，
        最后把 K 方向的偏积累加一次。这不是可选的 —— 寄存器堆恰好只装得下一个
        1024x1024 的 MXFP4 权重块（544 KB），K 不切的话
        `o_proj`(1024x2048) / `down_proj`(1024x3072) 根本装不进去。

        账目（严格串行、逐 token）：
          1. 激活量化（A4）；
          2. 按 (输出块, K 块)：装载该权重块（MEM 读 + PHY + GSRAM + 寄存器堆）→
             每个 token 一次单位块（1 x rows @ kin x 1）；
          3. K 方向的偏积只在累加器里留，**最后一块才写回 MEM**一次（可通过
             `write_output=False` 关闭，用于稍后统一写入 FeRAM 的 Q/K/V）；
          4. 数值：一次批量 GEMM（数学等价）。

        **K 向累加的记账规则（本函数是唯一的执行点）**：本函数已经把 K 维**自己切开**
        逐块发出，所以每次 `Core.matmul` 收到的 `K` 只有**一个** K 块（`bk == 1`，
        默认累加轮数为 0）。真正的 K 向累加发生在**块与块之间**，共 `bk - 1` 轮，
        因此只在**最后一个 K 块**上由 `accum_rounds` 一次记清，中间的块记 0。
        漏记会让累加能耗与累加拍数整段消失；重复记（每块都按整段 K 记）会让
        K 维的块数与 MAC 数被计 `bk` 遍 —— 后者正是本函数此前的缺陷，已修。
        """
        W = self.img.entry_shape(name)
        out, inn = W
        T = x.shape[0]
        xq = self.aquant(phase, layer, kind, x)
        bn, bk = ceil_div(out, 1024), ceil_div(inn, 1024)
        for b in range(bn):
            rows = min(1024, out - b * 1024)
            wo = mx_bytes((rows,))
            for kb in range(bk):
                kin = min(1024, inn - kb * 1024)
                wname = f"{name}.b{b}k{kb}"
                self.core.load_weight_block(phase, layer, f"{kind}.wload", wname,
                                            self._wbytes(name, rows, kin))
                rounds = (bk - 1) if kb + 1 == bk else 0
                for _t in range(T):
                    self.core.matmul(phase, layer, kind, 1, rows, kin,
                                     load_weight=False, x_bytes=mx_bytes((kin,)),
                                     out_bytes=(wo if write_output and kb + 1 == bk else None),
                                     accum_rounds=rounds)
                self.core.evict(wname)
        return self._mm(xq, name)

    # ---------------- 每层 ----------------

    def layer_forward(self, phase: str, layer: int, x: np.ndarray, *,
                      write_back: bool) -> np.ndarray:
        """一层的完整前向：**骨架**（残差 / 归一化摆放） + `attn_block` + `mlp_block`。

        `x` 形状 `(T, H)`；`write_back=True` 时把本层输出 X1 写回 MEM die。
        T = prompt 长度（prefill）或 1（decode）。

        骨架的顺序、残差位置、`phase`/`layer` 传参**与 Qwen3 时代逐行相同** ——
        原来的 `layer_forward` 每一行都原样搬进了 `attn_block`/`mlp_block`，
        没有重排、没有合并、没有新增任何 `elementwise`。族差异只体现在两处：

        * `norm.post_norm`（Gemma-2/3）：子层输出**先归一化再相加**，于是每层
          4 个归一化 + 2 个残差（Qwen3 是 2 + 2）。这是**账目结构差异**，不是数值近似。
        * 归一化的名字（`post_attention_layernorm` / `pre_feedforward_layernorm`）
          随摆放变 —— 名字由 `ArchParams.layer_norms` 给出，两处必须同源。
        """
        s = self.spec
        T = x.shape[0]
        H = s.hidden
        kind = s.attn_kind_of(layer)
        p = f"L{layer:02d}"
        h = rmsnorm(x, self._norm(f"{p}.input_layernorm"), s.rms_eps)
        self.core.elementwise(phase, layer, "rmsnorm", T * H, row_length=H)

        # ---- X 从 MEM 读入（上一层写回的激活）----
        self.core.read_back(phase, layer, "act_read", mx_bytes((T, H)))

        # ---- 注意力（Q/K/V / RoPE / qk_norm / KV 追加 / pair 逐个串行）----
        attn = self.attn_block(phase, layer, kind, h, T)

        # ---- o_proj ----
        # 注意力输出回读（用户流程：乘积写回 MEM，再读回来做 o_proj）
        self.core.read_back(phase, layer, "attn_read", T * mx_bytes((s.q_dim,)))
        o = self.linear(phase, layer, "o_proj", attn, f"{p}.o_proj")

        # ---- 残差（＋ post_norm 时先归一化子层输出）----
        if s.norm.post_norm:
            o = rmsnorm(o, self._norm(f"{p}.post_attention_layernorm"), s.rms_eps)
            self.core.elementwise(phase, layer, "rmsnorm", T * H, row_length=H)
        h2 = x + o
        self.core.elementwise(phase, layer, "residual", T * H)
        nm = "pre_feedforward_layernorm" if s.norm.post_norm else "post_attention_layernorm"
        h3 = rmsnorm(h2, self._norm(f"{p}.{nm}"), s.rms_eps)
        self.core.elementwise(phase, layer, "rmsnorm", T * H, row_length=H)

        # ---- FFN ----
        down = self.mlp_block(phase, layer, h3)
        if s.norm.post_norm:
            down = rmsnorm(down, self._norm(f"{p}.post_feedforward_layernorm"), s.rms_eps)
            self.core.elementwise(phase, layer, "rmsnorm", T * H, row_length=H)

        # ---- 残差 → X1 ----
        x1 = (h2 + down).astype(FP32)
        self.core.elementwise(phase, layer, "residual", T * H)
        if write_back:
            self.core.write_back(phase, layer, "act_write", T * mx_bytes((H,)))
        return x1

    # ---------------- 注意力子块（按 kind 分派） ----------------

    def attn_block(self, phase: str, layer: int, kind: str, h: np.ndarray,
                   T: int) -> np.ndarray:
        """Q/K/V → RoPE / qk_norm → KV 追加 → 注意力，返回 `(T, q_dim)`。

        `kind` 取 `full` / `sliding`（窗口只改 pair 数）/ `plain_mha`（无 qk_norm 的
        普通 MHA，走同一条路，差别全在 spec 里）。`mla` 的低秩投影属第三段，
        **现在硬报错**而不是按稠密近似 —— 那会把 KV 字节与算子序列一起算错。
        """
        s = self.spec
        p = f"L{layer:02d}"
        D = s.head_dim
        if kind == "mla":
            raise NotImplementedError(
                f"{p} 是 MLA（低秩 Q/KV 投影 + 解耦 rope，族 {s.family}）：前向属第三段。"
                f"容量账已经算得对（KV 行宽 {s.mla.kv_row if s.mla else '?'} 元素），"
                f"但算子序列与稠密族不同，不能按稠密近似")
        if kind not in ("full", "sliding", "plain_mha"):
            raise ValueError(f"未知的注意力种类 {kind!r}")

        # ---- Q / K / V（逐 token，一个单位块一个单位块）----
        if s.fused_qkv:
            # Phi-3：q | k | v 合成一个矩阵。**这是账目结构差异**：一次
            # `ceil((q_dim+2*kv_dim)/1024)` 与三次分开的 `ceil(...)` 之和不等。
            # The transformed Q/K/V values are written to FeRAM below. Avoid
            # the generic RRAM scratch write performed by linear() elsewhere.
            qkv = self.linear(phase, layer, "qkv_proj", h, f"{p}.qkv_proj",
                              write_output=False)
            qq, kk, vv = (qkv[:, :s.q_dim],
                          qkv[:, s.q_dim:s.q_dim + s.kv_dim],
                          qkv[:, s.q_dim + s.kv_dim:])
        else:
            # Q/K/V are placed in FeRAM after normalization/RoPE and
            # quantization; do not account an intermediate RRAM write here.
            qq = self.linear(phase, layer, "q_proj", h, f"{p}.q_proj",
                             write_output=False)
            kk = self.linear(phase, layer, "k_proj", h, f"{p}.k_proj",
                             write_output=False)
            vv = self.linear(phase, layer, "v_proj", h, f"{p}.v_proj",
                             write_output=False)
        qh = qq.reshape(T, s.q_heads, D)
        kh = kk.reshape(T, s.kv_heads, D)
        vh = vv.reshape(T, s.kv_heads, D)

        # ---- 每 head 的 q_norm / k_norm（对 head_dim 做 RMSNorm）----
        # 无 qk_norm 的族（Llama / Mistral / Mixtral / DeepSeek）**不做这一步**，
        # 逐元素算子的元素数因此少 `T x (q_dim + kv_dim)` —— 账目结构差异。
        if s.norm.qk_norm:
            qh = rmsnorm(qh, self._norm(f"{p}.q_norm"), s.rms_eps)
            kh = rmsnorm(kh, self._norm(f"{p}.k_norm"), s.rms_eps)
            self.core.elementwise(phase, layer, "qk_norm", T * (s.q_dim + s.kv_dim), row_length=D)

        # ---- RoPE ----
        positions = np.arange(self.pos, self.pos + T)
        rot = D
        if s.rope.partial_rotary_factor < 1.0:
            # 部分旋转（Phi-3 = 0.4）：只旋转前 `rot` 维，其余原样带过。
            # 账目不变（还是一次 `elementwise`），只改数值。
            rot = max(2, int(D * s.rope.partial_rotary_factor))
            rot -= rot % 2
        cos, sin = rope_tables(rot, positions, s.rope_theta)
        if rot == D:
            qh = apply_rope(qh, cos, sin)
            kh = apply_rope(kh, cos, sin)
        else:
            qh = np.concatenate([apply_rope(qh[..., :rot], cos, sin), qh[..., rot:]],
                                axis=-1).astype(FP32)
            kh = np.concatenate([apply_rope(kh[..., :rot], cos, sin), kh[..., rot:]],
                                axis=-1).astype(FP32)
        self.core.elementwise(phase, layer, "rope", T * (s.q_heads+s.kv_heads) * rot, row_length=rot)

        # Q/K/V are written after the transforms consumed by Attention. Q is a
        # reusable per-layer FeRAM scratch; K/V append into the FeRAM KV cache.
        if self.cfg.quantize_activations:
            qh = mxfp4.quantize_dequantize(qh)
        self.core.write_back(phase, layer, "q_write", T * mx_bytes((s.q_dim,)),
                             medium="feram")
        self.core.write_back(phase, layer, "k_write", T * mx_bytes((s.kv_dim,)),
                             medium="feram")
        self.core.write_back(phase, layer, "v_write", T * mx_bytes((s.kv_dim,)),
                             medium="feram")

        # ---- KV cache 追加（新 K/V 以 **MXFP4 码值**写进 MEM）----
        # KV cache 在 MEM die 上就是 4 bit 的，所以量化发生**在写的时候**
        # （这正是计划里「激活在每个算子边界过量化」中的「KV cache 的 K/V」那一项），
        # 之后读回来的就已经是 4 bit 的值了。
        # 于是**不再逐 head 重复量化**：MXFP4 的分组只沿 head_dim（128 = 4 组），
        # 行与行互不影响，所以「整段一次量化」与「逐 head 量化」逐位相同。
        for slot, t in ((0, kh), (1, vh)):
            self._kv_store(layer, slot, t, T)

        return self._attention(phase, layer, kind, qh, T)

    def _attention_fused(self, phase: str, layer: int, kind: str,
                         qh: np.ndarray, T: int) -> np.ndarray:
        """Causal Attention; 64 logical tiles/head and up to 16 heads/core.

        Prefill queries run serially, heads in waves. KV is reread per Q head;
        no cross-query caching, GQA multicast or compute/transfer overlap assumed.
        The FP32 weights never spill to S/A storage or pass through MXFP4.
        """
        s = self.spec
        out = np.zeros((T, s.q_dim), dtype=FP32)
        window = s.sliding_window if kind == "sliding" else None
        for t in range(T):
            end = self.pos + t + 1
            start = max(0, end - window) if window else 0
            n = end - start
            self.fused_attention.bill(self.ledger, phase, layer, n, s.q_heads)
            self.core.read_back(phase, layer, "attn_fused_q_read",
                                s.q_heads * mx_bytes((s.head_dim,)), medium="feram")
            # One read of K and V per query/head, not Q reread per pair.
            kv_transfer = self.core.read_back(phase, layer, "attn_fused_kv_read",
                                2 * s.q_heads * n * mx_bytes((s.head_dim,)), medium="feram")
            load_floor = self.fused_attention.profile(n)["kv_load_cycles"] * ((s.q_heads+15)//16)
            self.ledger.row(phase, layer, "attn_fused_16x4").cycles += max(0, load_floor - kv_transfer.cycles)
            if not self.shape_only:
                for h in range(s.q_heads):
                    hk = h // s.gqa_group
                    k = self.kv[layer, 0, hk, start:end, :]
                    v = self.kv[layer, 1, hk, start:end, :]
                    scores = (qh[t:t+1, h, :] @ k.T) * FP32(s.attn_scale)
                    out[t, h*s.head_dim:(h+1)*s.head_dim] = (softmax(scores) @ v)[0]
        # Next o_proj consumes the stored output. Boundary MXFP4 conversion
        # costs remain explicit pending bridge measurements, not invented prices.
        self.core.write_back(phase, layer, "attn_fused_output_write", T * mx_bytes((s.q_dim,)))
        return out

    def _attention(self, phase: str, layer: int, kind: str, qh: np.ndarray,
                   T: int) -> np.ndarray:
        """注意力：`S = Q K^T * scale → softmax → A V`。

        顺序按**数学正确的顺序**（用户已确认）：先 `S`、再 softmax 得注意力矩阵 `A`、
        再 `A V`。数据流动仍按用户描述：S 写回 MEM → softmax → A 写回 MEM → 乘 V 写回 MEM。

        **账目逐 pair 串行**（`cores = 1`，且用户要求「一次只能进行一个矩阵计算」）：
        * `QK`：每个 `(query, key)` pair 一次 `1x128 @ 128x1` 单位块；
        * softmax：逐 query 行；
        * `AV`：每个 `(query, key)` pair 一次 `1x128 @ 128x1` 单位块。
        聚合计数按 (head) 记，避免 4.7 亿次 Python 循环。

        GQA 的 2 个 q_head 共享同一个 kv_head，所以 K/V 是**同一份 4 bit 数据**，
        只读一次、不做第二遍量化（读的**字节数照旧**按每个 pair 各记一次）。

        **滑窗**（`kind == "sliding"`）：每个 query 只看最近 `window` 个位置，故
        `ctx_eff = min(ctx, window)`，pair 数随之变 —— 这是滑窗唯一改变的账目量。
        整块口径下它**不省块**（`M_e <= 1024` 都按一整块付），省的是 pair 数与
        S/A 的行宽。prefill 内部的因果斜坡（第 i 行只看得到 i+1 个 key）**未**
        单独扣除，故这里给的是**上界**；decode 时（T=1）它是精确值。
        """
        if self.fused_attention:
            return self._attention_fused(phase, layer, kind, qh, T)
        s = self.spec
        D = s.head_dim
        grp = s.gqa_group
        ctx = self.pos + T
        w = s.sliding_window if kind == "sliding" else None
        ctx_eff = ctx if not w else min(ctx, w)
        scale = s.attn_scale
        out = np.zeros((T, s.q_dim), dtype=FP32)

        per_pair_read = mx_bytes((D,)) * 2          # Q_i + K_j（不复用）
        per_pair_v_read = mx_bytes((D,))             # V_j resides in FeRAM
        s_write = 16                                # S_ij 单元素写回（最小 128-bit 访问）
        a_write = 16                                # A_ij 单元素写回
        s_row_read = mx_bytes((ctx_eff,))           # softmax 前把整行 S 读回来

        for h_kv in range(s.kv_heads):
            # KV cache 里存的就是 4 bit 的值（写入时已量化），直接读
            kq = self._kv_view(layer, 0, h_kv, ctx_eff)      # (ctx_eff, D)
            vq = self._kv_view(layer, 1, h_kv, ctx_eff)      # (ctx_eff, D)

            for h_q in range(h_kv * grp, (h_kv + 1) * grp):
                qh_h = qh[:, h_q, :]                      # (T, D)

                # ---- S = Q·K^T * scale ----
                # Q and K are already MXFP4 FeRAM records. Their storage reads
                # are accounted by the paired transfer below.
                s_mat = self._scores(qh_h, kq, ctx_eff, scale)
                pairs = T * ctx_eff
                self.core.matmul_bulk(phase, layer, "attn_qk", 1, 1, D, pairs,
                                      read_per=per_pair_read, write_per=s_write,
                                      read_medium="feram")

                # ---- softmax（逐 query 行）----
                self.core.elementwise(phase, layer, "attention_scale", pairs, row_length=ctx_eff)
                self.core.read_back(phase, layer, "attn_s_read", T * s_row_read)
                self.core.elementwise(phase, layer, "softmax", T * ctx_eff, row_length=ctx_eff)
                a = self._sm(s_mat)
                self.core.write_back(phase, layer, "attn_a_write", pairs * a_write)

                # ---- A·V ----
                o = self._pvo(self.aquant(phase, layer, "attn_a", a), vq, D)
                self.core.matmul_bulk(phase, layer, "attn_pv", 1, 1, D, pairs,
                                      read_per_by_medium={
                                          "rram": 16, "feram": per_pair_v_read},
                                      write_per=16)
                out[:, h_q * D:(h_q + 1) * D] = o
        return out

    # ---------------- FFN 子块（按 kind 分派） ----------------

    def mlp_block(self, phase: str, layer: int, h3: np.ndarray) -> np.ndarray:
        """FFN，返回 `(T, H)` 的子层输出（残差在骨架里加）。

        `gated`（SwiGLU/GeGLU）走 gate/up/down；`plain` 走 up/down（无 gate，元素数
        少一半的乘法）；`fused_gate_up`（Phi-3）把 gate 与 up 合成一个矩阵 ——
        与 fused QKV 同理，**块数与分开算不等**，是账目结构差异。

        MoE 层**硬报错**（第三段）：专家路由会改变「每 token 读多少权重」这个
        主导项（Qwen2-MoE 约 1.8 GB/token），按稠密近似等于把最要紧的那一项算错。
        """
        s = self.spec
        T = h3.shape[0]
        p = f"L{layer:02d}"
        if s.is_moe_layer(layer):
            raise NotImplementedError(
                f"{p} 是 MoE 层（{s.moe.n_experts} 专家 / top-{s.moe.top_k}，"
                f"族 {s.family}）：前向属第三段。容量账已经算得对（专家权重都在 "
                f"`ArchParams.matrices()` 里），但路由会决定「每 token 触碰多少权重」，"
                f"按稠密近似会把权重访存这个主导项算错一个量级")
        fn = act_fn(s.mlp.act)
        i = s.intermediate

        if s.mlp.kind == "plain":
            up = self.linear(phase, layer, "up_proj", h3, f"{p}.up_proj")
            act = fn(up).astype(FP32)
            self.core.elementwise(phase, layer, s.mlp.act, T * i, row_length=i)
            return self.linear(phase, layer, "down_proj", act, f"{p}.down_proj")

        if s.mlp.fused_gate_up:
            gu = self.linear(phase, layer, "gate_up_proj", h3, f"{p}.gate_up_proj")
            gate, up = gu[:, :i], gu[:, i:]
        else:
            gate = self.linear(phase, layer, "gate_proj", h3, f"{p}.gate_proj")
            up = self.linear(phase, layer, "up_proj", h3, f"{p}.up_proj")
        act = (fn(gate) * up).astype(FP32)
        # 种类名沿用 Qwen3 的写法（`silu` + `_mul` ⇒ `silu_mul`），故默认口径逐字不变
        self.core.elementwise(phase, layer, f"{s.mlp.act}_mul", T * i, row_length=i)
        return self.linear(phase, layer, "down_proj", act, f"{p}.down_proj")

    # ---------------- 词表 / lm_head / 采样 ----------------

    def embed(self, ids: list[int], phase: str = "prefill") -> np.ndarray:
        s = self.spec
        H = s.hidden
        T = len(ids)
        if self.shape_only:
            x = np.zeros((T, H), dtype=FP32)
        else:
            tbl = self.img.get("embed_tokens")
            x = np.asarray(tbl[np.asarray(ids, dtype=np.int64)], dtype=FP32)
        T, H = x.shape
        self.core.read_back(phase, -1, "embed_read", T * mx_bytes((H,)))
        if s.norm.embed_scale:
            # Gemma embedding scale uses the measured vector multiply command.
            self.core.elementwise(phase, -1, "embed_scale", T * H, op="attention_scale", row_length=H)
            x = (x * FP32(np.sqrt(H))).astype(FP32)
        return x

    def _lm_name(self) -> str:
        """词表投影用哪张矩阵：绑权重时就是 `embed_tokens`，否则是独立的 `lm_head`。"""
        return "embed_tokens" if self.spec.tie_embeddings else "lm_head"

    def lm_head(self, phase: str, step: int, h: np.ndarray) -> np.ndarray:
        """`logits = h @ E^T`（绑权重：与 embedding 共用同一张表，只读一遍）。

        `h` 只应包含**需要采样的位置**。词表投影的产物里只有 `sample()` 读的那一行
        （`logits[-1]`）被消费，其余行不参与下一步、属死代码；因此 prefill 只传最后
        **1** 个位置，而不是全部 `prompt_tokens` 个。否则 TTFT 段会多记
        `prompt_tokens - 1` 个位置的词表投影与采样开销（本层曾经如此，已修）。

        K 维（= `hidden`）与 `linear` 同规则：**逐 K 块串行**，最后一个 K 块才写回
        一次、才记 `bk - 1` 轮累加。`hidden <= 1024` 时 `bk == 1`，与不切块逐位相同；
        `hidden > 1024` 时必须切 —— 否则整行权重块（`rows x hidden`）装不进寄存器堆。
        """
        name = self._lm_name()
        V, H = self.img.entry_shape(name)                # (V, H)
        T = h.shape[0]
        hq = self.aquant(phase, -1, "lm_head", h)
        bn, bk = ceil_div(V, 1024), ceil_div(H, 1024)
        for b in range(bn):
            rows = min(1024, V - b * 1024)
            wo = mx_bytes((rows,))
            for kb in range(bk):
                kin = min(1024, H - kb * 1024)
                wname = f"{name}.lm.b{b}k{kb}"
                self.core.load_weight_block(phase, -1, "lm_head.wload", wname,
                                            self._wbytes(name, rows, kin))
                rounds = (bk - 1) if kb + 1 == bk else 0
                for _t in range(T):
                    self.core.matmul(phase, -1, "lm_head", 1, rows, kin,
                                     load_weight=False, x_bytes=mx_bytes((kin,)),
                                     out_bytes=(wo if kb + 1 == bk else None),
                                     accum_rounds=rounds)
                self.core.evict(wname)
        logits = self._mm(hq, name)
        # Token selection is a host operation, outside FP32 RTL cost coverage.
        return logits

    def sample(self, logits: np.ndarray, allowed: np.ndarray | None = None) -> int:
        """从最后一行 logits 采样。

        `allowed` 是**被允许的 id 集合**：占位分词器只能解码 `[256, 512)` 这 256 个 id，
        不限制的话 argmax 会取到解不出来的 id。真实 BPE 词表传 `None`。
        采样本身按轻量级算子计（`lm_head` 里已经记过一次 `sample`）。
        """
        row = logits[-1]
        if allowed is not None and allowed.size:
            mask = np.full(row.shape, -np.inf, dtype=FP32)
            mask[allowed] = 0.0
            row = row + mask
        if self.cfg.temperature and self.cfg.temperature > 0:
            p = softmax(row / FP32(self.cfg.temperature))
            rng = np.random.default_rng(self.cfg.sample_seed + self.pos)
            return int(rng.choice(row.size, p=p.astype(np.float64)))
        return int(np.argmax(row))

    # ---------------- 阶段驱动 ----------------

    def prefill(self) -> np.ndarray:
        """prefill：prompt 的 `prompt_tokens` 个 token 一次前向，产出最后一个位置的隐状态（用于首 token）。"""
        T = self.cfg.prompt_tokens
        x = self.embed(list(self.tokens), "prefill")
        assert x.shape[0] == T
        for layer in range(self.qcfg.layers):
            x = self.layer_forward("prefill", layer, x, write_back=(layer + 1 < self.qcfg.layers))
        self.pos += T
        return x

    def decode_step(self, step: int, token: int) -> np.ndarray:
        """一个 decode step：一个 token 过全部 28 层，返回最后位置的隐状态。

        暂不落 kv 的 pos 归位在**层循环之后**：`layer_forward` 把本 token 的 K/V 写在
        `pos` 处、注意力看到 `pos+1` 个位置，然后 `pos += 1` 交给下一步。
        """
        x = self.embed([token], "decode").copy()
        for layer in range(self.qcfg.layers):
            x = self.layer_forward("decode", layer, x, write_back=(layer + 1 < self.qcfg.layers))
        self.pos += 1
        return x

    def final_norm(self, phase: str, x: np.ndarray) -> np.ndarray:
        """最后一道 RMSNorm（走 model.norm），然后才是 lm_head。

        与 `lm_head` 同口径：只对**需要采样的位置**计费（prefill 传最后 1 个位置）。
        """
        y = rmsnorm(x, self._norm("model.norm"), self.spec.rms_eps)
        self.core.elementwise(phase, -1, "rmsnorm", x.shape[0] * self.spec.hidden, row_length=self.spec.hidden)
        return y
