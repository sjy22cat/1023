"""Token-weighted causal perplexity with explicit reference/quantized forwards.

No tokenizer, checkpoint or dataset is downloaded. Synthetic callbacks are
useful for unit tests but must not be presented as a model benchmark.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import hashlib
import json
import math
import types
import numpy as np


def evaluate_perplexity(token_ids, forwards, *, context=2048, stride=512,
                        metadata=None, collect_token_nll=False):
    ids = np.asarray(token_ids, dtype=np.int64)
    if ids.ndim != 1 or len(ids) < 2 or np.any(ids < 0):
        raise ValueError("need at least two nonnegative token IDs in one contiguous document stream")
    if context < 2 or not 1 <= stride < context:
        raise ValueError("require context>=2 and 1<=stride<context (each target needs its preceding token)")
    if not forwards or any(not callable(f) for f in forwards.values()):
        raise ValueError("provide named reference/quantized forward callables")
    sums = {name: 0.0 for name in forwards}
    counts = {name: 0 for name in forwards}
    token_nll = {name: [] for name in forwards}
    activity = {name: {} for name in forwards}
    windows = []
    previous_end = 0
    end = min(context, len(ids))
    while True:
        begin = max(0, end-context)
        target_start = max(1, previous_end, begin+1)
        targets = ids[target_start:end]
        windows.append({"begin": begin, "end": end, "target_begin": target_start,
                        "target_count": len(targets)})
        for name, forward in forwards.items():
            result = forward(ids[begin:end][None, :])
            stats = {}
            if isinstance(result, tuple):
                result, stats = result
            if hasattr(result, "detach"):
                result = result.detach().float().cpu().numpy()
            logits = np.asarray(result)
            if logits.ndim != 3 or logits.shape[:2] != (1,end-begin):
                raise ValueError(f"{name}: forward must return all-position [1,T,V] causal logits")
            if logits.shape[2] <= int(targets.max()):
                raise ValueError(f"{name}: target outside model vocabulary")
            selected = logits[0, target_start-begin-1:end-begin-1].astype(np.float64)
            if not np.isfinite(selected).all():
                raise FloatingPointError(f"{name}: nonfinite logits")
            mx = selected.max(-1)
            nll = mx + np.log(np.exp(selected-mx[:,None]).sum(-1)) - selected[np.arange(len(targets)),targets]
            sums[name] += float(nll.sum(dtype=np.float64))
            counts[name] += len(nll)
            if collect_token_nll:
                token_nll[name].extend(float(v) for v in nll)
            for key, value in stats.items():
                if isinstance(value, (int,float)):
                    activity[name][key] = activity[name].get(key,0)+value
        previous_end = end
        if end == len(ids):
            break
        end = min(len(ids),end+stride)
    modes = {}
    for name in forwards:
        if counts[name] != len(ids)-1:
            raise AssertionError("causal targets duplicated or omitted")
        avg = sums[name]/counts[name]
        modes[name] = {"total_nll": sums[name], "mean_nll": avg,
                       "perplexity": math.exp(avg) if avg < 709 else None,
                       "perplexity_overflow": avg >= 709,
                       "valid_token_count": counts[name], "activity": activity[name]}
        if collect_token_nll:
            modes[name]["token_nll"] = token_nll[name]
    return {"metric": "causal token-weighted perplexity", "token_count": len(ids),
            "context": context, "stride": stride, "window_count": len(windows),
            "windows": windows, "modes": modes, "metadata": metadata or {},
            "token_ids_sha256": hashlib.sha256(ids.tobytes()).hexdigest(),
            "boundary_policy": "contiguous token stream; score every target once; first token unscored"}


def _attach_fp32_comparison(modes):
    """Compare identical token-weighted evaluations against their FP32 mode."""
    reference = modes.get("fp32")
    if reference is None:
        return {"status": "unavailable", "reference_mode": "fp32",
                "reason": "include fp32 in --modes to compare against the standard reference"}
    ref_ppl, ref_nll = reference["perplexity"], reference["mean_nll"]
    for result in modes.values():
        ppl = result["perplexity"]
        result["comparison_to_fp32"] = {
            "delta_perplexity": None if ppl is None or ref_ppl is None else ppl - ref_ppl,
            "relative_delta_perplexity": (None if ppl is None or ref_ppl in (None, 0)
                                          else (ppl - ref_ppl) / ref_ppl),
            "delta_mean_nll": result["mean_nll"] - ref_nll,
        }
    return {"status": "available", "reference_mode": "fp32",
            "definition": "delta = mode metric - fp32 metric; relative PPL delta is divided by fp32 PPL"}


class LinearQuantization:
    """Temporary torch.nn.Linear adapters. Other model ops stay FP32.

    Dense mode quantizes weight/activation MXFP4 then uses torch linear.
    Finite mode evaluates the same quantized operands through the V3 kernel,
    including pre-PE scale-only skip (when a fixed threshold is supplied)
    and finite-width saturation. This is intentionally slow.
    The interface is not a claim that every operator or KV cache is MXFP4.
    """
    def __init__(self, model, mode, *, partial_bits=20, token_chunk=8, output_chunk=1024,
                 mx_skip_threshold_bits=None, enable_tag_skip=True, enable_mx_block_skip=True,
                 parameters=None, dataset=None):
        if mode not in ("dense_mxfp4", "finite_mxfp4"):
            raise ValueError("unknown quantization mode")
        self.model, self.mode = model, mode
        self.partial_bits, self.token_chunk, self.output_chunk = partial_bits, token_chunk, output_chunk
        self.mx_skip_threshold_bits = mx_skip_threshold_bits
        self.enable_tag_skip = bool(enable_tag_skip)
        self.enable_mx_block_skip = bool(enable_mx_block_skip)
        self.parameters, self.dataset = parameters, dataset
        if (mx_skip_threshold_bits is not None and
                (type(mx_skip_threshold_bits) is not int or mx_skip_threshold_bits < 1)):
            raise ValueError("mx_skip_threshold_bits must be a positive integer or None")
        if token_chunk < 1 or output_chunk < 1 or not 2 <= partial_bits <= 52:
            raise ValueError("invalid adapter chunk size or partial width")
        self.stats = {"linear_calls":0, "saturation_count":0, "active_mac":0, "dense_mac":0, "skipped_blocks":0}
        self.coverage = []

    def __enter__(self):
        import torch
        from ..formats import encode_mxfp4, decode_fp4
        from .. import V3Config, run_v3, V3Datasheet
        measured_dataset = self.dataset
        if self.mode == "finite_mxfp4":
            if measured_dataset is None:
                measured_dataset = V3Datasheet.from_parameters(self.parameters)
            if measured_dataset.production:
                self.partial_bits = measured_dataset.config_values["partial_bits"]
                self.mx_skip_threshold_bits = measured_dataset.config_values["mx_skip_threshold_bits"]
        self.originals = []
        try:
            for name,module in self.model.named_modules():
                if not isinstance(module,torch.nn.Linear):
                    continue
                original = module.forward
                # Convert only when the module is used; cache per layer.
                cached = {}
                def wrapped(layer, activation, _cache=cached, _name=name):
                    a = activation.detach().float().cpu().numpy()
                    k = a.shape[-1]
                    pk = (k+31)//32*32
                    aflat = a.reshape(-1,k)
                    if "wp" not in _cache:
                        w = layer.weight.detach().float().cpu().numpy()
                        padded = np.pad(w,((0,0),(0,pk-k)))
                        _cache["wp"], _cache["ws"] = encode_mxfp4(padded)
                    wp,ws = _cache["wp"],_cache["ws"]
                    chunks = []
                    self.stats["linear_calls"] += 1
                    for t in range(0,len(aflat),self.token_chunk):
                        x = np.pad(aflat[t:t+self.token_chunk],((0,0),(0,pk-k)))
                        xp,xs = encode_mxfp4(x)
                        if self.mode == "dense_mxfp4":
                            wdec = decode_fp4(wp,np.repeat(ws,32,-1))[...,:k]
                            xdec = decode_fp4(xp,np.repeat(xs,32,-1))[...,:k]
                            # torch accumulation order matches FP32 reference.
                            y = torch.nn.functional.linear(torch.from_numpy(xdec.astype(np.float32)).to(activation.device),
                                                          torch.from_numpy(wdec.astype(np.float32)).to(activation.device))
                            chunks.append(y.detach().cpu().numpy())
                            self.stats["dense_mac"] += len(x)*wp.shape[0]*k
                        else:
                            pieces = []
                            for o in range(0,wp.shape[0],self.output_chunk):
                                m = min(self.output_chunk,wp.shape[0]-o)
                                cfg = V3Config(m=m,n=1,k=k,batch=len(x),tile_rows=(m+31)//32,
                                               partial_bits=self.partial_bits,enable_softmax=False,
                                               mx_skip_threshold_bits=self.mx_skip_threshold_bits,
                                               enable_tag_skip=self.enable_tag_skip,
                                               enable_mx_block_skip=self.enable_mx_block_skip,
                                               global_sram_bytes=max(512*1024,pk*128))
                                r = run_v3(cfg,dataset=measured_dataset,weight_payload=wp[o:o+m],weight_scale=ws[o:o+m],
                                           input_payload=xp,input_scale=xs)
                                pieces.append(r.logits_hardware)
                                self.stats["saturation_count"] += r.report["finite_width"]["saturation_count"]
                                self.stats["active_mac"] += r.report["architecture"]["valid_macs"]
                                self.stats["dense_mac"] += len(x)*m*k
                                self.stats["skipped_blocks"] += r.report["skip"]["skipped_blocks"]
                                self.stats["rram_mc_reads"] = self.stats.get("rram_mc_reads",0)+r.report["rram_mc"]["read_requests"]
                                self.stats["rram_mc_skips"] = self.stats.get("rram_mc_skips",0)+r.report["rram_mc"]["skip_decisions"]
                            chunks.append(np.concatenate(pieces,-1))
                    out = torch.from_numpy(np.concatenate(chunks,0).reshape(a.shape[:-1]+(wp.shape[0],))).to(activation.device,dtype=activation.dtype)
                    if layer.bias is not None:
                        out = out+layer.bias
                    return out
                self.originals.append((module,original))
                module.forward = types.MethodType(wrapped,module)
                self.coverage.append(name)
        except BaseException:
            self.__exit__(None,None,None)
            raise
        return self

    def __exit__(self, *_):
        for module,original in self.originals:
            module.forward = original
        self.originals = []


def run_local_benchmark(checkpoint, text_file, *, modes=("fp32","dense_mxfp4","finite_mxfp4"),
                        context=2048,stride=512,max_tokens=None,partial_bits=20,device="cpu",
                        mx_skip_threshold_bits=None, enable_tag_skip=True, enable_mx_block_skip=True,
                        parameters=None):
    measured_dataset = None
    if "finite_mxfp4" in modes:
        from ..rtl_dataset import V3Datasheet
        measured_dataset = V3Datasheet.from_parameters(parameters)
        partial_bits = measured_dataset.config_values.get("partial_bits",partial_bits)
        mx_skip_threshold_bits = measured_dataset.config_values.get("mx_skip_threshold_bits",mx_skip_threshold_bits)
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    cp, data = Path(checkpoint).resolve(), Path(text_file).resolve()
    if not cp.is_dir() or not data.is_file():
        raise FileNotFoundError("provide a local pretrained checkpoint directory and held-out UTF-8 text file")
    if not (cp/"config.json").exists() or not any(cp.glob("*.safetensors")) and not any(cp.glob("pytorch_model*.bin")):
        raise ValueError("checkpoint must contain actual model config and weight files")
    if not modes or any(m not in ("fp32","dense_mxfp4","finite_mxfp4") for m in modes):
        raise ValueError("unknown or empty benchmark modes")
    tokenizer = AutoTokenizer.from_pretrained(cp,local_files_only=True,trust_remote_code=False)
    if "byte" in type(tokenizer).__name__.lower() and not (cp/"tokenizer_config.json").exists():
        raise ValueError("placeholder tokenizer cannot produce a formal benchmark")
    model = AutoModelForCausalLM.from_pretrained(cp,local_files_only=True,trust_remote_code=False,
                                                torch_dtype=torch.float32).to(device).eval()
    if not any(isinstance(m,torch.nn.Linear) for m in model.modules()) and any(m!="fp32" for m in modes):
        raise ValueError("this model needs a quantized callback for its projection type (no torch.nn.Linear coverage)")
    text = data.read_text(encoding="utf-8")
    ids = tokenizer(text,add_special_tokens=False)["input_ids"]
    if max_tokens is not None:
        if max_tokens < 2:
            raise ValueError("max_tokens must be >=2")
        ids=ids[:max_tokens]
    meta = {"checkpoint":str(cp),"checkpoint_config_sha256":hashlib.sha256((cp/"config.json").read_bytes()).hexdigest(),
            "weight_files":[{"name":p.name,"bytes":p.stat().st_size} for p in sorted(cp.glob("*")) if p.suffix in (".bin",".safetensors")],
            "tokenizer":type(tokenizer).__name__,"dataset":str(data),
            "dataset_sha256":hashlib.sha256(data.read_bytes()).hexdigest(),"max_tokens":max_tokens,
            "torch_version":torch.__version__,"partial_bits":partial_bits,
            "hardware_parameters": measured_dataset.source_path if measured_dataset else None,
            "mx_skip_threshold_bits": mx_skip_threshold_bits,
            "enable_tag_skip": bool(enable_tag_skip),
            "enable_mx_block_skip": bool(enable_mx_block_skip),
            "mx_skip_rule": "pre-PE E8M0 scale sums only; d>=threshold; no MX skip when threshold is unspecified",
            "quantization_coverage":"torch.nn.Linear weights and inputs; other ops, embedding and KV remain FP32",
            "reference":"loaded pretrained weights FP32; no shadow/random weight replacement"}
    reports = {}
    for mode in modes:
        def forward(token_array):
            with torch.inference_mode():
                return model(input_ids=torch.as_tensor(token_array,device=device),use_cache=False).logits
        if mode == "fp32":
            rep = evaluate_perplexity(ids,{mode:forward},context=context,stride=stride)
        else:
            with LinearQuantization(model,mode,partial_bits=partial_bits,
                                    mx_skip_threshold_bits=mx_skip_threshold_bits,
                                    enable_tag_skip=enable_tag_skip,
                                    enable_mx_block_skip=enable_mx_block_skip,
                                    dataset=measured_dataset) as adapter:
                rep = evaluate_perplexity(ids,{mode:forward},context=context,stride=stride)
                rep["modes"][mode]["activity"] = adapter.stats
                rep["modes"][mode]["linear_modules"] = adapter.coverage
        reports.update(rep["modes"])
    rep["modes"],rep["metadata"] = reports,meta
    rep["comparison"] = _attach_fp32_comparison(reports)
    return rep
