"""Qwen3-0.6B 的结构参数 + numpy 前向原语（RMSNorm / RoPE / SiLU / GQA / softmax）。

结构参数以仓库自己的 `Instruction/GEMM次数统计.md` §1.1 为准：
H=1024、L=28、NH=16、NKV=8、**head_dim=128**（≠ H/NH=64，是独立指定的）、I=3072、
V=151936、`tie_word_embeddings=true`、RMSNorm eps=1e-6、RoPE theta=1e6、
每 head 的 q_norm / k_norm（对 head_dim 做 RMSNorm）、attention scale = 1/sqrt(128)、
SwiGLU + SiLU、**无 bias**、28 层全 full attention（无滑窗）。

数值一律 fp32（与 RTL 的定点累加口径不同，README 里标注这是已知差异）。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np

FP32 = np.float32


# --------------------------------------------------------------------------
# 结构参数
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Qwen3Config:
    hidden: int = 1024
    layers: int = 28
    q_heads: int = 16
    kv_heads: int = 8
    head_dim: int = 128
    intermediate: int = 3072
    vocab: int = 151936
    rms_eps: float = 1e-6
    rope_theta: float = 1e6
    tie_embeddings: bool = True
    max_position: int = 40960

    # ---- 派生量 ----
    @property
    def q_dim(self) -> int:
        return self.q_heads * self.head_dim          # 2048

    @property
    def kv_dim(self) -> int:
        return self.kv_heads * self.head_dim         # 1024

    @property
    def gqa_group(self) -> int:
        return self.q_heads // self.kv_heads         # 2

    @property
    def attn_scale(self) -> float:
        return 1.0 / float(np.sqrt(self.head_dim))

    def validate(self) -> None:
        if self.q_heads % self.kv_heads:
            raise ValueError("q_heads 必须是 kv_heads 的整数倍（GQA）")
        if self.head_dim % 2:
            raise ValueError("head_dim 必须是偶数（RoPE 对半旋转）")
        if self.hidden <= 0 or self.layers <= 0:
            raise ValueError("hidden / layers 必须为正")

    def as_dict(self) -> dict[str, Any]:
        d = dict(self.__dict__)
        d.update(q_dim=self.q_dim, kv_dim=self.kv_dim, gqa_group=self.gqa_group,
                 attn_scale=self.attn_scale)
        return d


# --------------------------------------------------------------------------
# 参数清单（形状 + 元素数；数值实体在 weights.WeightImage 里）
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class MatrixSpec:
    name: str
    out_features: int
    in_features: int
    role: str            # "weight" | "embedding" | "norm"
    note: str = ""

    @property
    def shape(self) -> tuple[int, int]:
        return (self.out_features, self.in_features)

    @property
    def elements(self) -> int:
        return self.out_features * self.in_features


class Qwen3Params:
    """一层与全模型的参数清单（**不持有数值**）。

    `matrices()` 给出所有「要过阵列」的矩阵；`norm_vectors()` 给出轻量级的
    RMSNorm 权重与每 head 的 q_norm / k_norm。
    """

    def __init__(self, cfg: Qwen3Config) -> None:
        cfg.validate()
        self.cfg = cfg

    # ---- 每层 ----
    def layer_matrices(self, layer: int) -> list[MatrixSpec]:
        """每层的 7 个投影矩阵。**注意 `o_proj` 是 `q_dim -> hidden`**（2048 -> 1024），
        不是 `hidden -> hidden` —— head_dim = 128 != hidden/heads = 64，所以
        `q_dim = 16 x 128 = 2048 != hidden = 1024`。写成方阵会让参数量算成 567 M
        （与文档的 596.0 M 不符），且注意力输出送到 o_proj 时形状对不上。
        """
        c = self.cfg
        p = f"L{layer:02d}"
        return [
            MatrixSpec(f"{p}.q_proj", c.q_dim, c.hidden, "weight"),
            MatrixSpec(f"{p}.k_proj", c.kv_dim, c.hidden, "weight"),
            MatrixSpec(f"{p}.v_proj", c.kv_dim, c.hidden, "weight"),
            MatrixSpec(f"{p}.o_proj", c.hidden, c.q_dim, "weight"),
            MatrixSpec(f"{p}.gate_proj", c.intermediate, c.hidden, "weight"),
            MatrixSpec(f"{p}.up_proj", c.intermediate, c.hidden, "weight"),
            MatrixSpec(f"{p}.down_proj", c.hidden, c.intermediate, "weight"),
        ]

    def layer_norms(self, layer: int) -> list[tuple[str, int]]:
        c = self.cfg
        p = f"L{layer:02d}"
        return [(f"{p}.input_layernorm", c.hidden),
                (f"{p}.post_attention_layernorm", c.hidden),
                (f"{p}.q_norm", c.head_dim),
                (f"{p}.k_norm", c.head_dim)]

    def embedding(self) -> MatrixSpec:
        return MatrixSpec("embed_tokens", self.cfg.vocab, self.cfg.hidden, "embedding",
                          note="与 lm_head 绑权重（tie_word_embeddings=true），只存一份")

    def final_norm(self) -> tuple[str, int]:
        return ("model.norm", self.cfg.hidden)

    def lm_head(self) -> MatrixSpec:
        """绑权重：形状与 embedding 相同，**不重复占容量**。"""
        return MatrixSpec("lm_head", self.cfg.vocab, self.cfg.hidden, "embedding",
                          note="= embed_tokens（绑权重）")

    def matrices(self) -> list[MatrixSpec]:
        out: list[MatrixSpec] = []
        for l in range(self.cfg.layers):
            out += self.layer_matrices(l)
        return out

    # ---- 账 ----
    def accounting(self) -> dict[str, Any]:
        c = self.cfg
        per_layer = sum(m.elements for m in self.layer_matrices(0))
        norm_per_layer = sum(n for _, n in self.layer_norms(0))
        emb = self.embedding().elements
        proj_total = per_layer * c.layers
        total = proj_total + emb + norm_per_layer * c.layers + c.hidden
        return {
            "proj_elements": proj_total,
            "embedding_elements": emb,
            "norm_elements": norm_per_layer * c.layers + c.hidden,
            "total_elements": total,
            "total_params_millions": total / 1e6,
            "note": "与 Instruction/GEMM次数统计.md §1.1 的 596.0 M 对照（含绑权重的词表只算一次）",
            "per_layer_elements": per_layer,
        }


# --------------------------------------------------------------------------
# 前向原语（fp32）
# --------------------------------------------------------------------------

def rmsnorm(x: np.ndarray, weight: np.ndarray | None, eps: float = 1e-6) -> np.ndarray:
    """RMSNorm：`x / sqrt(mean(x^2) + eps) * w`（对最后一维）。"""
    xf = np.asarray(x, dtype=FP32)
    var = np.mean(np.square(xf, dtype=FP32), axis=-1, keepdims=True, dtype=FP32)
    y = xf / np.sqrt(var + FP32(eps))
    if weight is not None:
        y = y * np.asarray(weight, dtype=FP32)
    return y


def silu(x: np.ndarray) -> np.ndarray:
    xf = np.asarray(x, dtype=FP32)
    return xf / (FP32(1.0) + np.exp(-xf, dtype=FP32))


def rope_tables(head_dim: int, positions: np.ndarray, theta: float) -> tuple[np.ndarray, np.ndarray]:
    """RoPE 的 cos/sin 表，形状 `(len(positions), head_dim)`。

    约定与 HF Qwen3 一致：`inv_freq[i] = theta^(-2i/d)`（`i = 0..d/2-1`），
    角 `a[i] = pos * inv_freq[i]`，然后**对半拼接**成整条 `d` 长的向量
    （前半与后半用同一组角，配合 `rotate_half` 实现「对半旋转」）。
    """
    d = int(head_dim)
    half = d // 2
    inv_freq = 1.0 / (float(theta) ** (np.arange(0, half, dtype=np.float64) * 2.0 / d))
    ang = np.asarray(positions, dtype=np.float64)[:, None] * inv_freq[None, :]   # (T, d/2)
    cos = np.concatenate([np.cos(ang), np.cos(ang)], axis=-1).astype(FP32)
    sin = np.concatenate([np.sin(ang), np.sin(ang)], axis=-1).astype(FP32)
    return cos, sin


def rotate_half(x: np.ndarray) -> np.ndarray:
    """`[x1, x2] -> [-x2, x1]`（最后一维对半）。"""
    half = x.shape[-1] // 2
    x1, x2 = x[..., :half], x[..., half:]
    return np.concatenate([-x2, x1], axis=-1)


def apply_rope(x: np.ndarray, cos: np.ndarray, sin: np.ndarray) -> np.ndarray:
    """`x * cos + rotate_half(x) * sin`。

    `x` 形状 `(T, heads, head_dim)`；`cos`/`sin` 形状 `(T, head_dim)`（自动插 head 轴）。
    """
    xf = np.asarray(x, dtype=FP32)
    c = np.asarray(cos, dtype=FP32)[:, None, :]
    s = np.asarray(sin, dtype=FP32)[:, None, :]
    return (xf * c + rotate_half(xf) * s).astype(FP32)


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    """数值稳定的 softmax（fp32，减最大值后指数归一）。

    与 `yrr_v3.formats.stable_softmax` 同式（后者是 fp64 版，供既有模型用）。
    """
    xf = np.asarray(x, dtype=FP32)
    z = xf - np.max(xf, axis=axis, keepdims=True)
    e = np.exp(np.clip(z, FP32(-80.0), FP32(80.0)), dtype=FP32)
    return e / np.sum(e, axis=axis, keepdims=True, dtype=FP32)


def kv_head_of(q_head: int, cfg: Qwen3Config) -> int:
    """GQA 映射：`gqa_group = 2` 时，2 个 Q head 共享 1 个 KV head。"""
    return int(q_head) // cfg.gqa_group
