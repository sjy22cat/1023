"""LLM metric provenance for the unified external characterization contract."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Iterable

MEASURED = "measured"
STRUCTURAL = "structural"
PENDING = "pending"
SYNOPSYS_TIERS = (MEASURED,)
NON_PRICE_TIERS = (STRUCTURAL,)
TIER_LABEL = {MEASURED: "Synopsys measured JSON", STRUCTURAL: "elaborated design constant", PENDING: "external result missing"}

@dataclass(frozen=True)
class PriceReq:
    name: str
    tier: str
    source: str
    needed_from: str
    blocks: str
    note: str = ""
    @property
    def is_synopsys(self):
        return self.tier == MEASURED
    @property
    def is_price(self):
        return self.tier not in NON_PRICE_TIERS
    def as_dict(self):
        return dict(name=self.name, tier=self.tier, tier_label=TIER_LABEL[self.tier], source=self.source,
                    needed_from=self.needed_from, blocks=self.blocks, note=self.note)

_THROUGHPUT_NAMES = ("clock_ns", "block_cycles", "mem_rd_ns", "mem_wr_ns", "feram_rd_ns", "feram_wr_ns",
                    "hb_latency_ns", "phy_ps_per_bit", "nonmac")
_ENERGY_NAMES = ("pe_mac_pj", "reduction_add_pj", "phy_pj_per_bit", "nonmac",
                "gsram_read_pj_per_128b", "gsram_write_pj_per_128b", "tile_reg_write_pj_per_bit",
                "leakage_pj_per_cycle", "mem_rd_pj_per_128b", "mem_wr_pj_per_128b",
                "feram_rd_pj_per_128b", "feram_wr_pj_per_128b")
_TIER = {n: (PENDING, "not supplied by measured JSON") for n in (*_THROUGHPUT_NAMES, *_ENERGY_NAMES, "block_pj")}

def requirements_for(metric, billing="whole_block"):
    if metric == "throughput":
        names, tool = _THROUGHPUT_NAMES, "VCS/PrimeTime/PHY or memory IP timing characterization"
    elif metric == "efficiency":
        names, tool = _ENERGY_NAMES + (("block_pj",) if billing == "whole_block" else ()), "PrimeTime PX with VCS SAIF and memory/PHY macro power models"
    else:
        raise ValueError(f"unknown metric {metric!r}")
    return tuple(PriceReq(n, PENDING, "external result missing", tool, metric) for n in names)

def requirements(billing="whole_block"):
    return requirements_for("throughput", billing) + requirements_for("efficiency", billing)

def is_price(name: str) -> bool:
    """这个名字是不是"单价"（`structural` 是架构定义，不是物理量估计）。"""
    return _TIER[name][0] not in NON_PRICE_TIERS


def tier_of(name: str, filled: Iterable[str] = ()) -> str:
    """取某个单价的**当前**档位。

    统一 measured JSON 中已通过加载器验证的名字一律算 `measured`。
    """
    if name in filled:
        return MEASURED
    return _TIER[name][0]


def _resolve(req: PriceReq, filled: Iterable[str], sources=None) -> PriceReq:
    """按"是否已被 calib 填入"重新定档；来源串相应改写。"""
    tier, source = _TIER[req.name]
    if req.name in filled:
        tier, source = MEASURED, (sources or {}).get(req.name, "validated Synopsys measured JSON")
    return PriceReq(req.name, tier, source, req.needed_from, req.blocks, req.note)


def resolve(reqs: Iterable[PriceReq], filled: Iterable[str] = ()) -> tuple[PriceReq, ...]:
    """批量定档（`_resolve` 的公开入口，供 `metrics` 复用同一套口径）。"""
    filled = set(filled)
    return tuple(_resolve(r, filled) for r in reqs)


def audit(prices=None, billing: str = "whole_block",
          filled: Iterable[str] = ()) -> dict[str, Any]:
    """把两个指标的单价需求过一遍，给出缺口与状态。

    `prices.provenance` 用于记录实际选择的文件，档位仍由已验证的字段集合决定。
    `filled` 是统一 measured JSON 中已经验证的字段名集合。

    `status`：
      * `APPLIED`  —— 需要的单价**全部**是新思口径，两个指标都能出数；
      * `PENDING`  —— 一个新思值都还没有（现状）；
      * `PARTIAL`  —— 有一部分（例如时序到了、能耗还没到）。

    本函数**不填默认值**：档位表里是什么档就是什么档。
    """
    filled = set(filled)
    sources = getattr(prices, "provenance", {})
    source_file = sources.get("clock_ns", "")
    source_file = (source_file.split(":", 1)[1].split("#", 1)[0]
                   if source_file.startswith("measured:") else None)

    def _metric(name: str) -> dict[str, Any]:
        rs = tuple(_resolve(r, filled, sources) for r in requirements_for(name, billing))
        miss = [r.as_dict() for r in rs if not r.is_synopsys]
        return {"ok": not miss, "n_required": len(rs), "n_missing": len(miss),
                "missing": sorted(miss, key=lambda d: d["name"]),
                "required": [r.as_dict() for r in rs]}

    met = {"throughput": _metric("throughput"), "efficiency": _metric("efficiency")}
    all_reqs = [_resolve(r, filled, sources) for r in requirements(billing)]
    n_missing = sum(1 for r in all_reqs if not r.is_synopsys)
    n_total = len(all_reqs)
    status = "APPLIED" if n_missing == 0 else ("PENDING" if n_missing == n_total else "PARTIAL")

    # 已满足的（= 已经是新思口径）也列出来，让"哪个是新思的"一眼可见。
    ok_reqs = [r.as_dict() for r in all_reqs if r.is_synopsys]
    return {
        "status": status,
        "billing": billing,
        "assumptions_source": source_file or "TEST_ONLY",
        "synopsys_only_tiers": list(SYNOPSYS_TIERS),
        "n_required": n_total,
        "n_missing": n_missing,
        "satisfied": sorted(ok_reqs, key=lambda d: d["name"]),
        "missing": sorted([r.as_dict() for r in all_reqs if not r.is_synopsys],
                          key=lambda d: d["name"]),
        "by_metric": met,
        "calib_file": source_file,
        "note": (
            "吞吐率与能量效率只认统一 Synopsys measured JSON。"
            "加载器会拒绝缺字段，不拿 RTL/derived/fallback 值凑数。"
            "更新 measured JSON 后重新运行即可；缺口逐项列在 missing 里。"
        ),
    }
