"""LLM 报告的文本打印（与 `yrr_v3/report.py` 并列，互不影响）。

`yrr_v3/report.py` 的键集与排版被现有 45 项自检钉死，所以**一行不改**；
本文件只读 `inference.run_llm()` 产出的 dict，把它排成人能看的样子。
"""
from __future__ import annotations

import sys
import unicodedata
from typing import Any

W = 78          # 行宽


def _dw(s: str) -> int:
    """字符串的**显示宽度**：CJK / 全角字符算 2 列（否则中文表格全歪）。"""
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in s)


def _pad(s: str, width: int, align: str) -> str:
    gap = " " * max(0, width - _dw(s))
    return s + gap if align == "<" else gap + s


def setup_console() -> None:
    """让中文报告在 Windows 的**管道**输出下也不炸。

    直连控制台时不动它（Python 用控制台 API，中文本来就正常）；只在 stdout 被重定向
    （管道/文件）时切成 UTF-8，避免 cp936 编不出 `U+FFFD` 之类的字符而抛
    `UnicodeEncodeError`。
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            if not stream.isatty():
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def _hr(ch: str = "-") -> str:
    return ch * W


def _fmt_bytes(n: float) -> str:
    n = float(n)
    for unit, div in (("GiB", 1 << 30), ("MiB", 1 << 20), ("KiB", 1 << 10)):
        if abs(n) >= div:
            return f"{n / div:,.2f} {unit}"
    return f"{n:,.0f} B"


def _fmt_energy(pj: float) -> str:
    """pJ 自动升到 nJ / uJ / mJ / J / kJ / MJ。"""
    pj = float(pj)
    for unit, div in (("MJ", 1e18), ("kJ", 1e15), ("J", 1e12), ("mJ", 1e9),
                      ("uJ", 1e6), ("nJ", 1e3)):
        if abs(pj) >= div:
            return f"{pj / div:,.4g} {unit}"
    return f"{pj:,.4g} pJ"


def _fmt_time(ns: float) -> str:
    ns = float(ns)
    for unit, div in (("year", 365.25 * 24 * 3600 * 1e9), ("day", 24 * 3600 * 1e9),
                      ("h", 3600 * 1e9), ("min", 60 * 1e9), ("s", 1e9),
                      ("ms", 1e6), ("us", 1e3)):
        if abs(ns) >= div:
            return f"{ns / div:,.4g} {unit}"
    return f"{ns:,.4g} ns"


def _fmt_count(n: float) -> str:
    n = float(n)
    for unit, div in (("T", 1e12), ("G", 1e9), ("M", 1e6), ("K", 1e3)):
        if abs(n) >= div:
            return f"{n / div:,.4g}{unit}"
    return f"{n:,.4g}"


NA = "—"        # 「缺新思数据」—— 只在 [13]/[14]/[15] 里出现，含义见 [15]


def _fmt_num(x, spec: str = ",.4g") -> str:
    """给可能为 `None` 的指标用：`None` = 缺新思数据，打印成「—」。"""
    if x is None:
        return NA
    try:
        return format(float(x), spec)
    except (TypeError, ValueError):
        return str(x)


def _fmt_sci(x) -> str:
    """大范围的量（例如整块口径下的焦耳数）用科学计数法，避免一长串 0。"""
    return _fmt_num(x, ".4g")


def _table(headers: list[str], rows: list[list[str]], widths: list[int] | None = None,
           aligns: list[str] | None = None) -> list[str]:
    if widths is None:
        widths = [max([_dw(h)] + [_dw(r[i]) for r in rows]) for i, h in enumerate(headers)]
    aligns = aligns or ["<"] * len(headers)
    out = ["  ".join(_pad(h, w, a) for h, w, a in zip(headers, widths, aligns)).rstrip()]
    out.append("  ".join("-" * w for w in widths))
    for r in rows:
        out.append("  ".join(_pad(c, w, a) for c, w, a in zip(r, widths, aligns)).rstrip())
    return out


def _kv_shape_note(mdl: dict[str, Any]) -> str:
    """KV 行宽的逐元素说明（MLA 与非 MLA 是**两种不同的存法**，不能都用 GQA 那句）。"""
    if mdl.get("mla"):
        m = mdl["mla"]
        return (f" = {mdl['layers']} 层 x 位置 x {mdl['kv_row_elements']}"
                f"（MLA 压缩行宽 = kv_lora_rank {m['kv_lora_rank']} + "
                f"qk_rope_head_dim {m['qk_rope_head_dim']}）")
    return (f" = {mdl['layers']} 层 x 2 x {mdl['kv_heads']} head x 位置 x "
            f"{mdl['head_dim']}")


def _model_title(mdl: dict[str, Any]) -> str:
    """标题里的模型名。

    **不在呈现层猜名字**：`rep["model"]["title"]` 由 `inference._spec_title` 按
    spec 的出处算好（默认口径「Qwen3-0.6B」、动物园条目用它的名字、其余用
    「族名 + 形状」拼）。这里只做兜底，供手工拼出来的老报告用。
    """
    t = mdl.get("title")
    if t:
        return str(t)
    if (mdl.get("hidden"), mdl["layers"], mdl["vocab"]) == (1024, 28, 151936):
        return "Qwen3-0.6B"
    return (f"{mdl.get('family', '?')}（hidden={mdl['hidden']}, "
            f"layers={mdl['layers']}, vocab={mdl['vocab']}）")


def format_report(rep: dict[str, Any]) -> str:
    L: list[str] = []

    # ---------------- 标题 ----------------
    cfg, mdl, out = rep["config"], rep["model"], rep["output"]
    title = _model_title(mdl)
    L += [_hr("="),
          f"YRR V3 近存加速器 —— {title} 推理模拟与加速器服务评估（MXFP4 / W4A4）",
          _hr("="), ""]

    # ---------------- 0. 量级预告（放最前面） ----------------
    en, la = rep["energy"], rep["latency"]
    th, ef, pv = rep.get("throughput"), rep.get("efficiency"), rep.get("provenance")
    L += ["[0] 先看这里：本次口径下的量级", _hr()]
    L += [f"  能耗 total（整块计费，本次口径） : {_fmt_energy(en['total_whole_block_pj'])}"
          f"   （= {en['total_whole_block_pj']:,.0f} pJ）",
          f"  能耗 total（unit 对照口径）      : {_fmt_energy(en['total_unit_pj'])}"
          f"   （unit/whole = {en['ratio_unit_over_whole']:.4g}x）",
          f"  时间 total（1 core 全串行）      : {_fmt_time(la['ns_serial_1core'])}"
          f"   （= {la['cycles_serial_1core']:,.0f} 拍 @ {la['clock_ns']:g} ns）",
          f"  每 token 能耗（整块口径）        : {_fmt_energy(en['per_token_whole_pj'])}",
          "",
          "  注意：**这是两个已确认决定的直接算术后果**，不是 bug：",
          "    (1) 不足 1024x1024 的矩阵按**整块占用**计费 —— decode 的 [1,1024]x[1024,2048]",
          "        这种 skinny 矩阵要付满一整块 [1024,1024]x[1024,1024] 的价（~1024x 惩罚）；",
          "    (2) cores = 1，**一切全串行** —— 连 prefill 也没法并行，一个矩阵一个矩阵地算。",
          "  报告里同时并列 unit 口径，切换只是 LlmConfig.billing 一个字段。",
          ""]
    # 两个新指标的**状态**放在最前面 —— 因为"缺新思数据"是本轮预期结果，要一眼看到
    _th, _ef = rep.get("throughput"), rep.get("efficiency")
    if _th is not None and _ef is not None:
        L += [f"  吞吐率（token/s）   : {'可出数' if _th['per_core'] else '缺新思数据（PENDING）'}"
              f"   —— 见 [13]",
              f"  能量效率（J/token） : {'可出数' if _ef['by_billing'][_ef['billing']]['per_token_j'] else '缺新思数据（PENDING）'}"
              f"   —— 见 [14]",
              "  正式入口只读取统一 Synopsys measured JSON；缺必需参数时拒绝运行。",
              "  组件测试的合成价格不给出 measured 指标（见 [15] 的缺口表）。",
              ""]

    # ---------------- 1. 配置 ----------------
    L += ["  评估范围：已覆盖的加速器服务；Host MXFP4 编码、RoPE 表准备和 token 采样成本未覆盖。",
          "  非 MAC 周期/动态能耗来自集成 FP32 RTL 的实测算子/长度记录；非含 Host 的整机实测。", ""]
    L += ["[1] 配置", _hr()]
    L += _table(
        ["项", "值"],
        [["core 数", f"{cfg['cores']}（本次：1，全串行）"],
         ["MEM die", f"{cfg['mem_die_gib']:g} GiB / 颗，共 {cfg['mem_die_count']} 颗"],
         ["上下文输入", f"{cfg['prompt_tokens']} token"],
         ["输出", f"{cfg['max_new_tokens']} token"],
         ["推理次数", f"{cfg['n_runs']}"],
         ["量化", f"MXFP4 W{cfg['w_bits']}A{cfg['a_bits']}，组 {cfg['group_size']} 元素"
                  f"{'（激活也量化）' if cfg['quantize_activations'] else '（激活不量化，W4A16）'}"],
         ["计费口径", f"{cfg['billing']}"],
         ["跨 Die 链路", f"{cfg['phy_bpc']} bit/拍（HB_WIDTH；数据集字面值 BPC=1 见 [5]）"],
         ["权重来源", "模拟器内生成（种子 "
                      f"{cfg['seed']}）" if not cfg["weights"] else str(cfg["weights"])],
         ["分词器", str(out["tokenizer"]["name"])],
         ["采样", out["sampling"]]],
        widths=[16, 56], aligns=["<", "<"])
    L.append("")

    # ---------------- 2. 模型与参数 ----------------
    L += [f"[2] 模型（{title}）", _hr()]
    act = mdl["params"]
    L += _table(
        ["项", "值"],
        [["hidden / layers", f"{mdl['hidden']} / {mdl['layers']}"],
         ["heads (Q / KV)", f"{mdl['q_heads']} / {mdl['kv_heads']}（GQA 组 {mdl['gqa_group']}）"],
         ["head_dim", f"{mdl['head_dim']}"
                      + ("" if mdl['head_dim'] == mdl['hidden'] // mdl['q_heads']
                         else f"（!= hidden/heads = {mdl['hidden'] // mdl['q_heads']}，独立指定）")],
         ["q_dim / kv_dim", f"{mdl['q_dim']} / {mdl['kv_dim']}"],
         ["intermediate", f"{mdl['intermediate']}"],
         ["vocab", f"{mdl['vocab']:,}（tie_word_embeddings = {mdl['tie_embeddings']}）"],
         ["RMSNorm eps / RoPE theta", f"{mdl['rms_eps']:g} / {mdl['rope_theta']:g}"],
         ["attention scale", f"1/sqrt({mdl['head_dim']}) = {mdl['attn_scale']:.6g}"],
         ["参数量", f"{act['total_params_millions']:.1f} M"
                    f"（投影 {act['proj_elements'] / 1e6:.1f}M + 词表 {act['embedding_elements'] / 1e6:.1f}M"
                    f" + norm {act['norm_elements'] / 1e6:.3f}M）"]],
        widths=[26, 46], aligns=["<", "<"])
    L.append("")

    # ---------------- 3. 摆放 ----------------
    pl = rep["placement"]
    L += [f"[3] 摆放（logic die + 1 颗 {pl['capacity_gib']:g} GiB MEM die）", _hr()]
    L += [f"  容量  {pl['capacity_gib']:g} GiB = {pl['capacity_bytes']:,} B"
          f"（= {pl['capacity_decimal_gb']:.2f} x 10^9 B，两种读法都列出）",
          f"  已用  {_fmt_bytes(pl['used_bytes'])}（{pl['used_pct']:.3f}%）"
          f"   余 {_fmt_bytes(pl['free_bytes'])}", ""]
    L += _table(["角色", "张量数", "字节", "payload", "尺度/E8M0", "raw"],
                [[role, f"{d['tensors']:,}", _fmt_bytes(d["nbytes"]),
                  _fmt_bytes(d["payload_bytes"]), _fmt_bytes(d["scale_bytes"]),
                  _fmt_bytes(d["raw_bytes"])]
                 for role, d in sorted(pl["by_role"].items(),
                                       key=lambda kv: -kv[1]["nbytes"])],
                aligns=["<", ">", ">", ">", ">", ">"])
    L.append("")
    L += ["  最大的几块："]
    L += _table(["张量", "形状", "字节"],
                [[d["name"], "x".join(str(s) for s in d["shape"]), _fmt_bytes(d["nbytes"])]
                 for d in pl["largest"][:6]])
    L += [f"  KV cache：{pl['kv_cache_elements']:,} 个元素，按 MXFP4 存 "
          f"{_fmt_bytes(pl['kv_cache_bytes_fp4'])}"
          f"（形状 {' x '.join(str(s) for s in pl['kv_cache_shape'])}"
          + _kv_shape_note(mdl) + "）", ""]

    hm = rep.get("hybrid_memory")
    if hm is not None:
        L += ["[3a] RRAM / FeRAM 地址池", _hr()]
        for medium in ("rram", "feram"):
            pool = hm["by_medium"][medium]
            cap_text = (f"{pool['capacity_bytes']:,} B" if pool["capacity_bytes"] is not None
                        else "容量待 RTL 参数")
            L.append(f"  {medium.upper():5} {_fmt_bytes(pool['used_bytes'])} / {cap_text}"
                     f"，{len(pool['tensors'])} 个张量")
        L += [f"  容量状态：{hm['capacity_status']}",
              "  主机推理前装载权重到 RRAM；主机读写延迟不计入推理延迟。",
              f"  FeRAM 成本参数：{hm['parameter_status']}", ""]

    # ---------------- 4. core / 阵列 ----------------
    co = rep["core"]
    L += ["[4] compute core（1 个）", _hr()]
    L += [f"  阵列     {co['array']['rows']} 输出行 x {co['array']['k']} K"
          f"，{co['array']['pe']:,} PE，{co['array']['tiles']:,} 个 tile",
          f"  权重寄存器堆 {_fmt_bytes(co['regfile_bytes'])}"
          f"  —— 一个 1024x1024 的 MXFP4 权重块恰好 {_fmt_bytes(co['regfile_mxfp4_block_bytes'])}",
          f"  GSRAM    {_fmt_bytes(co['gsram_bytes'])}（当一整块用）",
          f"  权重装载 {co['weight_loads']:,} 次 / {_fmt_bytes(co['weight_load_bytes'])}"
          f"（常驻命中不计；寄存器堆峰值 {_fmt_bytes(co['regfile_high_water_bytes'])}）", ""]

    # ---------------- 5. 单价 ----------------
    cp = rep["cost_primitive"]
    ub = cp["unit_block"]
    L += ["[5] 单价（全部来自现有数据集，见 report 的 provenance 字段）", _hr()]
    L += _table(
        ["原语", "单价", "出处"],
        [["内部全阵列 GEMV（batch=1）", f"{ub['pj']:,.1f} pJ", "外部块价；权重已驻留"],
         ["单位块拍数", f"{ub['cycles']:,} 拍", "Host/DMA、权重装载、softmax 均另计"],
         ["FP32 non-MAC", "Measured operator/length profiles", "Engine + scratch; host quantization/sampling excluded"],
         ["RRAM 读 / 次 128bit", f"{cp['mem']['rd_pj_per_128b']:g} pJ / {cp['mem']['rd_ns']:g} ns", "外部 array 表征"],
         ["RRAM 写 / 次 128bit", f"{cp['mem']['wr_pj_per_128b']:g} pJ / {cp['mem']['wr_ns']:g} ns", "外部 array 表征"],
         ["PHY pJ/bit；ps/payload beat", f"{cp['phy']['pj_per_bit']:g} pJ / {cp['phy']['ps_per_bit']:g} ps", "外部 PHY/HB 表征"],
         ["HB 延迟 / 次传输", f"{cp['phy']['hb_latency_ns']:g} ns", "外部 HB 表征"],
         ["时钟", f"{cp['clock_ns']:g} ns（{cp['f_max_mhz']:g} MHz）", "实测参数；MHz 为换算值"]],
        widths=[32, 26, 22], aligns=["<", ">", "<"])
    L.append("")

    # ---------------- 6. 阶段 ----------------
    L += ["[6] 阶段分解（账目口径：逐 token / 逐 pair / 逐块串行）", _hr()]
    ph = rep["phases"]
    L += _table(["阶段", "操作数", "单位块", "MAC", "拍", "整块口径能耗", "unit 口径能耗"],
                [[p, _fmt_count(d["count"]), _fmt_count(d["blocks"]),
                  _fmt_count(d["macs"]), _fmt_count(d["cycles"]),
                  _fmt_energy(d["whole_pj"]), _fmt_energy(d["unit_pj"])]
                 for p, d in sorted(ph.items(), key=lambda kv: -kv[1]["whole_pj"])],
                aligns=["<", ">", ">", ">", ">", ">", ">"])
    cfg, mo = rep["config"], rep["model"]
    lm_blocks = -(-mo["vocab"] // 1024)          # lm_head 的输出块数 = ceil(vocab / 1024)
    L += [f"  prefill = prompt 的 {cfg['prompt_tokens']} token 过 {mo['layers']} 层；"
          f"decode = 逐步的 {mo['layers']} 层；"
          f"lm_head = 每步的词表投影（{lm_blocks} 个输出块）+ 采样 + 最终 RMSNorm。", ""]

    # ---------------- 7. 逐 op ----------------
    L += ["[7] 逐 op 汇总（按整块口径能耗降序，前 16）", _hr()]
    ok = sorted(rep["ops_by_kind"].items(), key=lambda kv: -kv[1]["whole_pj"])[:16]
    L += _table(["op", "类别", "计数", "单位块", "拍", "整块口径", "unit 口径", "访存字节"],
                [[k, d["cat"], _fmt_count(d["count"]), _fmt_count(d["blocks"]),
                  _fmt_count(d["cycles"]), _fmt_energy(d["whole_pj"]),
                  _fmt_energy(d["unit_pj"]),
                  _fmt_bytes(d["mem_rd_bytes"] + d["mem_wr_bytes"])]
                 for k, d in ok],
                aligns=["<", "<", ">", ">", ">", ">", ">", ">"])
    L.append("")

    # ---------------- 8. 访存与互连 ----------------
    tr = rep["memory_traffic"]
    L += ["[8] 访存与互连（四段分开，不合并）", _hr()]
    L += _table(["段", "字节", "能耗"],
                [["MEM die 读", _fmt_bytes(tr["read_bytes"]), _fmt_energy(tr["pj"]["mem_read"])],
                 ["MEM die 写", _fmt_bytes(tr["write_bytes"]), _fmt_energy(tr["pj"]["mem_write"])],
                 ["PHY 跨 Die（含 HB）", _fmt_bytes(tr["phy_bytes"]), _fmt_energy(tr["pj"]["phy"])],
                 ["GSRAM 中转（Die 内）", _fmt_bytes(tr["gsram_bytes"]), _fmt_energy(tr["pj"]["gsram"])],
                 ["权重寄存器堆写入", "-", _fmt_energy(tr["pj"]["regfile"])],
                 ["合计", _fmt_bytes(tr["total_bytes"]), _fmt_energy(sum(tr["pj"].values()))]],
                aligns=["<", ">", ">"])
    L += [f"  四段串行延迟合计 {_fmt_time(tr['ns'])}（各段的 ns 已按 128bit 访问/位串行摊开）", ""]
    if "by_medium" in tr:
        L += ["  按介质流量（主机读写字节分别包含在对应读/写流量中）："]
        L += _table(["介质", "读", "写", "其中主机读", "其中主机写"],
                    [[medium.upper(), _fmt_bytes(data["read_bytes"]),
                      _fmt_bytes(data["write_bytes"]),
                      _fmt_bytes(data["host_read_bytes"]),
                      _fmt_bytes(data["host_write_bytes"])]
                     for medium, data in tr["by_medium"].items()])
        L.append(f"  未计价访问字节：{tr.get('pending_cost_bytes', {})}")
        L.append("  主机读写延迟排除；FeRAM 阵列成本缺参时，上方延迟/能耗只包含已知部分。")
        L.append("")

    # ---------------- 9. 能耗分段 ----------------
    L += ["[9] 能耗分段", _hr()]
    if "status" in en:
        L.append(f"  完整性：{en['status']}")
    L += _table(["类别", "计数", "单位块", "元素", "整块口径", "unit 口径"],
                [[k, _fmt_count(d["count"]), _fmt_count(d["blocks"]),
                  _fmt_count(d["elements"]), _fmt_energy(d["whole_pj"]),
                  _fmt_energy(d["unit_pj"])]
                 for k, d in sorted(en["by_cat"].items(), key=lambda kv: -kv[1]["whole_pj"])],
                aligns=["<", ">", ">", ">", ">", ">"])
    L += [f"  其中切块累加（bk-1 轮完整归约）占 {_fmt_energy(en['accumulate_whole_pj'])}", ""]

    # ---------------- 10. 延迟 ----------------
    L += ["[10] 延迟", _hr()]
    L += [f"  1 core 全串行：{la['cycles_serial_1core']:,.0f} 拍 = "
          f"{_fmt_time(la['ns_serial_1core'])}"]
    L += _table(["core 数", "拍", "时间"],
                [[k, f"{v:,.0f}", _fmt_time(la["ns_with_cores"][k])]
                 for k, v in la["cycles_with_cores"].items()],
                aligns=[">", ">", ">"])
    L += ["  （cores > 1 是**上界乐观**的摊薄，真实调度还要处理依赖与同步；能耗不随 cores 变）", "",
          f"  PHY 时间对比：{cp['phy']['bpc']} bit/拍 → {_fmt_time(la['phy_ns_at_bpc_default'])}"
          f"；数据集字面 BPC=1 → {_fmt_time(la['phy_ns_at_bpc1'])}"
          + (f"（{la['phy_bpc_ratio']:,.4g}x）" if la['phy_bpc_ratio'] is not None
           else "（PHY 延迟缺参或为零，比值不可用）"), ""]

    # ---------------- 11. 调用次数 ----------------
    cc = rep["call_counts"]
    L += ["[11] 调用次数（与 Instruction/GEMM次数统计.md 同口径，用于验证调度没漏算子）", _hr()]
    L += [f"  每 token 算子调用 = {cc['operator_invocations_per_token']}"
          f"（{cc['formula']}）",
          f"  全 run 算子调用   = {cc['operator_invocations_total']:,}",
          f"  单位块总数        = {cc['unit_blocks']:,}",
          f"  矩阵计算事件      = {cc['matmul_events']:,}（聚合成账本行，不逐条 materialize）",
          f"  实际 MAC          = {cc['actual_macs']:,}",
          f"  计费 MAC（整块）  = {cc['billed_macs_whole_block']:,}"
          f"（= 单位块数 x 1024^3，比值 {cc['billed_macs_whole_block'] / max(cc['actual_macs'], 1):,.1f}x）",
          ""]

    # ---------------- 12. 输出 ----------------
    L += ["[12] 输出", _hr()]
    L += [f"  prompt（{cfg['prompt_tokens']} token）: {out['prompt_text'][:120]!r}",
          f"  生成 {len(out['generated_ids'])} 个 token，前 32 个 id：{out['generated_ids_head']}",
          f"  解码文本（前 200 字）：{out['generated_text'][:200]!r}",
          "",
          "  随机权重下输出必然是乱码 —— 这是硬件仿真，不是语言质量评测。",
          "  默认占位分词器保证 decode(encode(t)) == t，所以「输入 prompt → 输出结果」",
          "  这条链路是通的、可打印的；--weights/--tokenizer 可换成真实 checkpoint 与真 BPE。",
          ""]

    # ---------------- 13. 吞吐率 ----------------
    L += ["[13] 吞吐率（token/s）—— 统一新思实测参数", _hr()]
    if th is None:
        L += ["  （本次报告里没有这一段）", ""]
    else:
        L += [f"  定义：{th['definition']}",
              f"  规模：prompt {th['prompt_tokens']} token → 生成 {th['gen_tokens']} token"
              f"；计费口径 {th['billing']}；时钟 {th['clock_ns']:g} ns/拍",
              f"  状态：{th['status']}"
              + ("" if th["status"] == "APPLIED"
                 else f" —— 缺 {len(th['blocked_by'])} 项新思数据：{', '.join(th['blocked_by'])}"),
              ""]
        if th["per_core"] is None:
            L += ["  token/s 三栏全部为「—」：当前组件测试未使用完整 measured 输入。",
                  "  合成测试数据不能用于发布硬件指标。",
                  "  缺口与要哪个工具，见 [15]。", ""]
        else:
            L += _table(["core 数", "TTFT (s)", "TTFT token/s", "decode token/s", "端到端 token/s"],
                        [[k, _fmt_time(v["ttft_s"] * 1e9), _fmt_num(v["ttft_tok_s"]),
                          _fmt_num(v["decode_tok_s"]), _fmt_num(v["e2e_tok_s"])]
                         for k, v in th["per_core"].items()],
                        aligns=[">", ">", ">", ">", ">"])
            L += [""]
        # 不受时钟影响的对照 —— 缺时钟时至少能看结构
        cf = th["clock_free"]
        L += ["  -- 拍数口径的对照（不依赖 clock_ns；但**不等于**与新思无关，见下）--"]
        L += _table(["core 数", "TTFT 拍", "decode 拍", "端到端拍", "端到端每 1e6 拍产出 token"],
                    [[k, f"{v['ttft_cycles']:,.0f}", f"{v['decode_cycles']:,.0f}",
                      f"{v['e2e_cycles']:,.0f}", _fmt_num(v["e2e_tokens_per_1e6_cycles"])]
                     for k, v in sorted(cf.items()) if isinstance(v, dict)],
                    aligns=[">", ">", ">", ">", ">"])
        share = cf.get("ns_derived_share")
        L += [f"  {cf['caveat']}",
              f"  本次总拍数里由 ns 换算而来的比例："
              f"{'—' if share is None else f'{share:.2%}'}"
              f"（MEM / PHY / HB 那一段；其余是结构量拍数）",
              "", f"  {th['core_note']}", ""]

    # ---------------- 14. 能量效率 ----------------
    L += ["[14] 能量效率（J/token）—— 统一新思实测参数", _hr()]
    if ef is None:
        L += ["  （本次报告里没有这一段）", ""]
    else:
        L += [f"  定义：{ef['definition']}",
              f"  状态（{ef['billing']} 口径）：{ef['status']}", "",
              "  两种计费口径的缺口不同（unit 口径不读整块能耗本身，少一项），所以分开过门："]
        L += _table(["计费口径", "状态", "缺项", "decode J/token", "端到端 J/token",
                     "首 token 能耗 (J)"],
                    [[b, d["status"], str(len(d["blocked_by"])),
                      _fmt_num((d["per_token_j"] or {}).get("decode")),
                      _fmt_num((d["per_token_j"] or {}).get("e2e")),
                      _fmt_sci(d["energy_j"]["ttft"])]
                     for b, d in ef["by_billing"].items()],
                    aligns=["<", "<", ">", ">", ">", ">"])
        L += ["  「首 token 能耗」是 TTFT 段账本的 J，不是 J/token。",
              "  正式块单价来自外部测量；总量为该输入下的架构预测，数值等价需另验。", ""]
        if all(d["per_token_j"] is None for d in ef["by_billing"].values()):
            L += ["  J/token 全部为「—」：组件测试价格没有完整 measured 来源。",
                  "  正式入口应先提供并校验统一实测 JSON。",
                  "  缺口与要哪个工具，见 [15]。", ""]
        L += [f"  {ef['core_note']}", ""]

    # ---------------- 15. 单价来源缺口 ----------------
    L += ["[15] 单价来源缺口（还缺哪些新思数据）", _hr()]
    if pv is None:
        L += ["  （本次报告里没有这一段）", ""]
    else:
        L += [f"  总体状态：{pv['status']}"
              f"（需要 {pv['n_required']} 项，缺 {pv['n_missing']} 项）"
              f"；假定来源 {pv['assumptions_source']}", ""]
        for m, label in (("throughput", "吞吐率 token/s"), ("efficiency", "能量效率 J/token")):
            d = pv["by_metric"][m]
            L += [f"  -- {label}：需要 {d['n_required']} 项，缺 {d['n_missing']} 项 --"]
            if not d["missing"]:
                L += ["    全部具备（新思档）"]
            else:
                L += _table(["缺的单价", "当前档", "挡着什么", "要哪个工具 / 报告（指南 §4）"],
                            [[r["name"], r["tier_label"], r["blocks"], r["needed_from"]]
                             for r in d["missing"]],
                            aligns=["<", "<", "<", "<"])
            L += [""]
        L += [f"  已具备的新思单价（{len(pv['satisfied'])} 项）："
              + ", ".join(r["name"] for r in pv["satisfied"]),
              f"  投放口：{pv['calib_file']} —— 填一项即生效，**不改代码**",
              "  详见 README_LLM.md §13（按新思工具链的四类数据组织，含四个翻转率）。", ""]

    # ---------------- 16. 口径说明 ----------------
    L += ["[16] 口径说明", _hr()]
    for key, title in (("billing_note", "计费"), ("attn_note", "注意力")):
        L += [f"  -- {title} --"]
        L += [f"  {line}" if line else "" for line in rep[key].split("\n")]
    L.append("")
    L += ["  -- 数值 --", f"  {rep['errors']['quantizer']}"]
    L += [f"  往返最大绝对误差 {rep['errors']['roundtrip_max_abs_err']:.5g}"
          f"（相对 {rep['errors']['roundtrip_rel_err']:.3g}）",
          f"  {rep['errors']['legacy_encoder_note']}", ""]

    # ---------------- 17. 容量预算（解析式） ----------------
    cap = rep.get("capacity")
    L += ["[17] 容量预算（解析式，未分配任何数组）", _hr()]
    if cap is None:
        L += ["  （本次报告里没有这一段）", ""]
    else:
        L += [f"  模型 {cap['family']}：L={mdl['layers']} H={mdl['hidden']} "
              f"V={mdl['vocab']:,}，参数量 {cap['params_millions']:,.1f} M"
              + ("" if cap["active_elements_per_token"] == cap["params_elements"]
                 else f"（一个 token 实际读到 "
                      f"{cap['active_elements_per_token'] / 1e6:,.1f} M —— 其余专家没被激活）"),
              f"  容量 {cap['capacity_bytes']:,} B（{cap['capacity_gib']:g} GiB）"
              f"，本次 ctx = {cap['ctx']}（prompt {cap['prompt_tokens']} + 生成 "
              f"{cap['ctx'] - cap['prompt_tokens']}）", ""]
        L += _table(["项", "字节", "占容量", "说明"],
                    [[label, f"{nbytes:,}",
                      f"{100.0 * nbytes / cap['capacity_bytes']:.3f}%", note]
                     for _, label, nbytes, note in _capacity_terms(cap)],
                    aligns=["<", ">", ">", "<"])
        L += [""]
        L += [f"  合计 {cap['total_bytes']:,} B（{_fmt_bytes(cap['total_bytes'])}）"
              f"，占 {cap['used_pct']:.2f}%"
              f" —— {'装得下' if cap['fits'] else '**装不下**'}，余 {cap['free_bytes']:,} B",
              f"  最大 ctx {cap['max_ctx_that_fits']:,}"
              f"（受 {cap['limited_by']} 限制）→ 最大还能生成 {cap['max_gen_tokens']:,} token",
              f"  权重上限 {cap['max_params_that_fits'] / 1e9:.1f} B 参数，"
              "按 RRAM 容量与共享容量余量核算；KV 上限独立受 FeRAM 容量约束",
              f"  宿主侧影子（**不在 die 上**）：口径 {cap['kv_shadow']}，"
              f"{cap['host_shadow_bytes']:,} B（{_fmt_bytes(cap['host_shadow_bytes'])}）",
              "  这一段的数字与 [3] 的 used_bytes **逐字节相等**（同一个 `mx_bytes`，"
              "自检钉住）；容量同时受 RRAM、FeRAM 和共享总上限约束。"]
        L += [f"  告警：{t}" for t in cap["warnings"]]
        L.append("")

    # ---------------- 18. 多模型对照（--compare） ----------------
    cmp = rep.get("compare")
    if cmp is not None:
        L += format_compare(cmp, section=True)

    return "\n".join(L)


def _capacity_terms(cap: dict[str, Any]) -> list[tuple[str, str, int, str]]:
    """把 `capacity.as_dict()` 摊回 `(键, 名字, 字节, 说明)`，顺序即呈现顺序。

    报告里只放纯数据（`Budget` 对象不进 JSON），故这里按 `terms()` 的键序重建；
    键序的权威在 `capacity.Budget.terms()`。
    """
    labels = {"weights": "权重 W", "norms": "归一化 N", "scratch": "便签 S0",
              "act": "激活 A", "kv": "KV K"}
    notes = {
        "weights": "逐层矩阵 + 词表（绑权重只算一份）",
        "norms": "fp32 不量化，4 B/元素",
        "scratch": "Q/K/V 写回缓冲",
        "act": f"层输入（{cap['prompt_tokens']} 个 token）",
        "kv": f"ctx={cap['ctx']}，{cap['kv_bytes_per_token']} B/token",
    }
    return [(k, labels.get(k, k), int(v), notes.get(k, ""))
            for k, v in (cap.get("terms") or {}).items()]


def format_compare(cmp: Any, section: bool = False) -> list[str]:
    """把对照结果排成一张表（返回**行列表**，便于拼进报告）。

    `cmp` 可以是 `compare.compare()` 的原始结果（行是 `CompareRow` 对象），也可以是
    `compare.as_json()` 的结果（行是纯字典，就是报告里存的那一份）—— 后者是唯一的
    呈现路径，前者先转过去，免得两种形态各排一次、日后走样。
    CJK 对齐靠既有的 `_pad` / `_dw`，与报告其余表格同一套。
    """
    from .compare import COLUMNS, as_json

    if cmp["rows"] and not isinstance(cmp["rows"][0], dict):
        cmp = as_json(cmp)
    rows = cmp["rows"]
    L: list[str] = []
    if section:
        L += ["[18] 多模型对照（--compare，每一行都走同一个 run_llm）", _hr()]
    L += [f"  共同规模：prompt {cmp['config']['prompt_tokens']} → 生成 "
          f"{cmp['config']['max_new_tokens']}，计费 {cmp['config']['billing']}，"
          f"MEM die {cmp['config']['mem_die_bytes'] / (1 << 30):g} GiB", ""]
    L += _table([h for _, h, _ in COLUMNS], [r["cells"] for r in rows],
                aligns=["<", "<", ">", ">", "<", "<", "<", ">", ">", ">", ">",
                        ">", ">", ">", ">", ">", ">", ">", "<"])
    L.append("")
    L += [f"  {line}" for line in cmp["notes"]]
    L.append("")
    skip = [r for r in rows if r.get("status") != "ok"]
    if skip:
        L += ["  没跑成的（原因照抄，不静默跳过）："]
        L += [f"    {r['model']}：{r['status']} —— {r['detail']}" for r in skip]
        L.append("")
    ap = cmp.get("approximations") or {}
    if ap:
        L += ["  近似项（只改数值、不改账目的族差异，按语义近似）："]
        for ref, items in ap.items():
            L += [f"    {ref}："] + [f"      - {t}" for t in items]
        L.append("")
    return L


def print_report(rep: dict[str, Any]) -> None:
    print(format_report(rep))
