"""内置族默认表：`model_type` → 一份 `ArchSpec` 预设。

**族 = 一份 spec 预设**，不是子类。HF `config.json` 里凡是**必填**的形状字段
（`hidden_size` / `num_hidden_layers` / `num_attention_heads` / `vocab_size` 等）
由文件给出；族默认表只补那些**经常省略或各版本命名不一**的字段
（`head_dim` / `rms_norm_eps` / `rope_theta` / `tie_word_embeddings` / 各 bias 开关）。

每条预设的 `note` 说明它与 Qwen3 的**账目结构差异**（决策 3：覆盖账目结构差异，
只改数值的细节按语义近似并列进 `approximations`）。
"""
from __future__ import annotations

from dataclasses import replace
from typing import Any

from .spec import ArchSpec, MlaSpec, MlpSpec, MoeSpec, NormSpec, RopeSpec

# --------------------------------------------------------------------------
# 族预设
# --------------------------------------------------------------------------
# 约定：预设只写「与 Qwen3 不同」的字段；其余沿用 `ArchSpec` 的默认值。

_PRESETS: dict[str, dict[str, Any]] = {
    # ---- Qwen 系：结构最接近，几乎是本层的原生族 ----
    "qwen3": {},
    "qwen3_moe": {
        "mlp": MlpSpec(kind="moe", act="silu"),
        "approximations": ("未注入专家路由直方图时按**均匀**路由计（见 routing.py）",),
    },
    "qwen2": {
        "qkv_bias": True, "attention_bias": True,
        "rope_theta": 1e6,
        "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "structure_notes": ("无每 head 的 q_norm / k_norm：该结构不存在，"
                            "相应的张量与 elementwise 一并消失",),
    },
    "qwen2_moe": {
        "qkv_bias": True, "attention_bias": True,
        "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "mlp": MlpSpec(kind="moe", act="silu"),
        "moe": MoeSpec(n_experts=60, top_k=4, moe_intermediate=1408,
                       n_shared_experts=0, first_k_dense_replace=0),
        "structure_notes": ("无 q_norm / k_norm",),
        "approximations": ("未注入路由直方图时按均匀路由计",),
    },
    # ---- Llama 系：结构上与本层几乎同构，只是没有 qk_norm、theta 较小 ----
    "llama": {
        "rope_theta": 1e4,
        "rms_eps": 1e-5, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "structure_notes": ("无 q_norm / k_norm",),
    },
    "mistral": {
        "rope_theta": 1e4,
        "rms_eps": 1e-5, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "default_attn_kind": "sliding", "sliding_window": 4096,
        "structure_notes": ("无 q_norm / k_norm",
                            "全部层用滑窗注意力，pair 数按 `min(ctx, window)` 截断"),
        "approximations": ("整块口径下窗口**不省块**（`M_e ≤ 1024` 都按一整块付），"
                           "滑窗省的是 pair 数而非块数",),
    },
    "mixtral": {
        "rope_theta": 1e6,
        "rms_eps": 1e-5, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "mlp": MlpSpec(kind="moe", act="silu"),
        "moe": MoeSpec(n_experts=8, top_k=2, moe_intermediate=14336,
                       n_shared_experts=0, first_k_dense_replace=0),
        "default_attn_kind": "sliding", "sliding_window": 4096,
        "structure_notes": ("无 q_norm / k_norm",
                            "专家权重名用 `block_sparse_moe.experts.{e}.w{1,2,3}`"
                            "（w1=gate、w3=up、w2=down），在 names.py 里映射"),
        "approximations": ("未注入路由直方图时按均匀路由计",
                           "整块口径下窗口不省块",),
    },
    # ---- Gemma 系：norm 摆放不同、embed 要缩放、有 logit soft-cap、逐层交替滑窗 ----
    "gemma2": {
        "rope_theta": 1e4,
        "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False,
                         post_norm=True, embed_scale=True,
                         attn_logit_softcap=50.0, final_logit_softcap=30.0),
        # gemma-2 的 config.json 写 `hidden_activation: gelu_pytorch_tanh`，
        # 与 gemma-1 同一个激活（GeGLU）；不写默认的 silu。
        "mlp": MlpSpec(kind="gated", act="gelu_tanh"),
        "default_attn_kind": "sliding", "sliding_window": 4096,
        "structure_notes": ("post-norm 摆放：每层 4 个（而非 2 个）归一化向量",
                            "每 2 层一次全注意力：`sliding_window_pattern` 若给了就按它展开，"
                            "没给就按 gemma-2 建模代码里的 `layer_idx % 2` 展开"),
        "approximations": ("attention-logit 与 final-logit soft-capping 按**语义近似**："
                           "记为一次 elementwise，不建模其数值效果",
                           "embed 缩放 sqrt(hidden) 记为一次 elementwise",
                           "整块口径下窗口不省块"),
    },
    "gemma3": {
        "rope_theta": 1e6, "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False,
                                            post_norm=True, embed_scale=True),
        "mlp": MlpSpec(kind="gated", act="gelu_tanh"),
        "default_attn_kind": "sliding", "sliding_window": 1024,
        "structure_notes": ("post-norm 摆放：每层 4 个归一化向量",
                            "每 6 层一次全注意力（`sliding_window_pattern`）"),
        "approximations": ("embed 缩放记为一次 elementwise",
                           "整块口径下窗口不省块"),
    },
    "gemma": {
        "rope_theta": 1e4,
        "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False, embed_scale=True),
        "mlp": MlpSpec(kind="gated", act="gelu_tanh"),
        "approximations": ("GeGLU（gelu_tanh）与 SwiGLU 同构，只有激活函数不同",
                           "embed 缩放记为一次 elementwise"),
    },
    # ---- Phi 系：fused QKV / gate-up（**内存布局是账目结构差异**）、部分旋转 ----
    "phi3": {
        "rope_theta": 1e4,
        "rms_eps": 1e-5, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "rope": RopeSpec(partial_rotary_factor=0.4),
        "fused_qkv": True,
        "mlp": MlpSpec(kind="gated", act="silu", fused_gate_up=True),
        "structure_notes": ("fused QKV（`qkv_proj`）与 fused gate-up（`gate_up_proj`）："
                            "块数按 `ceil((q+2kv)/1024)` 与 `ceil(2I/1024)` 计，"
                            "不等于拆开的三个 / 两个 ceil 之和"),
        "approximations": ("partial_rotary_factor=0.4：只对前 40% 维旋转；"
                           "fused 矩阵的数值切片顺序不建模",),
    },
    "phi": {
        "rope_theta": 1e4,
        "rms_eps": 1e-5, "norm": NormSpec(kind="layernorm", qk_norm=False),
        "mlp": MlpSpec(kind="plain", act="gelu_tanh"),
        "structure_notes": ("LayerNorm 而非 RMSNorm",
                            "FFN 无 gate，只有 `fc1` / `fc2`"),
    },
    # ---- DeepSeek-V2 系：MLA ----
    "deepseek_v2": {
        "rope_theta": 1e4,
        "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "mla": MlaSpec(q_lora_rank=None, kv_lora_rank=512,
                       qk_nope_head_dim=128, qk_rope_head_dim=64, v_head_dim=128),
        "mlp": MlpSpec(kind="moe", act="silu"),
        "moe": MoeSpec(n_experts=64, top_k=6, moe_intermediate=1536,
                       n_shared_experts=2, first_k_dense_replace=1),
        "structure_notes": ("MLA：KV cache 只存压缩后的 (c_kv, k_rope)，"
                            "`(L, 2, kv_heads, ctx, head_dim)` → "
                            "`(L, ctx, kv_lora_rank + qk_rope_head_dim)`",
                            "每层 4 个归一化向量：2 个子层 norm + `q_a_layernorm`"
                            "（若有 `q_lora_rank`）+ `kv_a_layernorm`"),
        "approximations": ("MLA 对历史 token 用吸收式还是展开式不建模（只影响数值）",
                           "未注入路由直方图时按均匀路由计"),
    },
    "deepseek_v3": {
        "rope_theta": 1e4,
        "rms_eps": 1e-6, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "mla": MlaSpec(q_lora_rank=1536, kv_lora_rank=512,
                       qk_nope_head_dim=128, qk_rope_head_dim=64, v_head_dim=128),
        "mlp": MlpSpec(kind="moe", act="silu"),
        "moe": MoeSpec(n_experts=256, top_k=8, moe_intermediate=2048,
                       n_shared_experts=1, first_k_dense_replace=3),
        "structure_notes": ("同 DeepSeek-V2 的 MLA 与逐层 norm 结构",),
        "approximations": ("MLA 对历史 token 用吸收式还是展开式不建模",
                           "不含 MTP 附加层（只仿真主干的 decoder 层）",
                           "未注入路由直方图时按均匀路由计"),
    },
    # ---- OLMoE：小 MoE，权重名与 Qwen-MoE 同形 ----
    "olmoe": {
        "rope_theta": 1e4,
        "rms_eps": 1e-5, "norm": NormSpec(kind="rmsnorm", qk_norm=False),
        "mlp": MlpSpec(kind="moe", act="silu"),
        "moe": MoeSpec(n_experts=64, top_k=8, moe_intermediate=1024,
                       n_shared_experts=0, first_k_dense_replace=0),
        "structure_notes": ("无 q_norm / k_norm",),
        "approximations": ("未注入路由直方图时按均匀路由计",),
    },
}

# 别名：HF 的 `model_type` 与常见写法都收
_ALIASES: dict[str, str] = {
    "qwen3moe": "qwen3_moe",
    "qwen2moe": "qwen2_moe",
    "qwen2.5": "qwen2",
    "llama3": "llama",
    "phi3small": "phi3",
    "phimoe": "phi3",
    "deepseekv2": "deepseek_v2",
    "deepseekv3": "deepseek_v3",
    "deepseek_v2_lite": "deepseek_v2",
    "gemma2": "gemma2",
    "gemma3_text": "gemma3",
    "olmo": "olmoe",
}


def alternating_kinds(layers: int, period: int) -> tuple[str, ...]:
    """逐层交替的注意力种类：每 `period` 层一次全注意力，其余滑窗。

    与 `hf.py` 展开 `sliding_window_pattern` 的规则**同一处定义**（同一条式子），
    所以动物园条目与真实 config.json 走的是同一条路径，不会各写一遍而分歧。
    """
    if period < 1:
        raise ValueError(f"period 必须 >= 1，得到 {period}")
    return tuple("full" if (i + 1) % period == 0 else "sliding" for i in range(layers))


def family_names() -> list[str]:
    """已知的族名（已排序，供 `--list-models` 与错误提示用）。"""
    return sorted(_PRESETS)


def normalize_family(name: str) -> str:
    """把 `model_type` / 别名 / `--family` 的写法归一到一个族名。"""
    k = (name or "").strip().lower().replace("-", "_")
    if k in _PRESETS:
        return k
    if k in _ALIASES:
        return _ALIASES[k]
    # 退一步：去掉下划线再比一次（"qwen2_moe" / "qwen2moe" 都落到同一处）
    k2 = k.replace("_", "")
    for cand in _PRESETS:
        if cand.replace("_", "") == k2:
            return cand
    for alias, target in _ALIASES.items():
        if alias.replace("_", "") == k2:
            return target
    raise KeyError(f"未知的架构族：{name!r}。已知族：{', '.join(family_names())}")


def preset(family: str) -> ArchSpec:
    """取某族的预设 `ArchSpec`（**只有族默认值，形状还是 Qwen3 的默认形状**）。"""
    fam = normalize_family(family)
    base = ArchSpec(family=fam, source=f"builtin:{fam}")
    return replace(base, **_PRESETS[fam])


def compose(family: str, explicit: dict[str, Any], source: str = "") -> ArchSpec:
    """`preset(family)` 打底，`explicit`（来自 `config.json` 的**显式值**）逐个覆盖上去。

    **优先级：文件 > 族预设 > `ArchSpec` 默认。** 顺序不能反 —— 族预设只补
    「文件没给」的字段（`head_dim` / `rms_norm_eps` / `rope_theta` / 各 bias 开关
    这些经常省略或各版本命名不一的东西）。若让预设反过来覆盖文件，
    一个换过 `rope_theta` 的微调 checkpoint 会被静默改回族默认值。
    """
    fam = normalize_family(family)
    spec = replace(preset(fam), **explicit)
    return replace(spec, source=source or f"builtin:{fam}")


# --------------------------------------------------------------------------
# 模型动物园：`--model <名字>` 与 `--list-models` 的条目
# --------------------------------------------------------------------------
# 每条只写**形状与族**，其余走族预设。名字里带规模是为了让人一眼看懂量级。
#
# 每条都写死 `tie_embeddings`：**同一个族内并不统一**（Qwen3-0.6B/1.7B/4B 绑权重而
# 8B/14B/32B 不绑；Llama-3.2-1B/3B 绑而 3.1-8B/70B 不绑；Qwen2.5 的 1.5B/3B 绑而
# 7B 起不绑），所以它只能是**逐 checkpoint** 的事实，不能由族预设给。漏写一条会
# 少算一个 `vocab × hidden` 矩阵 —— 8B 级约 0.8 GB，不是舍入误差。
#
# **来源与限度**：这些形状与绑权重开关取自各 checkpoint 的**公开 config.json**，
# 在本环境（无网络）**无法复验**。它们是量级对准的起点而非权威值：任何定量结论都要
# 用 `--model path/to/config.json` 读真实文件复核，那才是权威来源（文件 > 族预设）。
_ZOO: dict[str, dict[str, Any]] = {
    # ---- Qwen3：0.6B/1.7B/4B 绑权重，8B 起不绑 ----
    "qwen3-0.6b": dict(family="qwen3", hidden=1024, layers=28, q_heads=16, kv_heads=8,
                       head_dim=128, intermediate=3072, vocab=151936),
    "qwen3-1.7b": dict(family="qwen3", hidden=2048, layers=28, q_heads=16, kv_heads=8,
                       head_dim=128, intermediate=6144, vocab=151936),
    "qwen3-4b": dict(family="qwen3", hidden=2560, layers=36, q_heads=32, kv_heads=8,
                     head_dim=128, intermediate=9728, vocab=151936),
    "qwen3-8b": dict(family="qwen3", hidden=4096, layers=36, q_heads=32, kv_heads=8,
                     head_dim=128, intermediate=12288, vocab=151936, tie_embeddings=False),
    "qwen3-14b": dict(family="qwen3", hidden=5120, layers=40, q_heads=40, kv_heads=8,
                      head_dim=128, intermediate=17408, vocab=151936, tie_embeddings=False),
    "qwen3-32b": dict(family="qwen3", hidden=5120, layers=64, q_heads=64, kv_heads=8,
                      head_dim=128, intermediate=25600, vocab=151936, tie_embeddings=False),
    # ---- Qwen2.5：1.5B/3B 绑权重，7B/14B 不绑 ----
    "qwen2.5-1.5b": dict(family="qwen2", hidden=1536, layers=28, q_heads=12, kv_heads=2,
                         head_dim=128, intermediate=8960, vocab=151936),
    "qwen2.5-3b": dict(family="qwen2", hidden=2048, layers=36, q_heads=16, kv_heads=2,
                       head_dim=128, intermediate=11008, vocab=151936),
    "qwen2.5-7b": dict(family="qwen2", hidden=3584, layers=28, q_heads=28, kv_heads=4,
                       head_dim=128, intermediate=18944, vocab=152064,
                       tie_embeddings=False),
    "qwen2.5-14b": dict(family="qwen2", hidden=5120, layers=48, q_heads=40, kv_heads=8,
                        head_dim=128, intermediate=13824, vocab=152064,
                        tie_embeddings=False),
    # Qwen1.5-MoE：`shared_expert_intermediate_size` 就是**那一个**共享专家的宽度
    # （HF 的 `Qwen2MoeSparseMoeBlock` 只有一个 `shared_expert`），故 n_shared=1。
    "qwen2-moe-2.7b": dict(family="qwen2_moe", hidden=2048, layers=24, q_heads=16,
                           kv_heads=2, head_dim=128, intermediate=5632, vocab=151936,
                           tie_embeddings=False,
                           moe=MoeSpec(n_experts=60, top_k=4, moe_intermediate=1408,
                                       n_shared_experts=1, shared_intermediate=5632,
                                       first_k_dense_replace=0),
                           mlp=MlpSpec(kind="moe", act="silu")),
    # ---- Llama：3.2 的 1B/3B 绑权重，3.1 起不绑 ----
    "llama-3.2-1b": dict(family="llama", hidden=2048, layers=16, q_heads=32, kv_heads=8,
                         head_dim=64, intermediate=8192, vocab=128256, max_position=131072),
    "llama-3.2-3b": dict(family="llama", hidden=3072, layers=28, q_heads=24, kv_heads=8,
                         head_dim=128, intermediate=8192, vocab=128256, max_position=131072),
    "llama-3.1-8b": dict(family="llama", hidden=4096, layers=32, q_heads=32, kv_heads=8,
                         head_dim=128, intermediate=14336, vocab=128256, max_position=131072,
                         tie_embeddings=False),
    "llama-3.1-70b": dict(family="llama", hidden=8192, layers=80, q_heads=64, kv_heads=8,
                          head_dim=128, intermediate=28672, vocab=128256,
                          max_position=131072, tie_embeddings=False),
    # ---- Mistral / Mixtral：v0.3 起不绑权重 ----
    "mistral-7b-v0.3": dict(family="mistral", hidden=4096, layers=32, q_heads=32,
                            kv_heads=8, head_dim=128, intermediate=14336, vocab=32768,
                            max_position=32768, sliding_window=4096,
                            tie_embeddings=False),
    "mixtral-8x7b": dict(family="mixtral", hidden=4096, layers=32, q_heads=32, kv_heads=8,
                         head_dim=128, intermediate=14336, vocab=32000, max_position=32768,
                         sliding_window=4096, tie_embeddings=False,
                         moe=MoeSpec(n_experts=8, top_k=2, moe_intermediate=14336,
                                     first_k_dense_replace=0),
                         mlp=MlpSpec(kind="moe", act="silu")),
    # ---- Gemma：绑权重 ----
    "gemma-2-2b": dict(family="gemma2", hidden=2304, layers=26, q_heads=8, kv_heads=4,
                       head_dim=256, intermediate=9216, vocab=256000, max_position=8192,
                       sliding_window=4096, layer_attn_kinds=alternating_kinds(26, 2)),
    "gemma-2-9b": dict(family="gemma2", hidden=3584, layers=42, q_heads=16, kv_heads=8,
                       head_dim=256, intermediate=14336, vocab=256000, max_position=8192,
                       sliding_window=4096, layer_attn_kinds=alternating_kinds(42, 2)),
    "gemma-3-4b": dict(family="gemma3", hidden=2560, layers=34, q_heads=8, kv_heads=4,
                       head_dim=256, intermediate=10240, vocab=262144, max_position=131072,
                       sliding_window=1024, layer_attn_kinds=alternating_kinds(34, 6)),
    # ---- Phi-3 / DeepSeek / OLMoE：均不绑权重 ----
    "phi-3-mini": dict(family="phi3", hidden=3072, layers=32, q_heads=32, kv_heads=32,
                       head_dim=96, intermediate=8192, vocab=32064, max_position=4096,
                       tie_embeddings=False),
    "deepseek-v2-lite": dict(family="deepseek_v2", hidden=2048, layers=27, q_heads=16,
                             kv_heads=16, head_dim=128, intermediate=10944, vocab=102400,
                             max_position=163840, tie_embeddings=False,
                             initializer_range=0.006,
                             mla=MlaSpec(q_lora_rank=None, kv_lora_rank=512,
                                         qk_nope_head_dim=128, qk_rope_head_dim=64,
                                         v_head_dim=128),
                             moe=MoeSpec(n_experts=64, top_k=6, moe_intermediate=1408,
                                         n_shared_experts=2, first_k_dense_replace=1),
                             mlp=MlpSpec(kind="moe", act="silu")),
    "olmoe-1b-7b": dict(family="olmoe", hidden=2048, layers=16, q_heads=16, kv_heads=16,
                        head_dim=128, intermediate=8192, vocab=50304, max_position=4096,
                        tie_embeddings=False,
                        moe=MoeSpec(n_experts=64, top_k=8, moe_intermediate=1024,
                                    first_k_dense_replace=0),
                        mlp=MlpSpec(kind="moe", act="silu")),
}


def zoo_names() -> list[str]:
    """动物园里的模型名（已排序）。"""
    return sorted(_ZOO)


def zoo_entry(name: str) -> ArchSpec:
    """取动物园里某个模型的 `ArchSpec`。名字不认就列出可选项。"""
    key = (name or "").strip().lower()
    if key not in _ZOO:
        raise KeyError(f"动物园里没有 {name!r}。可选项：{', '.join(zoo_names())}")
    kw = dict(_ZOO[key])
    fam = kw.pop("family")
    return compose(fam, kw, source=f"zoo:{key}")

