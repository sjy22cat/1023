"""LLM 推理仿真的配置与单价快照。

**单价一律来自现有数据集**（`yrr_v3.rtl_dataset.V3Datasheet`），本文件不新造任何单价，
只做「取出来、放在一起、标明出处」。
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Literal

GIB = 1 << 30

# SIM-1017 的固定阵列契约，加载实测文件时另行核对。
ARRAY_M = 1024   # 阵列输出行数（= 常驻权重矩阵的行数）
ARRAY_K = 1024   # 阵列 K 维宽度（= 输入向量长度）


@dataclass
class LlmConfig:
    """一次 LLM 推理仿真的全部旋钮。"""

    # ---------------- 计算核（logic die 上的近存加速器） ----------------
    # core 是完整阵列，不是 MC。LLM 当前按单 core 串行聚合记账。
    cores: int = 1

    # ---------------- MEM die（与 logic die 配对的那颗） ----------------
    mem_die_bytes: int = 16 * GIB
    mem_die_count: int = 1
    # RRAM / FeRAM capacities are supplied by RTL calibration. None means the
    # per-medium limit is unknown; mem_die_bytes remains the aggregate limit.
    rram_capacity_bytes: int | None = None
    feram_capacity_bytes: int | None = None

    # ---------------- 推理规模 ----------------
    prompt_tokens: int = 128        # 上下文输入 token 数
    max_new_tokens: int = 1024      # 输出 token 数
    n_runs: int = 1                 # 推理次数（本次 1 次）

    # ---------------- 量化：MXFP4，做到 W4A4 ----------------
    w_bits: int = 4
    a_bits: int = 4
    group_size: int = 32            # MXFP4 的 E8M0 共享指数粒度
    quantize_activations: bool = True   # False 则退化成 W4A16（仅供对照/调试）

    # ---------------- 计费口径 ----------------
    #   "whole_block" —— 每个 ≤1024×≤1024 的块都按**一整块 [1024,1024]×[1024,1024]
    #                    的乘加开销**计（阵列整块占用，不看实际利用率）。本次口径。
    #   "unit"        —— 对照口径：乘加按**实际 MAC 数**× pe_mac_pj 计。
    #   两者在同一个 run 里同时算出来并列，切块次数（= 阵列占用次数）对两者都一样。
    billing: Literal["whole_block", "unit"] = "whole_block"
    # 每 channel payload 宽度，正式入口必须匹配实测契约的 128 bit。
    phy_bpc: int = 128

    # ---------------- 权重来源 ----------------
    weights: str | None = None      # 指向 safetensors 目录；None = 模拟器内生成
    #   "full" —— 反量化后的 fp32 数值影子常驻（快；约 2.4 GB 主机内存）
    #   "none" —— 只留 MXFP4 码值，每次读 MEM 现场反量化（省内存、慢很多）
    weight_cache: Literal["full", "none"] = "full"
    seed: int = 1

    # ---------------- 宿主侧 KV 影子 ----------------
    #   "fp32"     —— 反量化后的 fp32 影子常驻（**今天的行为，逐位不变**）
    #   "codebook" —— 只存 (payload, scale)，按需反量化（逐位等价，省 8 倍）
    #   "none"     —— 完全不分配（形状驱动模式专用：数值从不被读）
    # 它**不在** MEM die 的账上，但 20B/长上下文下是十几 GB，是真瓶颈（见 capacity.py）。
    kv_shadow: Literal["fp32", "codebook", "none"] = "fp32"

    # ---------------- 前向模式（形状切换的核心开关） ----------------
    #   "auto"    —— 按模型规模自动判（默认；Qwen3-0.6B 判到 numeric，今天的行为不变）
    #   "numeric" —— 真算矩阵乘（数值可用，慢）
    #   "shape"   —— 只走形状与计费，数值一律跳过（账目是形状的纯函数，故账目逐位不变）
    # 判据见 capacity.resolve_forward / forward_note。
    forward: Literal["auto", "numeric", "shape"] = "auto"

    # ---------------- 模型形状与架构族 ----------------
    # 由 run_llm.py 的 `--model` / `--family` 解析后放进来（ArchSpec 实例）。
    # None = 按 Qwen3-0.6B 的既有形状（`model` 覆盖优先，见 inference._spec）。
    model_spec: Any = None

    # ---------------- MoE 路由 ----------------
    # None = 均匀（默认）；路径 = 读直方图投放口；"" = 明确按均匀处理。
    # 第三段实现，这里先把旋钮与合法性检查摆好。
    moe_routing: str | None = None

    # ---------------- 采样与分词 ----------------
    temperature: float = 0.0        # 0 = 贪心
    sample_seed: int = 0
    tokenizer: str | None = None    # 真实 Qwen BPE 目录；None = 可逆占位分词器

    # ---------------- 单价标定（新思数据投放口） ----------------
    # 已废弃的 flat calibration 字段，仅允许测试注入价格时使用。
    calib_path: str | None = None
    # Unified Synopsys measured JSON contract.  It contains structure, timing,
    # traffic, energy and area; no inferred/fallback values are accepted.
    rtl_1017_calibration_path: str | None = None

    # Independent optional calibration; existing collected prices stay unchanged.
    attention_impl: Literal["unfused", "fused_16x4"] = "unfused"
    attention_calibration_path: str | None = None

    # ---------------- 诊断开关 ----------------
    trace_limit: int = 4096         # trace 行数上限
    collect_trace: bool = True

    # ---------------- 省事的小配置（冒烟用；不改 Qwen3 的代码路径） ----------------
    model: "ModelOverride | None" = None

    def validate(self) -> None:
        if self.attention_impl not in ("unfused", "fused_16x4"):
            raise ValueError("attention_impl must be unfused / fused_16x4")
        if self.attention_impl == "fused_16x4" and not self.attention_calibration_path:
            raise ValueError("fused_16x4 requires attention_calibration_path / --attention-calibration")
        if self.cores < 1:
            raise ValueError("cores must be >= 1")
        if self.mem_die_count < 1:
            raise ValueError("mem_die_count must be >= 1")
        if self.mem_die_bytes <= 0:
            raise ValueError("mem_die_bytes must be positive")
        for name in ("rram_capacity_bytes", "feram_capacity_bytes"):
            value = getattr(self, name)
            if value is not None and value <= 0:
                raise ValueError(f"{name} must be positive when configured")
        if self.prompt_tokens < 1 or self.max_new_tokens < 0:
            raise ValueError("prompt_tokens >= 1 且 max_new_tokens >= 0")
        if self.n_runs < 1:
            raise ValueError("n_runs must be >= 1")
        if self.w_bits != 4 or self.a_bits != 4:
            raise ValueError("本模型按 MXFP4 W4A4 建模：w_bits = a_bits = 4")
        if self.group_size != 32:
            raise ValueError("MXFP4 的共享指数粒度固定为 32 个元素")
        if self.phy_bpc < 1:
            raise ValueError("phy_bpc must be >= 1")
        if self.kv_shadow not in ("fp32", "codebook", "none"):
            raise ValueError("kv_shadow 只能是 fp32 / codebook / none，"
                             f"得到 {self.kv_shadow!r}")
        if self.billing not in ("whole_block", "unit"):
            raise ValueError("billing must be whole_block or unit")
        if self.forward not in ("auto", "numeric", "shape"):
            raise ValueError("forward 只能是 auto / numeric / shape，"
                             f"得到 {self.forward!r}")
        if self.weight_cache not in ("full", "none"):
            raise ValueError("weight_cache 只能是 full / none，"
                             f"得到 {self.weight_cache!r}")
        if self.calib_path is not None and not isinstance(self.calib_path, str):
            raise ValueError("calib_path 只能是 None / \"\" / 路径字符串")
        if (self.rtl_1017_calibration_path is not None and
                not isinstance(self.rtl_1017_calibration_path, str)):
            raise ValueError("rtl_1017_calibration_path 只能是 None / 路径字符串")


@dataclass
class ModelOverride:
    """只用于冒烟/自检的极小模型形状；默认 None 表示按 Qwen3-0.6B 的真实形状。"""

    hidden: int = 1024
    layers: int = 28
    heads: int = 16
    kv_heads: int = 8
    head_dim: int = 128
    intermediate: int = 3072
    vocab: int = 151936


@dataclass(frozen=True)
class LlmPrices:
    """本次仿真用到的**全部单价**，逐条标明数据集出处。

    单位约定（与现有模型一致）：
      * `*_pj`        —— pJ
      * `*_ns`        —— ns
      * `*_cycles`    —— 拍（1 拍 = clock_ns）
      * `*_per_128b`  —— 每次 128 bit 访问
    """

    # ---- 单位块：权重驻留的一次满阵列 GEMV（batch=1）----
    block_pj: float                 # 一次内部满阵列 GEMV，权重已装载、无 Host/softmax
    block_cycles: int               # 同一内部 GEMV 的架构周期
    macs_per_block: int             # 1024²
    block_pj_by_mac: float          # 对照口径：同一个块的乘加按实际 MAC 计 = macs × pe_mac_pj

    # ---- 单元单价 ----
    pe_mac_pj: float
    reduction_add_pj: float         # 一次累加/归约加法活动

    gsram_read_pj_per_128b: float
    gsram_write_pj_per_128b: float
    tile_reg_write_pj_per_bit: float
    leakage_pj_per_cycle: float

    # ---- MEM die：外部 array 表征结果 ----
    mem_rd_pj_per_128b: float
    mem_wr_pj_per_128b: float
    mem_rd_ns: float
    mem_wr_ns: float

    # ---- PHY + Hybrid Bonding：外部 IP 表征结果 ----
    phy_pj_per_bit: float
    phy_ps_per_bit: float           # 旧名；实际单位为 ps / phy_bpc-bit payload beat
    hb_latency_ns: float
    phy_bpc: int

    # ---- 时钟 ----
    clock_ns: float
    f_max_mhz: float

    # ---- 出处（逐字段）----
    provenance: dict[str, str] = field(default_factory=dict)

    # FeRAM array prices await RTL / calibration data. Missing values are
    # reported as pending and are never substituted with RRAM prices.
    feram_rd_pj_per_128b: float | None = None
    feram_wr_pj_per_128b: float | None = None
    feram_rd_ns: float | None = None
    feram_wr_ns: float | None = None

    nonmac: dict = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        d = {k: v for k, v in self.__dict__.items() if k != "provenance"}
        d["provenance"] = dict(self.provenance)
        return d


# --------------------------------------------------------------------------
# 从实测参数包取配置和单价（只读）
# --------------------------------------------------------------------------

def bind_hardware_config(cfg: LlmConfig) -> LlmConfig:
    """Bind measured capacities before any CLI/compare capacity decision."""
    from ..rtl_dataset import load_1017_calibration
    if cfg.calib_path:
        raise ValueError("calib_path is retired; use rtl_1017_calibration_path / --parameters")
    raw = load_1017_calibration(cfg.rtl_1017_calibration_path)
    return replace(cfg, **raw["llm_hardware"])


def prices_from_dataset(dataset=None, phy_bpc: int = 128, force: bool = False) -> LlmPrices:
    """Load LLM event/block prices directly from Synopsys results.

    No architectural run, RTL parsing, gate count or cost fallback occurs here.
    Only unit conversion (MHz/ns) and MAC-count multiplication are performed.
    ``force`` is retained as a compatibility argument; values are not cached.
    """
    from ..rtl_dataset import V3Datasheet
    ds = dataset if dataset is not None else V3Datasheet.from_1017_calibration()
    raw = dict(ds.rtl_params["llm_prices"])
    if phy_bpc != raw["phy_bpc"]:
        raise ValueError("phy_bpc must match the characterized per-channel payload width")
    raw["nonmac"] = ds.nonmac_parallel or ds.rtl_params.get("nonmac", {})
    raw["f_max_mhz"] = 1000.0 / raw["clock_ns"]
    raw["block_pj_by_mac"] = raw["macs_per_block"] * raw["pe_mac_pj"]
    raw["provenance"] = {k: f"measured:{ds.source_path}#llm_prices.{k}" for k in raw}
    raw["provenance"]["nonmac"] = f"measured:{ds.source_path}#nonmac"
    if ds.nonmac_parallel:
        raw["provenance"]["nonmac"] = "user-supplied architectural estimate:"+ds.nonmac_parallel["source"]
    if not ds.production:
        raw["provenance"] = {k: "test-fixture:synthetic prices" for k in raw}
    return LlmPrices(**raw)
