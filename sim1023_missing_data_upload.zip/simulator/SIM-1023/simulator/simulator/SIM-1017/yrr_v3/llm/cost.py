"""成本原语：把「一次矩阵计算 / 一次搬运 / 一次轻量级算子」折算成**拍**与 **pJ**。

单价一律取自现有数据集（`LlmPrices`，字段上有 provenance），本文件**不新造任何单价**。

三条口径（全部写进 README_LLM.md 与报告里的 `billing_note`）：

1. **单位块**：一次内部满阵列 GEMV，权重已装载、不含 Host/DMA 和 softmax。
   调度器按 token / Attention pair 逐次调用，不足满阵列也按整块占用计费；
   超过 1024 的维度切块串行执行，K 向 partial 另做累加。
2. **两种计费并列**：`whole_block`（上述，本次口径）与 `unit`（乘加按**实际 MAC 数**
   计）。同一个 run 里两个数都算出来，让小形状的阵列浪费可见。
3. Non-MAC commands use exact measured operator/length profiles, including scratch.

"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Iterable, Literal

from .config import LlmPrices
from ..nonmac import NonmacCost, command_cost

BLOCK = 1024             # 阵列的一个整块边长（行 / 列 / K 都是它）
LINE_BYTES = 16          # MEM die 的一次访问 = 128 bit = 16 B
PHY_PS_PER_BIT = 625.0   # 数据集的字面值（见 LlmPrices.phy_ps_per_bit）


def ceil_div(a: int, b: int) -> int:
    return -(-int(a) // int(b))


def blocks(M: int, N: int, K: int) -> tuple[int, int, int, int]:
    """切块规则（用户给定）：超过 1024 的维才切。

    返回 `(bm, bn, bk, 总块数)`；`总块数 = bm * bn * bk`。

    例：`[1024,2048] x [2048,1024]`（M=1024,N=1024,K=2048）→ k 切 2 → 2 块 + 1 次累加；
        `[1,1024] x [1024,2048]`（M=1,N=2048,K=1024）  → n 切 2 → 2 块（M=1 也按整块付费）；
        `[1,1024] x [1024,1024]`                        → 1 块。
    """
    bm, bn, bk = ceil_div(M, BLOCK), ceil_div(N, BLOCK), ceil_div(K, BLOCK)
    return bm, bn, bk, bm * bn * bk


# --------------------------------------------------------------------------
# 原语返回结构
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class MatmulCost:
    """一次矩阵计算的账。`whole_pj` 是本次口径，`unit_pj` 是对照口径。"""
    M: int
    N: int
    K: int
    bm: int
    bn: int
    bk: int
    n_blocks: int
    macs: int
    rounds: int               # 本次**实际计入**的 K 向累加轮数（默认 bk-1）
    blocks_pj: float          # 块数 x 单位块能耗（整块占用）
    accum_whole_pj: float     # 累加的整块口径
    accum_unit_pj: float      # 累加的对照口径
    whole_pj: float           # = blocks_pj + accum_whole_pj
    unit_pj: float            # = macs x pe_mac_pj + accum_unit_pj
    cycles: int               # 块数 x 单位块拍数 + rounds 次累加

    @property
    def accum_rounds(self) -> int:
        """本次计入的累加轮数 —— 即字段 `rounds`（保留旧名，读法不变）。"""
        return self.rounds

    def scaled(self, n: int) -> "MatmulCost":
        """把一次计算的账乘以 `n`（= 同样的计算重复 `n` 次，逐次串行）。

        用途：注意力要按 `(query, key)` pair 记 ~4.7 亿次账，逐次调 Python 太慢，
        所以先算一次单价再整体放大。**放大后的 `M/N/K/bm/bn/bk` 保持单次的形状**，
        只有累计量（块数、MAC、能耗、拍数）乘了 `n`。`rounds` 是**单次**的属性，
        不随 `n` 放大（累加量已在 `accum_*_pj` 里乘过）。
        """
        if n == 1:
            return self
        return MatmulCost(
            M=self.M, N=self.N, K=self.K, bm=self.bm, bn=self.bn, bk=self.bk,
            n_blocks=self.n_blocks * n, macs=self.macs * n, rounds=self.rounds,
            blocks_pj=self.blocks_pj * n,
            accum_whole_pj=self.accum_whole_pj * n,
            accum_unit_pj=self.accum_unit_pj * n,
            whole_pj=self.whole_pj * n, unit_pj=self.unit_pj * n,
            cycles=self.cycles * n,
        )


ElementwiseCost = NonmacCost


@dataclass(frozen=True)
class Transfer:
    """一次搬运：MEM die 阵列 / PHY 跨 Die / Hybrid Bonding / 逻辑 Die 上 GSRAM 中转。

    四段**分开记**，这样「PHY 位串行单价把总量顶起来」这件事是可归因的，而不是一个黑盒大数。
    """
    kind: str                 # "mem_read" | "mem_write" | "gsram_read" | "gsram_write" | ...
    nbytes: int
    accesses_128b: int
    mem_pj: float
    phy_pj: float
    gsram_pj: float
    regfile_pj: float
    mem_ns: float
    phy_ns: float
    hb_ns: float
    cycles: int
    medium: Literal["rram", "feram"] | None = "rram"
    pending_components: tuple[str, ...] = ()
    origin: str | None = None
    phy_traversed: bool = False
    gsram_traversed: bool = False

    @property
    def pj(self) -> float:
        return self.mem_pj + self.phy_pj + self.gsram_pj + self.regfile_pj

    @property
    def ns(self) -> float:
        return self.mem_ns + self.phy_ns + self.hb_ns


# --------------------------------------------------------------------------
# 单价容器
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Cost:
    """把 `LlmPrices` 预热成常数：单位块的能耗/拍数在这里一次算清。"""
    pr: LlmPrices

    # ---- 单位块：一次全阵列 GEMV；Host I/O / 装载 / softmax 分别计账 ----
    block_pj: float
    block_cycles: int
    macs_per_block: int
    block_unit_pj: float      # 对照口径下**一个满块**的价：MACs x pe_mac_pj + m 次归约

    @classmethod
    def from_prices(cls, pr: LlmPrices) -> "Cost":
        # The price is already for a warm, host-free, softmax-free GEMV.
        # Subtracting the archived 1024x1024 softmax price here could make it
        # negative, and would conflict with separately billed Attention ops.
        macs = pr.macs_per_block
        return cls(
            pr=pr,
            block_pj=pr.block_pj,
            block_cycles=pr.block_cycles,
            macs_per_block=macs,
            block_unit_pj=macs * pr.pe_mac_pj + BLOCK * pr.reduction_add_pj,
        )

    # ---------------- 矩阵计算 ----------------

    def matmul(self, M: int, N: int, K: int,
               billing: Literal["whole_block", "unit"] = "whole_block",
               accum_rounds: int | None = None) -> MatmulCost:
        """按 `blocks()` 切块 + 累加。

        * **能耗**
          - `whole_block`：`块数 x 单位块能耗 + 累加`。`M/N/K` 不足 1024 也按一整块付。
          - `unit`：`M x N x K x pe_mac_pj + 累加`。切块只影响串行次数与访存。
        * **累加**：每输出行一次「完整归约」（与现有模型 `red_units = tile_rows x
          pe_per_tile` 同一个约定），默认共 `bk - 1` 轮。
          - 整块口径：阵列整块被占用 → 参与归约的行数 = `bm x 1024`。
          - 对照口径：只有真实的 `M` 行在动。
        * **`accum_rounds` 覆盖**：调用方若已经**自己把 K 维切开**、逐块调用本函数，
          那么每块传进来的 `K` 都只有一个块（`bk == 1`，默认轮数为 0），真正的 K 向
          累加发生在**块与块之间**。此时必须由调用方在**最后一个 K 块**上把 `bk - 1`
          一次记清；否则累加能耗与累加拍数会整段漏掉。中间的块传 0。
          （不传则保持原语义 `bk - 1`，逐块调用之外的调用点一律不受影响。）
        """
        bm, bn, bk, nb = blocks(M, N, K)
        rounds = (bk - 1) if accum_rounds is None else int(accum_rounds)
        if rounds < 0:
            raise ValueError(f"accum_rounds 不能为负：{rounds}")
        accum_whole = rounds * (bm * BLOCK) * self.pr.reduction_add_pj
        accum_unit = rounds * M * self.pr.reduction_add_pj
        macs = M * N * K
        # 累加本身也要占归约树：每轮 1 拍（阵列占用账里 reduce_tree = 1 拍）
        cycles = nb * self.block_cycles + rounds
        return MatmulCost(
            M=M, N=N, K=K, bm=bm, bn=bn, bk=bk, n_blocks=nb, macs=macs, rounds=rounds,
            blocks_pj=nb * self.block_pj,
            accum_whole_pj=accum_whole, accum_unit_pj=accum_unit,
            whole_pj=nb * self.block_pj + accum_whole,
            unit_pj=macs * self.pr.pe_mac_pj + accum_unit,
            cycles=cycles,
        )

    # ---------------- 轻量级算子 ----------------

    def elementwise(self, op: str, length: int, rows: int = 1) -> NonmacCost:
        return command_cost(self.pr.nonmac, op, length, rows)

    def _phy(self, nbytes: int, phy_bpc: int | None = None) -> tuple[float, float, float]:
        """PHY 跨 Die + Hybrid Bonding。返回 `(phy_pj, phy_ns, hb_ns)`。"""
        bits = nbytes * 8
        bpc = self.pr.phy_bpc if phy_bpc is None else phy_bpc
        phy_ns = (bits / bpc) * self.pr.phy_ps_per_bit / 1000.0   # ps -> ns
        return bits * self.pr.phy_pj_per_bit, phy_ns, self.pr.hb_latency_ns

    def _mem(self, nbytes: int, write: bool, medium: str = "rram"
             ) -> tuple[int, float, float, tuple[str, ...]]:
        acc = ceil_div(nbytes, LINE_BYTES)
        if medium == "rram":
            pj = self.pr.mem_wr_pj_per_128b if write else self.pr.mem_rd_pj_per_128b
            ns = self.pr.mem_wr_ns if write else self.pr.mem_rd_ns
            return acc, acc * pj, acc * ns, ()
        if medium != "feram":
            raise ValueError(f"unknown memory medium {medium!r}")
        pj_unit = self.pr.feram_wr_pj_per_128b if write else self.pr.feram_rd_pj_per_128b
        ns_unit = self.pr.feram_wr_ns if write else self.pr.feram_rd_ns
        pending: list[str] = []
        if pj_unit is None:
            pj_unit = 0.0
            pending.append("feram_array_energy")
        if ns_unit is None:
            ns_unit = 0.0
            pending.append("feram_array_latency")
        return acc, acc * pj_unit, acc * ns_unit, tuple(pending)

    def _gsram(self, nbytes: int, write: bool) -> tuple[float, int]:
        acc = ceil_div(nbytes, LINE_BYTES)
        unit = self.pr.gsram_write_pj_per_128b if write else self.pr.gsram_read_pj_per_128b
        return acc * unit, acc

    def mem_read(self, nbytes: int, *, via_phy: bool = True,
                 phy_bpc: int | None = None, gsram: bool = True,
                 regfile: bool = False, medium: Literal["rram", "feram"] = "rram",
                 origin: str | None = None) -> Transfer:
        """从 MEM die 读一段数据到逻辑 Die。

        分段开关让调用方按真实数据流选择：例如「权重装载」= MEM + PHY + GSRAM + 寄存器堆；
        「中间结果回读」= MEM + PHY + GSRAM（不写寄存器堆）；纯 GSRAM 中转则两者都关。
        """
        acc, mem_pj, mem_ns, pending = self._mem(nbytes, write=False, medium=medium)
        phy_pj = phy_ns = hb_ns = 0.0
        if origin == "host":
            # Host I/O is outside inference timing; don't price it as the
            # accelerator's MEM-die-to-logic-die path.
            via_phy = False
            gsram = False
            regfile = False
            mem_ns = 0.0
            mem_pj, pending = 0.0, ()
        if via_phy:
            phy_pj, phy_ns, hb_ns = self._phy(nbytes, phy_bpc)
        gsram_pj = gsram_cycles = 0.0
        if gsram:
            gsram_pj, gsram_cycles = self._gsram(nbytes, write=False)
        rp = nbytes * 8 * self.pr.tile_reg_write_pj_per_bit if regfile else 0.0
        return Transfer(
            kind="mem_read", nbytes=nbytes, accesses_128b=acc,
            mem_pj=mem_pj, phy_pj=phy_pj, gsram_pj=gsram_pj, regfile_pj=rp,
            mem_ns=mem_ns, phy_ns=phy_ns, hb_ns=hb_ns,
            cycles=(0 if origin == "host" else
                    int(math.ceil((mem_ns + phy_ns + hb_ns) / self.pr.clock_ns))),
            medium=medium, pending_components=pending, origin=origin,
            phy_traversed=via_phy, gsram_traversed=gsram,
        )

    def mem_write(self, nbytes: int, *, via_phy: bool = True,
                  phy_bpc: int | None = None, gsram: bool = True,
                  medium: Literal["rram", "feram"] = "rram",
                  origin: str | None = None) -> Transfer:
        """把一段数据从逻辑 Die 写回 MEM die。"""
        acc, mem_pj, mem_ns, pending = self._mem(nbytes, write=True, medium=medium)
        phy_pj = phy_ns = hb_ns = 0.0
        if origin == "host":
            # Host I/O is outside inference timing; don't price it as the
            # accelerator's MEM-die-to-logic-die path.
            via_phy = False
            gsram = False
            mem_ns = 0.0
            mem_pj, pending = 0.0, ()
        if via_phy:
            phy_pj, phy_ns, hb_ns = self._phy(nbytes, phy_bpc)
        gsram_pj = gsram_cycles = 0.0
        if gsram:
            gsram_pj, gsram_cycles = self._gsram(nbytes, write=True)
        return Transfer(
            kind="mem_write", nbytes=nbytes, accesses_128b=acc,
            mem_pj=mem_pj, phy_pj=phy_pj, gsram_pj=gsram_pj, regfile_pj=0.0,
            mem_ns=mem_ns, phy_ns=phy_ns, hb_ns=hb_ns,
            cycles=(0 if origin == "host" else
                    int(math.ceil((mem_ns + phy_ns + hb_ns) / self.pr.clock_ns))),
            medium=medium, pending_components=pending, origin=origin,
            phy_traversed=via_phy, gsram_traversed=gsram,
        )

    def gsram_transfer(self, nbytes: int, write: bool) -> Transfer:
        """逻辑 Die 内部：阵列 <-> Global SRAM（不过 PHY、不过 MEM）。"""
        pj, cyc = self._gsram(nbytes, write)
        return Transfer(
            kind="gsram_write" if write else "gsram_read", nbytes=nbytes,
            accesses_128b=ceil_div(nbytes, LINE_BYTES),
            mem_pj=0.0, phy_pj=0.0, gsram_pj=pj, regfile_pj=0.0,
            mem_ns=0.0, phy_ns=0.0, hb_ns=0.0, cycles=int(cyc),
            medium=None, gsram_traversed=True,
        )


# --------------------------------------------------------------------------
# 账本
# --------------------------------------------------------------------------

@dataclass
class OpRow:
    """账本的一行：按 `(phase, layer, kind)` 聚合后的 op 记录。

    聚合是必须的：单是 decode 的注意力对就有 ~4.7 亿个，逐条记会把 trace 撑爆。
    """
    phase: str                # "prefill" | "decode" | "lm_head" | "host" | "total"
    layer: int                # -1 = 不属某一层
    kind: str
    cat: str = "compute"      # "compute" | "accumulate" | "elementwise" | "mem" | "phy" | "gsram"
    count: int = 0
    cycles: float = 0.0
    whole_pj: float = 0.0
    unit_pj: float = 0.0
    accum_pj: float = 0.0
    macs: int = 0
    blocks: int = 0
    elements: int = 0
    mem_rd_bytes: int = 0
    mem_wr_bytes: int = 0
    phy_bytes: int = 0
    gsram_bytes: int = 0
    medium: str | None = None
    pending_components: set[str] = field(default_factory=set)
    origin: str | None = None
    nonmac_commands: int = 0
    nonmac_reads: int = 0
    nonmac_writes: int = 0
    nonmac_profiles: set[str] = field(default_factory=set)

    def add_mm(self, c: MatmulCost, times: int = 1) -> None:
        self.count += times
        self.cycles += c.cycles
        self.whole_pj += c.whole_pj
        self.unit_pj += c.unit_pj
        self.accum_pj += c.accum_whole_pj
        self.macs += c.macs
        self.blocks += c.n_blocks

    def add_ew(self, c: ElementwiseCost, times: int = 1) -> None:
        self.count += times
        self.cycles += c.cycles
        self.whole_pj += c.pj
        self.unit_pj += c.pj
        self.elements += c.elements
        self.nonmac_commands += c.commands
        self.nonmac_reads += c.reads
        self.nonmac_writes += c.writes
        self.nonmac_profiles.update(c.profiles)
        self.origin = "nonmac:llm_nonmac_fp32 measured op/length profiles"

    def add_tr(self, t: Transfer, times: int = 1) -> None:
        self.count += times
        self.cycles += t.cycles
        self.whole_pj += t.pj
        self.unit_pj += t.pj
        if t.medium is not None:
            if self.medium is not None and self.medium != t.medium:
                raise ValueError(f"mixed media in ledger row {self.kind!r}")
            self.medium = t.medium
        self.pending_components.update(t.pending_components)
        self.origin = t.origin or self.origin
        if t.kind == "mem_read":
            self.mem_rd_bytes += t.nbytes
        elif t.kind == "mem_write":
            self.mem_wr_bytes += t.nbytes
        if t.gsram_traversed:
            self.gsram_bytes += t.nbytes
        if t.phy_traversed:
            self.phy_bytes += t.nbytes

    def as_dict(self) -> dict[str, Any]:
        return {
            "phase": self.phase, "layer": self.layer, "kind": self.kind,
            "cat": self.cat, "count": self.count, "cycles": round(self.cycles, 3),
            "whole_pj": round(self.whole_pj, 3), "unit_pj": round(self.unit_pj, 3),
            "accum_pj": round(self.accum_pj, 3),
            "macs": self.macs, "blocks": self.blocks, "elements": self.elements,
            "mem_rd_bytes": self.mem_rd_bytes, "mem_wr_bytes": self.mem_wr_bytes,
            "phy_bytes": self.phy_bytes, "gsram_bytes": self.gsram_bytes,
            "medium": self.medium,
            "cost_pending": sorted(self.pending_components),
            "origin": self.origin,
            "nonmac_commands": self.nonmac_commands,
            "nonmac_read_count": self.nonmac_reads,
            "nonmac_write_count": self.nonmac_writes,
            "nonmac_profiles": sorted(self.nonmac_profiles),
        }


@dataclass(frozen=True)
class LedgerMark:
    """账本在某一时刻的**只读快照**，用来把一次运行切成 TTFT / decode 两段。

    为什么用快照而不是按阶段名去分：`lm_head` 是**独立阶段**，但它的调用既发生在
    prefill 之后（首 token）也发生在每个 decode 步 —— 光看阶段名分不出"哪一次是第一次"。
    快照法直接钉住"第一个 token 出来时的账目"，不猜归属，因此对 `n_runs > 1` 与
    `max_new_tokens == 0` 都自然成立。

    `whole_pj` / `unit_pj` 两种计费口径都带上，因为效率指标要分口径给。
    """

    cycles_by_cores: dict[str, float]   # core 数（字符串键）-> 该口径下的拍数
    whole_pj: float
    unit_pj: float

    def __sub__(self, other: "LedgerMark") -> "LedgerMark":
        return LedgerMark(
            {k: v - other.cycles_by_cores.get(k, 0.0)
             for k, v in self.cycles_by_cores.items()},
            self.whole_pj - other.whole_pj,
            self.unit_pj - other.unit_pj,
        )

    def __add__(self, other: "LedgerMark") -> "LedgerMark":
        """两段账相加 —— `n_runs > 1` 时把各轮的 TTFT / decode 段各自累起来。"""
        keys = set(self.cycles_by_cores) | set(other.cycles_by_cores)
        return LedgerMark(
            {k: self.cycles_by_cores.get(k, 0.0) + other.cycles_by_cores.get(k, 0.0)
             for k in keys},
            self.whole_pj + other.whole_pj,
            self.unit_pj + other.unit_pj,
        )

    @property
    def cycles_1core(self) -> float:
        return self.cycles_by_cores.get("1", 0.0)

    def as_dict(self) -> dict[str, Any]:
        return {"cycles_by_cores": {k: round(v, 3) for k, v in self.cycles_by_cores.items()},
                "whole_pj": round(self.whole_pj, 3), "unit_pj": round(self.unit_pj, 3)}


class Ledger:
    """按 `(phase, layer, kind)` 聚合的账本。

    * `cycles` 是 **1 core 全串行** 的口径（本次要求）。
    * C-core 的对照列由 `total_cycles(cores=C)` 现算 —— 可并行的 op 按 `min(C, count)`
      摊薄，能量的 `C x (work/C) = work` 不变，所以能耗栏不随 cores 变。
    """

    def __init__(self, leakage_pj_per_cycle: float = 0.0) -> None:
        self._rows: dict[tuple[str, int, str], OpRow] = {}
        self._order: list[tuple[str, int, str]] = []
        self.leakage_pj_per_cycle = leakage_pj_per_cycle

    def row(self, phase: str, layer: int, kind: str, cat: str = "compute") -> OpRow:
        k = (phase, layer, kind)
        r = self._rows.get(k)
        if r is None:
            r = OpRow(phase=phase, layer=layer, kind=kind, cat=cat)
            self._rows[k] = r
            self._order.append(k)
        return r

    # ---- 记账入口（全部返回被更新的行，便于调用方继续加）----
    def matmul(self, phase: str, layer: int, kind: str, c: MatmulCost,
               times: int = 1) -> OpRow:
        r = self.row(phase, layer, kind, cat="compute")
        r.add_mm(c, times)
        return r

    def elementwise(self, phase: str, layer: int, kind: str, c: ElementwiseCost,
                    times: int = 1) -> OpRow:
        r = self.row(phase, layer, kind, cat="elementwise")
        r.add_ew(c, times)
        return r

    def transfer(self, phase: str, layer: int, kind: str, t: Transfer,
                 times: int = 1) -> OpRow:
        cat = "gsram" if t.kind.startswith("gsram") else "mem"
        r = self.row(phase, layer, kind, cat=cat)
        r.add_tr(t, times)
        return r

    # ---- 汇总 ----
    def rows(self) -> list[OpRow]:
        rows = [self._rows[k] for k in self._order]
        # Dynamic command/transfer profiles exclude leakage. Bill the external
        # measured leakage rate over the serial active interval exactly once.
        if self.leakage_pj_per_cycle:
            phases = {}
            for r in rows:
                phases[r.phase] = phases.get(r.phase, 0.0) + r.cycles
            rows += [OpRow(phase=phase, layer=-1, kind="measured_leakage", cat="leakage",
                whole_pj=cycles*self.leakage_pj_per_cycle, unit_pj=cycles*self.leakage_pj_per_cycle,
                origin="measured leakage_pj_per_cycle; serial accelerator busy interval")
                for phase,cycles in phases.items()]
        return rows

    def by_cat(self) -> dict[str, dict[str, float]]:
        """按类别汇总：`compute` / `elementwise` / `mem` / `gsram`，外加 `accumulate`（累加分量）。

        `accumulate` 是从 `compute` 里**单列出来**的分量（`compute` 仍含它），
        这样「切块带来的累加开销有多大」是看得见的。
        """
        out: dict[str, dict[str, float]] = {}
        for r in self.rows():
            a = out.setdefault(r.cat, {"count": 0, "cycles": 0.0, "whole_pj": 0.0,
                                       "unit_pj": 0.0, "macs": 0, "blocks": 0,
                                       "elements": 0, "mem_rd_bytes": 0,
                                       "mem_wr_bytes": 0, "phy_bytes": 0,
                                       "gsram_bytes": 0})
            a["count"] += r.count
            a["cycles"] += r.cycles
            a["whole_pj"] += r.whole_pj
            a["unit_pj"] += r.unit_pj
            a["macs"] += r.macs
            a["blocks"] += r.blocks
            a["elements"] += r.elements
            a["mem_rd_bytes"] += r.mem_rd_bytes
            a["mem_wr_bytes"] += r.mem_wr_bytes
            a["phy_bytes"] += r.phy_bytes
            a["gsram_bytes"] += r.gsram_bytes
        c = out.get("compute")
        if c is not None:
            c["accumulate_whole_pj"] = sum(r.accum_pj for r in self.rows()
                                           if r.cat == "compute")
        return out

    def by_phase(self) -> dict[str, dict[str, float]]:
        out: dict[str, dict[str, float]] = {}
        for r in self.rows():
            a = out.setdefault(r.phase, {"count": 0, "cycles": 0.0, "whole_pj": 0.0,
                                         "unit_pj": 0.0, "macs": 0, "blocks": 0,
                                         "elements": 0, "mem_rd_bytes": 0,
                                         "mem_wr_bytes": 0, "phy_bytes": 0,
                                         "gsram_bytes": 0})
            a["count"] += r.count
            a["cycles"] += r.cycles
            a["whole_pj"] += r.whole_pj
            a["unit_pj"] += r.unit_pj
            a["macs"] += r.macs
            a["blocks"] += r.blocks
            a["elements"] += r.elements
            a["mem_rd_bytes"] += r.mem_rd_bytes
            a["mem_wr_bytes"] += r.mem_wr_bytes
            a["phy_bytes"] += r.phy_bytes
            a["gsram_bytes"] += r.gsram_bytes
        return out

    def by_kind(self) -> dict[str, dict[str, float]]:
        out: dict[str, dict[str, float]] = {}
        for r in self.rows():
            a = out.setdefault(r.kind, {"cat": r.cat, "count": 0, "cycles": 0.0,
                                        "whole_pj": 0.0, "unit_pj": 0.0, "macs": 0,
                                        "blocks": 0, "elements": 0,
                                        "mem_rd_bytes": 0, "mem_wr_bytes": 0})
            a["count"] += r.count
            a["cycles"] += r.cycles
            a["whole_pj"] += r.whole_pj
            a["unit_pj"] += r.unit_pj
            a["macs"] += r.macs
            a["blocks"] += r.blocks
            a["elements"] += r.elements
            a["mem_rd_bytes"] += r.mem_rd_bytes
            a["mem_wr_bytes"] += r.mem_wr_bytes
        return out

    def total_cycles(self, cores: int = 1) -> float:
        """C-core 的对照列：可并行的 op 按 `min(cores, count)` 摊掉。**

        注意这是**上界乐观**的摊薄（真实调度要处理依赖与同步），只作对照。
        """
        if cores <= 1:
            return sum(r.cycles for r in self.rows())
        return sum(r.cycles / min(cores, max(r.count, 1)) for r in self.rows())

    def cycles_by_phase_and_core(self,
                                 cores_list: Iterable[int] = (1, 2, 4, 8, 16),
                                 ) -> dict[str, dict[str, float]]:
        """`total_cycles()` 的**分阶段**版本：每个 core 数下逐阶段的拍数。

        用途：吞吐率的三个粒度（TTFT / decode / 端到端）的分界在**阶段**上，所以需要
        「逐阶段 x 逐 core 数」的拍数。摊薄规则与 `total_cycles` **完全一致**
        （可并行 op 按 `min(cores, count)` 除），因此每个 core 数列的各阶段之和
        恒等于 `total_cycles(cores)` —— 自检钉住这一条。
        """
        out: dict[str, dict[str, float]] = {}
        for k in cores_list:
            acc: dict[str, float] = {}
            for r in self.rows():
                c = r.cycles if k <= 1 else r.cycles / min(k, max(r.count, 1))
                acc[r.phase] = acc.get(r.phase, 0.0) + c
            out[str(k)] = acc
        return out

    def mark(self, cores_list: Iterable[int] = (1, 2, 4, 8, 16)) -> "LedgerMark":
        """取当前账目的快照（`LedgerMark`）。调两次、相减即得一段的净账。"""
        return LedgerMark(
            {str(k): self.total_cycles(k) for k in cores_list},
            sum(r.whole_pj for r in self.rows()),
            sum(r.unit_pj for r in self.rows()),
        )

    def ns_derived_cycles_share(self) -> dict[str, float]:
        """总拍数里**由 ns 换算而来**的占比 —— 诚实标注 `token/拍` 的可用性。

        阵列块与 GSRAM 的拍数是**结构量**（`block_cycles`、访问次数），只有 MEM/PHY/HB
        那一段搬运的拍数是 `ceil((mem_ns + phy_ns + hb_ns) / clock_ns)` —— 既依赖时钟、
        也依赖三段延迟，全都是 `rtl` 档。所以"不受时钟影响"这个说法只对**结构量那部分**
        成立；这个占比就是那部分的诚实边界，报告里要一并给出。
        """
        rows = self.rows()
        tot = sum(r.cycles for r in rows)
        ns_cyc = sum(r.cycles for r in rows if r.cat == "mem")
        return {"total_cycles": tot, "ns_derived_cycles": ns_cyc,
                "ns_derived_share": (ns_cyc / tot) if tot else 0.0}

    def totals(self) -> dict[str, float]:
        rows = self.rows()
        return {
            "count": sum(r.count for r in rows),
            "cycles": sum(r.cycles for r in rows),
            "whole_pj": sum(r.whole_pj for r in rows),
            "unit_pj": sum(r.unit_pj for r in rows),
            "accum_whole_pj": sum(r.accum_pj for r in rows),
            "macs": sum(r.macs for r in rows),
            "blocks": sum(r.blocks for r in rows),
            "elements": sum(r.elements for r in rows),
            "mem_rd_bytes": sum(r.mem_rd_bytes for r in rows),
            "mem_wr_bytes": sum(r.mem_wr_bytes for r in rows),
            "phy_bytes": sum(r.phy_bytes for r in rows),
            "gsram_bytes": sum(r.gsram_bytes for r in rows),
        }
