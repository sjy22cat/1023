"""多模型与架构族切换：声明式 `ArchSpec` + 族预设 + HF `config.json` 解析。

分四层，每层只依赖它下面那层：

```
spec.py      形状与种类的声明（`ArchSpec` 及其子 spec）—— 不含任何数值
families.py  族预设与模型动物园（一份 `ArchSpec` 预设 = 一个族）
hf.py        HF `config.json` -> `ArchSpec`（族探测 + 逐字段别名 + 必填校验）
params.py    张量清单与形状（`ArchParams`）—— 唯一权威
names.py     模拟器名 <-> HF 张量名
```

对外只暴露这几样：`ArchSpec` / `parse_config` / `load_config` / `resolve_model` /
`ArchParams` / `family_names` / `zoo_names`。**不导出 `_PRESETS` 之类的私有表**，
族事实一律经 `preset()` / `zoo_entry()` 取。
"""
from __future__ import annotations

from .families import compose, family_names, normalize_family, preset, zoo_entry, zoo_names
from .hf import detect_family, load_config, parse_config, resolve_model
from .names import hf_name, hf_to_sim, layer_tensor_names, sim_to_hf
from .params import ArchParams, TensorSpec
from .spec import (ATTN_KINDS, MLP_KINDS, NORM_KINDS, ROPE_SCALINGS, ArchSpec,
                   MlaSpec, MlpSpec, MoeSpec, NormSpec, RopeSpec)

__all__ = [
    "ArchSpec", "NormSpec", "RopeSpec", "MlaSpec", "MoeSpec", "MlpSpec",
    "ATTN_KINDS", "MLP_KINDS", "NORM_KINDS", "ROPE_SCALINGS",
    "ArchParams", "TensorSpec",
    "parse_config", "load_config", "resolve_model", "detect_family",
    "preset", "compose", "normalize_family", "family_names", "zoo_entry", "zoo_names",
    "hf_name", "hf_to_sim", "sim_to_hf", "layer_tensor_names",
]
