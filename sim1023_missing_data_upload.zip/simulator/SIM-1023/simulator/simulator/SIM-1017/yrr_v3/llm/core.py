"""`Core`：一个 logic die 上的近存加速器实例（本次 `cores = 1`，一切全串行）。

一台 core = 现有模拟器建模的那台阵列：
  * 输出 1024 行 x 1024 K、32768 PE、1024 个 32x32 tile；
  * **权重寄存器堆 544 KB**（= 现有 `array_weight_rtl_bytes` = 557,056 B，与面积账逐位对齐）；
  * **Global SRAM 512 KB**（= `V3Config.global_sram_bytes`，当一整块用、不作乒乓）。

**关键巧合（README 里也写）**：一个 `1024x1024` 的 MXFP4 权重块
= 512 KB payload + 32 KB E8M0 尺度 = **544 KB，恰好装满权重寄存器堆**。
所以「权重常驻寄存器堆、跨 token 复用」这个说法在本模型里**有容量依据**：
输出宽度 ≤ 1024 的权重矩阵一次装载、全程常驻；输出宽度 2048 / 3072 的
（q_proj / gate_proj / up_proj）按输出块滚动装载（2 块 / 3 块）。

**本类只做账目与常驻管理**，不持有数值张量（那是 `weights.WeightImage` 的事）——
否则 2.4 GB 的 fp32 影子会被复制一份。数值与账目由 `schedule.py` / `inference.py`
在**同一处**驱动，二者不会漂移。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Literal

from .config import GIB, LlmPrices
from .cost import Cost, ElementwiseCost, Ledger, MatmulCost, OpRow, Transfer, ceil_div

# 阵列的结构常量（与 RTL/V3 一致）
ARRAY_M = 1024
ARRAY_K = 1024
REGFILE_BYTES = 557_056          # = 现有模型的 array_weight_rtl_bytes（544 KB）
GSRAM_BYTES = 512 * 1024         # = V3Config.global_sram_bytes


@dataclass
class ResidentBlock:
    """寄存器堆里的一个权重块。"""
    name: str
    nbytes: int
    phase: str = ""
    layer: int = -1
    hits: int = 0
    note: str = ""


class Core:
    """一个近存加速器实例：寄存器堆常驻表 + 逐 op 出账。"""

    def __init__(self, cost: Cost, ledger: Ledger, prices: LlmPrices,
                 core_id: int = 0, cores: int = 1,
                 regfile_bytes: int = REGFILE_BYTES,
                 gsram_bytes: int = GSRAM_BYTES,
                 phy_bpc: int | None = None,
                 memdie: "MemDie | None" = None) -> None:
        self.cost = cost
        self.ledger = ledger
        self.prices = prices
        self.memdie = memdie
        self.core_id = core_id
        self.cores = cores
        self.regfile_bytes = regfile_bytes
        self.gsram_bytes = gsram_bytes
        self.phy_bpc = prices.phy_bpc if phy_bpc is None else phy_bpc

        self.resident: dict[str, ResidentBlock] = {}
        self._order: list[str] = []
        # 统计
        self.weight_loads = 0
        self.weight_load_bytes = 0
        self.regfile_high_water = 0
        self.gsram_high_water = 0

    # ---------------- 容量 ----------------

    def regfile_used(self) -> int:
        return sum(b.nbytes for b in self.resident.values())

    def regfile_free(self) -> int:
        return self.regfile_bytes - self.regfile_used()

    @property
    def blocks_per_regfile(self) -> int:
        """寄存器堆能装几个 1024x1024 的 MXFP4 权重块（本模型里恰好 = 1）。"""
        return self.regfile_bytes // (544 * 1024)

    # ---------------- 权重常驻 ----------------

    def is_resident(self, name: str) -> bool:
        return name in self.resident

    def touch(self, name: str) -> None:
        b = self.resident.get(name)
        if b is not None:
            b.hits += 1

    def evict(self, name: str) -> int:
        b = self.resident.pop(name, None)
        if b is None:
            return 0
        self._order.remove(name)
        return b.nbytes

    def reset_residency(self) -> None:
        """清空常驻表（跑另一次推理时用）。**不动累计统计。**"""
        self.resident.clear()
        self._order.clear()

    def load_weight_block(self, phase: str, layer: int, kind: str, name: str,
                          nbytes: int, *, force: bool = False,
                          medium: str = "rram") -> Transfer | None:
        """把权重块从 MEM die 装进寄存器堆（MEM 读 → PHY → GSRAM → 寄存器堆）。

        **已常驻则零开销**（这正是「权重常驻、跨 token 复用」的账目体现）。
        返回 `None` 表示命中常驻、没有记账；否则返回那次搬运的 `Transfer`。

        `force=True` 强制重新装载（不做命中判断）。
        """
        if not force and name in self.resident:
            self.touch(name)
            return None
        if nbytes > self.regfile_bytes:
            raise MemoryError(
                f"{name} 需要 {nbytes:,} B，超过寄存器堆 {self.regfile_bytes:,} B")
        # 腾地方（FIFO；本模型里一个块就占满，所以等价于整块换出）
        while self.regfile_free() < nbytes and self._order:
            self.evict(self._order[0])
        if medium != "rram":
            raise ValueError("weight blocks must be read from RRAM")
        t = self.cost.mem_read(nbytes, phy_bpc=self.phy_bpc, regfile=True,
                               medium=medium)
        self.bill(phase, layer, kind, t)
        self.resident[name] = ResidentBlock(name=name, nbytes=nbytes,
                                            phase=phase, layer=layer)
        self._order.append(name)
        self.weight_loads += 1
        self.weight_load_bytes += nbytes
        self.regfile_high_water = max(self.regfile_high_water, self.regfile_used())
        return t

    # ---------------- 计算 ----------------

    def matmul(self, phase: str, layer: int, kind: str, M: int, N: int, K: int, *,
               weight_name: str | None = None, weight_bytes: int | None = None,
               x_bytes: int | None = None, out_name: str | None = None,
               out_bytes: int | None = None, load_weight: bool = True,
               accum_rounds: int | None = None) -> MatmulCost:
        """一次矩阵计算：切块 + 累加 + 出入访存，逐项出账。

        账目顺序（严格串行）：
          1. 权重装载（若 `weight_name` 给定且未常驻）—— MEM 读 + PHY + GSRAM + 寄存器堆；
          2. 输入激活经 GSRAM 进阵列（`x_bytes`）—— 逻辑 Die 内，不过 PHY；
          3. 块 x 单位块能耗/拍数 + rounds 次累加；
          4. 结果写回 MEM die（若 `out_name` / `out_bytes` 给定）—— PHY + MEM 写。

        `accum_rounds` 透传给 `Cost.matmul`：调用方**自己按 K 块切分**时，
        每块的 `K` 只含一个块（默认 0 轮），须由调用方在最后一个 K 块上记 `bk - 1` 轮。
        """
        c = self.cost
        if load_weight and weight_name is not None and weight_bytes is not None:
            self.load_weight_block(phase, layer, f"{kind}.wload", weight_name, weight_bytes)
        if x_bytes:
            # 输入激活经 GSRAM 进阵列：逻辑 Die 内一次中转（写 GSRAM + 宽读）
            self.bill(phase, layer, f"{kind}.xstage",
                      c.gsram_transfer(x_bytes, write=True))
            self.gsram_high_water = max(self.gsram_high_water, min(x_bytes, self.gsram_bytes))
        mm = c.matmul(M, N, K, billing="whole_block", accum_rounds=accum_rounds)
        self.ledger.matmul(phase, layer, kind, mm)
        if out_bytes:
            self.write_back(phase, layer, f"{kind}.wback", out_bytes, name=out_name)
        return mm

    def matmul_bulk(self, phase: str, layer: int, kind: str, M: int, N: int, K: int,
                    count: int, *, read_per: int = 0, write_per: int = 0,
                    xstage_per: int = 0, read_medium: str = "rram",
                    read_per_by_medium: dict[str, int] | None = None,
                    write_medium: str = "rram") -> MatmulCost:
        """把 `count` 次**同形状**的矩阵计算一次性出账。

        注意力要按 `(query, key)` pair 记 ~4.7 亿次账，逐次走 Python 太慢；
        这里先算一次单价（`Cost.matmul`）再整体放大 `count` 倍，**语义完全一致**
        （账目本来就是把同形状的 op 串行相加）。`count` 会累加进 `OpRow.count`，
        于是「有多少个 pair」这个数在报告里是可查的。

        `read_per` / `write_per` 是**每个 pair** 的读/写字节（逐 pair 串行的数据流动）。
        """
        if count <= 0:
            return self.cost.matmul(M, N, K)
        read_map = (read_per_by_medium if read_per_by_medium is not None else
                    ({read_medium: read_per} if read_per else {}))
        for medium, per_medium in read_map.items():
            if medium not in ("rram", "feram"):
                raise ValueError(f"unknown memory medium {medium!r}")
            if per_medium:
                suffix = "" if medium == "rram" else f".{medium}"
                self.bill(phase, layer, f"{kind}.rd{suffix}",
                          self.cost.mem_read(per_medium * count,
                                             phy_bpc=self.phy_bpc, medium=medium),
                          times=count)
        if xstage_per:
            self.bill(phase, layer, f"{kind}.xstage",
                      self.cost.gsram_transfer(xstage_per * count, write=True),
                      times=count)
        mm = self.cost.matmul(M, N, K).scaled(count)
        self.ledger.matmul(phase, layer, kind, mm, times=count)
        if write_per:
            suffix = "" if write_medium == "rram" else f".{write_medium}"
            self.bill(phase, layer, f"{kind}.wr{suffix}",
                      self.cost.mem_write(write_per * count, phy_bpc=self.phy_bpc,
                                          medium=write_medium),
                      times=count)
        return mm

    def elementwise(self, phase: str, layer: int, kind: str, n_elements: int, *,
                    op: str | None = None, row_length: int | None = None) -> ElementwiseCost:
        """轻量级算子（embedding / 激活 / 归一化 / 残差 / 除法 / 开根 / softmax）。"""
        aliases = {"rmsnorm": "rmsnorm", "qk_norm": "rmsnorm", "residual": "residual",
                   "rope": "rope_vector", "softmax": "softmax", "silu": "silu_vector",
                   "gelu_tanh": "gelu_vector", "silu_mul": "swiglu_vector", "relu": "relu_vector",
                   "attention_scale": "attention_scale"}
        kernel = op or aliases.get(kind)
        if kernel is None:
            raise ValueError(f"{kind}: no corresponding non-MAC RTL kernel; no software price fallback")
        length = n_elements if row_length is None else row_length
        if length < 1 or n_elements % length:
            raise ValueError("non-MAC rows must be complete independent vectors")
        ew = self.cost.elementwise(kernel, length, n_elements // length)
        row = self.ledger.elementwise(phase, layer, kind, ew, times=ew.commands)
        row.origin = self.prices.provenance.get("nonmac", row.origin)
        return ew

    # ---------------- 搬运 ----------------

    def write_back(self, phase: str, layer: int, kind: str, nbytes: int,
                   *, name: str | None = None, medium: str = "rram") -> Transfer:
        """把中间结果写回 MEM die（Q / K / V / S / 注意力矩阵 / 每层激活）。"""
        t = self.cost.mem_write(nbytes, phy_bpc=self.phy_bpc, medium=medium)
        self.bill(phase, layer, kind, t)
        return t

    def read_back(self, phase: str, layer: int, kind: str, nbytes: int, *,
                  regfile: bool = False, medium: str = "rram") -> Transfer:
        """从 MEM die 读回中间结果（一次一对 Q/K、逐个 K_j / V_j 等）。"""
        t = self.cost.mem_read(nbytes, phy_bpc=self.phy_bpc, regfile=regfile,
                               medium=medium)
        self.bill(phase, layer, kind, t)
        return t

    def host_store(self, name: str, nbytes: int, *, medium: str = "rram") -> None:
        """Record host preloading before inference; host latency is excluded."""
        if self.memdie is None:
            raise RuntimeError("host_store requires a MemDie placement model")
        rec = self.memdie.tensors.get(name)
        if rec is None:
            raise KeyError(f"host_store references unallocated tensor {name!r}")
        if rec.medium != medium:
            raise ValueError(f"{name!r} is placed in {rec.medium}, not {medium}")
        if int(nbytes) != rec.nbytes:
            raise ValueError(f"host_store size for {name!r} does not match its allocation")
        self.memdie.record_host_write(nbytes, medium=medium)

    def host_load(self, name: str, nbytes: int, *, medium: str = "rram") -> None:
        """Record a host read from MEM without charging inference latency."""
        if self.memdie is None:
            raise RuntimeError("host_load requires a MemDie placement model")
        rec = self.memdie.tensors.get(name)
        if rec is None:
            raise KeyError(f"host_load references unallocated tensor {name!r}")
        if rec.medium != medium:
            raise ValueError(f"{name!r} is placed in {rec.medium}, not {medium}")
        if int(nbytes) != rec.nbytes:
            raise ValueError(f"host_load size for {name!r} does not match its allocation")
        self.memdie.record_host_read(nbytes, medium=medium)

    def gsram(self, phase: str, layer: int, kind: str, nbytes: int,
              *, write: bool) -> Transfer:
        """逻辑 Die 内部的 GSRAM 中转（不过 PHY、不过 MEM）。"""
        t = self.cost.gsram_transfer(nbytes, write=write)
        self.bill(phase, layer, kind, t)
        return t

    # ---------------- 账 ----------------

    def bill(self, phase: str, layer: int, kind: str, t: Transfer,
             times: int = 1) -> OpRow:
        """**唯一的出账口**：一笔搬运同时进账本（聚合）与 MEM die（四段分开）。

        两处都记不是重复：账本按 `(phase, layer, kind)` 供报告逐项查，
        MEM die 按「MEM 阵列 / PHY / GSRAM / 寄存器堆」四段供归因。
        """
        self.ledger.transfer(phase, layer, kind, t, times=times)
        if self.memdie is not None:
            self.memdie.charge(t)
        return self.ledger.row(phase, layer, kind)

    def as_dict(self) -> dict[str, Any]:
        return {
            "core_id": self.core_id,
            "cores": self.cores,
            "array": {"rows": ARRAY_M, "k": ARRAY_K, "pe": 32768, "tiles": 1024},
            "regfile_bytes": self.regfile_bytes,
            "regfile_mxfp4_block_bytes": 544 * 1024,
            "regfile_capacity_blocks": self.blocks_per_regfile,
            "gsram_bytes": self.gsram_bytes,
            "weight_loads": self.weight_loads,
            "weight_load_bytes": self.weight_load_bytes,
            "regfile_high_water_bytes": self.regfile_high_water,
            "gsram_high_water_bytes": self.gsram_high_water,
            "resident_now": len(self.resident),
            "note": "一个 1024x1024 的 MXFP4 权重块 = 512 KB payload + 32 KB 尺度 = 544 KB，"
                    "恰好等于寄存器堆容量 —— 「权重常驻」在本模型里有容量依据。",
        }
