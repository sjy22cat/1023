"""权重来源：模拟器内生成（种子可复现）/ 纯 numpy 读 safetensors。

两个来源都产出同一个 `WeightImage`：
  * 每个矩阵存 **MXFP4**（payload + E8M0 尺度）—— 这是它在 MEM die 上的存放形态，
    字节数进容量账与访存账；
  * 另存一份 **反量化后的 fp32 数值影子**（`weight_cache="full"`，默认）供数值计算用。
    「反量化到 fp32 再乘」与「在 MXFP4 上直接乘」完全等价，所以这只是加速、不改口径。
    影子约 2.4 GB（0.6B），`weight_cache="none"` 时不留影子（每次用现反量化，慢很多但省内存）。

`cache="shape"` 是第三种：**只登记形状与字节，一个数组都不分配**（形状驱动快跑模式）。
它不是另写一个类，而是同一个 `WeightImage` 的一种状态 —— 形状与字节的记账只有一条
构造路径，两条路不可能在这上面分歧；而 `get()` / `norm()` 在 shape 态**主动抛错**，
这本身就是「数值路径真的被跳过」的免费证明。

形状由 `ArchParams`（`arch/params.py`）给出，本模块不自己拼名字 ——
张量名的唯一权威在那里，HF 名映射在 `arch/names.py`。

**不装 torch、运行时不联网**：safetensors 的格式足够简单（8 字节小端头长 + JSON 头 +
连续的裸数据），自己解析；bf16 按 fp32 的高 16 位还原。
"""
from __future__ import annotations

import json
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator

import numpy as np

from . import mxfp4
from .arch.names import hf_to_sim
from .arch.params import ArchParams
from .qwen3 import Qwen3Config, Qwen3Params

FP32 = np.float32
_NORM_TOL = 1e-6


# --------------------------------------------------------------------------
# 权重映像
# --------------------------------------------------------------------------

@dataclass
class WeightEntry:
    name: str
    shape: tuple[int, int]
    payload_bytes: int
    scale_bytes: int
    payload: np.ndarray | None = None      # uint8，(out, in/2) 打包后仍是 (out, in) 的低 4 位
    scale: np.ndarray | None = None        # uint8，(out, in/32)
    shadow: np.ndarray | None = None       # fp32，(out, in)
    note: str = ""

    @property
    def nbytes(self) -> int:
        return self.payload_bytes + self.scale_bytes

    @property
    def elements(self) -> int:
        return self.shape[0] * self.shape[1]


class WeightImage:
    """全模型权重（矩阵 + 归一化向量）。

    `cache` 三态：`"full"`（fp32 影子常驻）/ `"none"`（现场反量化）/ `"shape"`
    （**只登记形状与字节，不分配**，见模块 docstring）。
    """

    def __init__(self, spec: Qwen3Config | Any, source: str = "generated", seed: int = 1,
                 cache: str = "full") -> None:
        if cache not in ("full", "none", "shape"):
            raise ValueError(f"cache 只能是 full / none / shape，得到 {cache!r}")
        self.cfg = spec
        self.params = ArchParams(spec)
        self.spec = self.params.spec
        self.source = source
        self.seed = seed
        self.cache = cache
        self.entries: dict[str, WeightEntry] = {}
        self.norms: dict[str, np.ndarray] = {}
        # 归一化向量的**元素数**单列一份：形状驱动模式下 `norms` 是空的（不分配），
        # 但字节账仍要按元素数记 —— 记账读 `norm_sizes`，读数值才读 `norms`。
        self.norm_sizes: dict[str, int] = {}
        self._order: list[str] = []

    # ---------------- 状态 ----------------

    @property
    def shape_only(self) -> bool:
        """形状驱动模式：一个数值都没有。"""
        return self.cache == "shape"

    def _numeric(self, name: str) -> None:
        if self.shape_only:
            raise RuntimeError(
                f"shape-only image: numerical access is a bug（试图取 {name}）—— "
                f"形状驱动模式下数值从不参与记账，`get()` / `norm()` 是这个前提的守卫")

    # ---------------- 访问 ----------------

    def matrix_names(self) -> list[str]:
        return list(self._order)

    def entry_shape(self, name: str) -> tuple[int, int]:
        """一个矩阵的形状（两种模式下都可用 —— `linear` 只需形状就能定块数）。"""
        e = self.entries.get(name)
        if e is None:
            raise KeyError(f"没有这个矩阵：{name}")
        return e.shape

    def get(self, name: str) -> np.ndarray:
        """取一个矩阵的 fp32 数值（形状 `(out, in)`）。"""
        self._numeric(name)
        e = self.entries.get(name)
        if e is None:
            raise KeyError(f"没有这个矩阵：{name}")
        if e.shadow is not None:
            return e.shadow
        if e.payload is None or e.scale is None:
            raise RuntimeError(f"{name} 既没有影子也没有 MXFP4 码值")
        return mxfp4.dequantize(e.payload, e.scale)

    def nbytes(self, name: str) -> int:
        """该矩阵在 MEM die 上占的 MXFP4 字节（payload + 尺度）。"""
        e = self.entries.get(name)
        if e is None:
            # 归一化向量等不量化的东西：按 fp32 计
            if name in self.norm_sizes:
                return 4 * self.norm_sizes[name]
            raise KeyError(name)
        return e.nbytes

    def add_norm(self, name: str, n: int, value: np.ndarray | None) -> None:
        """登记一个归一化向量：元素数必记，数值可选（形状驱动模式传 `None`）。"""
        if name in self.norm_sizes:
            raise KeyError(f"归一化权重重名：{name}")
        self.norm_sizes[name] = int(n)
        if value is not None:
            self.norms[name] = value

    def norm_items(self) -> list[tuple[str, int]]:
        """`(名字, 元素数)`，顺序 = 登记顺序（`norms` 的键序与它一致）。"""
        return list(self.norm_sizes.items())

    def norm(self, name: str) -> np.ndarray:
        self._numeric(name)
        if name not in self.norms:
            raise KeyError(f"没有这个归一化权重：{name}")
        return self.norms[name]

    def total_bytes(self) -> int:
        return sum(e.nbytes for e in self.entries.values()) + \
               4 * sum(self.norm_sizes.values())

    def add_entry(self, name: str, shadow: np.ndarray | None,
                  payload: np.ndarray | None, scale: np.ndarray | None,
                  shape: tuple[int, int], note: str = "") -> WeightEntry:
        key = (name,)
        if name in self.entries:
            raise KeyError(f"矩阵重名：{name}")
        e = WeightEntry(
            name=name, shape=shape,
            payload_bytes=mxfp4.payload_bytes(shape),
            scale_bytes=mxfp4.scale_bytes(shape),
            payload=payload, scale=scale, shadow=shadow, note=note)
        self.entries[name] = e
        self._order.append(name)
        return e

    def as_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "seed": self.seed,
            "weight_cache": self.cache,
            "shape_only": self.shape_only,
            "family": self.spec.family,
            "initializer_range": self.spec.initializer_range,
            "matrices": len(self.entries),
            "total_mxfp4_bytes": sum(e.nbytes for e in self.entries.values()),
            "total_fp32_shadow_bytes": sum(
                int(e.shadow.nbytes) for e in self.entries.values() if e.shadow is not None),
            "norm_vectors": len(self.norm_sizes),
            "norm_bytes_fp32": 4 * sum(self.norm_sizes.values()),
            "accounting": self.params.accounting(),
        }


# --------------------------------------------------------------------------
# 生成（种子可复现）
# --------------------------------------------------------------------------

def _gen_matrix(shape: tuple[int, int], std: float, rng: np.random.Generator,
                chunk_rows: int = 4096) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """分块生成 → MXFP4 量化 → 反量化影子。返回 `(shadow, payload, scale)`。"""
    out, inn = shape
    shadow = np.empty(shape, dtype=FP32)
    payload = np.empty(shape, dtype=np.uint8)
    ng = -(-inn // mxfp4.GROUP)
    scale = np.empty((out, ng), dtype=np.uint8)
    for r in range(0, out, chunk_rows):
        e = min(out, r + chunk_rows)
        x = rng.standard_normal((e - r, inn)).astype(np.float32) * FP32(std)
        p, s = mxfp4.quantize(x)
        payload[r:e] = p
        scale[r:e] = s
        shadow[r:e] = mxfp4.dequantize(p, s)
    return shadow, payload, scale


def generate_weights(spec: Qwen3Config | Any, seed: int = 1, *, std: float | None = None,
                     cache: str = "full") -> WeightImage:
    """按该族的初始化尺度在模拟器内生成权重（带种子，两次运行逐位相同）。

    `std` 默认取 `spec.initializer_range`（HF `config.json` 里的同名键，
    Qwen3-0.6B 是 0.02 = 既有口径），全模型统一用（Linear 与 Embedding 都是）。

    **张量清单与顺序**：词表 → 逐层矩阵 → （未绑权重时的）`lm_head`，与
    `ArchParams.matrices()` 同源。顺序对 Qwen3 逐字不变，故同一个种子在两版代码里
    生成同一份数值。

    `cache="shape"` 时**一次 `rng` 都不取、一个数组都不分配**：形状与字节的账
    与数值无关，跳过生成不改变任何账目数字。
    """
    p = ArchParams(spec)
    p.spec.validate()
    if std is None:
        std = float(p.spec.initializer_range)
    img = WeightImage(p.spec, source=f"generated(seed={seed}, std={std:g})",
                      seed=seed, cache=cache)
    if cache == "shape":
        # 只登记形状：`_gen_matrix` 连碰都不碰（它按 `cache="none"` 也会分配整块 fp32）
        img.add_entry(p.embedding().name, None, None, None, p.embedding().shape,
                      note=p.embedding().note)
        for m in p.matrices():
            img.add_entry(m.name, None, None, None, m.shape, note=m.note)
        for nm, n in p.all_norms():
            img.add_norm(nm, n, None)
        return img

    rng = np.random.default_rng(seed)
    keep = cache == "full"

    # 词表（绑权重：embed_tokens = lm_head，只生成一次）
    emb = p.embedding()
    sh, pl, sc = _gen_matrix(emb.shape, std, rng)
    img.add_entry(emb.name, sh if keep else None, None if keep else pl,
                  None if keep else sc, emb.shape, note=emb.note)

    # 每层的投影矩阵（MoE 的逐专家矩阵、MLA 的逐投影矩阵都由 `layer_matrices` 给出）
    for l in range(p.spec.layers):
        for m in p.layer_matrices(l):
            sh, pl, sc = _gen_matrix(m.shape, std, rng)
            img.add_entry(m.name, sh if keep else None, None if keep else pl,
                          None if keep else sc, m.shape, note=m.note)
        for nm, n in p.layer_norms(l):
            img.add_norm(nm, n, np.ones(n, dtype=FP32))

    # 未绑权重时那份独立的 lm_head（绑权重时 `extra_matrices()` 为空）
    for m in p.extra_matrices():
        sh, pl, sc = _gen_matrix(m.shape, std, rng)
        img.add_entry(m.name, sh if keep else None, None if keep else pl,
                      None if keep else sc, m.shape, note=m.note)

    nm, n = p.final_norm()
    img.add_norm(nm, n, np.ones(n, dtype=FP32))
    return img


def shape_only_image(spec: Qwen3Config | Any) -> WeightImage:
    """形状驱动模式用的权重映像：只有形状与字节，没有任何数值。

    计划里叫 `ShapeOnlyImage`；这里实现为 `WeightImage(cache="shape")` ——
    同一个类的两种状态，形状/字节的记账因此只有一条构造路径。
    """
    return generate_weights(spec, seed=0, cache="shape")


# --------------------------------------------------------------------------
# safetensors（纯 numpy）
# --------------------------------------------------------------------------

_DTYPES = {
    "F32": np.float32, "F16": np.float16, "F64": np.float64,
    "BF16": np.dtype(np.uint16), "I8": np.int8, "U8": np.uint8,
    "I32": np.int32, "I64": np.int64, "BOOL": np.bool_,
}


def _read_safetensors(path: Path) -> dict[str, np.ndarray]:
    """读一个 .safetensors 文件 → `{tensor 名: ndarray}`（bf16 还原成 fp32）。"""
    raw = Path(path).read_bytes()
    if len(raw) < 8:
        raise ValueError(f"{path} 太短，不是 safetensors")
    hlen = struct.unpack_from("<Q", raw, 0)[0]
    header = json.loads(raw[8:8 + hlen].decode("utf-8"))
    base = 8 + hlen
    out: dict[str, np.ndarray] = {}
    for name, spec in header.items():
        if name == "__metadata__":
            continue
        dt = spec["dtype"]
        shape = tuple(spec["shape"])
        lo, hi = spec["data_offsets"]
        buf = raw[base + lo: base + hi]
        if dt == "BF16":
            u16 = np.frombuffer(buf, dtype=np.uint16)
            arr = (u16.astype(np.uint32) << 16).view(np.float32).reshape(shape)
            out[name] = np.ascontiguousarray(arr)
        elif dt in _DTYPES:
            out[name] = np.frombuffer(buf, dtype=_DTYPES[dt]).reshape(shape)
        else:
            raise ValueError(f"{path} 里 {name} 的 dtype={dt} 不认识")
    return out


def _hf_name_map(spec: Any) -> dict[str, str]:
    """HF 的权重名 → 本层的矩阵名。

    表的权威在 `arch/names.py`（按族分岔：Mixtral 的 `w1/w3/w2`、Phi 的 `fc1/fc2`、
    DeepSeek 的 `shared_experts`…），这里只是它的一个入口。原实现只认 Qwen3 的九个
    名字，已由族表取代。
    """
    return hf_to_sim(ArchParams(spec).spec)


def load_safetensors(directory: str | Path, spec: Qwen3Config | Any,
                     cache: str = "full") -> WeightImage:
    """从一个目录里的 `*.safetensors` 读真实 checkpoint（任意受支持的族）。

    **任何一处形状 / 名称对不上就直接报错**，绝不静默退回生成权重 ——
    静默退回会让「跑的是真模型」这句话变成假的。
    """
    d = Path(directory)
    files = sorted(d.glob("*.safetensors"))
    if not files:
        raise FileNotFoundError(f"{d} 下没有 *.safetensors（真实权重需要下载到本地）")
    tensors: dict[str, np.ndarray] = {}
    for f in files:
        tensors.update(_read_safetensors(f))

    p = ArchParams(spec)
    p.spec.validate()
    img = WeightImage(p.spec, source=f"safetensors:{d}", seed=0, cache=cache)
    keep = cache == "full"
    mapping = _hf_name_map(p.spec)

    def take(sim: str) -> np.ndarray:
        hf = mapping.get(sim)
        if hf is None:
            raise KeyError(f"张量表里没有 {sim}（族 {p.spec.family}）")
        if hf not in tensors:
            raise KeyError(f"checkpoint 缺张量 {hf}")
        a = np.asarray(tensors[hf], dtype=np.float32)
        if a.ndim != 2:
            raise ValueError(f"{hf} 应该是二维，实际 {a.shape}")
        return a

    # ---- 词表 ----
    emb = p.embedding()
    w = take(emb.name)
    if tuple(w.shape) != emb.shape:
        raise ValueError(f"{mapping[emb.name]} 形状不符：期望 {emb.shape}，实际 {w.shape}")
    _add_from_fp32(img, emb.name, w, keep, note=emb.note)

    # ---- 每层 ----
    for l in range(p.spec.layers):
        for m in p.layer_matrices(l):
            w = take(m.name)
            if tuple(w.shape) != m.shape:
                raise ValueError(f"{mapping[m.name]} 形状不符：期望 {m.shape}，实际 {w.shape}")
            _add_from_fp32(img, m.name, w, keep, note=m.note)
        for nm, n in p.layer_norms(l):
            hf = mapping[nm]
            if hf not in tensors:
                raise KeyError(f"checkpoint 缺张量 {hf}")
            v = np.asarray(tensors[hf], dtype=np.float32).reshape(-1)
            if v.size != n:
                raise ValueError(f"{hf} 长度不符：期望 {n}，实际 {v.size}")
            img.add_norm(nm, n, v)

    # ---- 未绑权重时那份独立的 lm_head ----
    for m in p.extra_matrices():
        w = take(m.name)
        if tuple(w.shape) != m.shape:
            raise ValueError(f"{mapping[m.name]} 形状不符：期望 {m.shape}，实际 {w.shape}")
        _add_from_fp32(img, m.name, w, keep, note=m.note)

    nm, n = p.final_norm()
    hf = mapping[nm]
    if hf not in tensors:
        raise KeyError(f"checkpoint 缺张量 {hf}")
    v = np.asarray(tensors[hf], dtype=np.float32).reshape(-1)
    if v.size != n:
        raise ValueError(f"{hf} 长度不符：期望 {n}，实际 {v.size}")
    img.add_norm(nm, n, v)
    return img


# 旧名（只认 Qwen3）：`load_safetensors` 的前身。留着不删是为了不惊动外部调用点，
# 新代码一律用 `load_safetensors`（族表取代了写死的九名表）。
load_qwen3_safetensors = load_safetensors


def _add_from_fp32(img: WeightImage, name: str, w: np.ndarray, keep: bool,
                   note: str = "") -> None:
    p, s = mxfp4.quantize(w)
    sh = mxfp4.dequantize(p, s) if keep else None
    img.add_entry(name, sh, None if keep else p, None if keep else s,
                  tuple(w.shape), note=note)


def build_weight_image(spec: Qwen3Config | Any, weights: str | None = None, seed: int = 1,
                       cache: str = "full") -> WeightImage:
    """按配置选择来源：`weights` 为目录则读真实 checkpoint，否则在模拟器内生成。

    `cache="shape"`（形状驱动模式）下即使给了 `weights` 目录也**不读文件** ——
    那条路上数值一个都用不上，读几十 GB 的 safetensors 纯属浪费。
    """
    if cache == "shape":
        return shape_only_image(spec)
    if weights:
        return load_safetensors(weights, spec, cache=cache)
    return generate_weights(spec, seed=seed, cache=cache)
