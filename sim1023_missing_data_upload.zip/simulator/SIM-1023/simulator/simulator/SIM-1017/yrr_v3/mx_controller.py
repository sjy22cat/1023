"""Pre-broadcast PE-block gating. This module must never inspect payload/E3/M10."""
from dataclasses import dataclass
import numpy as np


@dataclass
class ScaleDecision:
    esum: np.ndarray
    emax: np.ndarray
    distance: np.ndarray
    skip: np.ndarray
    compute: np.ndarray
    enabled: bool
    status: str


def decide_scale_blocks(weight_scale, input_scale, *, threshold_bits=None,
                        enable=True, metadata_available=True):
    """Decide one vector's [output, K-block] mask using scale metadata alone.

    Esum = (Wcode-127)+(Xcode-127); Emax is the maximum over K blocks for
    EACH output. Using raw 9-bit code sums gives the same distances.
    With an explicitly supplied threshold T, d >= T skips the PE block.
    No payload-zero, product exponent or cancellation information is used.
    """
    w, x = np.asarray(weight_scale), np.asarray(input_scale)
    if w.ndim != 2 or x.shape != (w.shape[1],) or w.shape[1] < 1:
        raise ValueError("scales must have shapes [outputs,K-blocks] and [K-blocks]")
    for a in (w, x):
        if not np.isfinite(a).all() or np.any(a != np.floor(a)) or np.any((a < 0) | (a > 254)):
            raise ValueError("finite E8M0 scale codes must be integers in 0..254")
    if threshold_bits is not None and (type(threshold_bits) is not int or threshold_bits < 1):
        raise ValueError("threshold_bits must be a positive integer or None")
    # Widen BEFORE adding uint8 fields: their sum must not wrap at 255.
    esum = w.astype(np.int32) + x.astype(np.int32)[None, :] - 254
    emax = esum.max(axis=1)
    distance = emax[:, None] - esum
    enabled = bool(enable and metadata_available and threshold_bits is not None)
    skip = distance >= threshold_bits if enabled else np.zeros_like(esum, dtype=bool)
    status = ("enabled" if enabled else "disabled by config" if not enable else
              "scale metadata unavailable" if not metadata_available else
              "pending fixed threshold; no MX block savings credited")
    return ScaleDecision(esum, emax, distance, skip, ~skip, enabled, status)
