"""Partial component characterization, with original cells and explicit scope.

Unknown quantities stay null. A measured subtotal is never a whole-chip total.
The independent strict full-datasheet loader remains available.
"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

SCHEMA = "sim-1017-component-characterization/v1"


def default_component_path():
    return Path(__file__).resolve().parents[1]/"calibration"/"rtl_1017sim"/"components_20261019_sram128.json"


def import_workbook(path, *, phy_unit=None):
    import openpyxl  # only the import step needs openpyxl
    path = Path(path)
    book = openpyxl.load_workbook(path, data_only=True)
    sheet = book["Sheet1"]
    raw = {s.title: [[c.value for c in row] for row in s] for s in book}
    records = {}
    for row in sheet.iter_rows(min_row=2):
        name = str(row[0].value or "").split("（", 1)[0]
        if not name:
            continue
        vals = [c.value for c in row]
        def first(v):
            m = re.match(r"\s*(\d+(?:\.\d+)?)", str(v))
            return float(m[1]) if m else None
        records[name] = dict(area_um2=first(vals[1]), energy_pj=first(vals[2]),
                             latency_ns=first(vals[3]), source=f"Sheet1!A{row[0].row}:D{row[0].row}",
                             original=vals)
    # Do not infer the PHY denominator across contradictory sheet definitions.
    if phy_unit not in (None, "bit", "128bit"):
        raise ValueError("phy_unit must be bit, 128bit, or None (unresolved)")
    mc = records["mc"]
    nums = re.findall(r"(\d+(?:\.\d+)?)\s*pj", mc["original"][2], re.I)
    if len(nums) != 3:
        raise ValueError("MC cell must specify read / skip / write pJ explicitly")
    mc.update(read_pj=float(nums[0]), skip_pj=float(nums[1]), write_pj=float(nums[2]))
    # Sheet1 may contain either the historical 1024-row pair or the newer
    # 128-row high-speed macros. Parse the selected pair without assuming a
    # particular compiler macro name.
    sram_names = [name for name in records if name.startswith("SRAM_")]
    for name in sram_names:
        nums = re.findall(r"(\d+(?:\.\d+)?)\s*pJ/bit", records[name]["original"][2], re.I)
        if len(nums) != 2:
            continue
        records[name].update(read_pj_per_bit=float(nums[0]), write_pj_per_bit=float(nums[1]))
    # Prefer the user-supplied 128-row pair when present. The depth/width
    # metadata is explicit because the workbook energy cells do not encode it.
    if "SRAM_128X128_HS" in records and "SRAM_128X8_HS" in records:
        for name, width in (("SRAM_128X128_HS", 128), ("SRAM_128X8_HS", 8)):
            records[name].update(width_bits=width, depth_words=128)
        global_sram = dict(payload_macro="SRAM_128X128_HS", scale_macro="SRAM_128X8_HS",
                           depth_words=128, bank_count=32, pages_per_bank=1,
                           access_latency_assumption_ns=1.0)
    else:
        global_sram = None
    return dict(schema=SCHEMA, status="PARTIAL", source_workbook=path.name,
        workbook_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), selected_sheet="Sheet1",
        phy_energy_unit=phy_unit, records=records, original_sheets=raw,
        global_sram=global_sram,
        policy=dict(mc_partial_read_energy="full_read_cost_conservative_assumption",
                    pe_partial_mac_energy="full_PE_step_conservative_assumption",
                    default_rram_granularity_bits=128,
                    softmax="pending in Sheet1; old alternatives preserved but not selected"),
        missing=["RRAM array read energy/latency", "FeRAM read/write energy/latency",
                 "broadcast/interconnect", "leakage", "softmax/non-MAC characterization",
                 "element-masked MC/PE energy", "weight-scale metadata read energy",
                 "RRAM-FP storage format bit/plane read energy"])


def read_components(path):
    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if data.get("schema") != SCHEMA or data.get("status") != "PARTIAL":
        raise ValueError("expected explicit PARTIAL component characterization")
    if data.get("phy_energy_unit") not in (None, "bit", "128bit"):
        raise ValueError("invalid PHY energy denominator")
    import math
    for name, rec in data["records"].items():
        for key, val in rec.items():
            if key.endswith(("_pj", "_um2", "_ns", "_bit")) and val is not None:
                if type(val) not in (int, float) or not math.isfinite(val) or val < 0:
                    raise ValueError(f"invalid component {name}.{key}")
    sram_layout(data)
    return data


def sram_layout(data):
    """Resolve the selected macro pair; old workbook snapshots stay readable.

    A null macro latency never becomes measured timing: an explicit assumption
    is required to schedule it until access timing is supplied.
    """
    import math
    selected = data.get("global_sram")
    layout = dict(selected) if selected else dict(
        payload_macro="SRAM_1024X128_LL", scale_macro="SRAM_1024X8_LL",
        depth_words=1024, bank_count=32, pages_per_bank=1)
    for key in ("depth_words", "bank_count", "pages_per_bank"):
        if type(layout.get(key)) is not int or layout[key] < 1:
            raise ValueError(f"global_sram.{key} must be a positive integer")
    for kind, width in (("payload",128), ("scale",8)):
        name = layout.get(kind+"_macro")
        rec = data["records"].get(name)
        if rec is None:
            raise ValueError(f"selected SRAM macro {name!r} has no characterization")
        if selected and (rec.get("depth_words") != layout["depth_words"] or rec.get("width_bits") != width):
            raise ValueError(f"selected SRAM macro {name} geometry disagrees with layout")
        for key in ("area_um2", "read_pj_per_bit", "write_pj_per_bit"):
            x = rec.get(key)
            if type(x) not in (int,float) or not math.isfinite(x) or x < 0:
                raise ValueError(f"selected SRAM macro {name}.{key} requires a finite nonnegative value")
        latency = rec.get("latency_ns")
        assumed = latency is None
        if assumed:
            latency = layout.get("access_latency_assumption_ns")
        if type(latency) not in (int,float) or not math.isfinite(latency) or latency <= 0:
            raise ValueError(f"selected SRAM macro {name} requires timing or an explicit access-latency assumption")
        layout[kind+"_access_ns"] = latency
        layout[kind+"_timing_assumed"] = assumed
    return layout


def component_config(data):
    r = data["records"]
    sram = sram_layout(data)
    # One simulator tick = 1 ns. Partial timing includes the selected module
    # latencies; uncharacterized wire/array delays are reported separately.
    from math import ceil
    values = dict(clock_ns=1.0, weight_supply_mode="rram_per_pe",
        tile_rows=32,physical_tile_rows=32,physical_tile_cols=32,pe_per_tile=32,tile_k=32,
        mc_read_cycles=ceil(r["mc"]["latency_ns"]), mc_issue_cycles=ceil(r["mc"]["latency_ns"]),
        phy_read_cycles=ceil(r["phy"]["latency_ns"]), rram_array_read_cycles=0,
        gsram_read_cycles=ceil(sram["payload_access_ns"]),
        gsram_scale_read_cycles=ceil(sram["scale_access_ns"]),
        gsram_write_latency=0, gsram_write_bytes_per_cycle=512,
        pe_mul_cycles=ceil(r["PE_ALL"]["latency_ns"]), pe_acc_cycles=0,
        sa_pipeline_levels=ceil(r["bf16_align_add32"]["latency_ns"]),
        mx_control_cycles=ceil(r["mx_scale32"]["latency_ns"]),
        tag_decode_cycles=0, broadcast_cycles=0,
        # External physical channels stay separate from the PE-local MC array.
        rram_read_granularity_bits=data["policy"]["default_rram_granularity_bits"])
    if data.get("global_sram"):
        values.update(gsram_banks=sram["bank_count"], source_lanes=sram["bank_count"],
            global_sram_bytes=sram["bank_count"]*sram["depth_words"]*sram["pages_per_bank"]*16)
    return values


def cost(data, name, key="energy_pj"):
    return data["records"].get(name, {}).get(key)


def multiply(n, price):
    return 0.0 if n == 0 else None if price is None else float(n*price)


def area_report(data, cfg):
    r = data["records"]
    # Selected mapping assumptions: input converter per Tile, weight converter
    # per PE, one 32-K reducer and scale controller per output row.
    counts = dict(PE_ALL=cfg.pe_count, mc=cfg.mc_count,
        tile_nonpe=cfg.tile_count, rfp4_to_tagfp4_32=cfg.pe_count,
        mxfp4_to_tagfp4_32=cfg.tile_count,
        bf16_align_add32=cfg.physical_tile_rows*cfg.pe_per_tile,
        mx_scale32=cfg.physical_tile_rows*cfg.pe_per_tile)
    parts = {k: dict(instances=n, unit_um2=cost(data,k,"area_um2"),
                    total_um2=multiply(n,cost(data,k,"area_um2"))) for k,n in counts.items()}
    sram = sram_layout(data)
    from math import ceil
    # Usable payload excludes sideband; sideband cannot hold arbitrary logits.
    pages = sram["pages_per_bank"] if data.get("global_sram") else ceil(
        cfg.global_sram_bytes/(cfg.gsram_banks*sram["depth_words"]*16))
    for k in (sram["payload_macro"], sram["scale_macro"]):
        n = cfg.gsram_banks*pages
        parts[k] = dict(instances=n, unit_um2=cost(data,k,"area_um2"), total_um2=n*cost(data,k,"area_um2"))
    return dict(status="PARTIAL", components=parts,
        known_component_mm2=sum(p["total_um2"] for p in parts.values() if p["total_um2"] is not None)/1e6,
        logic_die_mm2=None, mc_unit_mm2=cost(data,"mc","area_um2")/1e6,
        mc_total_mm2=cfg.mc_count*cost(data,"mc","area_um2")/1e6,
        gsram_macro_depth_words=sram["depth_words"], gsram_macro_pages_per_bank=pages,
        gsram_payload_physical_bytes=cfg.gsram_banks*pages*sram["depth_words"]*16,
        gsram_scale_physical_bytes=cfg.gsram_banks*pages*sram["depth_words"],
        gsram_macro_physical_bytes=cfg.gsram_banks*pages*sram["depth_words"]*17,
        gsram_configured_usable_bytes=cfg.global_sram_bytes,
        source="selected characterized SRAM macro pair; payload and scale capacities separate",
        excluded=["PHY replication (topology not supplied)", "RRAM/FeRAM arrays", "softmax", "global routing/control"],
        mapping_assumptions="32-K reduction/mx_scale per output; Tile input decode; PE weight decode; no bank/global-summary double count")
