"""User-requested 1024-lane non-MAC estimate, independent of legacy RTL profiles.

One physical function unit is replicated 1024 times. Area is charged once;
dynamic energy is charged for each executed vector, latency once per parallel
wave. The supplied unit costs must cover the complete function (including an
allocated share of softmax max/sum and local storage). This is an architecture
estimate, not a measurement of the assembled 1024-lane engine.
"""
from __future__ import annotations

from copy import deepcopy
import json
import math
from pathlib import Path

SCHEMA = "sim-1017-parallel-nonmac/v1"
SCOPE = "replicated_unit_estimate_includes_shared_function_logic_and_local_storage"


def default_parallel_path():
    return Path(__file__).resolve().parents[1]/"calibration"/"rtl_1017sim"/"nonmac_parallel_1024.json"


def validate_parallel(data, clock_ns=None):
    if not isinstance(data, dict):
        raise ValueError("parallel nonmac parameters must be an object")
    if data.get("schema") != SCHEMA or data.get("parallel_lanes") != 1024:
        raise ValueError("parallel nonmac requires v1 schema and 1024 lanes")
    if data.get("status") not in ("PENDING", "USER_SUPPLIED") or data.get("scope") != SCOPE:
        raise ValueError("parallel nonmac requires explicit status and complete-function cost scope")
    if not data.get("source"):
        raise ValueError("parallel nonmac source is required")
    def number(value, name, *, integer=False, positive=False):
        if value is None:
            return
        if (type(value) not in (int, float) or not math.isfinite(value) or value < 0
                or (integer and type(value) is not int) or (positive and value <= 0)):
            raise ValueError(f"parallel nonmac {name} must be finite/nonnegative or null")
    number(data.get("clock_ns"), "clock_ns", positive=True)
    if data.get("clock_ns") is None or (clock_ns is not None and data["clock_ns"] != clock_ns):
        raise ValueError("parallel nonmac clock must match simulator clock")
    number(data.get("unit_area_um2"), "unit_area_um2")
    number(data.get("local_workspace_bytes"), "local_workspace_bytes", integer=True)
    from .nonmac import OPS
    operations = data.get("operations")
    if not isinstance(operations, dict):
        raise ValueError("parallel nonmac operations must be an object")
    for op, rec in operations.items():
        if op not in OPS or not isinstance(rec, dict):
            raise ValueError(f"parallel nonmac unsupported operation {op}")
        number(rec.get("unit_dynamic_pj"), f"{op}.unit_dynamic_pj")
        number(rec.get("latency_cycles"), f"{op}.latency_cycles", integer=True, positive=True)
    return data


def load_parallel(path=None):
    p = Path(path) if path is not None else default_parallel_path()
    data = json.loads(p.read_text(encoding="utf-8-sig"))
    validate_parallel(data)
    return deepcopy(data)


def command_cost(data, op, length, rows=1, *, allow_pending=False):
    from .nonmac import OPS, REDUCTIONS, NonmacCost
    validate_parallel(data)
    if op not in OPS:
        raise ValueError(f"nonmac operator {op!r} has no behavior contract")
    if type(length) is not int or length < 1 or type(rows) is not int or rows < 1:
        raise ValueError("nonmac length/rows must be positive integers")
    if op in REDUCTIONS and length > 1024:
        raise ValueError(f"{op} length exceeds 1024; independent chunks change the result")
    if op == "rope_vector" and length % 2:
        raise ValueError("rope_vector requires an even length")
    rec = data["operations"].get(op, {})
    energy, latency = rec.get("unit_dynamic_pj"), rec.get("latency_cycles")
    if not allow_pending and (energy is None or latency is None):
        raise ValueError(f"parallel nonmac {op} is PENDING; supply unit energy and vector latency")
    calls = math.ceil(length/1024)*rows
    # Even short tails reserve the complete physical engine. Do not invent
    # partial-lane clock/power gating savings without characterization.
    return NonmacCost(length*rows, None if energy is None else energy*1024*calls,
                      (latency or 0)*calls, calls, 0, 0, (f"parallel1024/{op}",))


def area_report(data):
    unit = data.get("unit_area_um2")
    return dict(instances=1024, unit_um2=unit,
                total_um2=None if unit is None else unit*1024,
                scope="one shared multifunction engine; area not multiplied by operation count",
                estimation="user-requested unit area times 1024")
