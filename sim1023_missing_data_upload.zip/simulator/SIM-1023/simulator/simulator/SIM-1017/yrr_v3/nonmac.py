"""Measured command costs for the integrated llm_nonmac_fp32 hardware.

No latency equations, interpolation, per-element energy estimates or RTL
interpretation live here. Each accepted length must have a measured record.
"""
from dataclasses import dataclass
import math

OPS = {"add": 0, "sub": 1, "mul": 2, "div": 3, "exp": 4, "sqrt": 5,
       "rsqrt": 6, "sigmoid": 7, "silu": 8, "gelu_tanh": 9,
       "rope_pair": 10, "swiglu": 11, "relu": 12,
       "softmax": 16, "rmsnorm": 17, "layernorm": 18, "residual": 19,
       "attention_scale": 20, "silu_vector": 21, "gelu_vector": 22,
       "swiglu_vector": 23, "rope_vector": 24, "relu_vector": 25}
REDUCTIONS = {"softmax", "rmsnorm", "layernorm", "rope_vector"}
VECTOR = {name for name, op in OPS.items() if op >= 16}
SCOPE = "engine_and_scratch_dynamic_excludes_staging_and_leakage"


def validate_nonmac(data, clock_ns):
    if not isinstance(data, dict):
        raise ValueError("required object: nonmac")
    if data.get("implementation") != "llm_nonmac_fp32" or data.get("max_vector_length") != 1024:
        raise ValueError("nonmac implementation/length must match llm_nonmac_fp32 / 1024")
    if type(data.get("clock_ns")) not in (int, float) or data.get("clock_ns") != clock_ns or data.get("scope") != SCOPE:
        raise ValueError("nonmac clock/scope disagrees with integrated hardware contract")
    for key in ("rtl_revision", "dw_version", "scratch_implementation", "activity_policy", "reports"):
        if not data.get(key):
            raise ValueError(f"nonmac.{key} is required")
    profiles = data.get("profiles")
    if not isinstance(profiles, dict) or not profiles:
        raise ValueError("nonmac.profiles requires measured op/length records")
    for op, lengths in profiles.items():
        if op not in OPS or not isinstance(lengths, dict) or not lengths:
            raise ValueError(f"unsupported/empty nonmac.profiles.{op}")
        for length, rec in lengths.items():
            if not length.isdecimal() or str(int(length)) != length:
                raise ValueError(f"nonmac length must be a canonical decimal string: {length}")
            n = int(length)
            if not 1 <= n <= (1024 if op in VECTOR else 1) or (op == "rope_vector" and n % 2):
                raise ValueError(f"invalid nonmac length: {op}/{n}")
            if not isinstance(rec, dict):
                raise ValueError(f"nonmac.profiles.{op}.{length} must be an object")
            for key in ("cycles", "dynamic_pj", "read_count", "write_count"):
                v = rec.get(key)
                if type(v) not in (int, float) or not math.isfinite(v) or v < 0:
                    raise ValueError(f"nonmac.profiles.{op}.{length}.{key} must be finite/nonnegative")
                if key != "dynamic_pj" and type(v) is not int:
                    raise ValueError(f"nonmac {key} must be an integer")
            if rec["cycles"] <= 0 or not rec.get("report"):
                raise ValueError(f"nonmac.profiles.{op}.{length}: positive cycles and report required")
            # Check observable request counts, never infer timing or energy.
            expected_reads = (3*n if op in ("softmax", "rmsnorm") else
                              5*n if op == "layernorm" else
                              2*n if op in ("residual", "rope_vector", "swiglu_vector") else
                              n if op in VECTOR else 0)
            expected_writes = 2*n if op == "softmax" else n if op in VECTOR else 0
            if (rec["read_count"],rec["write_count"]) != (expected_reads,expected_writes):
                raise ValueError(f"nonmac.profiles.{op}.{length} access counts disagree with RTL command")
    stages = data.get("reduce_staging")
    if not isinstance(stages, dict):
        raise ValueError("nonmac.reduce_staging must be an object (length records required when used)")
    for length, rec in stages.items():
        if not length.isdecimal() or str(int(length)) != length or not 1 <= int(length) <= 1024:
            raise ValueError("invalid nonmac.reduce_staging length")
        if not isinstance(rec, dict) or not rec.get("report"):
            raise ValueError("nonmac.reduce_staging requires records with report paths")
        for key in ("cycles", "dynamic_pj", "read_count", "write_count"):
            v = rec.get(key)
            if type(v) not in (int, float) or not math.isfinite(v) or v < 0:
                raise ValueError(f"nonmac.reduce_staging.{length}.{key} must be finite/nonnegative")
            if key != "dynamic_pj" and type(v) is not int:
                raise ValueError(f"nonmac.reduce_staging.{key} must be an integer")
        if rec["cycles"] <= 0 or rec["read_count"] != 0 or rec["write_count"] != int(length):
            raise ValueError("nonmac.reduce_staging must record positive cycles and one write per element")


@dataclass(frozen=True)
class NonmacCost:
    elements: int
    pj: float | None = 0.0
    cycles: int = 0
    commands: int = 0
    reads: int = 0
    writes: int = 0
    profiles: tuple[str, ...] = ()


def command_cost(data, op, length, rows=1):
    """Bill independent rows. Only pointwise kernels can be tiled at 1024."""
    from .parallel_nonmac import SCHEMA as PARALLEL_SCHEMA, command_cost as parallel_cost
    if data.get("schema") == PARALLEL_SCHEMA:
        return parallel_cost(data, op, length, rows)
    if op not in OPS:
        raise ValueError(f"nonmac operator {op!r} has no RTL implementation")
    if type(length) is not int or length < 1 or type(rows) is not int or rows < 1:
        raise ValueError("nonmac length/rows must be positive integers")
    if op in REDUCTIONS and length > 1024:
        raise ValueError(f"{op} length {length} exceeds RTL limit 1024; independent chunks change the result")
    if op == "rope_vector" and length % 2:
        raise ValueError("rope_vector requires an even length")
    chunks = []
    if op not in VECTOR:
        chunks = [(1, length * rows)]
    else:
        full, tail = divmod(length, 1024)
        if full:
            chunks.append((1024, full * rows))
        if tail:
            chunks.append((tail, rows))
    pj = cycles = commands = reads = writes = 0
    used = []
    for n, count in chunks:
        rec = data.get("profiles", {}).get(op, {}).get(str(n))
        if rec is None:
            raise ValueError(f"missing Synopsys nonmac profile: {op}/{n}; measure this command, no fallback")
        pj += rec["dynamic_pj"] * count
        cycles += rec["cycles"] * count
        reads += rec["read_count"] * count
        writes += rec["write_count"] * count
        commands += count
        used.append(f"{op}/{n}")
    return NonmacCost(length * rows, pj, cycles, commands, reads, writes, tuple(used))


def staging_cost(data, length):
    rec = data.get("reduce_staging", {}).get(str(length))
    if rec is None:
        raise ValueError(f"missing Synopsys nonmac reduce_staging/{length}; measure integrated conversion/writes")
    return NonmacCost(length, rec["dynamic_pj"], rec["cycles"], 0,
                      rec["read_count"], rec["write_count"], (f"reduce_staging/{length}",))
