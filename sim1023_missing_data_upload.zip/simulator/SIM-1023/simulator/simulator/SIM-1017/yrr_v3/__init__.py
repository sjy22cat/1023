"""Independent Python V3 full-chain MXFP4 near-memory simulator."""

from .config import EnergyParams, V3Config
from .formats import (decode_fp4, decode_rram_fp4, decode_tag_fp, encode_mxfp4,
                      e3_m10_value, fp4_to_e3_m10, mxfp4_to_rram_fp4,
                      rram_fp4_to_mxfp4, mxfp4_to_tag_fp, tag_fp_to_mxfp4,
                      stable_softmax, w4_to_a5)
from .interfaces import *
from .model import MxControlTrace, TraceEvent, V3Result, run_v3
from .report import format_report, to_dict, write_json
from .rtl_dataset import (RtlStructure, V3Datasheet,
                          calibration_config_overrides, load_1017_calibration,
                          default_1017_measured_path)
from .behavior import FormatBehavior, SimulatorSession
from .mx_controller import ScaleDecision, decide_scale_blocks

__version__ = "3.5.0-parallel-interconnect"

__all__ = ["EnergyParams", "V3Config", "V3Result", "run_v3", "FormatBehavior", "SimulatorSession", "ScaleDecision", "decide_scale_blocks", "decode_fp4", "decode_rram_fp4",
           "decode_tag_fp", "encode_mxfp4", "fp4_to_e3_m10", "e3_m10_value",
           "mxfp4_to_rram_fp4", "rram_fp4_to_mxfp4", "mxfp4_to_tag_fp", "tag_fp_to_mxfp4",
           "stable_softmax", "w4_to_a5", "format_report", "to_dict", "write_json", "TraceEvent", "MxControlTrace",
           "V3Datasheet", "RtlStructure", 
           "load_1017_calibration", "calibration_config_overrides",
           "default_1017_measured_path"]
