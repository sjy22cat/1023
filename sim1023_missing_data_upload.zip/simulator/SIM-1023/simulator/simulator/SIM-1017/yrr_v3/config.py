"""Architectural inputs; defaults require external calibration."""
from __future__ import annotations
from dataclasses import dataclass, field, fields
from typing import Literal
import math

HOST_DMA_CONFIG_FIELDS = frozenset({"model_host_io", "dma_staging_bytes",
    "dma_status_bytes_per_descriptor", "dma_descriptor_bytes", "dma_descriptor_count",
    "dma_latency", "host_bus_width"})
HOST_DMA_ENERGY_FIELDS = frozenset({"dma_pj_per_bit", "host_pj_per_bit"})


@dataclass
class EnergyParams:
    gsram_read_pj_per_128b: float | None = None
    gsram_write_pj_per_128b: float | None = None
    broadcast_pj_per_bit: float | None = None
    tile_reg_write_pj_per_bit: float | None = None
    tile_weight_write_pj_per_bit: float | None = None
    partial_link_pj_per_bit: float | None = None
    reduction_add_pj: float | None = None
    alignment_pj_per_bit: float | None = None
    mx_control_pj_per_block: float | None = None
    tag_decode_pj_per_element: float | None = None
    dma_pj_per_bit: float | None = None
    host_pj_per_bit: float | None = None
    pe_mac_pj: float | None = None
    mc_read_pj: float | None = None
    mc_skip_pj: float | None = None
    rram_read_pj_per_byte: float | None = None
    ferram_read_pj_per_byte: float | None = None
    ferram_write_pj_per_byte: float | None = None
    hybrid_bond_pj_per_bit: float | None = None
    fp32_conversion_pj: float | None = None
    leakage_pj_per_cycle: float | None = None
    provenance: str = "placeholder/assumption"
    sources: dict[str, str] = field(default_factory=dict)

    def validate(self, *, allow_missing=False):
        for f in fields(self):
            v = getattr(self, f.name)
            if f.name in ("provenance", "sources") or f.name in HOST_DMA_ENERGY_FIELDS:
                continue
            if v is None and allow_missing:
                continue
            if type(v) not in (int, float) or not math.isfinite(v) or v < 0:
                raise ValueError(f"energy.{f.name} must be finite and nonnegative")


@dataclass
class V3Config:
    m: int = 1024
    n: int = 1024
    k: int = 1024
    batch: int = 1
    tile_rows: int = 32
    tile_k: int = 32
    pe_per_tile: int = 32
    physical_tile_rows: int | None = None
    physical_tile_cols: int | None = None
    mem_die_count: int = 2
    layer_id: int = 0
    layer_die_map: dict[int, int] = field(default_factory=lambda: {0: 0})
    weights_resident: bool = True
    # RRAM-resident is different from a decoded Tile cache. In this mode
    # every PE owns a local 128-bit read controller, invoked every vector.
    weight_supply_mode: Literal["rram_per_pe", "tile_cache"] = "rram_per_pe"
    mc_read_cycles: int = 2
    mc_issue_cycles: int = 2
    phy_read_cycles: int = 2
    rram_array_read_cycles: int = 0  # uncharacterized, explicit timing assumption
    rram_read_granularity_bits: int = 128
    gsram_read_cycles: int = 1
    gsram_scale_read_cycles: int = 1
    gsram_write_latency: int = 0
    mem_die_latency: int = 4
    latency_source: Literal["auto", "config", "rtl", "measured"] = "auto"
    ideal_mem_die: bool = True
    mem_die_channels: int = 32
    mem_die_bytes_per_cycle: int = 128
    mem_die_queue_depth: int = 32
    gsram_banks: int = 32
    source_lanes: int = 32
    gsram_payload_bits: int = 128
    gsram_scale_bits: int = 8
    gsram_write_bytes_per_cycle: int = 128
    global_sram_bytes: int = 512 * 1024
    input_double_buffer: bool = True
    logits_double_buffer: bool = True
    # Retained solely to read old configurations. Host/DMA are outside all
    # inference cost/capacity accounting, regardless of these legacy values.
    dma_staging_bytes: int = 0
    dma_status_bytes_per_descriptor: int = 0
    dma_descriptor_bytes: int = 0
    dma_descriptor_count: int = 0
    dma_latency: int = 0
    model_host_io: bool = False
    host_bus_width: int = 64
    output_format: Literal["fp32", "bf16"] = "fp32"
    enable_softmax: bool = True
    partial_bits: int = 20
    reduction_style: Literal["tree", "serial"] = "tree"
    pe_mul_cycles: int = 1
    pe_acc_cycles: int = 0
    sa_pipeline_levels: int = 0  # 0 -> natural tree depth; >0 explicit latency
    broadcast_cycles: int = 1
    broadcast_style: Literal["wide", "serial"] = "wide"
    clock_ns: float = 1.0
    enable_tag_skip: bool = True
    enable_mx_block_skip: bool = True
    # Block gating sees ONLY E8M0 scale sums. The fixed distance threshold
    # must be supplied by the RTL contract; None leaves MX gating inactive
    # rather than guessing it from computed products or partial_bits.
    mx_skip_threshold_bits: int | None = None
    mx_control_cycles: int = 1
    tag_decode_cycles: int = 1
    mx_metadata_available: bool = True
    tag_metadata_available: bool = True
    rram_enabled: bool = True
    ferram_enabled: bool = True
    ferram_kv_capacity_bytes: int = 8 * 1024 * 1024
    ferram_kv_read_bytes_per_cycle: int = 64
    ferram_kv_write_bytes_per_cycle: int = 64
    ferram_kv_read_latency: int = 8
    ferram_kv_write_latency: int = 8
    ferram_channel_mode: Literal["independent", "shared"] = "independent"
    workload: Literal["gemv", "gemm"] = "gemv"
    seed: int = 1
    energy: EnergyParams = field(default_factory=EnergyParams)

    def __post_init__(self):
        if self.physical_tile_rows is None:
            self.physical_tile_rows = self.tile_rows
        if self.physical_tile_cols is None:
            self.physical_tile_cols = self.tile_cols

    @property
    def tile_cols(self):
        return (self.k + self.tile_k - 1) // self.tile_k

    @property
    def tile_count(self):
        return self.physical_tile_rows * self.physical_tile_cols

    @property
    def pe_count(self):
        return self.tile_count * self.pe_per_tile

    @property
    def mc_count(self):
        return self.pe_count

    @property
    def max_micro_batch(self):
        # Keep the accelerator command window bounded at 32 vectors. Larger
        # workloads, including the requested B=128 case, are split into
        # successive micro-batches; the selected SRAM capacity can impose an
        # even smaller resident window.
        return 32

    def validate(self, *, allow_partial_energy=False):
        for name in ("m", "n", "k", "batch", "tile_rows", "pe_per_tile", "physical_tile_rows",
                     "physical_tile_cols", "gsram_banks", "source_lanes",
                     "gsram_write_bytes_per_cycle", "global_sram_bytes", "pe_mul_cycles",
                     "mem_die_channels", "mem_die_bytes_per_cycle", "mem_die_queue_depth",
                     "ferram_kv_read_bytes_per_cycle", "ferram_kv_write_bytes_per_cycle",
                     "mc_read_cycles", "mc_issue_cycles"):
            v = getattr(self, name)
            if not isinstance(v, int) or v < 1:
                raise ValueError(f"{name} must be a positive integer")
        for name in ("pe_acc_cycles", "sa_pipeline_levels", "broadcast_cycles",
                     "mem_die_latency", "ferram_kv_read_latency", "ferram_kv_write_latency",
                     "ferram_kv_capacity_bytes",
                     "mx_control_cycles", "tag_decode_cycles", "gsram_read_cycles", "gsram_scale_read_cycles",
                     "gsram_write_latency", "phy_read_cycles", "rram_array_read_cycles"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be nonnegative")
        if self.tile_k != 32 or (self.gsram_payload_bits, self.gsram_scale_bits) != (128, 8):
            raise ValueError("external MXFP4 requires 32 elements, 128 payload bits and 8 scale bits")
        if self.rram_read_granularity_bits not in (4, 8, 16, 32, 64, 128):
            raise ValueError("RRAM read granularity must divide the 128-bit payload into FP4 groups")
        if self.m > self.physical_tile_rows * self.pe_per_tile or self.tile_cols > self.physical_tile_cols:
            raise ValueError("matrix exceeds physical array; partition into explicit layer calls")
        if self.mem_die_count != 2 or any(v not in (0, 1) for v in self.layer_die_map.values()):
            raise ValueError("layer mapping must select one of two homogeneous Mem Dies")
        for name, choices in {"output_format": ("fp32", "bf16"), "workload": ("gemv", "gemm"),
                              "reduction_style": ("tree", "serial"), "broadcast_style": ("wide", "serial"),
                              "ferram_channel_mode": ("independent", "shared"),
                              "latency_source": ("auto", "config", "rtl", "measured")}.items():
            if getattr(self, name) not in choices:
                raise ValueError(f"invalid {name}")
        if self.weight_supply_mode not in ("rram_per_pe", "tile_cache"):
            raise ValueError("invalid weight_supply_mode")
        if self.weight_supply_mode == "rram_per_pe" and not self.rram_enabled:
            raise ValueError("rram_per_pe requires RRAM enabled")
        if not 2 <= self.partial_bits <= 52:
            raise ValueError("partial_bits must be in [2,52]")
        if (self.mx_skip_threshold_bits is not None and
                (type(self.mx_skip_threshold_bits) is not int or self.mx_skip_threshold_bits < 1)):
            raise ValueError("mx_skip_threshold_bits must be a positive integer or None")
        if not math.isfinite(self.clock_ns) or self.clock_ns <= 0:
            raise ValueError("clock_ns must be finite and positive")
        vectors = self.batch * (self.n if self.workload == "gemm" else 1)
        if vectors * self.m * self.tile_cols * 48 > 2**30:
            raise ValueError("partial working set exceeds 1 GiB; split this invocation")
        self.energy.validate(allow_missing=allow_partial_energy)
