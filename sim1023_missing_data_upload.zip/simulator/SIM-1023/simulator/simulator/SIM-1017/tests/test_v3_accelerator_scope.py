"""Accelerator-only scope and the user-specified 1024-lane non-MAC estimate."""
from dataclasses import replace
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from yrr_v3 import V3Config, V3Datasheet, run_v3, format_report
from yrr_v3.config import HOST_DMA_CONFIG_FIELDS, HOST_DMA_ENERGY_FIELDS
from yrr_v3.nonmac import command_cost
from yrr_v3.parallel_nonmac import load_parallel, validate_parallel
from tests.test_v3_parameters import complete_synthetic_contract, write_contract


def supplied_nonmac():
    data = load_parallel()
    data.update(status="USER_SUPPLIED", source="TEST_ONLY arbitrary unit prices", unit_area_um2=3.0)
    data["operations"]["softmax"].update(unit_dynamic_pj=2.5, latency_cycles=7)
    data["operations"]["residual"].update(unit_dynamic_pj=1.5, latency_cycles=3)
    return data


def test_host_dma_flags_prices_and_buffers_cannot_affect_inference():
    ds = V3Datasheet.from_component_json()
    cfg = V3Config(m=32, k=32, batch=2, enable_softmax=False)
    a = run_v3(cfg, dataset=ds)
    cfg = replace(cfg, model_host_io=True, dma_descriptor_count=10**9,
                  dma_descriptor_bytes=10**9, dma_staging_bytes=0,
                  dma_latency=10**9, host_bus_width=0)
    b = run_v3(cfg, dataset=ds)
    assert a.report["cycles"] == b.report["cycles"]
    assert a.report["energy"] == b.report["energy"]
    assert a.report["capacity"] == b.report["capacity"]
    assert a.report["area"] == b.report["area"]
    assert np.array_equal(a.logits_hardware, b.logits_hardware)
    assert not b.report["host_io"]["counted"]
    assert all(b.report["host_io"][k] == 0 for k in ("input_bytes", "output_bytes", "axi_beats", "descriptors", "descriptor_setup_cycles"))
    assert not any("host" in e.resource.lower() or "dma" in e.resource.lower() for e in b.trace)
    assert "host_pj" not in b.report["energy"]["components_pj"]
    assert "dma_pj" not in b.report["energy"]["components_pj"]
    assert not any("host" in k or "dma" in k for k in b.report["uncalibrated_energy_parameters"])
    assert HOST_DMA_CONFIG_FIELDS <= b.report["inactive_config_fields"].keys()
    assert "Host/DMA/provisioning costs excluded" in format_report(b)


def test_exact_global_buffer_capacity_has_no_dma_reservation():
    # One input = 17B, one output = 128B; both ping-pong => 290B.
    cfg = V3Config(m=32, k=32, batch=2, enable_softmax=False, global_sram_bytes=290)
    r = run_v3(cfg, dataset=V3Datasheet.from_component_json()).report
    assert r["capacity"]["allocated_global_sram_bytes"] == 290
    assert r["capacity"]["micro_batch"] == 1
    assert r["capacity"]["micro_batch_count"] == 2
    assert all(r["capacity"][k] == 0 for k in ("dma_descriptor_bytes", "dma_status_bytes", "dma_staging_bytes"))


def test_parallel_nonmac_energy_and_area_scale_but_latency_does_not():
    ds = replace(V3Datasheet.from_component_json(), nonmac_parallel=supplied_nonmac())
    cfg = V3Config(m=32, k=32, batch=2)
    result = run_v3(cfg, dataset=ds)
    r = result.report
    assert r["energy"]["softmax_pj"] == 2.5*1024*2
    assert r["energy"]["nonmac_staging_pj"] == 0
    assert r["cycles"]["softmax"] == 7
    events = [e for e in result.trace if e.operation == "stable_softmax"]
    assert len(events) == 2 and all(e.end_cycle-e.start_cycle == 7 for e in events)
    assert r["cycles"]["resource_busy_cycles"]["FP32 non-MAC"] == 14
    assert not any(e.operation == "reduce_to_fp32_scratch" for e in result.trace)
    assert r["area"]["components"]["nonmac_parallel_1024"]["total_um2"] == 3*1024
    one = run_v3(replace(cfg,batch=1),dataset=ds)
    assert one.report["area"] == r["area"]
    assert r["nonmac"]["measurement_status"] == "USER_SUPPLIED_ESTIMATE"
    assert "parallel softmax vector latency" not in r["latency"]["uncharacterized"]
    assert r["energy"]["total_pj"] is None  # Other components still missing.
    np.testing.assert_allclose(result.softmax_output.sum(axis=-1), 1, rtol=1e-6)


def test_parallel_cost_tracks_function_calls_and_rejects_split_softmax():
    data = supplied_nonmac()
    c = command_cost(data,"residual",2051,2)
    assert c.elements == 4102 and c.commands == 6
    assert c.pj == 1.5*1024*6 and c.cycles == 3*6
    for op,n in (("softmax",1025),("rmsnorm",2048)):
        try:
            command_cost(data,op,n)
        except ValueError as e:
            assert "independent chunks" in str(e)
        else:
            raise AssertionError("nonlocal reduction was incorrectly partitioned")


def test_pending_nonmac_keeps_function_and_unknown_costs():
    ds = V3Datasheet.from_component_json()
    result = run_v3(V3Config(m=32,k=32),dataset=ds)
    r = result.report
    assert r["nonmac"]["parallel_lanes"] == 1024
    assert r["nonmac"]["measurement_status"] == "PENDING"
    assert r["energy"]["softmax_pj"] is None
    assert r["area"]["components"]["nonmac_parallel_1024"]["total_um2"] is None
    assert r["capacity"]["softmax_workspace_bytes"] is None
    assert not r["latency"]["complete_characterization"]
    supplied = run_v3(V3Config(m=32,k=32),dataset=replace(ds,nonmac_parallel=supplied_nonmac()))
    assert np.array_equal(result.logits_hardware,supplied.logits_hardware)
    assert np.array_equal(result.softmax_output,supplied.softmax_output)
    try:
        command_cost(ds.nonmac_parallel,"softmax",32)
    except ValueError as e:
        assert "PENDING" in str(e)
    else:
        raise AssertionError("pending cost leaked into the complete LLM cost ledger")


def test_unit_parameters_reject_invalid_values_and_clock_disagreement():
    for key,val in (("unit_dynamic_pj",True),("unit_dynamic_pj",-1),
                    ("unit_dynamic_pj",float("nan")),("latency_cycles",1.5),("latency_cycles",0)):
        data = supplied_nonmac()
        data["operations"]["softmax"][key] = val
        try:
            validate_parallel(data)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid unit characterization accepted")
    data = supplied_nonmac()
    data["clock_ns"] = 2
    try:
        run_v3(V3Config(m=32,k=32),dataset=replace(V3Datasheet.from_component_json(),nonmac_parallel=data))
    except ValueError as e:
        assert "clock" in str(e)
    else:
        raise AssertionError("inconsistent clocks accepted")


def test_parallel_json_loader_and_optional_legacy_host_fields():
    with TemporaryDirectory() as tmp:
        p = Path(tmp)/"unit.json"
        p.write_text(json.dumps(supplied_nonmac()),encoding="utf-8")
        ds = V3Datasheet.from_component_json().with_nonmac_parameters(p)
        assert ds.nonmac_parallel["unit_area_um2"] == 3
        raw = complete_synthetic_contract()
        raw["timing"].pop("host_dma_setup_cycles",None)
        for key in HOST_DMA_CONFIG_FIELDS:
            raw["config_overrides"].pop(key,None)
        for key in HOST_DMA_ENERGY_FIELDS:
            raw["energy"].pop(key,None)
        raw["area"].pop("dma_mm2")
        old = V3Datasheet.from_1017_calibration(write_contract(tmp,raw))
        r = run_v3(V3Config(m=32,k=32,enable_softmax=False),dataset=old).report
        assert r["evaluation_scope"]["dma_included"] is False
        assert "dma_mm2" not in r["area"]


def test_host_memory_helpers_return_no_energy_latency_or_missing_cost():
    from tests.hardware_fixture import synthetic_prices
    from yrr_v3.llm.cost import Cost
    c = Cost.from_prices(synthetic_prices())
    for tx in (c.mem_read(128,origin="host"),c.mem_write(128,origin="host")):
        assert tx.pj == 0 and tx.ns == 0 and tx.cycles == 0
        assert not tx.pending_components
