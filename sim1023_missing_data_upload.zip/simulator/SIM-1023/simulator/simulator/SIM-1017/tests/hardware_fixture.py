"""Explicit synthetic test data. These numbers are NOT hardware measurements."""
from yrr_v3 import V3Config, EnergyParams, V3Datasheet
from yrr_v3.rtl_dataset import ENERGY_FIELDS
from yrr_v3.llm.config import LlmPrices, prices_from_dataset
from yrr_v3.nonmac import OPS, VECTOR, SCOPE


def synthetic_nonmac(clock_ns=1.0, revision="synthetic contract test only"):
    """Arbitrary TEST ONLY records; never inferred hardware characterization."""
    profiles = {}
    for op, code in OPS.items():
        lengths = range(1, 1025) if op in VECTOR else (1,)
        profiles[op] = {str(n): dict(cycles=200+code+n*7, dynamic_pj=3.0+code+n/10,
            read_count=(3*n if op in ("softmax", "rmsnorm") else 5*n if op=="layernorm" else
                        2*n if op in ("residual", "rope_vector", "swiglu_vector") else n if op in VECTOR else 0),
            write_count=2*n if op=="softmax" else n if op in VECTOR else 0,
            report="TEST_ONLY: arbitrary synthetic profile") for n in lengths if op!="rope_vector" or n%2==0}
    return dict(implementation="llm_nonmac_fp32", max_vector_length=1024, clock_ns=clock_ns,
        scope=SCOPE, rtl_revision=revision, dw_version="TEST_ONLY", scratch_implementation="TEST_ONLY",
        activity_policy="TEST_ONLY", reports=["TEST_ONLY"], profiles=profiles,
        reduce_staging={str(n):dict(cycles=n+3,dynamic_pj=n/20,read_count=0,write_count=n,
            report="TEST_ONLY") for n in range(1,1025)})


def synthetic_dataset():
    prices = {name: 1.0 for name in LlmPrices.__dataclass_fields__
              if name not in ("provenance", "f_max_mhz", "block_pj_by_mac", "nonmac")}
    prices.update(block_pj=500.0, block_cycles=9, macs_per_block=1024**2,
                  phy_bpc=128, feram_rd_pj_per_128b=None,
                  feram_wr_pj_per_128b=None, feram_rd_ns=None, feram_wr_ns=None)
    e = EnergyParams(**{k: 0.01 for k in ENERGY_FIELDS}, provenance="test-fixture")
    for name in prices.keys() & ENERGY_FIELDS:
        prices[name] = getattr(e, name)
    return V3Datasheet("synthetic-test-fixture", e, 4, {k:"test-fixture:unit-test-only" for k in ENERGY_FIELDS},
                       rtl_params={"llm_prices": prices, "nonmac":synthetic_nonmac()},
                       config_values={"weight_supply_mode":"tile_cache"}, production=False)


SYNTHETIC = synthetic_dataset()


def run_test_v3(cfg=None, *, dataset=None, **kwargs):
    from yrr_v3 import run_v3
    return run_v3(cfg, dataset=synthetic_dataset() if dataset is None else dataset, **kwargs)


def synthetic_prices():
    return prices_from_dataset(synthetic_dataset())
