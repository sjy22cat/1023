"""The skip decision must precede the work it claims to eliminate.

All concrete T values below are boundary-test fixtures, not RTL calibration.
"""
from dataclasses import replace
import json
import tempfile
from pathlib import Path
import numpy as np
from yrr_v3 import V3Config, decide_scale_blocks


from tests.hardware_fixture import SYNTHETIC as TEST_DATASET, synthetic_dataset, run_test_v3 as run_v3

def case(m=64, threshold=20, **kw):
    cfg = V3Config(m=m, n=1, k=64, tile_rows=(m+31)//32,
                   mx_skip_threshold_bits=threshold, enable_softmax=False,
                   latency_source="config", **kw)
    data = dict(weight_payload=np.full((m,64), 2, np.uint8),
                weight_scale=np.full((m,2), 127, np.uint8),
                input_payload=np.full((1,64), 2, np.uint8),
                input_scale=np.full((1,2), 127, np.uint8))
    return cfg, data


def test_scale_only_threshold_boundary_and_no_uint8_wrap():
    w = np.array([[127,108,107,106], [254,235,234,233]], np.uint8)
    x = np.full(4, 254, np.uint8)
    d = decide_scale_blocks(w, x, threshold_bits=20)
    np.testing.assert_array_equal(d.distance, [[0,19,20,21]]*2)
    np.testing.assert_array_equal(d.skip, [[False,False,True,True]]*2)
    assert d.esum[1,0] == 254 and d.emax[0] == 127
    extremes = decide_scale_blocks(np.array([[0,254]], np.uint8),
                                   np.array([0,254], np.uint8), threshold_bits=20)
    np.testing.assert_array_equal(extremes.distance, [[508,0]])


def test_payload_and_product_e3_never_change_block_gate():
    cfg, data = case()
    data['weight_scale'][:,0] = 107  # d=20: skip, whatever E3/M10 would have been
    a = run_v3(cfg, dataset=TEST_DATASET, **data)
    data['weight_payload'][:,:32] = 7  # maximum magnitude rather than one
    data['input_payload'][:,:32] = 7
    b = run_v3(cfg, dataset=TEST_DATASET, **data)
    np.testing.assert_array_equal(a.mx_skip_mask, b.mx_skip_mask)
    np.testing.assert_array_equal(a.mx_distance, b.mx_distance)
    np.testing.assert_array_equal(a.logits_hardware, b.logits_hardware)
    assert a.report['skip']['skipped_blocks'] == cfg.m
    assert a.report['skip']['e3_m10_used_for_decision'] is False
    data['weight_payload'][:,:] = 0
    z = run_v3(cfg, dataset=TEST_DATASET, **data)
    np.testing.assert_array_equal(a.mx_skip_mask, z.mx_skip_mask)
    assert z.report['skip']['active_source_blocks'] == 1
    assert z.report['architecture']['valid_macs'] == 0


def test_zero_payload_does_not_remove_scale_from_emax():
    cfg, data = case(m=1, threshold=2)
    data['weight_scale'][:,0] = 124
    data['input_payload'][:,32:] = 0
    r = run_v3(cfg, dataset=TEST_DATASET, **data)
    # Highest Esum belongs to a zero payload. Scale-only hardware cannot
    # inspect that zero in advance and must still use it in Emax.
    np.testing.assert_array_equal(r.mx_skip_mask, [[[True,False]]])
    assert r.mx_emax[0,0] == 0
    assert r.logits_hardware[0,0] == 0
    assert r.logits_reference[0,0] == 4


def test_shared_tile_and_source_only_skip_when_every_receiver_skips():
    cfg, data = case()
    data['weight_scale'][:,0] = 100
    data['weight_scale'][0,0] = 127  # a single PE still needs K block zero
    r = run_v3(cfg, dataset=TEST_DATASET, **data)
    t = r.report['traffic']
    assert r.report['skip']['active_blocks'] == 65
    assert r.report['skip']['active_tile_receivers'] == 3
    assert r.report['skip']['active_source_blocks'] == 2
    assert t['global_sram_payload_read_bytes'] == 32
    assert t['tile_input_bytes'] == 3*17
    assert t['pe_input_block_deliveries'] == 65
    assert r.report['architecture']['valid_macs'] == 65*32


def test_skipped_payload_still_pays_scale_scan_and_predecision_latency():
    cfg, data = case(model_host_io=True)
    data['weight_scale'][:,0] = 100
    r = run_v3(cfg, dataset=TEST_DATASET, **data)
    t = r.report['traffic']
    assert t['global_sram_payload_read_bytes'] == 16
    assert t['global_sram_scale_sideband_bytes'] == 2
    assert t['global_sram_bank_read_bytes'] == 18
    assert t['mx_weight_scale_metadata_read_bytes'] == 64*2
    assert t['global_sram_all_read_bytes'] == 18
    # Full input already resides in SRAM; Host/DMA are outside this boundary.
    assert t['input_bytes_per_sample'] == 34
    assert r.report['host_io']['input_bytes'] == 0
    ops = ['input_scale_read', 'scale_block_decision',
           'input_prefetch', 'input_broadcast', 'mxfp4_to_tag_fp', 'array_mac', 'aligned_reduce']
    events = [next(e for e in r.trace if e.operation == op) for op in ops]
    assert all(a.end_cycle <= b.start_cycle for a,b in zip(events, events[1:]))
    ctrl = events[1]
    assert ctrl.metadata['e3_m10_used'] is False
    assert ctrl.end_cycle-ctrl.start_cycle == cfg.mx_control_cycles
    dense = run_v3(replace(cfg, enable_mx_block_skip=False), dataset=TEST_DATASET, **data)
    assert r.report['energy']['pe_mac_pj'] < dense.report['energy']['pe_mac_pj']
    assert r.report['energy']['broadcast_pj'] < dense.report['energy']['broadcast_pj']
    # Counts reconcile with trace without dropping metadata reads.
    reads = sum(e.bytes for e in r.trace if e.operation in ('input_prefetch','input_scale_read'))
    assert reads == t['global_sram_bank_read_bytes']


def test_unconfirmed_threshold_disables_skip_without_guessing():
    cfg, data = case(threshold=None)
    data['weight_scale'][:,0] = 100
    r = run_v3(cfg, dataset=TEST_DATASET, **data)
    assert not r.mx_skip_mask.any()
    assert r.report['skip']['requested'] is True
    assert r.report['skip']['mx_block_skip'] is False
    assert 'pending' in r.report['skip']['status']
    for field in ('enable_mx_block_skip', 'mx_metadata_available'):
        opts = {field:False, 'mx_skip_threshold_bits':20}
        d = run_v3(replace(cfg, **opts), dataset=TEST_DATASET, **data)
        assert not d.mx_skip_mask.any()


def test_scale_masks_survive_exports():
    cfg, data = case()
    data['weight_scale'][:,0] = 100
    r = run_v3(cfg, dataset=TEST_DATASET, **data)
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp)
        r.export_rtl_vectors(p/'vectors.npz')
        r.export_mx_control(p/'mx.json')
        with np.load(p/'vectors.npz') as v:
            np.testing.assert_array_equal(v['mx_skip_mask'], r.mx_skip_mask)
            np.testing.assert_array_equal(v['mx_esum'], r.mx_esum)
            assert v['mx_compute_mask'].shape == (1,64,2)
        ctrl = json.loads((p/'mx.json').read_text(encoding='utf-8'))[0]
        assert ctrl['threshold_bits'] == 20
        assert ctrl['max_exponent_per_output'] == [0]*64
        assert ctrl['decision_source'].startswith('E8M0 scales only')


def test_invalid_threshold_is_rejected():
    for threshold in (0,-1,True,2.5):
        try:
            V3Config(mx_skip_threshold_bits=threshold).validate()
        except ValueError:
            pass
        else:
            raise AssertionError('invalid threshold must fail')
