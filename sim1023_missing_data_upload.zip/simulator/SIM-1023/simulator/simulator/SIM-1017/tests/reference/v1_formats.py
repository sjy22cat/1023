"""数值格式与计算核的位精确模型。

本模块是 RTL 的**逐位镜像**，不是"数值近似"：
``pe_core()`` 与 ``shift_adder`` 的每一步移位/舍入/进位都与
``RTL/rtl/pe_core.v`` / ``RTL/rtl/shift_adder.v`` 一一对应，
因此可以与 RTL 的黄金转储做逐位相等断言（见 ``tests/test_golden.py``）。

格式定义见 ``RTL/rtl/yrr_fmt_defs.vh``：

    W4/D4   {S,E[1:0],M}  bias=1，正规数隐含前导 1，仅全零码字表示 0
    A5      {S,E[2:0],M}  bias=3，E==0 为次正规
    PEO15   {S,E[2:0],MANT[9:0],HIDDEN} + exp_hi 边带 = e8[7:3]
    E8M7S1  {S,E[7:0],MANT[6:0]} bias=127
    FP32    IEEE-754 单精度
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import List, Sequence, Tuple

# ---------------------------------------------------------------------------
# 常量（对应 yrr_fmt_defs.vh）
# ---------------------------------------------------------------------------
E8_BIAS = 127
PEO_E8_BASE = 121          # e8 = msb_pos + 121
A5_K_MIN = -3
A5_FIX_SHIFT = 6           # PE 定点累加器二进制点 2^-6

A5_SIGW = 11               # PEO15 有效位宽 = 隐藏位 + 10 尾数
ACC_M = 7                  # E8M{ACC_M}S1
ACC_SIGW = ACC_M + 1       # 含隐藏位
SA_W = 48                  # 移位加法器对齐工作区宽度
SA_SW = 50                 # 加法器位宽


# ===========================================================================
# 1. 格式编解码
# ===========================================================================
def w4_to_a5(w: int) -> int:
    """W4(4bit) -> A5(5bit) 无损转换，与 ``yrr_w4_to_a5`` 逐位一致。

        w[2:0]==0 ? {S, 3'd0, 1'b0} : {S, E+2, M}

    校验（16 个码字映射到 16 个互异 A5 码字且数值相等）见 tests。
    """
    w &= 0xF
    s = (w >> 3) & 1
    if (w & 0x7) == 0:
        return s << 4
    e2 = (w >> 1) & 0x3
    m = w & 1
    return (s << 4) | (((e2 + 2) & 0x7) << 1) | m


def a5_sig(a: int) -> int:
    """A5 -> SIG ∈ {0,1,2,3}：E==0 时无隐藏位，取 {1'b0,M}。"""
    a &= 0x1F
    e = (a >> 1) & 0x7
    m = a & 1
    return m if e == 0 else (2 | m)


def a5_k(a: int) -> int:
    """A5 -> K ∈ [-3,3]：E==0 时指数固定为 -3。"""
    a &= 0x1F
    e = (a >> 1) & 0x7
    return A5_K_MIN if e == 0 else e - 4


def a5_value(a: int) -> float:
    a &= 0x1F
    mag = a5_sig(a) * (2.0 ** a5_k(a))
    return -mag if (a >> 4) & 1 else mag


def w4_value(w: int) -> float:
    """W4 实数取值。网格 {0, ±0.5, ±0.75, ±1, ±1.5, ±2, ±3, ±4, ±6}。"""
    w &= 0xF
    if (w & 0x7) == 0:
        return -0.0 if (w >> 3) & 1 else 0.0
    base = {0: 0.5, 1: 1.0, 2: 2.0, 3: 4.0}[(w >> 1) & 0x3]
    mag = base * (1.0 + 0.5 * (w & 1))
    return -mag if (w >> 3) & 1 else mag


def peo15_value(peo15: int, exp_hi: int) -> float:
    """PEO15 + exp_hi -> 实数：e8 = {exp_hi, E[2:0]}，value = (1.MANT)*2^(e8-127)。

    **零的判据是 HIDDEN 位**，不是指数：PE 对零输出 ``{S, 14'b0}``，
    此时 exp_hi 仍是 e8=p+121 算出的残值（p=0 -> 121 -> 15），
    拿 e8 判零会把零读成 2^-7。
    """
    s = (peo15 >> 14) & 1
    e3 = (peo15 >> 11) & 0x7
    mant = (peo15 >> 1) & 0x3FF
    hid = peo15 & 1
    if hid == 0:
        # 非零结果的有效位一定归一化到 bit10（见 pe_core 的 sigx 构造），
        # 因此 HIDDEN==0 当且仅当数值为 0。
        return 0.0
    e8 = ((exp_hi & 0x1F) << 3) | e3
    mag = (1.0 + mant / 1024.0) * (2.0 ** (e8 - E8_BIAS))
    return -mag if s else mag


def fp32_to_float(bits: int) -> float:
    return struct.unpack("<f", struct.pack("<I", bits & 0xFFFFFFFF))[0]


def float_to_fp32(x: float) -> int:
    return struct.unpack("<I", struct.pack("<f", x))[0]


def ldexp2(x: float, k: int) -> float:
    return x * (2.0 ** k)


# ===========================================================================
# 2. PE 计算核
# ===========================================================================
@dataclass
class PeResult:
    """单 block PE 结果。"""

    peo15: int          # {S, E[2:0], MANT[9:0], HIDDEN}
    exp_hi: int         # e8[7:3]
    exact_sum: int      # 定点累加整数和（二进制点 2^-6），精确无误差
    nonzero: bool

    @property
    def sig11(self) -> int:
        """11bit 有效位（含隐藏位），移位加法器的输入。"""
        return ((self.peo15 & 1) << 10) | ((self.peo15 >> 1) & 0x3FF)

    @property
    def sign(self) -> int:
        return (self.peo15 >> 14) & 1

    @property
    def e8(self) -> int:
        return ((self.exp_hi & 0x1F) << 3) | ((self.peo15 >> 11) & 0x7)

    @property
    def value(self) -> float:
        return peo15_value(self.peo15, self.exp_hi)


def _msb(v: int) -> int:
    """最高置位 bit 下标；v==0 返回 0（与 yrr_msb25/49/50 一致）。"""
    return v.bit_length() - 1 if v else 0


def pe_core(wgt: Sequence[int], dat: Sequence[int]) -> PeResult:
    """与 ``pe_core.v`` 逐位一致的 32 lane **A5** 乘累加 + PEO15 归一化。

    定点累加：contrib = SIGw*SIGd << (Kw+Kd+6)，全部为精确整数。

    ！！入参必须是 A5 码字（PE 的输入端已经是转换后的 5bit）。
      若手上是 Mem Die 里读出的 W4 码字，请用 :func:`pe_core_w4`，
      否则 A5 解码会作用在错误的码字上（指数偏置 1 被当成 3）。
    """
    assert len(wgt) == len(dat)
    total = 0
    for aw, ad in zip(wgt, dat):
        sw = (aw >> 4) & 1
        sd = (ad >> 4) & 1
        sp = a5_sig(aw) * a5_sig(ad)               # 0..9
        kp = a5_k(aw) + a5_k(ad)                   # -6..6
        mag = sp << (kp + A5_FIX_SHIFT)            # 精确整数
        total += -mag if (sw ^ sd) else mag

    sgn = 1 if total < 0 else 0
    mag_abs = -total if sgn else total
    is_zero = mag_abs == 0
    p = _msb(mag_abs)                              # 0..20

    # 11bit 有效位（含隐藏位）
    sh_r = abs(p - 10)
    sigx = (mag_abs >> sh_r) if p >= 10 else (mag_abs << sh_r)

    # RNE：round/sticky/lsb
    has_rem = p > 10
    rsh = sh_r - 1 if has_rem else 0
    rb = (mag_abs >> rsh) & 1 if has_rem else 0
    stk = 1 if (has_rem and (mag_abs & ((1 << rsh) - 1))) else 0
    rup = rb & (stk | (sigx & 1))

    sig_p1 = sigx + rup                            # 12bit
    ovf = (sig_p1 >> 11) & 1
    sig_f = ((1 << 10) | ((sig_p1 >> 1) & 0x3FF)) if ovf else (sig_p1 & 0x7FF)

    e8 = p + PEO_E8_BASE + ovf

    if is_zero:
        peo15 = sgn << 14
    else:
        peo15 = ((sgn & 1) << 14) | ((e8 & 0x7) << 11) \
              | ((sig_f & 0x3FF) << 1) | ((sig_f >> 10) & 1)
    return PeResult(peo15=peo15, exp_hi=(e8 >> 3) & 0x1F,
                    exact_sum=total, nonzero=not is_zero)


def pe_core_w4(wgt_w4: Sequence[int], dat_w4: Sequence[int]) -> PeResult:
    """便捷入口：入参为 W4 码字，内部先做 4b->5b 无损转换再进 PE。

    与 RTL 的数据通路一致：Mem Die 读出的是 W4，
    权重经 ``wcv``、数据经 ``dcv``（均为 fmt_conv_4to5）后才进 PE。
    """
    return pe_core([w4_to_a5(w) for w in wgt_w4],
                   [w4_to_a5(d) for d in dat_w4])


# ===========================================================================
# 3. 移位加法器（32 block 串行累加 -> FP32）
# ===========================================================================
def _shr_sticky49(v: int, s: int) -> int:
    """``yrr_shr_sticky49``：逻辑右移并把移出的低位 OR 进 bit0。"""
    if s == 0:
        return v
    if s >= 49:
        return 1 if v else 0
    st = 1 if (v & ((1 << s) - 1)) else 0
    return (v >> s) | st


@dataclass
class SaStep:
    """移位加法器**第 idx 拍结束后**的轨迹快照。

    这是详解文档 6.5 节那张 32 行表的机器可读来源：``exact_sum`` 是双精度
    精确累加和，``acc_value`` 是 E8M7S1 累加器的实值，二者之差就是该拍的
    顺序相关舍入误差。**这些量只用于观测，不参与任何运算** —— 记录它们
    不会改变累加结果（黄金比对可证）。
    """

    idx: int              # 第几拍（0 起）
    blk: int              # block 序号
    in_e8: int            # 本拍输入（PEO15 有效位）的 e8
    in_sig: int           # 本拍输入的 11bit 有效位（含隐藏位）
    in_value: float       # 本拍输入实值
    exact_sum: float      # 到本拍为止的精确实数累加和（双精度）
    acc_sig: int          # 累加器有效位（8bit，含隐藏位）
    acc_e8: int
    acc_zero: bool

    @property
    def acc_value(self) -> float:
        """累加器实值 = SIG/2^7 * 2^(e8-127) = SIG * 2^(e8-134)。"""
        if self.acc_zero:
            return 0.0
        return self.acc_sig * (2.0 ** (self.acc_e8 - 134))

    @property
    def error(self) -> float:
        """当拍误差 = 累加器实值 - 精确和（就是舍入丢掉的部分）。"""
        return self.acc_value - self.exact_sum

    @property
    def quant_step(self) -> float:
        """量化步长 = 累加器 7bit 尾数的 1 LSB = 2^(e8-134)。"""
        if self.acc_zero:
            return 0.0
        return 2.0 ** (self.acc_e8 - 134)


@dataclass
class ShiftAdder:
    """``shift_adder.v`` 的位精确模型（E8M{ACC_M}S1 累加器）。"""

    acc_sign: int = 0
    acc_e8: int = 0
    acc_sig: int = 0
    acc_zero: bool = True
    count: int = 0
    _fp32: int = 0
    _exact_running: float = 0.0
    trace: List[SaStep] = field(default_factory=list)

    # ---- 首拍装载路径：11bit 有效位 RNE 压缩到 ACC_SIGW ----
    @staticmethod
    def _load(i_sig: int, i_e8: int) -> Tuple[int, int]:
        drop = max(A5_SIGW - ACC_SIGW, 0)
        trunc = (i_sig >> drop) & ((1 << ACC_SIGW) - 1)
        rb = (i_sig >> (drop - 1)) & 1 if drop > 0 else 0
        stk = 1 if (drop > 1 and (i_sig & ((1 << (drop - 1)) - 1))) else 0
        rup = rb & (stk | (trunc & 1))
        p = trunc + rup
        ovf = (p >> ACC_SIGW) & 1
        sig = ((1 << ACC_M) | ((p >> 1) & ((1 << ACC_M) - 1))) if ovf \
            else (p & ((1 << ACC_SIGW) - 1))
        return sig, (i_e8 + ovf) & 0xFF

    def clear(self) -> None:
        self.acc_sign = 0
        self.acc_e8 = 0
        self.acc_sig = 0
        self.acc_zero = True
        self.count = 0
        self._exact_running = 0.0
        self.trace.clear()

    def push(self, sign: int, e8: int, sig: int) -> None:
        """送出一个 block 结果（对应 RTL 的一拍 i_valid）。

        记录一拍轨迹后再退出。轨迹只是旁路观测：它读的是输入的 (sign,e8,sig)
        与累加器的状态，不写任何参与运算的量，因此不可能改变黄金比对结果。
        """
        self.count += 1
        sig11 = sig & ((1 << A5_SIGW) - 1)
        in_val = sig11 * (2.0 ** (e8 - 137))       # 11bit 有效位 -> 实值
        if sign & 1:
            in_val = -in_val
        self._exact_running += in_val
        self._step(sign, e8, sig)
        self.trace.append(SaStep(
            idx=len(self.trace), blk=self.count - 1,
            in_e8=e8 & 0xFF, in_sig=sig11, in_value=in_val,
            exact_sum=self._exact_running,
            acc_sig=self.acc_sig, acc_e8=self.acc_e8, acc_zero=self.acc_zero))

    def _step(self, sign: int, e8: int, sig: int) -> None:
        """一拍移位累加（``push`` 的运算本体）。"""
        in_zero = (sig & ((1 << A5_SIGW) - 1)) == 0

        if self.acc_zero:
            if in_zero:
                self.acc_sign, self.acc_e8 = 0, 0
                self.acc_sig, self.acc_zero = 0, True
            else:
                s, e = self._load(sig, e8)
                self.acc_sign, self.acc_e8, self.acc_sig = sign & 1, e, s
                self.acc_zero = False
            return

        if in_zero:
            return

        acc_ws = self.acc_sig << (SA_W - ACC_SIGW)
        in_ws = (sig & ((1 << A5_SIGW) - 1)) << (SA_W - A5_SIGW)

        diff = e8 - self.acc_e8                       # 9bit 有符号
        d_abs = abs(diff)
        sh = min(d_abs, SA_W - 1)

        a_sft = _shr_sticky49(acc_ws, sh)
        b_sft = _shr_sticky49(in_ws, sh)
        if diff > 0:
            a_al, b_al, e_cm = a_sft, in_ws, e8
        else:
            a_al, b_al, e_cm = acc_ws, b_sft, self.acc_e8

        # 50bit 有符号加法（容纳 2^48 进位）
        ws_a = -a_al if self.acc_sign else a_al
        ws_b = -b_al if (sign & 1) else b_al
        s = ws_a + ws_b
        sum_mag = -s if s < 0 else s
        add_zero = (sum_mag == 0)
        q = _msb(sum_mag)

        qd = abs(q - (SA_W - 1))
        nmag = (sum_mag >> qd) if q > (SA_W - 1) else (sum_mag << qd)

        trunc = (nmag >> (SA_W - ACC_SIGW)) & ((1 << ACC_SIGW) - 1)
        rb = (nmag >> (SA_W - ACC_SIGW - 1)) & 1
        stk = 1 if (nmag & ((1 << (SA_W - ACC_SIGW - 1)) - 1)) else 0
        rup = rb & (stk | (trunc & 1))
        p = trunc + rup
        ovf = (p >> ACC_SIGW) & 1
        sig_r = ((1 << ACC_M) | ((p >> 1) & ((1 << ACC_M) - 1))) if ovf \
            else (p & ((1 << ACC_SIGW) - 1))

        e_calc = e_cm + q - (SA_W - 1) + ovf
        e_final = 0 if e_calc < 0 else (0xFF if (e_calc >> 8) else (e_calc & 0xFF))

        if add_zero:
            self.acc_sign, self.acc_e8, self.acc_sig, self.acc_zero = 0, 0, 0, True
        else:
            self.acc_sign = 1 if s < 0 else 0
            self.acc_e8 = e_final
            self.acc_sig = sig_r
            self.acc_zero = False

    @property
    def fp32(self) -> int:
        if self.acc_zero:
            return 0
        return ((self.acc_sign & 1) << 31) | ((self.acc_e8 & 0xFF) << 23) \
             | ((self.acc_sig & ((1 << ACC_M) - 1)) << (23 - ACC_M))


# ===========================================================================
# 4. 端到端参考模型
# ===========================================================================
def block_codes(nblk: int, nlane: int, wfn, dfn) -> List[Tuple[List[int], List[int]]]:
    """构造 32x32 的 W4/D4 码字（与 RTL 测试平台的确定性哈希一致）。"""
    out = []
    for b in range(nblk):
        out.append(([wfn(b, l) for l in range(nlane)],
                    [dfn(b, l) for l in range(nlane)]))
    return out


def reference_pipeline(codes, do_round=True):
    """完整参考流水：W4->A5 转换 -> PE(每 block) -> 移位加法器 -> FP32。

    ``codes`` 是 Mem Die 中的 W4 码字对（与 RTL 主机预载的内容一致）。
    返回 ``(fp32, pe_results, sa)``。
    """
    sa = ShiftAdder()
    sa.clear()
    results = []
    for wgt, dat in codes:
        r = pe_core_w4(wgt, dat)
        results.append(r)
        sa.push((r.peo15 >> 14) & 1,
                r.e8,
                ((r.peo15 & 1) << 10) | ((r.peo15 >> 1) & 0x3FF))
    return sa.fp32, results, sa


def golden_real(codes) -> float:
    """双精度实数参考：sum_b sum_l (w4_value * w4_value)。"""
    total = 0.0
    for wgt, dat in codes:
        for w, d in zip(wgt, dat):
            total += w4_value(w) * w4_value(d)
    return total
