# 历史测试参考

`v1_formats.py` 是从原工程 V1 的 `yrr_v1/formats.py` 原样复制的测试参考。
当前回归仅从中提取 `w4_to_a5()`，核查全部 16 个输入码字与 V3 一致。
它不参与 V3 的运行时计算，不代表 V3 采用 V1 的其他数值或架构规则。
原始位置和文件哈希保存在根目录的 `PACKAGE_SOURCE.json`。

`legacy_llm_checks.py` 从旧 `tests/test_llm.py` 归档，依赖已经移除的估算数据集和旧账本断言，不能作为当前测试运行。当前入口为 `tests/run_current.py`；文件名避免进入 pytest 的默认发现范围。
