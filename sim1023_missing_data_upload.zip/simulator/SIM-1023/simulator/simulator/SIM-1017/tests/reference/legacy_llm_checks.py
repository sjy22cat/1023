"""历史测试档案：依赖已移除的旧数据集/估算 API，不属于当前回归和 pytest 自动发现。

当前验证请运行 tests/run_current.py；不要为通过本历史断言恢复估算入口。

LLM 推理层（`yrr_v3/llm/`）的旧自检：切块算术、单价、搬运、容量、MXFP4、确定性、
调度完整性、两种计费、端到端链路、回归隔离。

**只读**现有模型与数据集（`run_v3` / `V3Datasheet`），不改它们一行 —— 所以本文件可以
在现有 45 项自检之外独立跑，且不改变现有 report 的任何键。

    python tests/test_llm.py
    python -m pytest tests/test_llm.py
"""
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from yrr_v3 import V3Config, V3Datasheet, run_v3                        # noqa: E402
from yrr_v3.formats import FP4_VALUES, decode_fp4                      # noqa: E402
from yrr_v3.llm import (ByteTokenizer, Cost, Core, Ledger, LlmConfig,   # noqa: E402
                        LlmPrices, MemDie, ModelOverride, Qwen3Config,
                        Qwen3Params, SimContext, build_weight_image, calib,
                        format_report, metrics, mxfp4, prices_from_dataset,
                        provenance, run_llm)
from yrr_v3.llm.core import GSRAM_BYTES, REGFILE_BYTES                  # noqa: E402
from yrr_v3.llm.cost import BLOCK, LINE_BYTES, LedgerMark, blocks       # noqa: E402
from yrr_v3.llm.inference import tokenize_prompt                        # noqa: E402
from yrr_v3.llm.schedule import mx_bytes                                # noqa: E402

# 现场测得的真实单价（= run_v3(V3Config()) 的 energy.total_pj；见 test_unit_block_price…）
BLOCK_PJ = 49325754.74803192        # pJ：一整块 [1024,1024]x[1024,1024]
BLOCK_CYCLES = 4098                 # 填充 6 + (1024-1) x 每向量 4 拍
SOFTMAX_PJ_PER_BLOCK = 1024 * 1024 * 0.10416      # 单位块自带的那 1024 行 softmax

# MXFP4 的码值集合（非负 8 个：{0,.5,1,1.5,2,3,4,6}）
CODEBOOK = sorted(set(float(v) for v in np.abs(FP4_VALUES[:8])))
# 同一组内「幅值之比」的全集 —— 用于验证一段数据确实落在 码值 x 2 的幂 上
RATIOS = {round(a / b, 6) for a in CODEBOOK for b in CODEBOOK if b > 0}


def approx(a, b, tol=1e-9):
    assert math.isclose(a, b, rel_tol=tol, abs_tol=1e-6), f"{a!r} != {b!r}"


def on_codebook(row: np.ndarray) -> bool:
    """`row` 的元素是否全是 `码值 x 2 的幂`（同一行共用一个指数）。

    做法：归一化到本行最大幅值 —— 若成立，比值必落在码值的两两之比里。
    必须在 **float64** 里比：float32 的 1/3 四舍五入到 6 位小数后与 Python 的
    `round(1/3, 6)` 不等，会假报失败。
    """
    a = np.abs(np.asarray(row, dtype=np.float64))
    m = float(a.max())
    if m == 0.0:
        return True
    return set(np.round(a / m, 6).tolist()) <= RATIOS


# --------------------------------------------------------------------------
# 冒烟配置：1 层、hidden=128。走**同一条代码路径**（同一个 `SimContext` / `run_llm`），
# 只是形状小到秒级。
# --------------------------------------------------------------------------

def small_cfg(**kw) -> LlmConfig:
    kw.setdefault("prompt_tokens", 8)
    kw.setdefault("max_new_tokens", 2)
    return LlmConfig(model=ModelOverride(hidden=128, layers=1, heads=4, kv_heads=2,
                                        head_dim=32, intermediate=256, vocab=512), **kw)


def small_qcfg() -> Qwen3Config:
    return Qwen3Config(hidden=128, layers=1, q_heads=4, kv_heads=2, head_dim=32,
                       intermediate=256, vocab=512)


_PR: LlmPrices | None = None


def prices() -> LlmPrices:
    global _PR
    if _PR is None:
        _PR = prices_from_dataset()
    return _PR


# --- 1. 切块算术（用户规则：超过 1024 才切，不足 1024 按整块计） ---------------

def test_blocks_rule():
    # 用户的例子：[1024,2048] x [2048,1024]（M=1024,N=1024,K=2048）→ k 切 2
    assert blocks(1024, 1024, 2048) == (1, 1, 2, 2)
    # decode 的 [1,1024] x [1024,2048]（M=1,N=2048,K=1024）→ n 切 2（M=1 也按整块付费）
    assert blocks(1, 2048, 1024) == (1, 2, 1, 2)
    # [1,1024] x [1024,1024] → 1 块
    assert blocks(1, 1024, 1024) == (1, 1, 1, 1)
    # M 超过 1024 也要切
    assert blocks(4096, 1024, 1024) == (4, 1, 1, 4)
    # 三维都超：2 x 3 x 2 = 12
    assert blocks(2048, 3072, 2048) == (2, 3, 2, 12)
    # 不足 1024 的每一维都只算一块（整块占用计费）
    for M, N, K in ((1, 1, 1), (1023, 1023, 1023), (1, 1024, 1024), (1024, 1, 1)):
        assert blocks(M, N, K) == (1, 1, 1, 1), (M, N, K)


def test_matmul_cost_tiles_and_accumulates():
    c = Cost.from_prices(prices())
    # 用户的例子：[1024,2048] x [2048,1024] = 2 个单位块 + 1 次累加
    mm = c.matmul(1024, 1024, 2048)
    assert (mm.bm, mm.bn, mm.bk, mm.n_blocks, mm.accum_rounds) == (1, 1, 2, 2, 1)
    approx(mm.whole_pj, 2 * c.block_pj + 1024 * prices().reduction_add_pj)
    assert mm.cycles == 2 * c.block_cycles + 1          # 2 块 + 1 拍累加
    # 不足 1024 的 skinny 矩阵：仍是一整块
    mm1 = c.matmul(1, 1024, 1024)
    assert mm1.n_blocks == 1 and mm1.accum_rounds == 0
    approx(mm1.whole_pj, c.block_pj)
    approx(mm1.cycles, c.block_cycles)
    assert mm1.unit_pj < mm1.whole_pj / 1000.0          # unit 口径只按实际 MAC 计
    # 归约轮数 = bk - 1；整块口径下参与归约的行数是 bm x 1024（阵列整块被占用）
    mm2 = c.matmul(1, 1024, 3072)
    assert (mm2.bk, mm2.n_blocks, mm2.accum_rounds) == (3, 3, 2)
    approx(mm2.accum_whole_pj, 2 * (1 * BLOCK) * prices().reduction_add_pj)
    approx(mm2.accum_unit_pj, 2 * 1 * prices().reduction_add_pj)
    assert mm2.cycles == 3 * c.block_cycles + 2
    # M 超 1024 时归约按 bm x 1024 行算
    approx(c.matmul(2048, 1024, 2048).accum_whole_pj,
           1 * (2 * BLOCK) * prices().reduction_add_pj)
    # scaled() 只放大累计量，单次的形状不变
    s5 = mm2.scaled(5)
    assert s5.n_blocks == 15 and s5.macs == 5 * mm2.macs
    assert (s5.M, s5.N, s5.K, s5.bk, s5.accum_rounds) == (mm2.M, mm2.N, mm2.K,
                                                          mm2.bk, mm2.accum_rounds)
    assert mm2.scaled(1) is mm2                          # n = 1 直接返回自己


# --- 2. 单价**现场**取自现有模型（防漂移） -----------------------------------

def test_unit_block_price_matches_live_run_v3():
    rep = run_v3(V3Config()).report          # batch = 1024 的默认口径
    pipe = rep["cycles"]["pipelined"]
    live_cycles = pipe["fill_cycles"] + (1024 - 1) * pipe["cycles_per_vector"]
    pr = prices()
    # 单价不是抄来的常数：与现算结果逐位相同
    approx(pr.block_pj, rep["energy"]["total_pj"], 1e-15)
    assert pr.block_cycles == live_cycles
    assert (pr.block_cycles, pr.macs_per_block) == (BLOCK_CYCLES, 1024 ** 3)
    approx(pr.block_pj, BLOCK_PJ, 1e-15)
    approx(pr.block_pj_by_mac, 1024 ** 3 * pr.pe_mac_pj)
    # 单位块的**净**价已经把自带的那 1024 行 softmax 扣掉（避免与注意力 softmax 双计）
    c = Cost.from_prices(pr)
    approx(c.softmax_pj_per_block, SOFTMAX_PJ_PER_BLOCK)
    approx(c.block_pj_with_softmax, pr.block_pj, 1e-15)
    approx(c.block_pj, pr.block_pj - SOFTMAX_PJ_PER_BLOCK, 1e-12)
    # 对照口径：同一个满块按实际 MAC 计 —— 满块下两口径只差约 10%
    approx(c.block_unit_pj, 1024 ** 3 * pr.pe_mac_pj + BLOCK * pr.reduction_add_pj)
    assert 1.0 < c.block_pj / c.block_unit_pj < 1.2


def test_prices_all_come_from_dataset():
    d = V3Datasheet.from_rtl()
    pr = prices()
    approx(pr.pe_mac_pj, d.energy.pe_mac_pj, 1e-15)
    approx(pr.reduction_add_pj, d.energy.reduction_add_pj, 1e-15)
    approx(pr.softmax_exp_pj, d.energy.softmax_exp_pj, 1e-15)
    approx(pr.softmax_add_pj, d.energy.softmax_add_pj, 1e-15)
    approx(pr.gsram_read_pj_per_128b, d.energy.gsram_read_pj_per_128b, 1e-15)
    approx(pr.gsram_write_pj_per_128b, d.energy.gsram_write_pj_per_128b, 1e-15)
    approx(pr.tile_reg_write_pj_per_bit, d.energy.tile_reg_write_pj_per_bit, 1e-15)
    approx(pr.mem_rd_pj_per_128b, d.tech["MEM_RD_ENERGY_PJ"], 1e-15)
    approx(pr.mem_wr_pj_per_128b, d.tech["MEM_WR_ENERGY_PJ"], 1e-15)
    approx(pr.mem_rd_ns, d.tech["MEM_RD_LATENCY_NS"], 1e-15)
    approx(pr.mem_wr_ns, d.tech["MEM_WR_LATENCY_NS"], 1e-15)
    approx(pr.phy_pj_per_bit, d.measured.phy_energy_pj_per_bit, 1e-15)
    approx(pr.phy_ps_per_bit, d.measured.phy_delay_ps_per_bit, 1e-15)
    approx(pr.hb_latency_ns, d.tech["HB_LATENCY_NS"], 1e-15)
    approx(pr.clock_ns, 1000.0 / d.tech["TECH_FMAX_MHZ"], 1e-15)
    # 结构常量与现有 V3Config 一致（跨 Die 位宽默认取 HB_WIDTH = 128，见 .vh §4）
    assert pr.phy_bpc == 128
    assert pr.softmax_lanes == V3Config().softmax_lanes == 1024
    # 逐字段的出处都要有记录
    for k in ("block", "pe_mac_pj", "reduction_add_pj", "softmax_exp_pj", "softmax_add_pj",
              "gsram_*", "tile_reg_write_pj_per_bit", "mem_rd", "mem_wr", "phy",
              "hb_latency_ns", "clock_ns"):
        assert k in pr.provenance, k
    # 缓存：同参数重复取要拿到同一个对象（否则每层都会重跑一次现有模型）
    assert prices_from_dataset() is pr


# --- 3. 轻量级算子（用户口径：一律用 softmax 的数据） -------------------------

def test_elementwise_uses_softmax_price():
    pr, c = prices(), Cost.from_prices(prices())
    approx(pr.elementwise_pj_per_element, pr.softmax_exp_pj + pr.softmax_add_pj, 1e-15)
    approx(pr.elementwise_pj_per_element, 0.10416, 1e-12)
    for n in (0, 1, 1024, 1025, 1024 * 1024, 151936 * 2):
        e = c.elementwise(n)
        assert e.elements == n
        approx(e.pj, n * (pr.softmax_exp_pj + pr.softmax_add_pj))
        assert e.cycles == -(-n // pr.softmax_lanes)      # = ceil(n / 1024)


# --- 4. MEM die / PHY / Hybrid Bonding / GSRAM 的搬运账 -----------------------

def test_mem_and_phy_transfer_accounting():
    pr, c = prices(), Cost.from_prices(prices())
    nb = 32 * LINE_BYTES                        # 32 次 128 bit 访问
    assert LINE_BYTES == 16
    t = c.mem_read(nb, phy_bpc=128, regfile=True)
    assert (t.kind, t.accesses_128b, t.nbytes) == ("mem_read", 32, nb)
    approx(t.mem_pj, 32 * pr.mem_rd_pj_per_128b, 1e-12)
    approx(t.mem_ns, 32 * pr.mem_rd_ns, 1e-12)
    approx(t.phy_pj, nb * 8 * pr.phy_pj_per_bit, 1e-9)                 # 1.44 pJ/bit
    approx(t.phy_ns, nb * 8 / 128 * pr.phy_ps_per_bit / 1000.0, 1e-9)  # 625 ps/bit
    approx(t.hb_ns, pr.hb_latency_ns, 1e-15)                           # HB 1.20 ns / 次
    approx(t.regfile_pj, nb * 8 * pr.tile_reg_write_pj_per_bit, 1e-9)
    approx(t.gsram_pj, 32 * pr.gsram_read_pj_per_128b, 1e-12)
    # 四段是**并列的通道**，总能耗 = 四段之和；总延迟 = MEM + PHY + HB
    approx(t.pj, t.mem_pj + t.phy_pj + t.gsram_pj + t.regfile_pj, 1e-12)
    approx(t.ns, t.mem_ns + t.phy_ns + t.hb_ns, 1e-12)
    assert t.cycles == math.ceil(t.ns / pr.clock_ns)
    # 写：更贵更慢，且不写寄存器堆
    w = c.mem_write(nb)
    approx(w.mem_pj, 32 * pr.mem_wr_pj_per_128b, 1e-12)
    approx(w.mem_ns, 32 * pr.mem_wr_ns, 1e-12)
    assert w.regfile_pj == 0.0 and w.hb_ns == pr.hb_latency_ns
    assert w.mem_pj > t.mem_pj and w.mem_ns > t.mem_ns
    # 访问次数向上取整：不足 128 bit 也算一次
    assert c.mem_read(1).accesses_128b == 1
    assert c.mem_read(17).accesses_128b == 2
    assert c.mem_read(LINE_BYTES).accesses_128b == 1
    # PHY 位宽参数化：BPC=1 的时间是 BPC=128 的 128 倍，**能耗不变**（按 bit 计）
    a, b = c.mem_read(1 << 20, phy_bpc=1), c.mem_read(1 << 20, phy_bpc=128)
    approx(a.phy_ns / b.phy_ns, 128.0, 1e-9)
    approx(a.phy_pj, b.phy_pj, 1e-15)
    # 分段开关：中间结果回读不过寄存器堆；纯 GSRAM 中转既不过 PHY 也不过 MEM
    assert c.mem_read(nb, regfile=False).regfile_pj == 0.0
    g = c.gsram_transfer(nb, write=True)
    assert (g.mem_pj, g.phy_pj, g.ns) == (0.0, 0.0, 0.0)
    approx(g.gsram_pj, 32 * pr.gsram_write_pj_per_128b, 1e-12)
    gr = c.gsram_transfer(nb, write=False)
    approx(gr.gsram_pj, 32 * pr.gsram_read_pj_per_128b, 1e-12)
    assert gr.gsram_pj < g.gsram_pj                                   # 读比写便宜
    # 不过 PHY 的那一路：延迟只剩 MEM 阵列
    no_phy = c.mem_read(nb, via_phy=False)
    assert no_phy.phy_pj == no_phy.phy_ns == no_phy.hb_ns == 0.0


# --- 5. 16 GiB 容量 ----------------------------------------------------------

def test_mem_die_capacity_and_overflow():
    d = MemDie(16 * (1 << 30))
    assert d.capacity_bytes == 17_179_869_184
    assert d.usage()["capacity_gib"] == 16.0
    # 一个 1024x1024 的 MXFP4 权重块 = 512 KB payload + 32 KB 尺度 = 544 KB
    rec = d.allocate("w", (1024, 1024), "weight")
    assert rec.payload_bytes == 512 * 1024 and rec.scale_bytes == 32 * 1024
    assert rec.nbytes == 544 * 1024 == 557_056
    # 与现有模型报出的寄存器堆容量逐位对齐（跑现有模型取数，不抄常数）
    assert run_v3(V3Config()).report["capacity"]["array_weight_rtl_bytes"] == rec.nbytes
    # 非 MXFP4 的按原始位宽记（归一化权重是 fp32）
    n = d.allocate("norm", (1024,), "weight", fp4=False, raw_bits=32)
    assert n.raw_bytes == 4096 and n.fp4 is False and n.payload_bytes == 0
    assert d.by_role()["weight"]["tensors"] == 2
    assert d.used_bytes() == rec.nbytes + n.raw_bytes
    assert d.free("norm") == 4096 and d.free("norm") == 0        # 幂等
    # 超容必须抛错，不能静默截断
    try:
        d.allocate("huge", (2 ** 40,), "weight")
    except MemoryError:
        pass
    else:
        raise AssertionError("超容没有抛 MemoryError")
    # 重名必须抛错
    try:
        d.allocate("w", (8,), "weight")
    except KeyError:
        pass
    else:
        raise AssertionError("重名没有抛 KeyError")
    # 读一个不存在的张量要抛错（而不是静默返回 0 字节）
    d.cost = Cost.from_prices(prices())
    try:
        d.read("nope")
    except KeyError:
        pass
    else:
        raise AssertionError("读不存在的张量没有抛 KeyError")


def test_real_model_fits_in_16gib():
    """Qwen3-0.6B 的权重 + KV cache + 峰值激活 << 16 GiB（**纯算术**，不建权重映像）。

    按 MXFP4 的字节口径：payload 4 bit/元素 + E8M0 尺度 8 bit/32 元素；
    归一化权重不量化（fp32）。
    """
    q = Qwen3Config()
    p = Qwen3Params(q)
    mats = p.matrices() + [p.embedding()]        # 绑权重：词表只算一份
    payload = sum(mxfp4.payload_bytes(m.shape) for m in mats)
    scale = sum(mxfp4.scale_bytes(m.shape) for m in mats)
    acc = p.accounting()
    raw = acc["norm_elements"] * 4               # 归一化权重不量化
    assert 290e6 < payload < 310e6, payload      # 约 298 MB
    assert 18e6 < scale < 20e6, scale            # 约 18.6 MB
    assert acc["norm_elements"] == 65536 and raw == 262144
    # 词表（绑权重）是最大的单张：155.6 M 元素 → 78 MB payload + 4.9 MB 尺度
    emb = p.embedding()
    assert mxfp4.payload_bytes(emb.shape) == 151936 * 1024 // 2
    assert mxfp4.scale_bytes(emb.shape) == 151936 * 32
    # KV cache：28 层 x 2(K/V) x 8 head x (128 + 1024) 位置 x 128 head_dim
    kv = mx_bytes((q.layers, 2, q.kv_heads,
                   LlmConfig().prompt_tokens + LlmConfig().max_new_tokens, q.head_dim))
    assert kv == 35_094_528, kv                  # 约 35 MB
    total = payload + scale + raw + kv
    assert total < 16 * (1 << 30)
    assert 1.0 < 100.0 * total / (16 << 30) < 5.0      # 占用约 2%
    # 一个 token 的激活（hidden + q_dim + kv_dim）远小于一个权重块
    assert mx_bytes((1, q.hidden)) < 1024 * 1024
    assert mx_bytes((q.q_dim + 2 * q.kv_dim,)) < 1024 * 1024


# --- 6. MXFP4（W4A4）：逐位对朴素参考、数据确实落在码本上 ---------------------

def naive_mxfp4(x, group=32):
    """逐组朴素的 MXFP4（float64、逐元素 `argmin`）—— 独立写的参考实现。

    这是「MXFP4 规范 + `np.argmin` 并列取先出现」的字面翻译，**不共享被测代码的任何一行**。
    """
    xa = np.asarray(x, np.float64)
    orig = xa.shape
    lead, last = xa.shape[:-1], xa.shape[-1]
    ng = -(-last // group)
    pad = ng * group - last
    if pad:
        xa = np.concatenate([xa, np.zeros(lead + (pad,), np.float64)], -1)
    g = xa.reshape(-1, ng, group)
    cb = np.asarray(FP4_VALUES[:8], np.float64)
    out = np.empty(g.shape, np.float64)
    sc = np.empty(g.shape[:2], np.uint8)
    for r in range(g.shape[0]):
        for c in range(ng):
            b = g[r, c]
            am = float(np.max(np.abs(b)))
            e = 127.0 if am == 0.0 else \
                float(np.clip(np.floor(np.log2(am / 6.0)) + 127.0, 0.0, 255.0))
            sc[r, c] = np.uint8(e)
            s = b / np.exp2(e - 127.0)
            # 最近邻 = |「幅值」- 码值| 最小（**取幅值**，码本全为非负）；并列取先出现
            idx = np.array([int(np.argmin(np.abs(np.abs(v) - cb))) for v in s], np.uint8)
            out[r, c] = np.where(s < 0, -cb[idx], cb[idx]) * np.exp2(e - 127.0)
    pay = out.reshape(-1, ng * group)[:, :last].reshape(orig)
    return pay, (sc.reshape(lead + (ng,)) if lead else sc.reshape((ng,)))


def test_quantizer_matches_rowwise_reference():
    """逐位对齐一份独立写的朴素实现 —— 这条钉住三条口径：

    1. 指数要够精确（`log2` 在 2 的整数次幂附近差一个 ULP 就会掉一档）；
    2. 最近邻并列时取**先出现**的码值（与 `np.argmin` 同口径）；
    3. 尾部不足 32 个元素时按 0 补齐、解完裁回原形状（补 0 不改变真实元素的码值）。
    """
    rng = np.random.default_rng(7)
    for shp in [(1, 1024), (4, 32), (3, 100), (17, 64), (5, 8, 33), (200, 128),
                (2, 1), (1, 1), (33, 33), (1152, 128), (1024, 1024), (7, 32)]:
        for _ in range(2):
            x = (rng.standard_normal(shp) * rng.uniform(0.05, 12.0)).astype(np.float32)
            p, s = mxfp4.quantize(x)
            y = mxfp4.dequantize(p, s)
            ref, refs = naive_mxfp4(x)
            assert p.shape == x.shape and y.shape == x.shape and p.dtype == np.uint8
            assert s.shape == refs.shape == x.shape[:-1] + ((x.shape[-1] + 31) // 32,)
            assert np.array_equal(s, refs), f"尺度不一致 {shp}"       # 逐位
            assert np.array_equal(y, ref.astype(np.float32)), f"数值不一致 {shp}"
            assert int(p.max()) <= 15                                  # 只用低 4 位
            assert np.array_equal(mxfp4.quantize_dequantize(x), y)      # 往返 = 量化+反量化


def test_quantizer_keeps_negatives_and_per_group_exponents():
    rng = np.random.default_rng(0)
    x = rng.standard_normal((4, 32)).astype(np.float32)
    p, s = mxfp4.quantize(x)
    y = mxfp4.dequantize(p, s)
    assert (x < 0).sum() > 0 and (x > 0).sum() > 0
    # 符号是**独立的 1 bit**：每个负输入的 payload 第 3 位必须置起。
    # （注意：幅值相对本组 amax 太小的负值会量化到 `0`，但那也是 **-0.0** ——
    #  既有编码器是无论大小一律丢成 -0.0，这里区分得开。）
    assert np.all((p[x < 0] & np.uint8(8)) == np.uint8(8)), "负值的符号位丢了"
    assert np.all((p[x > 0] & np.uint8(8)) == np.uint8(0)), "正值的符号位被置起"
    assert int((y < 0).sum()) > 0, "负值被丢掉了"
    nz = y[y != 0.0]
    assert int((nz < 0).sum()) > 0 and int((nz > 0).sum()) > 0
    assert np.all(np.sign(y[x < 0][y[x < 0] != 0.0]) == -1.0), "负值没有保留符号"
    assert np.all(y[(x < 0) & (y == 0.0)] == 0.0)          # 归零的也只是 -0.0
    # 逐行幅值差 1000 倍：逐组指数必须保留小行，不能被大行压成 0
    x2 = np.zeros((2, 32), np.float32)
    x2[0] = 1000.0
    x2[1] = 1.0
    p2, s2 = mxfp4.quantize(x2)
    assert p2.shape == (2, 32) and s2.shape == (2, 1)
    assert s2[0, 0] != s2[1, 0], "整块共用一个指数"
    y2 = mxfp4.dequantize(p2, s2)
    assert abs(float(y2[0].max()) - 768.0) < 1e-3      # 1000 -> 6 x 2^7
    assert abs(float(y2[1].max()) - 0.75) < 1e-3       # 1    -> 1.5 x 2^-1
    # 同一行里两个组幅值不同 → 两个尺度
    p3, s3 = mxfp4.quantize(np.array([[8.0] * 32 + [1.0] * 32], np.float32))
    assert s3.shape == (1, 2) and s3[0, 0] != s3[0, 1]
    # 全零组 → 指数 127（= 2^0），解码回 0
    assert mxfp4.quantize(np.zeros((1, 32), np.float32))[1][0, 0] == 127
    assert not mxfp4.quantize_dequantize(np.zeros((1, 32), np.float32)).any()
    # 每 32 个元素恰好一个尺度字节（E8M0）
    assert mxfp4.scale_bytes((28, 3072, 1024)) == 28 * 3072 * 32
    assert mxfp4.payload_bytes((1024, 1024)) == 1024 * 1024 // 2


def test_legacy_encoder_has_two_defects():
    """既有的 `model._payload_from_values()` 有两处缺陷（**本层不使用它**）。

    这条把缺陷的行为**钉死**，于是 `mxfp4.py` 的模块 docstring 与 `README_LLM.md` 的
    「与既有实现的两处差异」不是说法而是可复现的事实：
      * **整块共享一个指数**：`mx = max(|整块|)` 里整块 = 所有行 —— 一行幅值大，
        其余行被整行压成 0（`s2` 只有一列，且两行取到同一个指数）；
      * **负值全部丢成 -0.0**：`argmin(|scaled - |码本||)` 拿**带符号**的值去比非负码本，
        任何负值的最近邻都落在码本第 0 项，再补符号位 → -0.0。
    """
    from yrr_v3.model import _payload_from_values
    rng = np.random.default_rng(0)

    # 缺陷 2：负值
    x = rng.normal(0.0, 1.0, (4, 32))
    assert int((x < 0).sum()) > 0
    p, s = _payload_from_values(x, rng)
    y = decode_fp4(p, s)
    assert int((y < 0).sum()) == 0, "既有编码器本该把负值丢成 -0.0"
    # 缺陷 1：整块一个指数（shape 是 (4,1)：一列 32 个元素共用一个指数）
    assert s.shape == (4, 1) and np.unique(s).size == 1
    # 具体例子：负值 → -0.0，且幅值只有 4 档
    v = np.zeros((1, 32), np.float64)
    v[0, :4] = [2.041, -2.556, 0.418, -0.568]
    pv, sv = _payload_from_values(v, rng)
    assert sv.tolist() == [[125]]
    assert np.allclose(decode_fp4(pv, sv)[0, :4], [1.5, -0.0, 0.375, -0.0], atol=1e-9)
    # 缺陷 1 的后果：两行幅值差 1000 倍 → 小行整行归零（本层实现不会）
    x3 = np.zeros((2, 32), np.float64)
    x3[0] = 1000.0
    x3[1] = 1.0
    p3, s3 = _payload_from_values(x3, rng)
    assert np.all(decode_fp4(p3, s3)[1] == 0.0)
    assert abs(float(mxfp4.quantize_dequantize(x3.astype(np.float32))[1].max()) - 0.75) < 1e-3


def test_weights_and_kv_live_on_the_mxfp4_codebook():
    """权重与 KV cache 的每个 32 元素组都必须落在 `码值 x 2 的幂` 上（≤7 种幅值）。"""
    q = small_qcfg()
    img = build_weight_image(q, None, seed=1, cache="full")
    w = img.get("L00.k_proj")
    assert w.shape == (q.kv_dim, q.hidden)
    groups = w.reshape(-1, 32)
    assert groups.shape[0] == q.kv_dim * q.hidden // 32
    for row in groups:
        m = float(np.abs(row).max())
        if m == 0.0:
            continue
        assert np.unique(np.abs(row[np.abs(row) > 0])).size <= 7
        assert on_codebook(row), f"不落在码本上：{row[:8]}"
    # 具体一组：0.5..6 乘以 2^-7
    assert np.allclose(np.unique(np.abs(w[0, :32])),
                       [0, 0.00390625, 0.0078125, 0.01171875, 0.015625, 0.0234375,
                        0.03125, 0.046875], atol=1e-12)
    # KV cache 同理（写入时就量化成 MXFP4 码值，见 schedule.layer_forward 的 kv_quant）
    ctx = _smoke_ctx()
    ctx.tokens = [1] * 8
    ctx.prefill()
    ctx.decode_step(1, 1)
    used = ctx.kv[:, :, :, :9, :].reshape(-1, q.head_dim)
    assert int((used != 0).sum()) > 0
    for row in used:
        assert on_codebook(row), row[:8]


def test_activation_quantized_at_every_operator_boundary():
    """W4A4 的 A4：每个算子边界都过一遍量化（**打桩计数**验证，不靠读代码）。

    每层每趟前向的量化点（`quantize_dequantize` 的调用次数）：
      * 7 个投影的输入各 1；
      * 每个 q_head 的 Q 与注意力矩阵 A 各 1 → `2 x q_heads`；
      * KV cache 的 K 与 V 各 1（**写在 cache 里就是 4 bit**，所以只量化一次，
        不随 head 数重复）。
    再加每个生成 token 的 lm_head 输入，以及收尾时 `_errors` 的一次自检往返。
    """
    cfg = small_cfg(prompt_tokens=8, max_new_tokens=3)
    q = small_qcfg()
    calls = []
    orig = mxfp4.quantize_dequantize

    def spy(x, *a, **kw):
        calls.append(np.asarray(x).shape)
        return orig(x, *a, **kw)

    mxfp4.quantize_dequantize = spy
    try:
        run_llm(cfg)
    finally:
        mxfp4.quantize_dequantize = orig
    per_fwd = 7 + 2 * q.q_heads + 2
    n_fwd = 1 + (cfg.max_new_tokens - 1)                  # prefill + decode 步数
    assert len(calls) == per_fwd * n_fwd + cfg.max_new_tokens + 1

    # 关掉 A4（退化成 W4A16 对照）就一次都不该调 —— 只剩 `_errors` 那次自检
    calls.clear()
    mxfp4.quantize_dequantize = spy
    try:
        run_llm(small_cfg(quantize_activations=False))
    finally:
        mxfp4.quantize_dequantize = orig
    assert calls == [(8, 1024)], calls


# --- 7. 确定性 ---------------------------------------------------------------

def test_same_seed_is_bit_identical():
    a = run_llm(small_cfg(seed=1))
    b = run_llm(small_cfg(seed=1))
    assert a.generated_ids == b.generated_ids
    assert a.generated_text == b.generated_text
    for k in ("total_whole_block_pj", "total_unit_pj", "accumulate_whole_pj"):
        assert a.report["energy"][k] == b.report["energy"][k]
    assert a.report["latency"]["cycles_serial_1core"] == b.report["latency"]["cycles_serial_1core"]
    assert a.report["call_counts"] == b.report["call_counts"]
    assert a.report["memory_traffic"] == b.report["memory_traffic"]
    # 换种子：账目结构（算子数、块数、拍数）不变，只是权重不同
    c = run_llm(small_cfg(seed=2))
    assert c.report["call_counts"] == a.report["call_counts"]
    assert c.report["latency"]["cycles_serial_1core"] == a.report["latency"]["cycles_serial_1core"]
    assert c.report["energy"]["total_whole_block_pj"] == a.report["energy"]["total_whole_block_pj"]


def test_weights_differ_with_seed_but_shape_does_not():
    q = small_qcfg()
    i1 = build_weight_image(q, None, seed=1, cache="full")
    i2 = build_weight_image(q, None, seed=2, cache="full")
    assert i1.matrix_names() == i2.matrix_names()
    assert len(i1.matrix_names()) == q.layers * 7 + 1        # 7 个投影 + 词表
    w1, w2 = i1.get("L00.q_proj"), i2.get("L00.q_proj")
    assert w1.shape == w2.shape == (q.q_dim, q.hidden)
    assert not np.array_equal(w1, w2)
    # 同一颗种子两次生成逐位相同
    assert np.array_equal(w1, build_weight_image(q, None, seed=1, cache="full").get("L00.q_proj"))
    # 归一化权重是 ones（不量化，fp32）
    assert np.all(i1.norm("L00.input_layernorm") == 1.0)
    assert i1.norm("model.norm").size == q.hidden
    # 容量账：权重按 MXFP4 记字节，归一化按 fp32 记
    assert i1.nbytes("embed_tokens") == mx_bytes((q.vocab, q.hidden))
    assert i1.nbytes("L00.k_proj") == mx_bytes((q.kv_dim, q.hidden))
    assert i1.nbytes("L00.input_layernorm") == q.hidden * 4
    # cache="none" 时不留 fp32 影子，取数时现场反量化，数值必须一致
    i3 = build_weight_image(q, None, seed=1, cache="none")
    assert i3.entries["L00.q_proj"].shadow is None
    assert np.array_equal(i3.get("L00.q_proj"), w1)


# --- 8. 结构参数与调度完整性（与 Instruction/GEMM次数统计.md §1.1 对照） -------

def test_qwen3_config_and_param_accounting():
    q = Qwen3Config()
    assert (q.hidden, q.layers, q.q_heads, q.kv_heads, q.head_dim) == (1024, 28, 16, 8, 128)
    assert q.head_dim != q.hidden // q.q_heads           # 128 != 64：独立指定
    assert q.q_dim == 2048 and q.kv_dim == 1024 and q.gqa_group == 2
    assert (q.intermediate, q.vocab) == (3072, 151936)
    approx(q.attn_scale, 1.0 / math.sqrt(128), 1e-15)
    assert q.tie_embeddings and q.rope_theta == 1e6 and q.rms_eps == 1e-6
    # **o_proj 是 q_dim -> hidden**（2048 -> 1024），不是方阵
    shapes = {m.name.split(".")[-1]: m.shape for m in Qwen3Params(q).layer_matrices(0)}
    assert shapes == {"q_proj": (2048, 1024), "k_proj": (1024, 1024),
                      "v_proj": (1024, 1024), "o_proj": (1024, 2048),
                      "gate_proj": (3072, 1024), "up_proj": (3072, 1024),
                      "down_proj": (1024, 3072)}, shapes
    # 每层 4 条归一化权重（2 个 hidden 的 + 2 个 head_dim 的）
    assert [n for n, _ in Qwen3Params(q).layer_norms(0)] == [
        "L00.input_layernorm", "L00.post_attention_layernorm", "L00.q_norm", "L00.k_norm"]
    # 参数量与文档 §1.1 的 596.0 M 对得上（绑权重的词表只算一次）
    acc = Qwen3Params(q).accounting()
    approx(acc["total_params_millions"], 596.04992)
    assert acc["total_elements"] == (acc["proj_elements"] + acc["embedding_elements"]
                                     + acc["norm_elements"])
    assert acc["per_layer_elements"] == 15_728_640
    assert Qwen3Params(q).embedding().elements == 151936 * 1024
    assert Qwen3Params(q).lm_head().shape == Qwen3Params(q).embedding().shape
    assert len(Qwen3Params(q).matrices()) == 28 * 7


def test_register_file_fits_exactly_one_weight_block():
    """544 KB 寄存器堆 = 恰好一个 1024x1024 的 MXFP4 权重块。

    这条不是巧合，是「权重常驻、跨 token 复用」在本模型里的**容量依据**；
    也是 `linear()` 必须同时切 K 维的原因（o_proj / down_proj 的 K > 1024 装不下）。
    """
    block = 1024 * 1024 // 2 + 1024 * (1024 // 32)       # payload + 尺度
    assert block == 544 * 1024 == REGFILE_BYTES == 557_056
    assert run_v3(V3Config()).report["capacity"]["array_weight_rtl_bytes"] == REGFILE_BYTES
    assert GSRAM_BYTES == 512 * 1024 == V3Config().global_sram_bytes
    core = _smoke_core()
    assert core.blocks_per_regfile == 1
    assert core.regfile_bytes == REGFILE_BYTES
    # 装不下就必须抛（这正是 o_proj 的 K 维要被切的原因）
    try:
        core.load_weight_block("prefill", 0, "wload", "too_big", REGFILE_BYTES + 1)
    except MemoryError:
        pass
    else:
        raise AssertionError("超过寄存器堆没有抛 MemoryError")
    # 装得下的块：记账一次；**已常驻则零开销**（命中返回 None，不重复记账）
    t = core.load_weight_block("prefill", 0, "wload", "w0", REGFILE_BYTES)
    assert t is not None and t.nbytes == REGFILE_BYTES and t.regfile_pj > 0
    assert core.weight_loads == 1 and core.regfile_used() == REGFILE_BYTES
    assert core.regfile_free() == 0 and core.regfile_high_water == REGFILE_BYTES
    assert core.load_weight_block("prefill", 0, "wload", "w0", REGFILE_BYTES) is None
    assert core.weight_loads == 1
    assert core.resident["w0"].hits == 1
    # 换一个块：FIFO 换出（一个块就占满，等价于整块换出）
    assert core.load_weight_block("prefill", 0, "wload", "w1", REGFILE_BYTES) is not None
    assert core.evict("w0") == 0 and core.weight_loads == 2      # w0 已被换出
    assert core.evict("w1") == REGFILE_BYTES


def test_call_counts_match_documented_formula():
    cfg = small_cfg()
    r = run_llm(cfg).report
    L = r["model"]["layers"]
    cc = r["call_counts"]
    # 每 token = 层数 x 9 算子（7 个投影 + QK + PV）+ 1 次 lm_head
    assert cc["operator_invocations_per_token"] == L * 9 + 1
    assert Qwen3Config().layers == 28 and 28 * 9 + 1 == 253
    n_tok = cfg.n_runs * (cfg.prompt_tokens + cfg.max_new_tokens)
    assert n_tok == r["config"]["n_tokens_total"] == 10
    assert cc["operator_invocations_total"] == (L * 9 + 1) * n_tok
    # 每个阶段都有账
    for phase in ("prefill", "decode", "lm_head"):
        assert phase in r["phases"], phase
        assert r["phases"][phase]["cycles"] > 0
        assert r["phases"][phase]["whole_pj"] > 0
    # 账本自洽：分类之和 = 按 kind 之和 = 按阶段之和 = 总计
    tot = r["energy"]["total_whole_block_pj"]
    approx(sum(d["whole_pj"] for d in r["energy"]["by_cat"].values()), tot)
    approx(sum(d["whole_pj"] for d in r["ops_by_kind"].values()), tot)
    approx(sum(d["whole_pj"] for d in r["phases"].values()), tot)
    # 整块口径记账的 MAC = 块数 x 1024^3（小矩阵被按整块收费）
    assert cc["unit_blocks"] > 0 and cc["actual_macs"] > 0
    assert cc["billed_macs_whole_block"] == cc["unit_blocks"] * 1024 ** 3
    assert cc["billed_macs_whole_block"] > cc["actual_macs"] * 1000
    approx(r["energy"]["per_token_whole_pj"], tot / n_tok)
    approx(r["energy"]["accumulate_whole_pj"],
           sum(d["accumulate_whole_pj"] for d in r["energy"]["by_cat"].values()
               if "accumulate_whole_pj" in d))


def test_kv_cache_and_reuse_accounting():
    """decode 的注意力必须**随步数增长**：第 t 步看到 `pos + t + 1` 个位置。"""
    q = small_qcfg()
    ctx = _smoke_ctx(prompt_tokens=8, max_new_tokens=3)
    assert ctx.pos == 0
    assert ctx.kv.shape == (q.layers, 2, q.kv_heads, 11, q.head_dim)
    ctx.tokens = [1] * 8
    ctx.prefill()
    assert ctx.pos == 8
    # prefill：每个 q_head 的 pair 数 = T x ctx = 8 x 8
    base = ctx.ledger.by_kind()["attn_qk"]["count"]
    assert base == 8 * 8 * q.q_heads
    counts, deltas, prev = [], [], base
    for s in range(3):
        ctx.decode_step(s, 1)
        cur = ctx.ledger.by_kind()["attn_qk"]["count"]
        counts.append(cur)
        deltas.append(cur - prev)
        prev = cur
    # 第 t 步的增量 = 1 x (8 + t + 1) x q_heads —— 上下文确实在长
    assert deltas == [1 * 9 * q.q_heads, 1 * 10 * q.q_heads, 1 * 11 * q.q_heads], (counts, deltas)
    assert ctx.pos == 11
    # QK 与 PV 的 pair 数一致；S 与 A 的写回都是「单元素 + 最小 128 bit 访问」
    kinds = ctx.ledger.by_kind()
    assert kinds["attn_pv"]["count"] == kinds["attn_qk"]["count"] == counts[-1]
    assert kinds["attn_qk.wr"]["mem_wr_bytes"] == counts[-1] * 16
    assert kinds["attn_a_write"]["mem_wr_bytes"] == counts[-1] * 16
    # softmax 是对每个 query 行做的：T x ctx x q_heads（prefill 8x8x4 + 逐 step）
    assert kinds["softmax"]["elements"] == (8 * 8 + 1 * 9 + 1 * 10 + 1 * 11) * q.q_heads


def test_weight_residency_is_reused_across_tokens():
    """权重块按 token 常驻：token 从 8 涨到 16，装载次数与字节数都不变。"""
    for mn in (0, 1):
        r8 = run_llm(small_cfg(prompt_tokens=8, max_new_tokens=mn)).report
        r16 = run_llm(small_cfg(prompt_tokens=16, max_new_tokens=mn)).report
        assert r8["core"]["weight_loads"] == r16["core"]["weight_loads"]
        assert r8["core"]["weight_load_bytes"] == r16["core"]["weight_load_bytes"]
    r = run_llm(small_cfg(prompt_tokens=8, max_new_tokens=0)).report
    # prefill 一趟：每层 7 个投影，每个 (输出块, K 块) 各装载一次 —— 8 个 token 复用同一批
    assert r["core"]["weight_loads"] == 7
    assert r["core"]["weight_load_bytes"] == (
        mx_bytes((q_dim_(), 128)) + mx_bytes((64, 128)) * 2 + mx_bytes((128, 128))
        + mx_bytes((256, 128)) * 2 + mx_bytes((128, 256)))
    assert r["core"]["regfile_capacity_blocks"] == 1
    assert r["core"]["regfile_high_water_bytes"] <= REGFILE_BYTES
    assert r["phases"]["prefill"]["cycles"] > 0


def q_dim_() -> int:
    return small_qcfg().q_dim


# --- 9. 两种计费口径 --------------------------------------------------------

def test_both_billings_coexist_and_scale_with_blocks():
    c, pr = Cost.from_prices(prices()), prices()
    # 整块口径随块数线性；unit 口径随实际 MAC 线性
    for (M, N, K), nb in (((1024, 1024, 1024), 1), ((1024, 1024, 2048), 2),
                          ((2048, 1024, 1024), 2), ((2048, 2048, 2048), 8)):
        mm = c.matmul(M, N, K)
        assert mm.n_blocks == nb
        approx(mm.blocks_pj, nb * c.block_pj)
        approx(mm.whole_pj, mm.blocks_pj + mm.accum_whole_pj)
        approx(mm.unit_pj - mm.accum_unit_pj, M * N * K * pr.pe_mac_pj)
    # 同一个 run 里两个口径都报出来，且整块口径远大于 unit（skinny 矩阵的 ~1024x 惩罚）
    r = run_llm(small_cfg()).report
    en = r["energy"]
    assert en["billing"] == "whole_block"
    assert en["total_whole_block_pj"] > en["total_unit_pj"] * 100
    approx(en["ratio_unit_over_whole"], en["total_unit_pj"] / en["total_whole_block_pj"])
    approx(en["total_whole_block_j"], en["total_whole_block_pj"] / 1e12)
    assert en["total_unit_j"] > 0 and en["accumulate_whole_pj"] >= 0
    approx(en["per_token_unit_pj"], en["total_unit_pj"] / r["config"]["n_tokens_total"])
    # 换口径只换「谁是主口径」：两个总量**同时**在，数值一个都不变
    en2 = run_llm(small_cfg(billing="unit")).report["energy"]
    assert en2["billing"] == "unit"
    assert en2["total_unit_pj"] == en["total_unit_pj"]
    assert en2["total_whole_block_pj"] == en["total_whole_block_pj"]
    assert en2["ratio_unit_over_whole"] == en["ratio_unit_over_whole"]
    assert en2["per_token_unit_pj"] == en["per_token_unit_pj"]
    # 两段说明文字各自说明一件事：主口径的账目、以及为什么并列 unit
    note = r["billing_note"] + en["note"]
    assert "unit" in r["billing_note"] and "billing" in r["billing_note"]
    assert "whole_block" in note and "1024" in note


def test_cores_columns_shrink_cycles_not_energy():
    """C-core 对照列只除时间：能耗 `C x (work/C) = work`，与 cores 无关。"""
    pr = prices()
    c = Cost.from_prices(pr)
    unit = c.matmul(1, 1024, 1024)
    assert unit.cycles == BLOCK_CYCLES and unit.n_blocks == 1
    led = Ledger()
    led.matmul("prefill", -1, "proj", unit.scaled(8), times=8)     # 8 个可并行的单位块
    led.elementwise("prefill", -1, "act", c.elementwise(4096))
    proj, ew = 8 * unit.cycles, 4                                # 4 = ceil(4096/1024)
    assert led.total_cycles(1) == proj + ew
    assert led.total_cycles(2) == proj / 2 + ew
    assert led.total_cycles(4) == proj / 4 + ew
    assert led.total_cycles(8) == proj / 8 + ew
    assert led.total_cycles(16) == led.total_cycles(8)           # 只有 8 个可并行
    t = led.totals()
    approx(t["whole_pj"], 8 * unit.whole_pj + 4096 * pr.elementwise_pj_per_element)
    approx(t["unit_pj"], 8 * unit.unit_pj + 4096 * pr.elementwise_pj_per_element)
    assert t["unit_pj"] < t["whole_pj"] / 100                    # skinny M=1 的整块惩罚
    assert t["blocks"] == 8 and t["macs"] == 8 * unit.macs
    for cores in (2, 4, 8, 16):
        assert led.totals() == t                                 # 能耗不随 cores 变
    # 报告里两列都在，且 1-core 那列就是串行口径
    lat = run_llm(small_cfg()).report["latency"]
    for k in ("1", "2", "4", "8", "16"):
        assert k in lat["cycles_with_cores"] and k in lat["ns_with_cores"]
    assert lat["cycles_with_cores"]["1"] == lat["cycles_serial_1core"]
    assert lat["cycles_with_cores"]["16"] < lat["cycles_with_cores"]["1"]
    approx(lat["ns_serial_1core"], lat["cycles_serial_1core"] * lat["clock_ns"])
    # PHY 位宽对照：BPC=1 与默认 128 的串行化时间差 128 倍
    assert lat["phy_ns_at_bpc1"] > lat["phy_ns_at_bpc_default"]
    approx(lat["phy_bpc_ratio"], lat["phy_ns_at_bpc1"] / lat["phy_ns_at_bpc_default"])
    approx(lat["phy_bpc_ratio"], 128.0)


# --- 10. 分词与端到端链路 ---------------------------------------------------

def test_placeholder_tokenizer_roundtrip_and_prompt_fit():
    tok = ByteTokenizer()
    for s in ("hello", "近存计算", "a\nb\tc", ""):
        assert tok.decode(tok.encode(s)) == s
    for text, n in (("近存计算是", 4), ("近存计算是", 8), ("abc", 8), ("abc", 1), ("x", 32)):
        ids, shown = tokenize_prompt(tok, text, n)
        assert len(ids) == n, (text, n, len(ids))
        assert all(0 <= i < tok.vocab_size for i in ids), ids
        # 解码回来的 prompt 必须是合法文本（不切进多字节字符的中间）
        assert shown == tok.decode(ids)
        assert "�" not in shown
    # 太长的 prompt 从左边按**整字符**截断
    ids, shown = tokenize_prompt(tok, "abcde", 2)
    assert shown == "de" and ids == tok.encode("de")
    # 一个字符就跨过预算时，仍要补足到 n 个（前面补 pad）
    ids, shown = tokenize_prompt(tok, "近存计算是", 4)
    assert ids[0] == tok.pad_id and shown == "是"
    # 太短的 prompt 前面补 pad（保证 prompt 末尾正对生成起点）
    ids, _ = tokenize_prompt(tok, "a", 4)
    assert ids == [tok.pad_id, tok.pad_id, tok.pad_id] + tok.encode("a")
    # 采样被限制在分词器能解码的那一段 id 上
    allowed = tok.allowed_ids(tok.vocab_size)
    assert allowed[0] == tok.offset == 256 and allowed[-1] == tok.offset + 255
    assert tok.allowed_ids(300).tolist() == list(range(256, 300))
    assert tok.allowed_ids(128) is None                    # 词表比 offset 还小 → 不限制


def test_end_to_end_produces_requested_token_count():
    cfg = small_cfg(prompt_tokens=8, max_new_tokens=5)
    r = run_llm(cfg)
    assert len(r.generated_ids) == 5
    allowed = set(ByteTokenizer().allowed_ids(512).tolist())
    assert all(int(i) in allowed for i in r.generated_ids), r.generated_ids
    assert isinstance(r.generated_text, str)
    rep = r.report
    # 报告必备的顶层键
    for k in ("config", "model", "placement", "core", "phases", "ops_by_kind",
              "energy", "latency", "memory_traffic", "billing_note", "attn_note",
              "call_counts", "output", "trace", "errors", "cost_primitive"):
        assert k in rep, k
    assert rep["config"]["cores"] == 1 and rep["config"]["n_runs"] == 1
    assert rep["config"]["prompt_tokens"] == 8 and rep["config"]["max_new_tokens"] == 5
    assert rep["config"]["mem_die_gib"] == 16.0
    assert rep["config"]["w_bits"] == rep["config"]["a_bits"] == 4
    assert rep["config"]["model_override"] is not None
    assert rep["config"]["n_tokens_total"] == 13
    assert rep["model"]["layers"] == 1 and rep["model"]["quant"]["format"] == "MXFP4"
    assert rep["model"]["quant"]["activation_quantized"] is True
    # 16 GiB 容量账确实登记了权重 / KV cache / 激活
    assert rep["placement"]["capacity_gib"] == 16.0
    assert rep["placement"]["used_bytes"] > 0
    roles = rep["placement"]["by_role"]
    assert roles["kv_cache"]["tensors"] == 1 and roles["activation"]["tensors"] >= 1
    assert roles["weight"]["tensors"] > 0 and roles["embedding"]["tensors"] == 1
    # 四段访存账都在，且 PHY 字节数 > 0（跨 die 是真的在搬）
    mt = rep["memory_traffic"]
    for k in ("read_bytes", "write_bytes", "phy_bytes", "gsram_bytes"):
        assert mt[k] > 0, k
    for k in ("mem_read", "mem_write", "phy", "gsram", "regfile"):
        assert mt["pj"][k] > 0, k
    assert mt["pj"]["phy"] > mt["pj"]["mem_read"]         # PHY 的 1.44 pJ/bit 是主导项
    assert mt["ns"] > 0
    # 生成完 5 个 token，输出里也要有 5 个 id
    assert len(rep["output"]["generated_ids"]) == 5
    assert rep["output"]["sampling"] == "greedy(argmax)"
    assert rep["trace"] and len(rep["trace"]) <= cfg.trace_limit + 1
    assert rep["errors"]["roundtrip_rel_err"] >= 0.0
    assert rep["errors"]["roundtrip_max_abs_err"] > 0.0
    # 分词器信息
    ti = rep["output"]["tokenizer"]
    assert ti["name"] == "byte-placeholder" and ti["allowed_ids"]["restricted"] is True
    assert ti["allowed_ids"]["start"] == 256 and ti["allowed_ids"]["count"] == 256
    # trace 的每条记录都是聚合后的 op（有 count / 字节 / 拍）
    row = rep["trace"][0]
    for k in ("phase", "kind", "count", "cycles", "whole_pj", "blocks", "elements"):
        assert k in row, k


def test_lm_head_uses_tied_weights_only_once():
    """绑权重：词表只占一份容量，lm_head 不重复登记。"""
    r = run_llm(small_cfg()).report
    names = [d["name"] for d in r["placement"]["largest"]]
    assert "embed_tokens" in names
    assert "lm_head" not in names
    roles = r["placement"]["by_role"]
    assert roles["embedding"]["tensors"] == 1
    # 词表是最大的单张（绑权重，只算一份）
    assert r["placement"]["largest"][0]["name"] == "embed_tokens"
    p = r["model"]["params"]
    assert p["total_elements"] == (p["proj_elements"] + p["embedding_elements"]
                                   + p["norm_elements"])
    assert p["embedding_elements"] == r["model"]["vocab"] * r["model"]["hidden"]
    # lm_head 的权重块用的就是 embed_tokens 的名字（同一份数据）
    kinds = r["ops_by_kind"]
    assert kinds["lm_head.wload"]["count"] == r["config"]["max_new_tokens"]


# --- 11. 回归隔离：现有模型与现有 report 一字未变 -----------------------------

def test_cli_knobs_reach_the_config():
    """README_LLM.md 里写的每个开关都必须真的落到 `LlmConfig` 上。

    这条挡的是「文档写了、代码没接」：默认值一变、或者某个 add_argument 被漏接，
    这里就红。
    """
    import run_llm
    ap = run_llm.build_parser()
    d = run_llm.config_from_args(ap.parse_args([]))
    assert isinstance(d, LlmConfig)
    # 默认就是本次口径
    assert (d.cores, d.prompt_tokens, d.max_new_tokens, d.n_runs) == (1, 128, 1024, 1)
    assert d.billing == "whole_block" and d.phy_bpc == 128
    assert d.quantize_activations is True                  # W4A4
    assert d.mem_die_bytes == 16 << 30 and d.mem_die_count == 1
    assert (d.w_bits, d.a_bits, d.group_size) == (4, 4, 32)
    assert d.weights is None and d.temperature == 0.0      # 生成权重 / 贪心
    d.validate()
    # 每个开关都真的接上了
    a = ap.parse_args(["--cores", "4", "--billing", "unit", "--phy-bpc", "1",
                       "--no-act-quant", "--prompt-tokens", "7", "--max-new-tokens", "3",
                       "--n-runs", "2", "--mem-die-gb", "8", "--seed", "5",
                       "--weight-cache", "none", "--temperature", "0.7"])
    c = run_llm.config_from_args(a)
    assert (c.cores, c.billing, c.phy_bpc) == (4, "unit", 1)
    assert c.quantize_activations is False                  # W4A16
    assert (c.prompt_tokens, c.max_new_tokens, c.n_runs) == (7, 3, 2)
    assert c.mem_die_bytes == 8 << 30 and c.seed == 5
    assert c.weight_cache == "none" and c.temperature == 0.7
    # --smoke 走的是同一条代码路径，只是把模型缩到秒级
    s = run_llm.config_from_args(ap.parse_args(["--smoke"]))
    assert s.model is not None and s.prompt_tokens == 8 and s.max_new_tokens == 4
    assert s.model.layers == 1 and s.model.hidden == 128
    s.validate()


def test_existing_model_untouched():
    base = run_v3(V3Config()).report
    d = V3Datasheet.from_rtl()
    # 现有自检钉住的那些键集合 / 关键路径口径（ESTIMATE 分支）
    dep = run_v3(V3Config(), dataset=d).report["cycles"]["dependency_path"]
    assert {k for k in dep if k not in ("total", "note")} == {
        "input_dist", "compute", "reduce", "softmax"}
    assert set(run_v3(V3Config(), dataset=d).report["latency"]["combinational_paths"]) == {
        "logit_max", "fixed_from"}
    assert set(run_v3(V3Config(), dataset=d).report["model_scope"]["removed_pj_at_batch1"]) == {
        "partial_link_pj"}
    # 默认口径的总量与拍数逐位不变
    approx(base["energy"]["total_pj"], BLOCK_PJ, 1e-15)
    assert base["cycles"]["pipelined"]["fill_cycles"] == 6
    assert base["cycles"]["pipelined"]["cycles_per_vector"] == 4
    assert base["capacity"]["array_weight_rtl_bytes"] == REGFILE_BYTES
    assert len(json.dumps(base)) < 100_000
    # 跑一通 LLM 层之后，现有模型的输出**一字未变**（含带 dataset 的那条路径）
    run_llm(small_cfg())
    after = run_v3(V3Config()).report
    assert json.dumps(after, sort_keys=True) == json.dumps(base, sort_keys=True)
    assert run_v3(V3Config(), dataset=d).report["cycles"] == \
        run_v3(V3Config(), dataset=d).report["cycles"]


# --- 14. 吞吐率与能量效率：公式、只认新思的门、缺口语义 -------------------------

def _mark(cyc_1c: float, whole_pj: float, unit_pj: float,
          cores=(1, 2, 4, 8, 16)) -> LedgerMark:
    """造一个账本快照：单核拍数与能耗给我，其余 core 数按 `min(cores, count)` 的
    同一条摊薄规则缩（用 1/k 近似，只为手算方便 —— 真实 `LedgerMark` 由 `Ledger.mark()`
    现算，见 `test_ledger_mark_matches_total_cycles`）。"""
    return LedgerMark({str(k): cyc_1c / k for k in cores}, whole_pj, unit_pj)


class _FakePrices:
    """只要一个 `clock_ns` 就能算秒 —— 用来把公式与报价单解耦。"""
    clock_ns = 1.0


def test_metric_formulas():
    """四个公式逐个手算复核：TTFT / decode token/s / 端到端 token/s / J/token。"""
    T = 100
    ttft = _mark(1e9, 3e12, 1.5e12)      # 1 s，3 J
    dec = _mark(2e9, 6e12, 3.0e12)       # 2 s，6 J（总共 3 s，9 J）
    need = sorted({r.name for r in provenance.requirements("whole_block")})
    r = metrics.build(ttft=ttft, decode=dec, prices=_FakePrices(), gen_tokens=T,
                      prompt_tokens=10, billing="whole_block", filled=need)
    one = r["throughput"]["per_core"]["1"]
    approx(one["ttft_s"], 1.0)
    approx(one["decode_s"], 2.0)
    approx(one["e2e_s"], 3.0)
    approx(one["ttft_tok_s"], 1.0)                  # 1 / 1 s
    approx(one["decode_tok_s"], 50.0)               # 100 / 2 s
    approx(one["e2e_tok_s"], 100.0 / 3.0)
    j = r["efficiency"]["by_billing"]["whole_block"]["per_token_j"]
    approx(j["decode"], 6e12 / 1e12 / T)            # 0.06 J/token
    approx(j["e2e"], 9e12 / 1e12 / T)               # 0.09 J/token
    approx(j["first_token_j"], 3.0)                 # 首 token 那一下是 J，不是 J/token


def test_metric_token_s_scales_with_cores_but_j_per_token_does_not():
    """两条**容易被当成 bug** 的性质：token/s 随 core 数变，J/token 不变。"""
    T = 64
    ttft = _mark(8e8, 3e12, 1.5e12)
    dec = _mark(2e9, 6e12, 3.0e12)
    need = sorted({r.name for r in provenance.requirements("whole_block")})
    r = metrics.build(ttft=ttft, decode=dec, prices=_FakePrices(), gen_tokens=T,
                      billing="whole_block", filled=need)
    pc = r["throughput"]["per_core"]
    # 拍数按 1/k 缩 -> token/s 按 k 涨
    approx(pc["16"]["e2e_tok_s"] / pc["1"]["e2e_tok_s"], 16.0, 1e-12)
    approx(pc["4"]["decode_tok_s"] / pc["1"]["decode_tok_s"], 4.0, 1e-12)
    approx(pc["8"]["ttft_tok_s"] / pc["1"]["ttft_tok_s"], 8.0, 1e-12)
    # J/token **没有** core 维度：C x (work/C) = work
    blk = r["efficiency"]["by_billing"]["whole_block"]
    assert "per_core" not in blk and isinstance(blk["per_token_j"], dict)
    approx(blk["per_token_j"]["e2e"], 9e12 / 1e12 / T)


def test_metric_declines_without_synopsys_data():
    """**门的作用**：缺新思数据时给 null + 缺口表，而不是拿 RTL 估算值凑一个数出来。"""
    ttft = _mark(1e9, 3e12, 1.5e12)
    dec = _mark(2e9, 6e12, 3.0e12)
    r = metrics.build(ttft=ttft, decode=dec, prices=_FakePrices(), gen_tokens=100,
                      billing="whole_block", filled=(), ns_derived_share=0.1165)
    # 一个数都不给
    assert r["throughput"]["per_core"] is None
    assert r["throughput"]["status"] == "PENDING"
    for b in r["efficiency"]["by_billing"].values():
        assert b["per_token_j"] is None and b["status"] == "PENDING"
    # 但**缺口表**要齐全：缺哪个、要哪个新思工具/报告
    assert set(r["throughput"]["blocked_by"]) == {"clock_ns", "mem_rd_ns", "mem_wr_ns",
                                                 "hb_latency_ns"}
    for b in r["throughput"]["blocked_release"]:
        assert b["needed_from"] and b["blocks"] and b["tier"] != provenance.MEASURED
    # 而且 clock_ns 必须是吞吐率的缺口之一（它是装秒的唯一入口）
    assert "clock_ns" in r["throughput"]["blocked_by"]
    # 拍数口径的对照仍然有值（不依赖 clock_ns），但**带着**它的诚实边界
    cf = r["throughput"]["clock_free"]["1"]
    approx(cf["e2e_cycles"], 3e9)
    approx(cf["e2e_tokens_per_1e6_cycles"], 100 * 1e6 / 3e9)
    approx(r["throughput"]["clock_free"]["ns_derived_share"], 0.1165)
    # caveat 必须**自己说清**这一栏仍依赖时钟（不然会被误读成"纯结构量"）
    cav = r["throughput"]["clock_free"]["caveat"]
    assert "换算" in cav and "clock_ns" in cav and "ns_derived_share" in cav


def test_metric_gate_follows_calib_fills():
    """填一项 -> 该项从「缺」变成「已具备」；填满 -> APPLIED。这就是"填 JSON 即生效"。"""
    ttft, dec = _mark(1e9, 3e12, 1.5e12), _mark(2e9, 6e12, 3.0e12)
    need = sorted({r.name for r in provenance.requirements("whole_block")})
    # 一个都不填 -> PENDING + 报缺
    a0 = provenance.audit(billing="whole_block", filled=())
    assert a0["status"] == "PARTIAL" and a0["n_missing"] > 0
    assert "clock_ns" in [r["name"] for r in a0["by_metric"]["throughput"]["missing"]]
    # 填上时序那几项 -> 吞吐率解锁（能量效率还缺）
    a1 = provenance.audit(billing="whole_block",
                          filled=[r.name for r in provenance._THROUGHPUT])
    assert a1["by_metric"]["throughput"]["ok"] is True
    assert a1["by_metric"]["efficiency"]["ok"] is False
    r1 = metrics.build(ttft=ttft, decode=dec, prices=_FakePrices(), gen_tokens=10,
                       billing="whole_block", filled=[x.name for x in provenance._THROUGHPUT])
    assert r1["throughput"]["per_core"] is not None      # 出数了
    assert r1["efficiency"]["by_billing"]["whole_block"]["per_token_j"] is None
    # 填满 -> 两个都出数
    a2 = provenance.audit(billing="whole_block", filled=need)
    assert a2["status"] == "APPLIED" and a2["n_missing"] == 0
    # 四个新思单价（.vh §8）**本来就具备**，不因门口径而消失
    assert {r["name"] for r in a0["satisfied"]} >= {
        "pe_mac_pj", "reduction_add_pj", "phy_pj_per_bit", "phy_ps_per_bit"}
    # `unit` 口径不读整块能耗本身 -> 缺口比 whole_block 少一项
    u = provenance.audit(billing="unit", filled=())
    assert u["n_missing"] == a0["n_missing"] - 1
    assert "block_pj" in [r["name"] for r in a0["missing"]]
    assert "block_pj" not in [r["name"] for r in u["missing"]]


def test_calib_applies_and_is_off_by_default():
    """投放口：默认（全 null）**什么都不覆盖**；填了才覆盖，且填进来的算新思档。"""
    base = prices()
    # 1) 默认模板：一个非 null 都没有 -> 单价逐位不变
    cal = calib.load_calib()
    assert cal["_status"] == "PENDING" and cal["n_filled"] == 0 and not cal["unknown"]
    same, info = calib.apply_calib(base, cal)
    assert info["filled"] == [] and info["changes"] == {}
    assert same == base                       # frozen dataclass -> 值相等
    # 2) 明确关掉（calib_path=""）也是"什么都不覆盖"，且两个指标照样报缺
    assert calib.load_for(LlmConfig(calib_path=""))["filled"] == {}
    # 3) 填一项 -> 覆盖，且来源档算 measured
    fake = {"filled": {"clock_ns": 0.5}, "n_filled": 1, "_status": "APPLIED",
            "_source": "unit-test", "unknown": []}
    new, info2 = calib.apply_calib(base, fake)
    approx(new.clock_ns, 0.5)
    approx(new.f_max_mhz, 2000.0)             # 互为倒数，自动折算
    assert info2["filled"] == ["clock_ns"]
    assert info2["changes"]["clock_ns"]["from"] == base.clock_ns
    assert provenance.tier_of("clock_ns", filled=["clock_ns"]) == provenance.MEASURED
    assert provenance.tier_of("clock_ns") == provenance.RTL
    # 4) 只给 f_max_mhz 也认（反向折算）
    new2, _ = calib.apply_calib(base, {"filled": {"f_max_mhz": 500.0}, "unknown": []})
    approx(new2.clock_ns, 2.0)
    # 5) unit_block_pj 是 block_pj 的口径别名
    new3, info3 = calib.apply_calib(base, {"filled": {"unit_block_pj": 4.8e7},
                                           "unknown": []})
    approx(new3.block_pj, 4.8e7)
    assert info3["filled"] == ["block_pj"]
    # 6) 认不出的键不吃掉、也不覆盖
    _, info4 = calib.apply_calib(base, {"filled": {}, "unknown": ["not_a_price"]})
    assert info4["unknown"] == ["not_a_price"] and info4["filled"] == []


def test_ledger_mark_matches_total_cycles():
    """`Ledger.mark()` 的快照必须与 `total_cycles()` 一致，且相减可加。"""
    led = _smoke_ctx().ledger
    m = led.mark((1, 2, 4, 8, 16))
    for k in (1, 2, 4, 8, 16):
        approx(m.cycles_by_cores[str(k)], led.total_cycles(k), 1e-12)
    approx(m.whole_pj, sum(r.whole_pj for r in led.rows()), 1e-12)
    approx(m.unit_pj, sum(r.unit_pj for r in led.rows()), 1e-12)
    # 相减 = 段的净账；再相加能还原（n_runs > 1 时靠这条累加）
    z = m - m
    assert z.whole_pj == 0.0 and z.cycles_1core == 0.0
    approx((z + m).whole_pj, m.whole_pj, 1e-12)
    # 逐阶段拍数之和 == 该 core 数下的总拍数（与 total_cycles 同一条摊薄规则）
    bp = led.cycles_by_phase_and_core((1, 4))
    for k in ("1", "4"):
        approx(sum(bp[k].values()), led.total_cycles(int(k)), 1e-9)
    # ns 换算来的拍数占比：只统计搬运段（cat == "mem"），且必须在 [0, 1] 内
    sh = led.ns_derived_cycles_share()
    assert 0.0 <= sh["ns_derived_share"] <= 1.0
    approx(sh["total_cycles"], led.total_cycles(1), 1e-12)


def test_report_has_metrics_and_they_are_pending_by_default():
    """端到端：默认口径（投放口全 null）下跑一小段，三段都在，且指标是"报缺"而不是 0。"""
    rep = run_llm(small_cfg()).report
    for k in ("throughput", "efficiency", "provenance", "calib"):
        assert k in rep, f"report 缺 {k}"
    th, ef, pv = rep["throughput"], rep["efficiency"], rep["provenance"]
    assert th["gen_tokens"] == len(rep["output"]["generated_ids"])
    assert th["prompt_tokens"] == 8
    # 现状：单价全是 RTL 估算档 -> 两个指标都必须**报缺**（用户口径，不是故障）
    assert rep["calib"]["filled"] == []
    if pv["status"] != "APPLIED":
        assert th["per_core"] is None and th["status"] == "PENDING"
        assert ef["by_billing"][ef["billing"]]["per_token_j"] is None
        assert th["blocked_by"], "报缺时必须列出缺哪些"
    # 段落切分必须是**完整划分**：TTFT 段 + decode 段 == 总计（账本无遗漏、无重复）。
    # 这是快照法唯一真正要钉的性质 —— 它保证 TTFT 没有把 prefill 或某次 lm_head 漏掉。
    seg = th["segment_marks"]
    assert len(seg) == 1                      # n_runs = 1
    seg_pj = seg[0]["ttft"]["whole_pj"] + seg[0]["decode"]["whole_pj"]
    approx(seg_pj, rep["energy"]["total_whole_block_pj"], 1e-6)
    seg_pj_u = seg[0]["ttft"]["unit_pj"] + seg[0]["decode"]["unit_pj"]
    approx(seg_pj_u, rep["energy"]["total_unit_pj"], 1e-6)
    # 拍数同理（1 core 口径）
    approx(seg[0]["ttft"]["cycles_by_cores"]["1"] + seg[0]["decode"]["cycles_by_cores"]["1"],
           rep["latency"]["cycles_serial_1core"], 1e-6)
    # 三段的自洽：e2e 拍 = ttft 拍 + decode 拍（每个 core 数都成立）
    for k, v in th["clock_free"].items():
        if isinstance(v, dict):
            approx(v["e2e_cycles"], v["ttft_cycles"] + v["decode_cycles"], 1e-9)
    # 两种计费口径都在（efficiency 自己并列给出）
    assert set(ef["by_billing"]) == {"whole_block", "unit"}


def test_report_renders_new_sections():
    """报告打印：新增三段能渲染，且缺数据时显示「—」而不是崩掉或显示估算值。"""
    rep = run_llm(small_cfg()).report
    txt = format_report(rep)
    for tag in ("[13] 吞吐率", "[14] 能量效率", "[15] 单价来源缺口", "[16] 口径说明"):
        assert tag in txt, f"报告里缺 {tag}"
    assert "缺新思数据" in txt
    # 缺口表里必须点名 clock_ns 与它要哪个工具（指南 §4.2）
    assert "clock_ns" in txt and "PrimeTime" in txt
    # 旧的 [13] 口径说明已让位给新段（编号不重复）。
    # 只数**行首**的分段标题 —— [0] 与 [13]/[14] 的正文里会交叉引用「见 [13]」「见 [15]」，
    # 按全串 count 会把那些引用也算进来（曾因此误报）。
    heads = [ln for ln in txt.splitlines() if ln.startswith("[")]
    assert sum(1 for h in heads if h.startswith("[13]")) == 1, "分段 [13] 出现了不止一次"
    assert sum(1 for h in heads if h.startswith("[15]")) == 1, "分段 [15] 出现了不止一次"


# --------------------------------------------------------------------------
# K 块计费的记账规则（`schedule.linear` 自己切开 K 维时必须遵守）
#
# 缺陷回顾：`linear()` 一直按 `for kb in range(bk)` 逐 K 块发出，却把**完整 `inn`**
# 当 K 传给 `Core.matmul`；`Cost.matmul` 内部再按 `ceil(K/1024)` 切一次，于是 K 维的
# 块数 / MAC / 累加轮数全被计了 `bk` 遍。指纹：`o_proj`(K=2048) 记 2 倍、
# `down_proj`(K=3072) 记 3 倍，而 `q/k/v/gate/up_proj`(K=1024, bk=1) 不受影响 ——
# 这正是它长期未被发现的原因。后果是 `down_proj` 的成本随 `intermediate`
# **平方增长**，换任何 FFN 宽度不同的模型做横向对比都会被系统性扭曲。
# --------------------------------------------------------------------------

def _split_k_cost(c: Cost, rows: int, inn: int) -> tuple[int, int, float, int]:
    """按 `linear()` 的**正确**规则把 K 维切开记账，返回 `(总块数, 总MAC, whole_pj, 拍数)`。

    规则：每个 K 块只记自己那一个单位块的块数；K 向的 `bk-1` 轮累加**只在最后一个
    K 块上一次记清**（逐 token 各一次）。
    """
    bk = -(-inn // BLOCK)
    blocks = macs = cyc = 0
    pj = 0.0
    for kb in range(bk):
        kin = min(BLOCK, inn - kb * BLOCK)
        rounds = (bk - 1) if kb + 1 == bk else 0
        mm = c.matmul(1, rows, kin, accum_rounds=rounds)
        blocks += mm.n_blocks
        macs += mm.macs
        pj += mm.whole_pj
        cyc += mm.cycles
    return blocks, macs, pj, cyc


def test_k_block_split_bills_each_block_once():
    """切 K 记账 == 整段 K 一次记账（能耗、拍数、MAC、块数四项全等）。"""
    c = Cost.from_prices(prices())
    for rows, inn in ((1024, 2048), (1024, 3072), (1024, 1024), (128, 2048),
                      (1024, 2560), (384, 4224), (7, 5000)):
        whole = c.matmul(1, rows, inn)
        b, m, pj, cyc = _split_k_cost(c, rows, inn)
        assert b == whole.n_blocks == -(-inn // BLOCK), (rows, inn, b, whole.n_blocks)
        assert m == whole.macs == rows * inn, (rows, inn)
        approx(pj, whole.whole_pj, 1e-9)
        assert cyc == whole.cycles, (rows, inn, cyc, whole.cycles)


def test_linear_no_longer_overcounts_k_blocks():
    """`linear()` 的块数 == 调用次数，且 MAC == `tokens x out x in`（线性，不随 `bk` 翻倍）。"""
    q = Qwen3Config(hidden=128, layers=1, q_heads=16, kv_heads=2, head_dim=128,
                    intermediate=2048, vocab=512)
    cfg = LlmConfig(prompt_tokens=8, max_new_tokens=3, collect_trace=False,
                    model=ModelOverride(hidden=128, layers=1, heads=16, kv_heads=2,
                                        head_dim=128, intermediate=2048, vocab=512))
    rep = run_llm(cfg, prompt="x").report
    obk = rep["ops_by_kind"]
    # 一层 token 数 = prefill 的 S 个 + decode 的 (T-1) 个（首 token 已由 prefill 那批算出）
    t_layers = cfg.prompt_tokens + (cfg.max_new_tokens - 1)
    # q_dim = 16x128 = 2048 > 1024 → q_proj 输出切 2 块；o_proj/down_proj 的 K = 2048 切 2 块
    for kind, out, inn in (("q_proj", q.q_dim, q.hidden),
                           ("o_proj", q.hidden, q.q_dim),
                           ("down_proj", q.hidden, q.intermediate),
                           ("gate_proj", q.intermediate, q.hidden)):
        r = obk[kind]
        expect_blocks = (-(-out // BLOCK)) * (-(-inn // BLOCK)) * t_layers
        assert r["blocks"] == r["count"] == expect_blocks, (kind, r["blocks"], r["count"])
        assert r["macs"] == t_layers * out * inn, (kind, r["macs"])
    # 关键交叉验证：`down_proj`(1024x2048) 与 `gate_proj`(2048x128) 不同形，
    # 但同为「K 切 2 块的 128 行输出」，`down_proj` 的 MAC 必须严格线性于 intermediate。
    assert obk["down_proj"]["macs"] == t_layers * q.hidden * q.intermediate


def test_compute_rows_have_blocks_equal_count():
    """不变量：修复后每个 compute 行的 `blocks == count`（每单位块记一块）。"""
    rep = run_llm(small_cfg(collect_trace=False), prompt="x").report
    bad = [(k, v["blocks"], v["count"]) for k, v in rep["ops_by_kind"].items()
           if v["cat"] == "compute" and v["blocks"] != v["count"]]
    assert not bad, f"下列 compute 行的 blocks != count：{bad}"
    assert rep["call_counts"]["unit_blocks"] == sum(
        v["blocks"] for v in rep["ops_by_kind"].values() if v["cat"] == "compute")


def test_accum_rounds_override_and_guard():
    """`accum_rounds` 覆盖默认 `bk-1`；负数拒绝；`scaled()` 保留单次的 rounds。"""
    c = Cost.from_prices(prices())
    # 默认仍是 bk-1（不传就不改变任何既有调用点）
    assert c.matmul(1, 1024, 3072).rounds == 2
    assert c.matmul(1, 1024, 1024).rounds == 0
    # 覆盖
    mm = c.matmul(1, 1024, 1024, accum_rounds=2)
    assert (mm.rounds, mm.accum_rounds) == (2, 2)
    approx(mm.accum_whole_pj, 2 * (1 * BLOCK) * prices().reduction_add_pj)
    assert mm.cycles == c.block_cycles + 2
    zero = c.matmul(1, 1024, 1024, accum_rounds=0)
    assert zero.accum_whole_pj == 0.0 and zero.accum_unit_pj == 0.0
    assert zero.cycles == c.block_cycles
    # scaled() 不放大 rounds（累加量已在 accum_*_pj 里乘过）
    assert mm.scaled(7).rounds == 2 and mm.scaled(7).accum_whole_pj == 7 * mm.accum_whole_pj
    # 负轮数直接拒绝，不静默取 0
    for bad in (-1, -5):
        try:
            c.matmul(1, 1024, 1024, accum_rounds=bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"accum_rounds={bad} 应报错")


def test_default_config_totals_match_closed_form():
    """默认口径（Qwen3-0.6B，128 -> 1024）的总块数与总 MAC 用**闭式**钉住。

    替代 276 s 的实跑：全部账目都是形状的整数函数，可以从 `Qwen3Config` 直接算出来。
    修复后的真值：601,945,180 块 / 743,186,628,608 MAC（修复前是 602,203,004 / 1,013,534,687,232）。
    """
    q, c = Qwen3Config(), Cost.from_prices(prices())
    S, T, L, n_runs = 128, 1024, q.layers, 1
    t_layer = S + (T - 1)                      # 每层的 token 数：prefill S 个 + decode T-1 个
    specs = Qwen3Params(q).layer_matrices(0)
    blk = macs = 0
    for m in specs:
        bn, bk = -(-m.out_features // BLOCK), -(-m.in_features // BLOCK)
        blk += bn * bk * t_layer
        macs += t_layer * m.out_features * m.in_features
    blk *= L
    macs *= L
    # 注意力：每层 pairs 数 = 同一层里 QK 与 PV 各记一遍，(kv_head x q_head) 个子块各调一次
    pairs_layer = S * S + sum(S + t for t in range(1, T))     # prefill 的 S 行 + 每个 decode 步
    assert pairs_layer == S * S + (T - 1) * S + (T - 1) * T // 2
    n_sub = q.kv_heads * q.gqa_group                          # 每个 (kv_head, q_head) 组合
    attn_pairs = pairs_layer * n_sub * L
    for _ in range(2):                                        # attn_qk + attn_pv
        blk += attn_pairs
        macs += attn_pairs * q.head_dim                       # 每次 1 x head_dim @ head_dim x 1
    # lm_head：绑权重，按输出块切；K=hidden 切 bk 块
    vocab_blocks = -(-q.vocab // BLOCK)
    n_lm = n_runs * (1 + (T - 1))                             # prefill 一次 + 每个 decode 步一次
    blk += vocab_blocks * n_lm
    macs += n_lm * (sum(min(BLOCK, q.vocab - b * BLOCK) for b in range(vocab_blocks))
                    * q.hidden)
    assert blk == 601_945_180, blk
    assert macs == 743_186_628_608, macs


# --------------------------------------------------------------------------
# 公用小工具
# --------------------------------------------------------------------------
# 12. 算子序列 golden：段二重构（形状 + 架构族切换）的**唯一硬证据**
#
# `tests/llm_golden.py` 是**重构前**从 `run_llm()` 内部逐行抓下来的账目快照
# （捕获时机在段一 K 块修正之后、段二架构重构之前）。重构的要求是「逐位不变」，
# 所以这一节一律用 `==`，**不用 `approx`**。
#
# golden 被压成「一个 kind 模板 + 层区间 + 每 (phase, kind) 一组五行数」，
# 压缩所依据的两条恒等式由这里**自己重新断言**：层与层不再同构时这里会红，
# 而不是静默拿一层的数当全部。
# --------------------------------------------------------------------------

from dataclasses import replace as _replace                        # noqa: E402
from tests import llm_golden as golden                             # noqa: E402
from yrr_v3.llm import GIB, capacity, compare                            # noqa: E402
from yrr_v3.llm import inference as _inf                                 # noqa: E402
from yrr_v3.llm.arch import (ArchParams, load_config, parse_config,      # noqa: E402
                             resolve_model, zoo_entry, zoo_names)
from yrr_v3.llm.report import format_compare                             # noqa: E402

_GOLDEN_KW = {
    # 小形状：1 层、hidden 64，走 `--smoke` 那条路（`ModelOverride`）。
    "small": dict(prompt_tokens=8, max_new_tokens=4, model=ModelOverride(
        hidden=64, layers=1, heads=4, kv_heads=2, head_dim=16, intermediate=128,
        vocab=512)),
    # 默认 Qwen3-0.6B 形状但只生成 4 个 token：与全长 1024 步**逐层同构**，
    # 墙钟却从 276 s 降到十几秒（形状驱动模式 1 s 以内）。全长账目另有闭式自检
    # （`test_default_config_totals_match_closed_form`）单独钉住。
    "fullshape": dict(prompt_tokens=128, max_new_tokens=4),
}


def _golden_cfg(tag: str, forward: str) -> LlmConfig:
    return LlmConfig(collect_trace=False, forward=forward, **_GOLDEN_KW[tag])


def _capture(cfg: LlmConfig):
    """跑一次 `run_llm`，并从**它自己那条路**上把 `SimContext` 实例捞出来。

    做法是把 `inference.SimContext` 暂时换成会登记的派生类，跑完换回来。
    不另写一个驱动器 —— 那样证明的就不是 `run_llm` 的行为了。
    """
    made: list = []
    orig = _inf.SimContext

    class _Spy(orig):                                    # type: ignore[misc,valid-type]
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            made.append(self)

    _inf.SimContext = _Spy
    try:
        res = _inf.run_llm(cfg)
    finally:
        _inf.SimContext = orig
    assert len(made) == 1, f"期望恰好构造一个 SimContext，实际 {len(made)} 个"
    return res, made[0]


def _r6(v: float) -> float:
    """`cycles` 进 golden 时收了六位小数，比之前同样收一下。"""
    return round(float(v), 6)


def _expand(seq, templates) -> list[tuple[str, int, str]]:
    return [(phase, layer, kind)
            for phase, l0, l1, name in seq
            for layer in range(l0, l1 + 1)
            for kind in templates[name]]


def _same_sequence(ctx, g) -> None:
    """整条 `(phase, layer, kind)` 序列 + 逐行五行数，逐位相等。"""
    rows = ctx.ledger.rows()
    got = [(r.phase, r.layer, r.kind) for r in rows]
    want = _expand(g["seq"], g["templates"])
    assert len(got) == len(want), f"账目行数不同：{len(got)} vs {len(want)}"
    for i, (a, b) in enumerate(zip(got, want)):
        assert a == b, f"第 {i} 行不同：got={a} want={b}"
    for r in rows:
        # 恒等式 2：同 (phase, kind) 的五行数在**所有层**上一致 —— 逐行比就是断言它
        w = g["num"].get((r.phase, r.kind))
        assert w is not None, f"golden 里没有 (phase, kind)={(r.phase, r.kind)!r}"
        five = (r.count, r.blocks, r.macs, _r6(r.cycles), r.elements)
        assert five == w, f"{(r.phase, r.kind)}（第 {r.layer} 层）：{five} != {w}"


def _same_totals(ctx, g) -> None:
    tot, w = ctx.ledger.totals(), g["totals"]
    assert tot["blocks"] == w["blocks"], (tot["blocks"], w["blocks"])
    assert tot["macs"] == w["macs"], (tot["macs"], w["macs"])
    assert _r6(tot["whole_pj"]) == w["whole_pj"], (tot["whole_pj"], w["whole_pj"])
    assert _r6(tot["unit_pj"]) == w["unit_pj"], (tot["unit_pj"], w["unit_pj"])
    assert _r6(ctx.ledger.total_cycles(1)) == w["cycles"]


def _same_placement(ctx, g) -> None:
    """摆放逐字节相等。

    golden 存的就是 `ctx.memdie.usage()`，只是按捕获脚本的约定去掉了 `largest`
    那一列（逐张量的字节明细，几百行）；`weights` 那一项**不在 `usage()` 里**，
    它是报告另加的（镜像来源、`shape_only`、fp32 影子字节），两种前向模式下本来就
    不同，故这里不比 —— 两边真正共享的 `total_mxfp4_bytes` 由
    `test_shape_and_numeric_agree_field_by_field` 显式钉住。
    """
    def _cut(d):
        return {k: v for k, v in d.items() if k not in ("largest", "weights")}

    got, want = _cut(ctx.memdie.usage()), _cut(g["placement"])
    if got != want:
        diff = sorted(k for k in set(got) | set(want) if got.get(k) != want.get(k))
        raise AssertionError("摆放与 golden 不同：" + "；".join(
            f"{k}: got={got.get(k)!r} want={want.get(k)!r}" for k in diff[:4]))


def _same_block(got: dict, want: dict, *, key: str, ignore=(), must_have=()) -> None:
    """报告的一个子块与 golden 逐字段相等。

    `ignore` 是**预期不同、故只比键不比值**的键（每一条都要在调用处写明理由）；
    `must_have` 是重构后**新增**的键。两者都必须显式列出来：一个键悄悄消失与一个键
    悄悄出现，都是重构跑偏的信号。
    """
    a = {k: v for k, v in got.items() if k not in ignore and k not in must_have}
    b = {k: v for k, v in want.items() if k not in ignore}
    if a != b:
        diff = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
        raise AssertionError(f"report[{key!r}] 与 golden 不同：{diff}\n" + "\n".join(
            f"  {k}:\n    got ={a.get(k)!r}\n    want={b.get(k)!r}" for k in diff[:3]))
    for k in must_have:
        assert k in got, f"report[{key!r}] 少了重构后应有的新键 {k!r}"


def _same_report(res, g) -> None:
    rep = res.report
    for key, gk in (("energy", "energy"), ("latency", "latency"),
                    ("memory_traffic", "traffic")):
        _same_block(rep[key], g[gk], key=key)
    # `core` 多了两个驻留刻画键（权重是否常驻 / 驻留粒度）
    _same_block(rep["core"], g["core"], key="core",
                must_have=("weights_resident", "resident_granularity"))
    # `call_counts` 的 `formula` 从**硬编码**改成按 spec 现算（Qwen3 稠密以外的族
    # 算子数不同，`L*9+1` 只对 Qwen3 成立），串不同是预期的；新增
    # `per_layer_operators` 同理。其余计数一个都不许动。
    _same_block(rep["call_counts"], g["call_counts"], key="call_counts",
                ignore=("formula",), must_have=("per_layer_operators",))


def test_operator_sequence_golden_small():
    """小形状 + 真数值：算子序列与全部账目**逐位**等于重构前的 golden。"""
    res, ctx = _capture(_golden_cfg("small", "numeric"))
    _same_sequence(ctx, golden.SMALL)
    _same_totals(ctx, golden.SMALL)
    _same_report(res, golden.SMALL)
    _same_placement(ctx, golden.SMALL)
    # 这两项只在数值模式成立：形状驱动不分配 KV 的 host 影子、也不做采样
    assert tuple(ctx.kv.shape) == tuple(golden.SMALL["kv_shape"])
    assert list(res.generated_ids) == list(golden.SMALL["generated_ids"])


def test_operator_sequence_golden_fullshape():
    """默认 Qwen3-0.6B 形状（128 -> 4）、形状驱动模式：序列与账目逐位不变。

    这是「换模型/换模式不会悄悄改账」的那条证据里覆盖面最广的一轮：
    28 层、全部七种投影、GQA 注意力、绑权重的 lm_head 都过一遍。
    """
    res, ctx = _capture(_golden_cfg("fullshape", "shape"))
    _same_sequence(ctx, golden.FULLSHAPE)
    _same_totals(ctx, golden.FULLSHAPE)
    _same_report(res, golden.FULLSHAPE)
    _same_placement(ctx, golden.FULLSHAPE)
    assert ctx.kv.size == 0            # 形状驱动不分配 KV 的 host 影子


# --------------------------------------------------------------------------
# 13. 两种前向模式等价：账目是**形状的纯函数**
# --------------------------------------------------------------------------

def test_shape_and_numeric_agree_field_by_field():
    """同一形状、两种前向模式：账目逐字段 `==`（整数计数，不是近似）。

    允许不同的只有五处，且每一处都在这里显式写出来：
    `config.wall_clock_s`（唯一非确定字段）、`config.forward` 与
    `config.kv_shadow`（模式开关本身）、`output.generated_*`（随机权重下的采样
    本来就没有意义）、`placement.weights` 的元信息（形状驱动的镜像只有形状）、
    以及 `capacity` 里由影子口径导出的那三项（形状驱动真的不分配 fp32 影子，
    预算必须报**有效**口径，否则同一个报告里会出现 `none` 与 `fp32` 并存）。
    die 一侧的容量账（`terms` / `total_bytes` / `max_*`）不受影子影响，整体相等。
    """
    res_n, ctx_n = _capture(_golden_cfg("small", "numeric"))
    res_s, ctx_s = _capture(_golden_cfg("small", "shape"))

    fields = ("phase", "layer", "kind", "count", "blocks", "macs", "elements")

    def _rows(ctx):
        out = []
        for r in ctx.ledger.rows():
            row = [getattr(r, k) for k in fields]
            row.append(_r6(r.cycles))
            out.append(tuple(row))
        return out

    assert _rows(ctx_n) == _rows(ctx_s)
    assert ctx_n.ledger.totals() == ctx_s.ledger.totals()
    assert ctx_n.memdie.traffic() == ctx_s.memdie.traffic()
    _same_placement(ctx_s, golden.SMALL)             # 两种模式都等于同一份 golden

    # 影子口径导出的三项**只**在 `capacity` 里开这个口子，范围钉死
    _SHADOW = ("kv_shadow", "host_shadow_bytes", "host_bytes")

    def _cap(res):
        return {k: v for k, v in res.report["capacity"].items() if k not in _SHADOW}

    cn, cs = _cap(res_n), _cap(res_s)
    assert cn == cs, ("两种模式的容量账（除影子口径外）不一致："
                      + "；".join(f"{k}:{cn[k]}!={cs.get(k)}"
                                  for k in sorted(cn) if cn[k] != cs.get(k)))
    assert res_n.report["capacity"]["kv_shadow"] == "fp32"
    assert res_s.report["capacity"]["kv_shadow"] == "none"
    assert res_n.report["capacity"]["host_shadow_bytes"] > 0
    assert res_s.report["capacity"]["host_shadow_bytes"] == 0

    differ = []
    for key in sorted(set(res_n.report) | set(res_s.report)):
        if key in ("config", "forward", "output", "placement", "capacity"):
            continue
        if res_n.report[key] != res_s.report[key]:
            differ.append(key)
    assert not differ, f"两种模式的账目不一致：{differ}"

    # 被排除的五项也钉住，免得「排除」变成藏差异的抽屉
    assert res_n.report["forward"]["mode"] == "numeric"
    assert res_s.report["forward"]["mode"] == "shape"
    assert res_n.report["config"]["kv_shadow"] == "fp32"
    assert res_s.report["config"]["kv_shadow"] == "none"
    for k in ("generated_ids", "generated_text", "generated_ids_head"):
        assert k in res_n.report["output"] and k in res_s.report["output"]
    assert res_n.report["placement"]["weights"]["shape_only"] is False
    assert res_s.report["placement"]["weights"]["shape_only"] is True
    assert (res_n.report["placement"]["weights"]["total_mxfp4_bytes"]
            == res_s.report["placement"]["weights"]["total_mxfp4_bytes"])


# --------------------------------------------------------------------------
# 14. 形状驱动模式：零分配
# --------------------------------------------------------------------------

def test_shape_only_image_has_shapes_and_refuses_values():
    """形状驱动的权重镜像：`entry_shape()` / `nbytes()` 可用，`get()` **主动抛错**。

    `get()` 抛错本身就是「数值路径真的被跳过」的免费证明 —— 哪天有谁在形状模式
    下悄悄读了一次数值，这里会响。
    """
    img = build_weight_image(zoo_entry("qwen3-0.6b"), None, 1, "shape")
    d = img.as_dict()
    assert d["shape_only"] is True
    assert d["total_fp32_shadow_bytes"] == 0
    assert d["matrices"] == 28 * 7 + 1                  # 每层 7 个投影 + lm_head
    names = sorted(img.matrix_names())
    assert len(names) == d["matrices"]
    for n in (names[0], names[-1]):
        assert img.entry_shape(n) and img.nbytes(n) > 0
    try:
        img.get(names[0])
    except RuntimeError as ex:
        assert "shape-only" in str(ex)
    else:
        raise AssertionError("形状驱动的镜像不该拿得出数值")


def test_shape_mode_leaves_no_kv_shadow_in_host_memory():
    """KV 的 fp32 影子是片上 fp4 的 `4 / 0.53125` 倍，且**不在 MEM die 上**。

    0.6B/上下文 10 时是 2.2 MB（无所谓），20B/32k 时是十几 GB（还是无所谓，
    但只在形状驱动模式下无所谓）。所以这个模式必须真的不分配它。
    """
    spec = zoo_entry("qwen3-0.6b")
    cfg = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                    forward="shape", model_spec=spec)
    res, ctx = _capture(cfg)
    assert ctx.kv.size == 0
    fp4 = capacity.kv_bytes(spec, ctx.max_ctx)
    assert res.report["placement"]["kv_cache_bytes_fp4"] == fp4
    assert list(res.report["placement"]["kv_cache_shape"]) == \
        list(capacity.kv_shape(spec, ctx.max_ctx))

    # 容量账必须记**真正分配的量**：同一条形状驱动的 run 里
    # `config.kv_shadow` 与 `capacity.kv_shadow` 不许一个说 none 一个说 fp32，
    # 更不许为一份从不存在的宿主影子报出几 MB 的 `host_shadow_bytes`。
    assert res.report["config"]["kv_shadow"] == "none"
    cap = res.report["capacity"]
    assert cap["kv_shadow"] == "none" and cap["host_shadow_bytes"] == 0

    # 数值模式则照旧分配，倍数与 `FP32_OVER_MXFP4` 一致。
    # `kv_shadow` 显式给 `"fp32"`：形状驱动会把这一档改成 `none`，而 `run_llm`
    # 现在是改**副本**、不动调用者的对象，所以这里再显式说一次更清楚。
    res_n, ctx_n = _capture(LlmConfig(**{**cfg.__dict__, "forward": "numeric",
                                         "kv_shadow": "fp32"}))
    assert list(ctx_n.kv.shape) == list(capacity.kv_shape(spec, ctx_n.max_ctx))
    assert ctx_n.kv.nbytes == int(round(fp4 * capacity.FP32_OVER_MXFP4))
    assert capacity.FP32_OVER_MXFP4 == 4.0 / 0.53125
    cap_n = res_n.report["capacity"]
    assert cap_n["kv_shadow"] == "fp32"
    assert cap_n["host_shadow_bytes"] == capacity.kv_shadow_bytes(spec, ctx_n.max_ctx)
    # 形状驱动的口径只影响宿主侧，die 上的摆放两种模式逐字节相同
    assert (cap_n["total_bytes"], cap_n["kv_bytes"], cap_n["weights_bytes"]) == \
        (cap["total_bytes"], cap["kv_bytes"], cap["weights_bytes"])


def test_run_llm_does_not_mutate_the_callers_config():
    """`run_llm(cfg)` 不许改传进来的那个对象。

    形状驱动要把 KV 影子口径降到 `none`，早先的做法是**就地**写 `cfg.kv_shadow`。
    于是同一个 `cfg` 跑过一次形状驱动之后，再跑数值模式会静默带上 `kv_shadow="none"`
    —— 报告的 KV 口径与真分配的那 8 倍影子对不上，而配置对象看起来是用户自己给的。
    """
    for mode in ("shape", "numeric", "auto"):
        cfg = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                        forward=mode, model_spec=zoo_entry("qwen3-0.6b"))
        before = dict(cfg.__dict__)
        res = run_llm(cfg)
        assert dict(cfg.__dict__) == before, (mode, "配置对象被就地改动了")
        assert res.report["config"]["kv_shadow"] == res.config.kv_shadow


# --------------------------------------------------------------------------
# 15. 容量门：解析式预算、与 MemDie 逐字节对齐、装不下先报明细
# --------------------------------------------------------------------------

def test_capacity_budget_equals_memdie_placement():
    """容量门**不分配任何张量**，纯解析地算；装得下时它与 `MemDie` 的摆放
    逐字节相等 —— 这是「两套算法不会分歧」的唯一证据。"""
    for z in ("qwen3-0.6b", "llama-3.2-1b", "gemma-2-2b", "phi-3-mini", "qwen3-14b"):
        spec = zoo_entry(z)
        cfg = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                        forward="shape", model_spec=spec)
        b = capacity.budget(spec, cfg)
        rep = run_llm(cfg).report
        assert b.total_bytes == rep["placement"]["used_bytes"], z
        # `terms()` 是 (键, 中文名, 字节, 说明) 四元组列表；分项之和必须等于总额
        assert sum(t[2] for t in b.terms()) == b.total_bytes, z
        assert [t[0] for t in b.terms()] == ["weights", "norms", "scratch", "act", "kv"], z
        assert list(capacity.kv_shape(spec, cfg.prompt_tokens + cfg.max_new_tokens)) \
            == list(rep["placement"]["kv_cache_shape"]), z
        assert b.fits and b.limited_by == "weights", (z, b.limited_by)


def test_capacity_gate_rejects_before_allocating():
    """装不下：先出**明细**、再硬报错，且在报错之前**没有分配过权重镜像**。

    `build_weight_image` 被换成会登记的桩：它一次都不许被调用 —— 这正是
    `run_llm()` 里「先算预算、再分配」那个顺序的保证（否则会在一个无望的配置上
    先申请几十 GB 的 numpy 数组）。
    """
    spec = zoo_entry("llama-3.1-70b")
    cfg = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                    forward="shape", model_spec=spec)
    calls: list = []
    orig = _inf.build_weight_image

    def _spy(*a, **k):
        calls.append(a)
        return orig(*a, **k)

    _inf.build_weight_image = _spy
    try:
        try:
            run_llm(cfg)
        except capacity.CapacityError as ex:
            err = ex
        else:
            raise AssertionError("70B 装不进 16 GiB，应该抛 CapacityError")
    finally:
        _inf.build_weight_image = orig

    assert not calls, "报错之前就已经分配权重镜像了"
    b = err.budget
    assert not b.fits
    assert b.total_bytes == capacity.budget(spec, cfg).total_bytes
    assert b.limited_by == "weights"
    assert b.max_ctx_that_fits <= 0                 # 权重都放不下，谈不上 ctx
    assert "llama-3.1-70b" in (b.render() + str(b.__dict__))
    assert isinstance(err, MemoryError)             # 沿用内建的语义


def test_mxfp4_ceiling_and_the_0_6b_to_20b_envelope():
    """MXFP4 = 0.5 + 1/32 = 0.53125 B/参数 ⇒ 16 GiB 装约 32 B 参数。

    推论是本层的结论性事实：**用户要的 0.6B–20B 区间远不是被 die 的权重容量
    卡住的**，动物园里装不下的三个都在区间之外；区间内真正的瓶颈是宿主侧的
    fp32 影子与长上下文下的 KV。
    """
    per = capacity.MXFP4_BYTES_PER_PARAM
    assert per == 0.5 + 1 / 32 == 0.53125
    ceiling = 16 * GIB / per
    assert 30e9 < ceiling < 34e9, ceiling

    over = {z for z in zoo_names() if not capacity.budget(zoo_entry(z), LlmConfig()).fits}
    assert over == {"llama-3.1-70b", "mixtral-8x7b", "qwen3-32b"}, over

    inband = {z for z in zoo_names()
              if 0.6e9 <= ArchParams(zoo_entry(z)).accounting()["total_elements"] <= 20e9}
    assert inband, "0.6B–20B 区间里一个模型都没有？"
    assert not (inband & over), f"区间内装不下的模型：{sorted(inband & over)}"


def test_zoo_param_counts_are_locked():
    """动物园的参数量钉住：改形状就该改这张表，表对不上说明形状改错了。

    取的是 `ArchParams.accounting()` 的原值（不做四舍五入）：参数量是形状的纯函数，
    这里逐位相等才有意义 —— 差一个元素就说明某条投影的尺寸算错了。
    """
    want = {
        "deepseek-v2-lite": 15706.484224, "gemma-2-2b": 2614.341888,
        "gemma-2-9b": 9241.705984, "gemma-3-4b": 3880.08192,
        "llama-3.1-70b": 70553.706496, "llama-3.1-8b": 8030.261248,
        "llama-3.2-1b": 1235.8144, "llama-3.2-3b": 3212.749824,
        "mistral-7b-v0.3": 7248.023552, "mixtral-8x7b": 46702.792704,
        "olmoe-1b-7b": 6919.09632, "phi-3-mini": 3821.079552,
        "qwen2-moe-2.7b": 14139.426816, "qwen2.5-1.5b": 1543.65696,
        "qwen2.5-14b": 14769.6896, "qwen2.5-3b": 3085.846528,
        "qwen2.5-7b": 7615.487488, "qwen3-0.6b": 596.04992,
        "qwen3-1.7b": 1720.574976, "qwen3-14b": 14768.3072,
        "qwen3-32b": 32762.123264, "qwen3-4b": 4022.468096,
        "qwen3-8b": 8190.73536,
    }
    got = {z: ArchParams(zoo_entry(z)).accounting()["total_params_millions"]
           for z in zoo_names()}
    assert got == want
    # 与 Instruction/GEMM次数统计.md §1.1 的 596.0 M 对齐（绑权重的词表只算一份）
    assert got["qwen3-0.6b"] == 596.04992


# --------------------------------------------------------------------------
# 16. HF config.json 解析：手写取样逐字段对齐动物园条目
#
# **本机没有网络**（huggingface.co 报 read ECONNRESET），所以这批 config.json 是照
# 公开字段名**手写**的。它验证的是「解析器符合对 HF 字段名的理解」，**不等于**
# 「解析器能读 HF 的真文件」。缓解：取样只用公认稳定的字段；未知键只收集不报错；
# 必填键缺失硬报错。**首次接真实 checkpoint 时必须复验**。
# --------------------------------------------------------------------------

_CFG_DIR = Path(__file__).resolve().parent / "data" / "llm_cfgs"

_CFG_PAIRS = {
    "qwen3_0_6b": "qwen3-0.6b",
    "llama_3_2_1b": "llama-3.2-1b",
    "mistral_7b_v0_3": "mistral-7b-v0.3",
    "gemma_2_2b": "gemma-2-2b",
    "gemma_3_4b": "gemma-3-4b",
    "phi_3_mini": "phi-3-mini",
    "qwen2_moe_2_7b": "qwen2-moe-2.7b",
    "deepseek_v2_lite": "deepseek-v2-lite",
    "olmoe_1b_7b": "olmoe-1b-7b",
}

# 这份比对里**不比**的字段，理由逐条写明：
#   structure_notes / approximations：动物园条目自带的话，与文件无关；
#   unknown_keys / source：本来就是「这份文件」的元信息；
#   head_dim_explicit：文件里**写没写** `head_dim` 的来源标记。动物园条目把
#     `head_dim=128` 写死（故 True），而真实的 DeepSeek-V2-Lite config.json 不给
#     这个键、由 `hidden / q_heads` 推出来（故 False）—— 取值两边都是 128。
_CFG_SKIP = ("structure_notes", "approximations", "unknown_keys", "source",
             "head_dim_explicit")


def _cfg(name: str) -> dict:
    return json.loads((_CFG_DIR / f"{name}.json").read_text(encoding="utf-8"))


def test_handwritten_hf_configs_parse_to_the_zoo_specs():
    """九个手写 config.json 解析出来的 spec 与动物园条目**逐字段相同**。

    族名单独用一张字面表钉住（`vars` 比对只保证「文件解析结果 == 动物园条目」，
    两边一起写错时它不会响）。
    """
    fam = {"qwen3_0_6b": "qwen3", "llama_3_2_1b": "llama",
           "mistral_7b_v0_3": "mistral", "gemma_2_2b": "gemma2",
           "gemma_3_4b": "gemma3", "phi_3_mini": "phi3",
           "qwen2_moe_2_7b": "qwen2_moe", "deepseek_v2_lite": "deepseek_v2",
           "olmoe_1b_7b": "olmoe"}
    assert sorted(fam) == sorted(_CFG_PAIRS)
    for fn, z in sorted(_CFG_PAIRS.items()):
        spec = load_config(_CFG_DIR / f"{fn}.json")
        want = zoo_entry(z)
        a = {k: v for k, v in vars(spec).items() if k not in _CFG_SKIP}
        b = {k: v for k, v in vars(want).items() if k not in _CFG_SKIP}
        diff = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
        assert not diff, (fn, {k: (a.get(k), b.get(k)) for k in diff})
        assert spec.family == want.family == fam[fn], (fn, spec.family)
        # 逐层注意力种类是 config.json 里最隐蔽的一项（Gemma 的交替），单独比
        assert spec.layer_attn_kinds == want.layer_attn_kinds, fn


def test_gemma3_text_config_is_unwrapped_from_a_multimodal_file():
    """Gemma-3 的 config.json 是多模态的：语言模型那份在 `text_config` 里，
    `model_type` 写 `gemma3_text`。两条都要认，否则一份真文件直接解析失败。"""
    d = _cfg("gemma_3_4b")
    assert "hidden_size" not in d and d["text_config"]["model_type"] == "gemma3_text"
    spec = parse_config(d)
    assert spec.family == "gemma3" and spec.layers == 34 and spec.hidden == 2560
    assert spec.layer_attn_kinds[:7] == ("sliding",) * 5 + ("full", "sliding")


def test_missing_required_key_fails_loud_and_names_the_key():
    """必填键缺失**硬报错并指名缺哪个键**，不静默套族默认。

    fail loud 在这里的分量：静默套默认会得出一个自洽但错的报告，而接真
    checkpoint 时那种错没人会怀疑。
    """
    base = _cfg("qwen3_0_6b")
    for k in ("hidden_size", "num_hidden_layers", "num_attention_heads", "vocab_size"):
        d = dict(base)
        d.pop(k)
        try:
            parse_config(d)
        except KeyError as ex:
            assert k in str(ex), (k, str(ex))
        else:
            raise AssertionError(f"缺 {k} 应该硬报错")


def test_moe_and_mla_partial_keys_fail_loud():
    """MoE / MLA 只给一半字段同样是硬错：半套字段能算出一个**看着对**的数。

    报错信息要**指名缺哪个键**，并列出已经看见的那几个（真实文件里字段名与
    HF 版本有关，看不出「它到底想干什么」时的下一步就是去看这几个键）。
    """
    d = _cfg("qwen2_moe_2_7b")
    d.pop("num_experts_per_tok")
    try:
        parse_config(d)
    except KeyError as ex:
        assert "top_k" in str(ex), str(ex)
        assert "moe_intermediate" in str(ex) and "n_experts" in str(ex), str(ex)
    else:
        raise AssertionError("MoE 缺 top-k 应该硬报错")

    m = _cfg("deepseek_v2_lite")
    m.pop("kv_lora_rank")
    try:
        parse_config(m)
    except KeyError as ex:
        assert "kv_lora_rank" in str(ex), str(ex)
        assert "qk_nope_head_dim" in str(ex), str(ex)
    else:
        raise AssertionError("MLA 缺 kv_lora_rank 应该硬报错")


def test_unknown_keys_are_collected_not_fatal():
    """未知键只收集不报错：真文件里总有几十个本层不读的键。"""
    d = _cfg("qwen3_0_6b")
    d["some_future_field"] = 123
    spec = parse_config(d)
    assert "some_future_field" in spec.unknown_keys
    assert "torch_dtype" in spec.unknown_keys        # 真文件里必然有、本层不读
    assert "use_sliding_window" not in spec.unknown_keys   # 这个是真读了的
    assert spec.hidden == 1024 and spec.layers == 28


def test_unknown_model_type_errors_listing_known_families():
    d = _cfg("qwen3_0_6b")
    d["model_type"] = "brand_new_arch"
    d.pop("architectures")
    try:
        parse_config(d)
    except KeyError as ex:
        msg = str(ex)
        assert "brand_new_arch" in msg
        for fam in ("qwen3", "llama", "gemma2", "deepseek_v2"):
            assert fam in msg, msg
    else:
        raise AssertionError("认不出的 model_type 应该报错并列出已知族")


def test_use_sliding_window_false_means_full_attention():
    """Qwen2 系照给 `sliding_window: 4096`，却用 `use_sliding_window` 关掉它。

    不看这个开关，Qwen2 / Qwen2.5 / Qwen2-MoE 会被整体算成滑窗 —— pair 数少算，
    而账目看上去仍然自洽（正是这个仓库最在意的那类错）。
    """
    d = _cfg("qwen2_moe_2_7b")
    assert d["sliding_window"] == 4096 and d["use_sliding_window"] is False
    spec = parse_config(d)
    assert spec.sliding_window is None and spec.default_attn_kind == "full"
    assert any("use_sliding_window" in s for s in spec.approximations)
    # Mistral 是真的全程滑窗，两者必须分得开
    m = parse_config(_cfg("mistral_7b_v0_3"))
    assert m.sliding_window == 4096 and m.default_attn_kind == "sliding"


def test_llama3_rope_scaling_is_approximated_not_rejected():
    """`rope_scaling.type = llama3` 是真实 Llama-3.1/3.2 的写法。

    它只改频率取值、不改任何账目（RoPE 是乘性逐元素算子，账目由
    `partial_rotary_factor` 与 theta 决定），所以按 theta 语义近似并在报告里标注，
    不因此拒绝一份真 checkpoint。
    """
    d = _cfg("llama_3_2_1b")
    assert d["rope_scaling"]["rope_type"] == "llama3"
    spec = parse_config(d)
    assert spec.rope.scaling == "none" and spec.rope.scaling_factor == 1.0
    assert any("llama3" in s for s in spec.approximations)
    # 未知的 scaling 类型仍然硬报错
    bad = dict(d)
    bad["rope_scaling"] = {"rope_type": "invented_scaling", "factor": 2.0}
    try:
        parse_config(bad)
    except KeyError as ex:
        assert "invented_scaling" in str(ex)
    else:
        raise AssertionError("认不出的 rope_scaling 应该报错")


def test_repo_id_resolution_never_silently_falls_back():
    """repo-id 那条路要 `huggingface_hub`，本机没有：必须**干净报错并指名缺哪个
    包**，绝不静默退回 Qwen3-0.6B 的形状。"""
    try:
        import huggingface_hub                     # noqa: F401
    except ImportError:
        has_hub = False
    else:
        has_hub = True
    if not has_hub:
        try:
            resolve_model("meta-llama/Llama-3.2-1B")
        except ImportError as ex:
            assert "huggingface_hub" in str(ex), str(ex)
            assert "qwen3-0.6b" in str(ex)          # 顺带告诉用户动物园里有什么
        else:
            raise AssertionError("缺 huggingface_hub 时 repo-id 应该报 ImportError")
        try:
            resolve_model("no-such-model-anywhere")
        except ImportError as ex:
            assert "huggingface_hub" in str(ex)
        else:
            raise AssertionError("认不出的名字不该静默回退")
    # 动物园名与 `json:` 内联两条路都不依赖网络
    assert resolve_model("qwen3-0.6b").hidden == 1024
    inline = resolve_model('json:{"model_type":"llama","hidden_size":64,'
                           '"num_hidden_layers":1,"num_attention_heads":1,'
                           '"vocab_size":128}')
    assert inline.family == "llama" and inline.hidden == 64 and inline.layers == 1


def test_default_arch_spec_is_qwen3_0_6b():
    """默认 `ArchSpec()` 就是 Qwen3-0.6B：与本层原有的 `Qwen3Config` 逐字段一致，
    参数 596.04992 M。两者分歧就意味着「不指定模型」时的口径变了。"""
    from yrr_v3.llm.arch import ArchSpec
    a, q = ArchSpec(), Qwen3Config()
    for f in ("hidden", "layers", "vocab", "q_heads", "kv_heads", "head_dim",
              "intermediate", "tie_embeddings"):
        assert getattr(a, f) == getattr(q, f), f
    assert ArchParams(a).accounting()["total_params_millions"] == 596.04992
    # MXFP4 的 0.53125 B/参数是**逐元素**的；真记到 die 上的是逐矩阵上取整后的和，
    # 所以它只会略小于 `0.53125 x 参数量`（这里小 34816 B）。两者必须都对得上。
    w = {t[0]: t[2] for t in capacity.budget(a, LlmConfig()).terms()}["weights"]
    assert w == 316616704
    assert w < capacity.MXFP4_BYTES_PER_PARAM * 596049920
    assert abs(w / 596049920 - capacity.MXFP4_BYTES_PER_PARAM) < 1e-4


# --------------------------------------------------------------------------
# 17. `--compare`：对照行与单独跑逐字段一致，JSON 可往返
# --------------------------------------------------------------------------

def test_compare_rows_match_standalone_runs():
    """每一行都走同一个 `run_llm()`：对照行与单独跑在**构造上**就不可能不一致。"""
    refs = ["qwen3-0.6b", "llama-3.2-1b", "gemma-2-2b", "deepseek-v2-lite", "qwen3-32b"]
    cfg = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                    forward="shape")
    rows = compare.rows_for(refs, cfg)
    assert [r.ref for r in rows] == refs
    assert [r.status for r in rows] == [compare.OK, compare.OK, compare.OK,
                                        compare.NOT_IMPLEMENTED,
                                        compare.OVER_CAPACITY]
    assert rows[3].report is None and rows[4].report is None
    assert "MLA" in rows[3].detail and "weights" in rows[4].detail

    for r in rows[:3]:
        alone = run_llm(LlmConfig(**{**cfg.__dict__, "model_spec": r.spec})).report
        for key in ("call_counts", "energy", "latency", "memory_traffic", "phases",
                    "ops_by_kind", "placement"):
            assert r.report[key] == alone[key], (r.ref, key)


def test_compare_json_round_trips_without_numpy():
    """对照 JSON 必须是纯 Python 标量：`json.dumps` 不许炸（numpy 标量会炸）。"""
    cfg = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                    forward="shape")
    cmp_res = compare.compare(["qwen3-0.6b", "llama-3.2-1b", "deepseek-v2-lite",
                               "qwen3-32b"], cfg)
    js = compare.as_json(cmp_res)
    text = json.dumps(js, ensure_ascii=False)         # numpy 标量会在这里 TypeError
    assert len(text) > 0
    back = json.loads(text)
    assert [r["status"] for r in back["rows"]] == \
        [compare.OK, compare.OK, compare.NOT_IMPLEMENTED, compare.OVER_CAPACITY]
    for r in back["rows"]:
        assert len(r["cells"]) == len(compare.COLUMNS)
    # 表格渲染也要能过（只对装得下的行要求有载荷）
    lines = format_compare(cmp_res)
    assert any("qwen3-0.6b" in ln for ln in lines)
    assert any("qwen3-32b" in ln for ln in lines)


# --------------------------------------------------------------------------
# 18. 新报告段与近似项
# --------------------------------------------------------------------------

def test_report_carries_family_capacity_and_approximations():
    """族名、近似项清单、容量预算都必须是**报告字段**，不能只写在正文里。"""
    res = run_llm(LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                            forward="shape", model_spec=zoo_entry("gemma-2-2b")))
    rep = res.report
    assert rep["model"]["family"] == "gemma2"
    assert rep["model"]["title"] == "gemma-2-2b"
    assert len(rep["approximations"]) >= 2
    assert any("soft-cap" in s or "softcap" in s for s in rep["approximations"])
    cap = rep["capacity"]
    assert cap["family"] == "gemma2" and cap["fits"] is True
    assert cap["max_ctx_that_fits"] > 0 and cap["max_params_that_fits"] > 0
    assert cap["limited_by"] in ("weights", "kv_cache")
    # 逐层交替注意力必须真的走到账目里：同一模型内出现**两种**注意力代价，
    # 且滑窗那一种**严格更便宜**。窗口不咬合时两种层同价（8 个 token 远小于
    # 4096），所以这里把窗口压到 4 个 token 才看得见 —— 判据是 spec 的逐层种类，
    # 不是靠数出两堆数来反推。
    spec = _replace(zoo_entry("gemma-2-2b"), sliding_window=4)
    assert len(set(spec.layer_attn_kinds)) == 2
    ctx = _capture(LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                             forward="shape", model_spec=spec))[1]
    qk: dict[int, int] = {}
    for r in ctx.ledger.rows():
        if r.phase == "prefill" and r.kind == "attn_qk":
            qk.setdefault(r.layer, r.macs)
    assert len(qk) == spec.layers, (len(qk), spec.layers)
    slide = [v for k, v in qk.items() if spec.layer_attn_kinds[k] == "sliding"]
    full = [v for k, v in qk.items() if spec.layer_attn_kinds[k] == "full"]
    assert slide and full, (len(slide), len(full))
    assert len(set(slide)) == 1 and len(set(full)) == 1, (slide, full)
    assert slide[0] < full[0], (slide[0], full[0])

    text = format_report(rep)
    assert "[17]" in text and "容量" in text
    assert "gemma2" in text


def test_sliding_window_saturates_and_degrades_to_dense():
    """滑窗只改 pair 数：`ctx_eff = min(ctx, window)`。三条边界一次钉住。

    用 Gemma-2 做这件事是因为它**一份 spec 里同时有全注意力层与滑窗层**，两种层
    形状完全一样，于是所有比较都在同一个模型内完成 —— 不跨形状比数，也就不会把
    「形状不同」误读成「窗口生效」。

    1. 窗口 >= 上下文：滑窗层与全注意力层**逐位同价**（退化为稠密）；
    2. 窗口咬合：滑窗层严格更便宜，且全注意力层**一个数都不动**（只改该改的）；
    3. 窗口变小：pair 数单调不增、且严格更小。
    """
    base = zoo_entry("gemma-2-2b")
    kinds = base.layer_attn_kinds

    def _qk(window):
        """逐层的 `attn_qk` 计费数。用 `count`（pair 数）而不是 `macs`：整块口径下
        相邻的 pair 数会被取整到同一个块数，`macs` 分不开 26 与 33 个 pair。"""
        spec = _replace(base, sliding_window=window)
        ctx = _capture(LlmConfig(prompt_tokens=8, max_new_tokens=0,
                                 collect_trace=False, forward="shape",
                                 model_spec=spec))[1]
        return {r.layer: r.count for r in ctx.ledger.rows()
                if r.phase == "prefill" and r.kind == "attn_qk"}

    def _side(d, kind):
        return {v for k, v in d.items() if kinds[k] == kind}

    big = _qk(1000)                                   # 窗口 > 上下文
    assert len(set(big.values())) == 1, sorted(set(big.values()))
    assert _side(big, "sliding") == _side(big, "full")

    small, mid = _qk(4), _qk(6)
    n_slide = sum(1 for k in kinds if k == "sliding")
    assert n_slide > 1 and len(kinds) == base.layers       # 真的有多层滑窗层
    assert max(_side(small, "sliding")) < min(_side(small, "full")), \
        "窗口咬合后滑窗层应严格更便宜"
    # 窗口越小越省，且**严格**更省：4 -> 256、6 -> 384、1000 -> 512（饱和）
    assert max(_side(small, "sliding")) < max(_side(mid, "sliding")) \
        < max(_side(big, "sliding")), "pair 数应随窗口单调不减"
    assert min(_side(mid, "sliding")) > 0, "窗口 6 在 8 token 的上下文里仍应有 pair"
    for d in (small, mid):
        assert _side(d, "full") == _side(big, "full"), "全注意力层不该受窗口影响"


def test_resolve_forward_auto_rules_in_order():
    """`auto` 的判定顺序：显式给的赢 > 宿主影子过大或 prompt 过长退回 shape >
    否则 numeric。默认配置（Qwen3-0.6B，128 -> 1024）**必须仍是 numeric**，
    否则今天的默认报告会变。"""
    spec = zoo_entry("qwen3-0.6b")
    base = LlmConfig(prompt_tokens=8, max_new_tokens=2, collect_trace=False,
                     model_spec=spec)
    assert capacity.resolve_forward(spec, base) == "numeric"
    for fwd in ("numeric", "shape"):
        assert capacity.resolve_forward(spec, LlmConfig(**{**base.__dict__,
                                                           "forward": fwd})) == fwd
    long_prompt = LlmConfig(**{**base.__dict__,
                               "prompt_tokens": capacity.AUTO_NUMERIC_MAX_PROMPT_TOKENS + 1})
    assert capacity.resolve_forward(spec, long_prompt) == "shape"
    # 大模型的宿主影子（fp32 的 8 倍）自己就会把它推去 shape
    assert capacity.numeric_host_bytes(zoo_entry("qwen3-14b"), LlmConfig()) \
        > capacity.AUTO_NUMERIC_MAX_HOST_BYTES
    assert capacity.resolve_forward(zoo_entry("qwen3-14b"), LlmConfig()) == "shape"
    # 默认口径：一个字都没改
    assert capacity.resolve_forward(Qwen3Config(), LlmConfig()) == "numeric"


# --------------------------------------------------------------------------

def _smoke_ctx(prompt_tokens: int = 8, max_new_tokens: int = 3) -> SimContext:
    q = small_qcfg()
    return SimContext(small_cfg(prompt_tokens=prompt_tokens, max_new_tokens=max_new_tokens),
                      prices(), q, build_weight_image(q, None, 1, "full"))


def _smoke_core() -> Core:
    return Core(Cost.from_prices(prices()), Ledger(), prices())


if __name__ == "__main__":
    from yrr_v3.llm.report import setup_console
    setup_console()
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    bad = 0
    for fn in fns:
        try:
            fn()
            print(f"PASS {fn.__name__}")
        except Exception as ex:  # noqa: BLE001
            bad += 1
            print(f"FAIL {fn.__name__}: {type(ex).__name__}: {ex}")
    print(f"\n{len(fns) - bad}/{len(fns)} passed")
    sys.exit(1 if bad else 0)
