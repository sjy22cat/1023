"""Contract tests with SYNTHETIC values written only to temporary files.

MEASURED here exercises the status validator; this fixture is not a hardware
characterization and must never be installed as the production parameter file.
"""
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import subprocess
import sys

from yrr_v3 import V3Config, V3Datasheet, load_1017_calibration, run_v3
from yrr_v3.rtl_dataset import (SCHEMA, CONFIG_FIELDS, STRUCTURE_FIELDS,
                                TIMING_CONFIG, AREA_FIELDS, ENERGY_FIELDS)
from yrr_v3.llm.config import LlmPrices, LlmConfig, ModelOverride, prices_from_dataset
from yrr_v3.llm.inference import run_llm
from tests.hardware_fixture import synthetic_nonmac


def complete_synthetic_contract():
    cfg = asdict(V3Config())
    structure = {k: 32 for k in STRUCTURE_FIELDS}
    structure.update(payload_bits=128, scale_bits=8, gsram_depth=1024,
                     gsram_pages=1, mc_count=32768,
                     mc_mapping="mc_id=tile_id*pe_per_tile+pe_id")
    hw = {k: cfg[k] for k in CONFIG_FIELDS}
    hw.update(ideal_mem_die=False, mem_die_bytes_per_cycle=17, weight_supply_mode="tile_cache")
    timing = {src: cfg[dst] for dst, src in TIMING_CONFIG.items()}
    timing.update(clock_ns=2.0, reduction_cycles=5)
    energy = {k: 0.01 for k in ENERGY_FIELDS}
    names = set(LlmPrices.__dataclass_fields__) - {"provenance", "f_max_mhz", "block_pj_by_mac", "nonmac"}
    prices = {k: 1.0 for k in names}
    prices.update(block_pj=777.0, block_cycles=11, clock_ns=2.0, macs_per_block=1024**2,
                  phy_bpc=128)
    prices.update({k: energy[k] for k in names & ENERGY_FIELDS})
    return dict(schema=SCHEMA, status="MEASURED",
        _TEST_ONLY="SYNTHETIC CONTRACT TEST, NOT A SYNOPSYS MEASUREMENT",
        structure=structure, config_overrides=hw, timing=timing, energy=energy,
        llm_prices=prices, nonmac=synthetic_nonmac(2.0), area={k: 1.0 for k in AREA_FIELDS},
        llm_hardware=dict(mem_die_bytes=2**30, mem_die_count=1,
                          rram_capacity_bytes=2**28, feram_capacity_bytes=2**28),
        provenance={k: "synthetic contract test only" for k in ("rtl_revision", "tool_versions",
            "pvt", "clock_constraint", "activity_window", "reports", "energy_scope")})


def write_contract(root, data):
    p = Path(root)/"synthetic_contract.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def rejects(data, message):
    with TemporaryDirectory() as tmp:
        try:
            load_1017_calibration(write_contract(tmp, data))
        except (ValueError, TypeError) as exc:
            assert message in str(exc), str(exc)
        else:
            raise AssertionError("invalid parameters were accepted")


def test_missing_nan_bool_negative_and_unknown_inputs_are_rejected():
    base = complete_synthetic_contract()
    for value in (None, float("nan"), True, -1):
        data = deepcopy(base)
        data["energy"]["pe_mac_pj"] = value
        rejects(data, "energy.pe_mac_pj")
    for value in (float("nan"), True, -1):
        data = deepcopy(base)
        data["config_overrides"]["mem_die_bytes_per_cycle"] = value
        rejects(data, "config_overrides.mem_die_bytes_per_cycle")
    data = deepcopy(base)
    data["config_overrides"]["input_double_buffer"] = 1
    rejects(data, "JSON boolean")
    data = deepcopy(base)
    data["config_overrides"]["typo_capacity"] = 1
    rejects(data, "unknown")
    data = deepcopy(base)
    del data["timing"]["pe_mul_cycles"]
    rejects(data, "timing.pe_mul_cycles")


def test_pending_old_schema_and_wrong_mapping_are_rejected():
    data = complete_synthetic_contract()
    data["schema"] = "sim-1017-rtl-calibration/v1"
    rejects(data, "schema")
    data = complete_synthetic_contract()
    data["status"] = "PENDING"
    rejects(data, "PENDING")
    data = complete_synthetic_contract()
    data["structure"]["mc_mapping"] = "old MC column mapping"
    rejects(data, "MC c")


def test_duplicate_price_or_clock_cannot_silently_disagree():
    for field in ("clock_ns", "pe_mac_pj"):
        data = complete_synthetic_contract()
        data["llm_prices"][field] *= 2
        rejects(data, "disagree")


def test_measured_binding_consumes_timing_area_energy_and_32_channels():
    data = complete_synthetic_contract()
    data["timing"]["gsram_payload_read_cycles"] = 3
    data["timing"]["broadcast_cycles"] = 4
    data["timing"]["pe_mul_cycles"] = 2
    with TemporaryDirectory() as tmp:
        ds = V3Datasheet.from_1017_calibration(write_contract(tmp, data))
        result = run_v3(V3Config(m=32, k=1024, n=1, enable_softmax=False,
                                mem_die_latency=999, clock_ns=999), dataset=ds)
    r = result.report
    assert r["latency"]["clock_ns"] == 2.0
    assert r["cycles"]["compute"] == 2
    assert r["cycles"]["dependency_path"]["input_prefetch"] == 3
    assert r["cycles"]["dependency_path"]["input_broadcast"] == 4
    assert r["area"]["logic_die_mm2"] == data["area"]["logic_die_mm2"]-data["area"]["dma_mm2"]
    assert r["energy_provenance_detail"]["pe_mac_pj"]["value"] == 0.01
    requests = [e for e in result.trace if e.operation == "weight_load"]
    assert len(requests) == 32
    assert len({e.resource for e in requests}) == 32
    assert {e.start_cycle for e in requests} == {0}


def test_llm_block_prices_are_direct_inputs_and_not_recomputed():
    data = complete_synthetic_contract()
    with TemporaryDirectory() as tmp:
        p = write_contract(tmp, data)
        ds = V3Datasheet.from_1017_calibration(p)
        pr = prices_from_dataset(ds)
        assert pr.block_cycles == 11 and pr.block_pj == 777
        result = run_llm(LlmConfig(rtl_1017_calibration_path=str(p), billing="unit", prompt_tokens=2,
            max_new_tokens=2, model=ModelOverride(hidden=32, layers=1, heads=1,
                kv_heads=1, head_dim=32, intermediate=32, vocab=512)))
        assert result.report["calib"]["path"] == str(p)
        assert result.report["provenance"]["status"] == "APPLIED"
        assert result.report["provenance"]["calib_file"] == str(p.resolve())
        assert result.report["efficiency"]["by_billing"]["whole_block"]["status"] == "APPLIED"
        json.dumps(result.report, allow_nan=False)


def test_compare_binds_measured_capacities_before_budgeting():
    from yrr_v3.llm.compare import compare, OVER_CAPACITY
    data = complete_synthetic_contract()
    data["llm_hardware"].update(mem_die_bytes=1024, rram_capacity_bytes=512,
                                feram_capacity_bytes=512)
    with TemporaryDirectory() as tmp:
        p = write_contract(tmp, data)
        result = compare(["qwen3-0.6b"], LlmConfig(rtl_1017_calibration_path=str(p)))
    assert result["rows"][0].status == OVER_CAPACITY
    assert result["rows"][0].budget.capacity_bytes == 1024
    assert result["config"]["mem_die_bytes"] == 1024


def test_cli_uses_explicit_parameter_file_and_rejects_estimation_flags():
    root = Path(__file__).resolve().parents[1]
    with TemporaryDirectory() as tmp:
        p = write_contract(tmp, complete_synthetic_contract())
        out = Path(tmp)/"matrix.json"
        run = subprocess.run([sys.executable, str(root/"run.py"), "--parameters", str(p),
            "--m", "32", "--k", "32", "--json", str(out)], capture_output=True, text=True)
        assert run.returncode == 0, run.stderr
        assert json.loads(out.read_text(encoding="utf-8"))["dataset"]["source_path"] == str(p.resolve())
        invalid = subprocess.run([sys.executable, str(root/"run.py"), "--estimate"], capture_output=True, text=True)
        assert invalid.returncode != 0
