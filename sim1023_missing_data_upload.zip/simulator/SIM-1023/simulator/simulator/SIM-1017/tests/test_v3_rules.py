"""Numerical, traffic and scheduling invariants; no pytest dependency."""
import sys
from pathlib import Path
from dataclasses import replace
import tempfile
import json
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from yrr_v3 import V3Config,SimulatorSession,FormatBehavior
from yrr_v3.formats import toward_zero_shift,signed_saturate,fp4_to_e3_m10,e3_m10_value,FP4_VALUES,w4_to_a5


from tests.hardware_fixture import SYNTHETIC as TEST_DATASET, synthetic_dataset, run_test_v3 as run_v3

def cfg(**kw):
    # T=20 is an explicit TEST FIXTURE, not an inferred RTL threshold.
    return V3Config(**{'m':64,'n':64,'k':64,'tile_rows':2,'enable_softmax':False,
                      'mx_skip_threshold_bits':20,**kw})


def payload_case(c,wp=2,xp=2,ws=127,xs=127):
    return dict(weight_payload=np.full((c.m,c.tile_cols*32),wp,np.uint8),
                weight_scale=np.full((c.m,c.tile_cols),ws,np.uint8),
                input_payload=np.full((c.batch,c.tile_cols*32),xp,np.uint8),
                input_scale=np.full((c.batch,c.tile_cols),xs,np.uint8))


def test_sign_and_m10_and_toward_zero():
    p=np.arange(16,dtype=np.uint8)
    e,m=fp4_to_e3_m10(p)
    np.testing.assert_array_equal(e3_m10_value(e,m),FP4_VALUES)
    assert toward_zero_shift(-3,1)==-1
    assert toward_zero_shift(-1,1000)==0
    assert signed_saturate(999,8)==(127,True)
    assert signed_saturate(-999,8)==(-128,True)


def test_a5_matches_v1():
    # Unmodified V1 format source is bundled as a test-only reference, so the
    # package does not require the original repository layout.
    reference=Path(__file__).resolve().parent/'reference'/'v1_formats.py'
    assert reference.is_file()
    import ast
    tree=ast.parse(reference.read_text(encoding='utf-8'))
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='w4_to_a5')
    scope={}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),str(reference),'exec'),scope)
    assert [w4_to_a5(i) for i in range(16)]==[scope['w4_to_a5'](i) for i in range(16)]


def test_tag_half_is_not_zero():
    c=cfg(k=32)
    r=run_v3(c,dataset=TEST_DATASET, **payload_case(c,xp=1))
    np.testing.assert_array_equal(r.logits_hardware,np.full((1,64),16.0))
    assert r.report['architecture']['valid_macs']==64*32


def test_zero_dense_and_gated_activity():
    c=cfg()
    r=run_v3(c,dataset=TEST_DATASET, **payload_case(c,xp=0))
    assert r.report['architecture']['valid_macs']==0
    # Equal scales keep both blocks regardless of payload zeros. TAG zero
    # metadata is decoded after broadcast and can gate only PE lanes.
    assert r.report['traffic']['global_sram_bank_read_bytes']==34
    assert r.report['skip']['skipped_blocks']==0
    dense=replace(c,enable_tag_skip=False,enable_mx_block_skip=False)
    d=run_v3(dense,dataset=TEST_DATASET, **payload_case(dense,xp=0))
    assert d.report['architecture']['valid_macs']==64*64
    assert d.report['traffic']['global_sram_bank_read_bytes']==34
    np.testing.assert_array_equal(r.logits_hardware,d.logits_hardware)


def test_cancellation_does_not_skip():
    c=cfg(k=32)
    data=payload_case(c)
    data['input_payload'][0,1::2]=10
    r=run_v3(c,dataset=TEST_DATASET, **data)
    assert not np.any(r.logits_hardware)
    assert r.report['architecture']['valid_macs']==64*32
    assert r.report['skip']['active_source_blocks']==1
    assert not all(r.mx_control[0].zero_mask)


def test_shared_scale_product_and_negative():
    c=cfg(k=32)
    r=run_v3(c,dataset=TEST_DATASET, **payload_case(c,wp=10,ws=130,xs=125))
    np.testing.assert_array_equal(r.logits_hardware,np.full((1,64),-64.0))


def test_scale_sum_exponent_gap_and_metadata():
    c=cfg()
    data=payload_case(c)
    data['weight_scale'][:,0]=100
    r=run_v3(c,dataset=TEST_DATASET, **data)
    assert r.report['skip']['active_source_blocks']==1
    np.testing.assert_array_equal(r.logits_hardware,np.full((1,64),32.0))
    d=run_v3(replace(c,mx_metadata_available=False),dataset=TEST_DATASET, **data)
    assert d.report['skip']['active_source_blocks']==2
    assert d.report['architecture']['valid_macs']>r.report['architecture']['valid_macs']


def test_finite_width_changes_keep_and_saturates():
    c=cfg(partial_bits=8)
    r=run_v3(c,dataset=TEST_DATASET, **payload_case(c,wp=7,xp=7))
    assert r.report['finite_width']['saturation_count']>0
    assert np.isfinite(r.logits_hardware).all()
    assert r.report['errors']['max_abs']>0


def test_bank_sensitivity_unchanged_values_and_single_compute():
    values=[]
    for banks in (1,2,4,8,16,32):
        c=V3Config(gsram_banks=banks,source_lanes=32,enable_softmax=False)
        r=run_v3(c,dataset=TEST_DATASET, **payload_case(c))
        values.append(r.logits_hardware)
        assert r.report['bandwidth']['prefetch_cycles']==32//banks
        ev=next(e for e in r.trace if e.operation=='array_mac')
        assert ev.end_cycle-ev.start_cycle==1
        assert ev.metadata['active_tiles']==1024 and ev.metadata['active_pe']==32768
        assert ev.metadata['active_mac']==1048576
    for v in values[1:]:
        np.testing.assert_array_equal(values[0],v)


def test_full_array_traffic_and_capacity():
    c=V3Config(enable_softmax=False)
    r=run_v3(c,dataset=TEST_DATASET, **payload_case(c))
    t,b,cap=r.report['traffic'],r.report['bandwidth'],r.report['capacity']
    assert (b['gsram_payload_source_bits_per_cycle'],b['gsram_scale_source_bits_per_cycle'])==(4096,256)
    assert (b['active_broadcast_payload_bits'],b['active_broadcast_scale_bits'])==(131072,8192)
    assert t['input_bytes_per_sample']==544 and t['fp32_logits_bytes_per_sample']==4096
    assert t['tile_input_bytes']==17408 and t['partial_bytes']==81920
    assert cap['tile_weight_logic_bytes']==672 and cap['array_weight_physical_bytes']==672*1024
    assert cap['tile_input_logic_bytes']==21 and cap['tile_input_double_buffer_bytes']==64


def test_mem_die_mapping_residency_and_reload():
    c=cfg(layer_id=3,layer_die_map={3:1},batch=2)
    s=SimulatorSession()
    a=run_v3(c,dataset=TEST_DATASET, session=s)
    b=run_v3(c,dataset=TEST_DATASET, session=s)
    assert a.report['mem_dies'][0]['read_requests']==0 and a.report['mem_dies'][1]['read_requests']==4
    assert b.report['weights_warm_at_entry'] and b.report['mem_dies'][1]['read_requests']==0
    d=run_v3(replace(c,weights_resident=False),dataset=TEST_DATASET)
    assert d.report['mem_dies'][1]['read_requests']==8
    assert all(q['nbytes']==544 for q in a.report['mem_die_protocol']['requests'])


def test_single_double_buffers_and_no_resource_overlap():
    c=cfg(batch=8,enable_softmax=True,model_host_io=True)
    a=run_v3(c,dataset=TEST_DATASET)
    b=run_v3(replace(c,input_double_buffer=False,logits_double_buffer=False),dataset=TEST_DATASET)
    np.testing.assert_array_equal(a.logits_hardware,b.logits_hardware)
    assert a.report['cycles']['end_to_end_cycles']<=b.report['cycles']['end_to_end_cycles']
    for result in (a,b):
        grouped={}
        for ev in result.trace:
            if ev.end_cycle>ev.start_cycle:
                grouped.setdefault(ev.resource,[]).append(ev)
        for events in grouped.values():
            events.sort(key=lambda x:x.start_cycle)
            assert all(x.end_cycle<=y.start_cycle for x,y in zip(events,events[1:]))
        assert max(e.end_cycle for e in result.trace)==result.report['cycles']['end_to_end_cycles']
        assert result.report['host_io']['descriptors']==0
        assert not result.report['host_io']['counted']


def test_microbatch_and_capacity_rejection():
    c=cfg(batch=65)
    r=run_v3(c,dataset=TEST_DATASET)
    assert r.report['capacity']['micro_batch_count']==3
    assert r.report['capacity']['allocated_global_sram_bytes']<=c.global_sram_bytes
    try:
        run_v3(replace(c,global_sram_bytes=128),dataset=TEST_DATASET)
    except ValueError as e:
        assert 'Global SRAM' in str(e)
    else:
        raise AssertionError('must reject impossible buffer allocation')


def test_gemm_and_padding():
    c=cfg(m=35,n=3,k=33,batch=2,workload='gemm',enable_softmax=True)
    r=run_v3(c,dataset=TEST_DATASET)
    assert r.logits_hardware.shape==(2,3,35) and r.tile_partials.shape==(2,3,2,2,32)
    np.testing.assert_allclose(r.logits_hardware,r.logits_reference,atol=0.03,rtol=0.01)
    np.testing.assert_allclose(r.softmax_output.sum(-1),1,rtol=1e-7)


def test_measured_softmax_workspace_and_reduction_styles():
    # The integrated microprogram always materializes exponentials in the
    # external 8192-word scratch, independent of the matrix reduction style.
    c=cfg(batch=2,enable_softmax=True)
    a=run_v3(c,dataset=TEST_DATASET)
    b=run_v3(replace(c,reduction_style='serial'),dataset=TEST_DATASET)
    np.testing.assert_array_equal(a.logits_hardware,b.logits_hardware)
    np.testing.assert_array_equal(a.softmax_output,b.softmax_output)
    assert a.report['capacity']['softmax_workspace_bytes']==b.report['capacity']['softmax_workspace_bytes']==32768


def test_ferram_live_size_separate_from_traffic():
    c=cfg(ferram_kv_capacity_bytes=1024)
    r=run_v3(c,dataset=TEST_DATASET, ferram_read_bytes=8192,ferram_write_bytes=4096,ferram_live_bytes=512)
    assert r.report['ferram']['capacity_used_bytes']==512
    base=run_v3(c,dataset=TEST_DATASET)
    assert r.report['cycles']['end_to_end_cycles']>base.report['cycles']['end_to_end_cycles']
    try:
        run_v3(c,dataset=TEST_DATASET, ferram_live_bytes=2048)
    except ValueError:
        pass
    else:
        raise AssertionError('live KV overflow must be rejected')


def test_format_behavior_callback_and_exports():
    calls=[]
    base=FormatBehavior()
    def encode(p):
        calls.append(p.shape)
        return base.input_encode(p)
    r=run_v3(cfg(),dataset=TEST_DATASET, format_behavior=FormatBehavior(input_encode=encode,name='test adapter'))
    assert calls
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)
        r.export_trace_json(p/'trace.json')
        r.export_mx_control(p/'mx.json')
        r.export_tile_partials(p/'partials.npz')
        r.export_rtl_vectors(p/'rtl.npz')
        assert len(json.loads((p/'trace.json').read_text()))==len(r.trace)
        with np.load(p/'rtl.npz') as data:
            assert 'input_tag_payload' in data and 'partial_exponents' in data


def test_fixed_seed_full_scale_batches():
    for b in (1,2,8,32):
        r=run_v3(V3Config(batch=b),dataset=TEST_DATASET)
        assert r.logits_hardware.shape==(b,1024)
        np.testing.assert_allclose(r.logits_hardware,r.logits_reference,atol=0.02,rtol=0.01)
        np.testing.assert_allclose(r.softmax_output.sum(-1),1,rtol=1e-7)
        if b==1:
            again=run_v3(V3Config(),dataset=TEST_DATASET)
            np.testing.assert_array_equal(r.logits_hardware,again.logits_hardware)
