"""Per-PE read gating and dimensional/unit tests against supplied workbook."""
from dataclasses import replace
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
from yrr_v3 import V3Config, V3Datasheet, SimulatorSession, run_v3, format_report
from yrr_v3.pe_memory import plan_reads
from tests.hardware_fixture import synthetic_dataset


def operands(m=32,k=64,batch=1):
    return dict(weight_payload=np.full((m,k),2,np.uint8),
        weight_scale=np.full((m,(k+31)//32),127,np.uint8),
        input_payload=np.full((batch,k),2,np.uint8),
        input_scale=np.full((batch,(k+31)//32),127,np.uint8))


def workbook(**overrides):
    ds=V3Datasheet.from_component_json()
    return replace(ds,config_values={**ds.config_values,**overrides})


def test_full_array_mapping_and_mc_area_replication():
    cfg=V3Config(enable_softmax=False)
    p=plan_reads(cfg,np.ones((1024,32),bool),np.ones((32,32),bool))
    assert cfg.mc_count==32768 and cfg.mem_die_channels==32
    assert np.unique(p.mc_ids).size==32768
    assert set(p.mc_ids.ravel())==set(range(32768))
    assert p.mc_ids[32,1]==(32+1)*32
    assert p.read_words==32768 and p.physical_read_bits==32768*128
    from yrr_v3.characterization import area_report
    a=area_report(workbook().components,cfg)
    assert np.isclose(a['mc_total_mm2'],32768*882.588024/1e6)


def test_scale_skip_prevents_only_own_pe_read_and_uses_scale_only():
    op=operands()
    op['weight_scale'][0,1]=100
    ds=workbook(mx_skip_threshold_bits=20)
    r=run_v3(V3Config(m=32,k=64,enable_softmax=False),dataset=ds,**op)
    mc=r.report['rram_mc']
    assert mc['scale_block_skips']==1 and mc['read_requests']==63
    assert r.mc_element_enable_mask[0,0,1]==0
    assert r.mc_element_enable_mask[0,1,1]==0xffffffff
    assert r.report['bandwidth']['active_source_payload_bits']==256
    # Cancellation and zero weights cannot retroactively suppress RRAM reads.
    op['weight_payload'][:]=0
    z=run_v3(V3Config(m=32,k=64,enable_softmax=False),dataset=ds,**op)
    assert np.array_equal(z.mx_skip_mask,r.mx_skip_mask)
    assert np.array_equal(z.mc_element_enable_mask,r.mc_element_enable_mask)


def test_input_tag_zero_masks_elements_before_weight_read():
    op=operands(k=32)
    op['input_payload'][0,::2]=0
    r=run_v3(V3Config(m=32,k=32,enable_softmax=False),dataset=workbook(),**op)
    assert np.all(r.mc_element_enable_mask==0xaaaaaaaa)
    assert r.report['rram_mc']['enabled_elements']==32*16
    assert r.report['rram_mc']['physical_read_bits']==32*128
    assert r.report['rram_mc']['partial_read_words']==32
    # No proportional price cut is invented for partially enabled words.
    e=r.report['energy']['components_pj']
    assert np.isclose(e['mc_read_pj'],32*1.543)
    assert np.isclose(e['pe_mac_pj'],32*4.85984)


def test_all_zero_tag_avoids_read_but_pays_skip_decision():
    op=operands(k=32)
    op['input_payload'][:]=0
    r=run_v3(V3Config(m=32,k=32,enable_softmax=False),dataset=workbook(),**op)
    mc=r.report['rram_mc']
    assert mc['scale_block_skips']==0 and mc['tag_all_zero_skips']==32
    assert mc['read_requests']==0 and mc['physical_read_bits']==0
    assert np.all(r.logits_hardware==0)
    e=r.report['energy']['components_pj']
    assert e['mc_read_pj']==0 and np.isclose(e['mc_skip_pj'],32*0.3389)
    assert not any(t.operation=='rram_pe_read' for t in r.trace)


def test_disabling_tag_metadata_restores_full_weight_word_enables():
    op=operands(k=32)
    op['input_payload'][:]=0
    for kwargs in ({'enable_tag_skip':False},{'tag_metadata_available':False}):
        r=run_v3(V3Config(m=32,k=32,enable_softmax=False,**kwargs),dataset=workbook(),**op)
        assert np.all(r.mc_element_enable_mask==0xffffffff)
        assert r.report['rram_mc']['read_requests']==32


def test_subword_gating_reports_array_bits_separately_from_response_slots():
    op=operands(k=32)
    op['input_payload'][:]=0
    op['input_payload'][0,0]=2
    cfg=V3Config(m=32,k=32,enable_softmax=False)
    word=run_v3(cfg,dataset=workbook(),**op)
    elem=run_v3(cfg,dataset=workbook(rram_read_granularity_bits=4),**op)
    assert word.report['rram_mc']['physical_read_bits']==32*128
    assert elem.report['rram_mc']['physical_read_bits']==32*4
    assert elem.report['rram_mc']['response_slot_bits']==32*128
    assert np.array_equal(word.logits_hardware,elem.logits_hardware)
    assert word.report['energy']['mc_read_pj']==elem.report['energy']['mc_read_pj']
    assert word.report['energy']['hybrid_bond_phy_pj']==elem.report['energy']['hybrid_bond_phy_pj']


def test_rram_runtime_reads_continue_when_session_is_warm():
    cfg=V3Config(m=32,k=64,batch=2,enable_softmax=False)
    op=operands(batch=2)
    session=SimulatorSession()
    a=run_v3(cfg,dataset=workbook(),session=session,**op)
    b=run_v3(cfg,dataset=workbook(),session=session,**op)
    assert b.report['weights_warm_at_entry']
    assert a.report['rram_mc']['read_requests']==b.report['rram_mc']['read_requests']==128
    assert a.report['energy']['mc_read_pj']==b.report['energy']['mc_read_pj']
    assert b.report['mem_dies'][0]['read_requests']==128
    assert not any(t.operation=='weight_load' for t in b.trace)
    assert b.report['capacity']['array_weight_physical_bytes']==0
    assert b.report['capacity']['rram_weight_payload_bytes']==32*2*16
    assert b.report['capacity']['rram_response_slot_logical_bytes']==32768*16
    assert np.array_equal(a.logits_hardware,b.logits_hardware)


def test_mc_count_is_independent_of_external_channels_and_numeric_path():
    cfg=V3Config(m=64,k=64,enable_softmax=False)
    op=operands(m=64)
    a=run_v3(cfg,dataset=workbook(mem_die_channels=1),**op)
    b=run_v3(cfg,dataset=workbook(mem_die_channels=32),**op)
    cache=run_v3(cfg,dataset=synthetic_dataset(),**op)
    assert a.report['rram_mc']==b.report['rram_mc']
    assert a.report['cycles']['array_start_cycles']==b.report['cycles']['array_start_cycles']
    assert np.array_equal(a.logits_hardware,cache.logits_hardware)


def test_workbook_prices_use_whole_module_operations_and_unknown_totals():
    r=run_v3(V3Config(m=32,k=64,enable_softmax=False),dataset=workbook(),**operands())
    e=r.report['energy']
    assert np.isclose(e['pe_mac_pj'],64*4.85984)
    assert np.isclose(e['hybrid_bond_phy_pj'],64*1.56518495)
    assert np.isclose(e['mx_control_pj'],32*7.043384955752213)
    assert np.isclose(e['reduction_pj'],32*3.3262)
    # The default partial workbook now selects the user-supplied 128-row
    # high-speed payload/scale pair. Keep the assertion tied to the selected
    # characterization instead of the historical 1024-row macro price.
    s = r.report['global_sram']
    assert np.isclose(e['gsram_read_pj'],
                      2*128*s['payload_read_pj_per_bit'] + 2*8*s['scale_read_pj_per_bit'])
    assert np.isclose(e['gsram_write_pj'],128*8*s['payload_write_pj_per_bit'])
    assert e['mem_die_read_pj'] is None and e['total_pj'] is None
    assert np.isclose(e['known_dynamic_pj'],sum(x for x in e['components_pj'].values() if x is not None))
    assert r.report['characterization']['phy_energy_unit']=='128bit'
    assert r.report['dataset']['parameter_status']=='PARTIAL'
    assert not r.report['energy_claim_ready']
    assert 'full total unavailable' in format_report(r)
    json.dumps(r.report,allow_nan=False)
    assert r.report['host_rram_provisioning']['included_in_inference'] is False
    assert 'known_mc_write_pj' not in r.report['host_rram_provisioning']


def test_rram_response_and_mc_interval_enforced_before_compute():
    cfg=V3Config(m=32,k=32,batch=3,enable_softmax=False)
    r=run_v3(cfg,dataset=workbook(mc_issue_cycles=50),**operands(k=32,batch=3))
    ctrl=[e for e in r.trace if e.operation=='rram_pe_control']
    assert len(ctrl)==3
    assert all(b.start_cycle-a.start_cycle>=50 for a,b in zip(ctrl,ctrl[1:]))
    for v,start in enumerate(r.report['cycles']['array_start_cycles']):
        response=[e.end_cycle for e in r.trace if e.operation=='rram_pe_read' and e.metadata['vector_id']==v]
        assert start>=max(response)


def test_long_rram_response_holds_controller_until_read_completes():
    r=run_v3(V3Config(m=32,k=32,batch=2,enable_softmax=False),
        dataset=workbook(rram_array_read_cycles=100),**operands(k=32,batch=2))
    reads=[e for e in r.trace if e.operation=='rram_pe_read']
    controls=[e for e in r.trace if e.operation=='rram_pe_control']
    assert controls[1].start_cycle>=reads[0].end_cycle


def test_padding_and_exports_preserve_lane_mask_bit_order():
    cfg=V3Config(m=1,k=33,enable_softmax=False)
    r=run_v3(cfg,dataset=workbook(),**operands(m=1,k=33))
    assert r.mc_element_enable_mask[0,0,0]==0xffffffff
    assert r.mc_element_enable_mask[0,0,1]==1
    with TemporaryDirectory() as tmp:
        p=Path(tmp)/'mc.npz'
        r.export_rram_mc_control(p)
        with np.load(p) as data:
            assert np.array_equal(data['element_enable_mask'],r.mc_element_enable_mask)
            assert bool(data['mask_lane0_is_lsb'])
        p=Path(tmp)/'all.npz'
        r.export_rtl_vectors(p)
        with np.load(p) as data:
            assert 'mc_ids' in data and 'mc_element_enable_mask' in data


def test_pending_softmax_still_computes_function_without_claiming_timing():
    r=run_v3(V3Config(m=32,k=32),dataset=workbook(),**operands(k=32))
    assert np.isclose(r.softmax_output.sum(),1.0)
    assert r.report['nonmac']['measurement_status']=='PENDING'
    assert r.report['energy']['softmax_pj'] is None
    assert 'parallel softmax vector latency' in r.report['latency']['uncharacterized']


def test_workbook_snapshot_retains_conflicts_and_confirmed_overrides():
    ds=workbook()
    raw=ds.components
    assert raw['selected_sheet']=='Sheet1'
    assert len(raw['workbook_sha256'])==64
    assert raw['records']['PE_ALL']['energy_pj']==4.85984
    # Preserve original rows; do not silently replace the conflicting old tab.
    old=next(v for k,v in raw['original_sheets'].items() if k!='Sheet1')
    assert old[1][9]==10.518
    assert raw['phy_energy_unit']=='128bit'
    assert raw['records']['llm_nonmac_fp32']['energy_pj'] is None


def test_component_loader_rejects_bad_prices_and_llm_entry_rejects_partial():
    from yrr_v3.characterization import read_components
    from yrr_v3.rtl_dataset import load_1017_calibration
    from copy import deepcopy
    data=deepcopy(workbook().components)
    with TemporaryDirectory() as tmp:
        p=Path(tmp)/'partial.json'
        data['records']['mc']['read_pj']=-1
        p.write_text(json.dumps(data),encoding='utf-8')
        try: read_components(p)
        except ValueError as e: assert 'mc.read_pj' in str(e)
        else: raise AssertionError('negative price accepted')
        try: load_1017_calibration(p)
        except ValueError as e: assert 'run_llm requires complete' in str(e)
        else: raise AssertionError('partial characterization billed as complete LLM')
