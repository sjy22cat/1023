"""Assertions for the current V3 contract.

The older ``test_llm.py`` file intentionally keeps archived LLM billing
assumptions. These tests exercise the public V3 behavior/event entry point.
"""
from __future__ import annotations

from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from yrr_v3 import V3Config, V3Datasheet, SimulatorSession, format_report  # noqa: E402
from yrr_v3.interfaces import (  # noqa: E402
    DmaDescriptor, MemDieRequest, MemDieResponse, MxControl, PeMacResult,
    PhyWord, ReductionPacket, SoftmaxPacket, TileInputBlock, TilePartial,
    TileWeightLoad,
)
from yrr_v3.llm.config import prices_from_dataset  # noqa: E402


from tests.hardware_fixture import SYNTHETIC as TEST_DATASET, synthetic_dataset, run_test_v3 as run_v3

def test_price_snapshot_reads_external_block_price_without_reestimating():
    ds = synthetic_dataset()
    cfg = V3Config(batch=1, enable_tag_skip=False, enable_mx_block_skip=False,
                   model_host_io=False, enable_softmax=False)
    session = SimulatorSession()
    # Uniform blocks have no data-dependent exponent shift activity. The price
    # baseline has no numerical payload and accounts alignment separately.
    operands = dict(weight_payload=np.ones((cfg.m, cfg.k), dtype=np.uint8),
                    weight_scale=np.full((cfg.m, cfg.tile_cols), 127, dtype=np.uint8),
                    input_payload=np.ones((1, cfg.k), dtype=np.uint8),
                    input_scale=np.full((1, cfg.tile_cols), 127, dtype=np.uint8))
    run_v3(cfg, dataset=ds, session=session, **operands)
    report = run_v3(cfg, dataset=ds, session=session, **operands).report
    prices = prices_from_dataset(ds, force=True)
    assert prices.block_pj == ds.rtl_params["llm_prices"]["block_pj"]
    assert prices.provenance["block_pj"].startswith("test-fixture:")
    assert prices.block_cycles == ds.rtl_params["llm_prices"]["block_cycles"]
    assert prices.macs_per_block == cfg.m * cfg.k


def test_current_default_contract_and_capacity_fields():
    report = run_v3(V3Config()).report
    assert report["config"]["batch"] == 1
    assert report["nonmac"]["implementation"] == "llm_nonmac_fp32"
    assert report["architecture"]["total_pe"] == 32768
    assert report["architecture"]["macs_per_vector"] == 1024 * 1024
    assert report["capacity"]["array_weight_external_mxfp4_bytes"] == 557056
    assert report["capacity"]["array_weight_behavior_a5_bytes"] == 688128
    assert report["capacity"]["array_weight_physical_bytes"] == 688128
    path = report["cycles"]["dependency_path"]
    assert set(path) >= {"input_prefetch", "input_broadcast", "array_mac",
                         "reduction", "logits_write", "softmax", "total"}
    assert report["energy"]["total_pj"] > 0
    assert report["energy_claim_ready"] is False


def test_measured_timing_replaces_hardware_defaults():
    from dataclasses import replace
    ds = replace(synthetic_dataset(), production=True,
                 config_values={"mem_die_latency": 19, "clock_ns": 2.0, "latency_source": "measured"})
    cfg = V3Config(m=64, k=64, n=1, mem_die_latency=4, clock_ns=1.0, enable_softmax=False)
    result = run_v3(cfg, dataset=ds)
    timing = result.report["cycles"]["timing_model"]
    assert timing["source"] == "measured"
    assert timing["mem_die_latency"] == 19
    assert result.report["latency"]["clock_ns"] == 2.0
    assert cfg.mem_die_latency == 4  # binding never mutates the caller


def test_block_level_valid_mask_and_rtl_handshake_fields():
    cfg = V3Config(m=32, n=32, k=33, enable_softmax=False,
                   latency_source="config")
    weight_payload = np.ones((cfg.m, cfg.tile_cols * 32), dtype=np.uint8)
    weight_scale = np.full((cfg.m, cfg.tile_cols), 127, dtype=np.uint8)
    input_payload = np.zeros((1, cfg.tile_cols * 32), dtype=np.uint8)
    input_payload[:, 32:33] = 1
    input_scale = np.full((1, cfg.tile_cols), 127, dtype=np.uint8)
    result = run_v3(cfg, dataset=TEST_DATASET, weight_payload=weight_payload,
                    weight_scale=weight_scale, input_payload=input_payload,
                    input_scale=input_scale)
    valid = np.asarray(result.mx_control[0].valid_mask, dtype=bool)
    assert valid.size == cfg.m * cfg.tile_cols
    # Pre-PE controller sees scales/layout only, never payload nonzero flags.
    assert np.all(valid)
    assert not any(result.mx_control[0].block_skip_mask)

    objects = [
        PhyWord(), MemDieRequest(0, 0, 0, 0, 0, 1, "r"),
        MemDieResponse(0, "r", None, 0, 1), TileWeightLoad(0, 0, None, None),
        TileInputBlock(0, 0, 0, None, 0), PeMacResult(0, 0, 0, 0, 0.0),
        TilePartial(0, 0, 0, None), MxControl(0, [], [], [], False, False, 0),
        ReductionPacket(0, 0, 0.0, 0), DmaDescriptor(), SoftmaxPacket(0, 0, 0.0),
    ]
    for obj in objects:
        for field in ("valid", "ready", "cycle"):
            assert hasattr(obj, field), (type(obj).__name__, field)
