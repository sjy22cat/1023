"""External calibration and synthetic-test provenance regressions."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
from yrr_v3 import V3Config,V3Datasheet,default_1017_measured_path,load_1017_calibration
from tests.hardware_fixture import run_test_v3
from yrr_v3.rtl_dataset import SCHEMA


def test_default_path_is_package_relative():
    p = default_1017_measured_path()
    assert p.parent.parent.parent == Path(__file__).resolve().parents[1]
    assert p.name == "rtl_1017sim_measured.json"


def test_pending_template_is_not_a_measurement():
    with TemporaryDirectory() as tmp:
        p = Path(tmp)/"pending.json"
        p.write_text(json.dumps({"schema":SCHEMA, "status":"PENDING"}))
        try:
            V3Datasheet.from_1017_calibration(p)
        except ValueError as exc:
            assert "PENDING" in str(exc)
        else:
            raise AssertionError("pending data must never run")


def test_removed_rtl_estimation_api():
    assert not hasattr(V3Datasheet,"from_rtl")
    assert not hasattr(V3Datasheet,"fallback")
    import yrr_v3
    assert not hasattr(yrr_v3,"ESTIMATE")


def test_synthetic_inputs_are_not_hardware_claims():
    r = run_test_v3(V3Config(m=32,n=32,k=32,tile_rows=1))
    assert r.report["area"]["status"] == "TEST_ONLY"
    assert not r.report["energy_claim_ready"]


def test_per_field_energy_provenance_and_no_double_sum():
    r=run_test_v3(V3Config(m=32,n=32,k=32,tile_rows=1))
    e=r.report["energy"]
    assert abs(sum(e["components_pj"].values())-e["total_dynamic_pj"])<1e-9
    assert abs(e["total_dynamic_pj"]+e["leakage_pj"]-e["total_pj"])<1e-9
    assert not r.report["energy_claim_ready"]
