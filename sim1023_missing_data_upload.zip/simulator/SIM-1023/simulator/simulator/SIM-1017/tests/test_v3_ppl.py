"""Dependency-free checks for the causal perplexity interface."""
from __future__ import annotations

import numpy as np

from yrr_v3.llm.ppl import _attach_fp32_comparison, evaluate_perplexity


def test_sliding_windows_score_each_target_once():
    ids = np.arange(6, dtype=np.int64)

    def zero_logits(tokens):
        # Uniform logits over eight classes make the expected PPL exactly 8.
        return np.zeros((1, tokens.shape[1], 8), dtype=np.float32)

    report = evaluate_perplexity(
        ids,
        {"fp32": zero_logits},
        context=4,
        stride=2,
        collect_token_nll=True,
    )
    mode = report["modes"]["fp32"]
    assert report["window_count"] == 2
    assert mode["valid_token_count"] == len(ids) - 1
    assert len(mode["token_nll"]) == len(ids) - 1
    assert np.isclose(mode["perplexity"], 8.0)
    assert sum(w["target_count"] for w in report["windows"]) == len(ids) - 1


def test_perplexity_rejects_invalid_forward_shape():
    ids = np.arange(4, dtype=np.int64)

    def bad_logits(tokens):
        return np.zeros((tokens.shape[1], 8), dtype=np.float32)

    try:
        evaluate_perplexity(ids, {"bad": bad_logits}, context=4, stride=2)
    except ValueError as exc:
        assert "all-position" in str(exc)
    else:
        raise AssertionError("invalid forward output must be rejected")


def test_mode_comparison_uses_fp32_as_reference():
    modes = {
        "fp32": {"perplexity": 10.0, "mean_nll": np.log(10.0)},
        "finite_mxfp4": {"perplexity": 11.0, "mean_nll": np.log(11.0)},
    }
    summary = _attach_fp32_comparison(modes)
    assert summary["status"] == "available"
    assert modes["fp32"]["comparison_to_fp32"]["delta_perplexity"] == 0.0
    assert np.isclose(modes["finite_mxfp4"]["comparison_to_fp32"]["delta_perplexity"], 1.0)
    assert np.isclose(modes["finite_mxfp4"]["comparison_to_fp32"]["relative_delta_perplexity"], 0.1)
    assert np.isclose(modes["finite_mxfp4"]["comparison_to_fp32"]["delta_mean_nll"], np.log(1.1))
