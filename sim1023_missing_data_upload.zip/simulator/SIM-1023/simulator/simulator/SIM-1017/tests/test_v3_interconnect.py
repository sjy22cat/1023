"""Topology, gating, pipeline and disjoint-accounting invariants."""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import numpy as np
from yrr_v3 import V3Config, V3Datasheet, run_v3
from yrr_v3.architecture import Reservations
from yrr_v3.interconnect import load_interconnect, estimate_interconnect, validate_interconnect

PARAMETERS = Path(__file__).resolve().parents[1]/"interconnect_eval_20261019"/"dedicated_network_parameters.json"


def masks(cfg, compute):
    receivers = np.array([compute[r*32:min(cfg.m,(r+1)*32)].any(axis=0)
                          for r in range((cfg.m+31)//32)])
    return [receivers], [compute]


def test_full_array_has_parallel_trees_and_five_hops_not_1024_serial_transfers():
    cfg = V3Config()
    r = estimate_interconnect(cfg, load_interconnect(PARAMETERS), *masks(cfg,np.ones((1024,32),bool)))
    v = r["vectors"][0]
    assert v["broadcast"]["active_edges"] == 32*62
    assert v["reduction"]["active_edges"] == 1024*62
    assert v["broadcast"]["latency_cycles"] == v["reduction"]["latency_cycles"] == 5
    assert r["broadcast_initiation_interval_cycles"] == 1
    assert v["broadcast"]["transfer_bits"] == 32*62*144
    assert v["reduction"]["transfer_bits"] == 1024*62*32


def test_parallel_pipeline_accepts_every_cycle_while_data_is_in_flight():
    reservations = Reservations()
    events = [reservations.reserve_pipeline("parallel columns", "broadcast", 0, 5, 1) for _ in range(8)]
    assert [e.start_cycle for e in events] == list(range(8))
    assert [e.end_cycle for e in events] == list(range(5,13))
    assert events[1].start_cycle < events[0].end_cycle
    assert len(reservations.calendar["parallel columns"]) == 8
    assert sum(z-a for a,z in reservations.calendar["parallel columns"]) == 8


def test_skip_location_changes_tree_energy_even_at_identical_mac_count():
    cfg, data = V3Config(), load_interconnect(PARAMETERS)
    contiguous = np.zeros((1024,32),bool); contiguous[:,:16] = True
    dispersed = np.zeros((1024,32),bool); dispersed[:,::2] = True
    a = estimate_interconnect(cfg, data, *masks(cfg, contiguous))
    b = estimate_interconnect(cfg, data, *masks(cfg, dispersed))
    assert contiguous.sum() == dispersed.sum()
    assert a["totals"]["broadcast"]["dynamic_pj"] == b["totals"]["broadcast"]["dynamic_pj"]
    assert a["totals"]["reduction"]["dynamic_pj"] < b["totals"]["reduction"]["dynamic_pj"]


def test_skipping_one_pe_does_not_prune_shared_tile_input():
    cfg, data = V3Config(), load_interconnect(PARAMETERS)
    all_active = np.ones((1024,32),bool)
    one_per_tile = all_active.copy(); one_per_tile[::32,:] = False
    a = estimate_interconnect(cfg, data, *masks(cfg,all_active))
    b = estimate_interconnect(cfg, data, *masks(cfg,one_per_tile))
    assert a["totals"]["broadcast"] == b["totals"]["broadcast"]
    assert a["totals"]["reduction"]["dynamic_pj"] > b["totals"]["reduction"]["dynamic_pj"]


def test_optional_network_changes_timing_energy_not_logits_or_existing_arithmetic():
    ds = V3Datasheet.from_component_json()
    net = ds.with_interconnect_parameters(PARAMETERS)
    cfg = V3Config(m=64,k=64,batch=2,enable_softmax=False)
    a, b = run_v3(cfg,dataset=ds), run_v3(cfg,dataset=net)
    assert np.array_equal(a.logits_hardware,b.logits_hardware)
    assert np.array_equal(a.mx_compute_mask,b.mx_compute_mask)
    assert np.array_equal(a.mc_element_enable_mask,b.mc_element_enable_mask)
    assert b.report["cycles"]["critical_path"] > a.report["cycles"]["critical_path"]
    for key in ("pe_mac_pj","reduction_pj","mc_read_pj","hybrid_bond_phy_pj"):
        assert a.report["energy"][key] == b.report["energy"][key]
    for key, stage in (("broadcast_pj","broadcast"),("partial_interconnect_pj","reduction")):
        assert a.report["energy"][key] is None
        assert b.report["energy"][key] == b.report["interconnect"]["totals"][stage]["dynamic_pj"]
        assert key not in b.report["energy"]["missing_components"]
    assert b.report["energy"]["total_pj"] is None and not b.report["energy_claim_ready"]
    assert all(e.metadata["initiation_interval_cycles"] == 1 for e in b.trace
               if e.operation in ("input_broadcast","aligned_reduce"))
    assert "interconnect: parallel dedicated trees" in __import__('yrr_v3').format_report(b)


def test_unknown_physical_or_transport_inputs_fail_instead_of_silent_extrapolation():
    data = load_interconnect(PARAMETERS)
    for changed in ({"tile_pitch_mm":0.41}, {"broadcast_bits":128}, {"broadcast_issue_cycles":0}):
        bad = deepcopy(data); bad.update(changed)
        try:
            validate_interconnect(bad)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid/uncalibrated topology accepted")
    cfg = V3Config(clock_ns=2.0)
    try:
        estimate_interconnect(cfg,data,*masks(cfg,np.ones((1024,32),bool)))
    except ValueError:
        pass
    else:
        raise AssertionError("clock mismatch accepted")


def test_zero_active_tree_has_no_dynamic_transfer_or_latency_but_physical_leakage():
    cfg = V3Config()
    r = estimate_interconnect(cfg,load_interconnect(PARAMETERS),*masks(cfg,np.zeros((1024,32),bool)))
    for stage in ("broadcast","reduction"):
        assert r["totals"][stage]["dynamic_pj"] == 0
        assert r["vectors"][0][stage]["latency_cycles"] == 0
        assert r["vectors"][0][stage]["physical_leakage_w"] > 0
