import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from yrr_v3 import V3Config


from tests.hardware_fixture import SYNTHETIC as TEST_DATASET, synthetic_dataset, run_test_v3 as run_v3

def test_mapping_and_full_chain_small():
    cfg = V3Config(m=64, n=64, k=64, tile_rows=2, tile_k=32, pe_per_tile=32,
                   gsram_banks=2, batch=2)
    r = run_v3(cfg)
    assert r.report["architecture"]["tiles"] == 4
    assert r.report["architecture"]["total_pe"] == 128
    assert r.tile_partials.shape == (2, 2, 2, 32)
    assert r.softmax_output.shape == (2, 64)
    np.testing.assert_allclose(r.softmax_output.sum(axis=1), 1.0, rtol=1e-6)
    assert r.report["bandwidth"]["gsram_payload_source_bits_per_cycle"] == 256


def test_default_bandwidth_and_interfaces():
    r = run_v3(V3Config(batch=1))
    b = r.report["bandwidth"]
    assert b["gsram_payload_source_bits_per_cycle"] == 4096
    assert b["gsram_scale_source_bits_per_cycle"] == 256
    assert b["broadcast_payload_bits_per_cycle"] == 131072
    assert b["broadcast_scale_bits_per_cycle"] == 8192
    assert r.report["traffic"]["input_bytes_per_sample"] == 544
    assert r.report["traffic"]["fp32_logits_bytes_per_sample"] == 4096
    assert len([t for t in r.mx_control if t.reduction_stage >= 0]) == 5


def test_resident_weights_and_determinism():
    cfg = V3Config(m=64, n=64, k=64, tile_rows=2, tile_k=32, pe_per_tile=32, seed=9)
    a, b = run_v3(cfg), run_v3(cfg)
    np.testing.assert_array_equal(a.logits_hardware, b.logits_hardware)
    assert a.report["mem_dies"][0]["read_requests"] > 0
    assert a.report["mem_dies"][1]["read_requests"] == 0
