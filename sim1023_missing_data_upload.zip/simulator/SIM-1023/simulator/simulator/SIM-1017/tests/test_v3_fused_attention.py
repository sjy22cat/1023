"""Meaningful scheduling/traffic/calibration tests; all prices are TEST ONLY."""
from dataclasses import replace
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

import numpy as np

from tests.hardware_fixture import synthetic_prices
from yrr_v3.llm.config import LlmConfig, ModelOverride
from yrr_v3.llm.cost import Cost, Ledger
from yrr_v3.llm.core import Core
from yrr_v3.llm.fused_attention import (
    FusedAttentionProfiles, PARAMETERS, RTL_FILES, SCHEMA, SCOPE, required_contexts)
from yrr_v3.llm.schedule import SimContext, mx_bytes


def fixture_data():
    # Arbitrary numeric fixtures marked TEST_ONLY in every provenance field.
    return dict(schema=SCHEMA, status="MEASURED", scope=SCOPE,
                parameters=PARAMETERS.copy(), clock_ns=1.0,
                validation={k: True for k in ("official_dw_numeric_pass", "full_top_mapped",
                    "no_blackboxes", "setup_pass", "hold_pass")},
                provenance=dict(tools="TEST_ONLY", library="TEST_ONLY", pvt="TEST_ONLY",
                    reports=["TEST_ONLY"], activity_policy="TEST_ONLY",
                    rtl_sha256={name: "0"*64 for name in RTL_FILES}),
                profiles={str(n): dict(cycles=1000+(n+31)//32, kv_load_cycles=(n+31)//32,
                    dynamic_pj=7.0+n, report="TEST_ONLY") for n in (1, 2, 3, 4, 32, 33, 512, 513, 1152)})


def load(data=None):
    return FusedAttentionProfiles(fixture_data() if data is None else data,
                                  source="TEST_ONLY", clock_ns=1.0, head_dim=128)


def must_fail(callback, text):
    try:
        callback()
    except (ValueError, TypeError) as error:
        assert text in str(error), str(error)
    else:
        raise AssertionError("invalid calibration was accepted")


def test_fused_profile_rejects_pending_width_clock_checks_and_missing_records():
    bad = fixture_data(); bad["status"] = "PENDING"
    must_fail(lambda: load(bad), "MEASURED")
    must_fail(lambda: FusedAttentionProfiles(fixture_data(), source="TEST_ONLY", clock_ns=2., head_dim=128), "clocks differ")
    must_fail(lambda: FusedAttentionProfiles(fixture_data(), source="TEST_ONLY", clock_ns=1., head_dim=32), "HEAD_DIM")
    for field in ("official_dw_numeric_pass", "full_top_mapped", "no_blackboxes", "setup_pass", "hold_pass"):
        bad = fixture_data(); bad["validation"][field] = False
        must_fail(lambda: load(bad), "must pass")
    bad = fixture_data(); bad["profiles"]["32"]["dynamic_pj"] = None
    must_fail(lambda: load(bad), "dynamic_pj")
    bad = fixture_data(); bad["profiles"]["32"]["kv_load_cycles"] = 2
    must_fail(lambda: load(bad), "handshake")
    bad = fixture_data(); del bad["provenance"]["rtl_sha256"][RTL_FILES[0]]
    must_fail(lambda: load(bad), "SHA256")
    bad = fixture_data(); bad["profiles"]["not_a_context"] = {}
    must_fail(lambda: load(bad), "invalid context")
    bad = fixture_data(); bad["provenance"]["rtl_sha256"][RTL_FILES[0]] = None
    must_fail(lambda: load(bad), "SHA256")
    must_fail(lambda: load().profile(34), "no interpolation")


def test_fused_heads_parallel_latency_energy_scales_once_no_legacy_mac_price():
    profiles = load()
    for n in (1, 32, 33, 512, 513, 1152):
        for heads in (1, 16, 17, 32):
            ledger = Ledger()
            profiles.bill(ledger, "decode", 0, n, heads, queries=2)
            r = ledger.rows()[0]
            assert r.cycles == 1000 * ((heads+15)//16) * 2
            assert r.whole_pj == r.unit_pj == (7+n) * heads * 2
            assert r.macs == 2*n*128*heads*2 and r.blocks == 0
            assert r.count == heads*2


def test_fused_kv_loading_never_faster_than_physical_tile_handshakes():
    ctx = context(True)
    # Even a zero-latency external storage fixture cannot remove the actual
    # K/V input port's one-tile-per-cycle service requirement.
    def instant_transfer(*args, **kwargs):
        return SimpleNamespace(cycles=0)
    ctx.core.read_back = instant_transfer
    ctx.core.write_back = lambda *args, **kwargs: None
    ctx._attention("decode", 0, "full", np.zeros((1,16,128),np.float32), 1)
    assert ctx.ledger.rows()[0].cycles == 1001


def context(shape_only, heads=16, pos=0):
    ctx = SimContext.__new__(SimContext)
    ctx.spec = SimpleNamespace(q_heads=heads, kv_heads=heads//2, head_dim=128,
                              q_dim=heads*128, gqa_group=2,
                              attn_scale=1/np.sqrt(128), sliding_window=2)
    ctx.forward = "shape" if shape_only else "numeric"
    ctx.pos = pos
    ctx.fused_attention = load()
    ctx.ledger = Ledger()
    prices = synthetic_prices()
    ctx.core = Core(Cost.from_prices(prices), ctx.ledger, prices)
    rng = np.random.default_rng(23)
    ctx.kv = rng.uniform(-.5, .5, (1, 2, heads//2, 4, 128)).astype(np.float32)
    return ctx


def test_fused_causal_context_traffic_no_s_a_spills_or_pair_q_reads():
    ctx = context(True)
    out = ctx._attention("prefill", 0, "full", np.zeros((3, 16, 128), np.float32), 3)
    assert out.shape == (3, 2048)
    rows = {r.kind: r for r in ctx.ledger.rows()}
    assert set(rows) == {"attn_fused_16x4", "attn_fused_q_read", "attn_fused_kv_read", "attn_fused_output_write"}
    assert rows["attn_fused_16x4"].cycles == 3000
    assert rows["attn_fused_16x4"].whole_pj == 16*((7+1)+(7+2)+(7+3))
    assert rows["attn_fused_q_read"].mem_rd_bytes == 3*16*mx_bytes((128,))
    assert rows["attn_fused_kv_read"].mem_rd_bytes == 2*16*(1+2+3)*mx_bytes((128,))
    assert rows["attn_fused_output_write"].mem_wr_bytes == 3*mx_bytes((2048,))


def test_fused_numeric_is_causal_fp32_and_billing_matches_shape():
    numeric, shape = context(False), context(True)
    q = np.random.default_rng(3).uniform(-.5,.5,(3,16,128)).astype(np.float32)
    actual = numeric._attention("prefill", 0, "full", q, 3)
    shape._attention("prefill", 0, "full", q, 3)
    np.testing.assert_array_equal([r.as_dict() for r in numeric.ledger.rows()],
                                  [r.as_dict() for r in shape.ledger.rows()])
    for t in range(3):
        for h in range(16):
            k = numeric.kv[0,0,h//2,:t+1]
            v = numeric.kv[0,1,h//2,:t+1]
            a = q[t,h] @ k.T / np.sqrt(128)
            a = np.exp(a-a.max()); a /= a.sum()
            np.testing.assert_allclose(actual[t,h*128:(h+1)*128], a@v, rtol=3e-6, atol=1e-7)
    # A later cached context and a partial sliding window use the matching tail.
    numeric.pos = 3
    numeric._attention("decode", 0, "sliding", q[:1], 1)
    assert "2" in numeric.fused_attention.used


def test_fused_cli_contract_and_context_request_matches_decode_steps():
    from run_llm import build_parser, config_from_args
    args = build_parser().parse_args(["--attention-impl", "fused_16x4", "--attention-calibration", "new.json"])
    cfg = config_from_args(args)
    assert cfg.attention_impl == "fused_16x4" and cfg.attention_calibration_path == "new.json"
    cfg.validate()
    must_fail(lambda: replace(cfg, attention_calibration_path=None).validate(), "requires")
    assert required_contexts(1024,128) == list(range(1,1152))
    assert required_contexts(128,1024) == list(range(1,1152))
    assert required_contexts(3,1) == [1,2,3]


def test_fused_full_inference_report_marks_missing_integration_and_preserves_legacy():
    from yrr_v3.llm import run_llm, format_report
    with TemporaryDirectory() as tmp:
        path = Path(tmp)/"TEST_ONLY.json"
        path.write_text(json.dumps(fixture_data()), encoding="utf-8")
        cfg = LlmConfig(prompt_tokens=2, max_new_tokens=2, forward="shape", kv_shadow="none",
                        model=ModelOverride(hidden=128, layers=1, heads=16, kv_heads=8,
                                            head_dim=128, intermediate=128, vocab=512),
                        attention_impl="fused_16x4", attention_calibration_path=str(path))
        rep = run_llm(cfg, prices=synthetic_prices()).report
        assert rep["attention_mapping"]["concurrent_heads"] == 16
        assert rep["throughput"]["per_core"] is None
        assert not rep["energy"]["complete"]
        assert rep["hybrid_memory"]["placement_policy"]["attention_intermediate_S_A"].startswith("not written")
        assert any(r["kind"] == "attn_fused_16x4" for r in rep["trace"])
        assert not any(r["kind"] in ("attn_qk", "attn_pv", "softmax", "attention_scale") for r in rep["trace"])
        assert "MXFP4/FP32 bridge" in format_report(rep)
