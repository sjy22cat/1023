"""Measured non-MAC costs, command boundaries and no-estimate regressions."""
from copy import deepcopy
from dataclasses import replace

from tests.hardware_fixture import synthetic_dataset, synthetic_nonmac
from tests.test_v3_parameters import complete_synthetic_contract, rejects
from yrr_v3 import V3Config, run_v3
from yrr_v3.nonmac import command_cost
from yrr_v3.llm.config import prices_from_dataset
from yrr_v3.llm.cost import Cost, Ledger
from yrr_v3.llm.core import Core


def test_exact_profile_cost_and_pointwise_tiling():
    data = synthetic_nonmac()
    data["profiles"]["softmax"]["32"].update(cycles=713, dynamic_pj=192.5)
    c = command_cost(data, "softmax", 32, 7)
    assert (c.cycles,c.pj,c.commands,c.reads,c.writes)==(4991,1347.5,7,672,448)
    a = command_cost(data, "residual", 2051, 2)
    full = data["profiles"]["residual"]["1024"]
    tail = data["profiles"]["residual"]["3"]
    assert a.commands == 6 and a.elements == 4102
    assert a.cycles == full["cycles"]*4+tail["cycles"]*2
    assert a.pj == full["dynamic_pj"]*4+tail["dynamic_pj"]*2


def test_missing_profile_and_nonlocal_reductions_never_fallback():
    data = synthetic_nonmac()
    del data["profiles"]["softmax"]["33"]
    for op,n,text in (("softmax",33,"missing Synopsys"),("softmax",1025,"RTL limit"),
                      ("rmsnorm",2048,"RTL limit"),("layernorm",2048,"RTL limit"),
                      ("rope_vector",3,"even"),("rope_vector",2048,"RTL limit"),("quantize",32,"no RTL")):
        try:
            command_cost(data,op,n)
        except ValueError as exc:
            assert text in str(exc),str(exc)
        else:
            raise AssertionError(f"invalid/unmeasured command accepted: {op}/{n}")


def test_single_operator_uses_measured_energy_once_including_scratch():
    base = synthetic_dataset()
    changed = deepcopy(base.rtl_params)
    changed["nonmac"]["profiles"]["softmax"]["32"]["dynamic_pj"] += 123
    cfg = V3Config(m=32,k=32,batch=2,model_host_io=False)
    a = run_v3(cfg,dataset=base)
    b = run_v3(cfg,dataset=replace(base,rtl_params=changed))
    assert abs(b.report["energy"]["total_dynamic_pj"]-a.report["energy"]["total_dynamic_pj"]-246)<1e-7
    assert a.report["nonmac"]["scratch_read_count"] == 192
    assert not any(e.operation=="softmax_memory" for e in a.trace)
    assert a.report["energy"]["fp32_conversion_pj"]==0 # included in measured staging


def test_llm_preserves_softmax_rows_and_refuses_unimplemented_kernel():
    pr = prices_from_dataset(synthetic_dataset())
    ledger=Ledger();core=Core(Cost.from_prices(pr),ledger,pr)
    c=core.elementwise("prefill",0,"softmax",96,row_length=32)
    assert c.commands==3 and c.cycles==3*pr.nonmac["profiles"]["softmax"]["32"]["cycles"]
    row=ledger.rows()[0]
    assert row.nonmac_commands==3 and row.count==3 and row.nonmac_profiles=={"softmax/32"}
    try:
        core.elementwise("prefill",0,"gelu",32)
    except ValueError as exc:
        assert "no corresponding" in str(exc)
    else:
        raise AssertionError("exact GELU must not borrow the GELU-tanh price")


def test_nonmac_contract_rejects_invalid_measured_records():
    for key,value in (("dynamic_pj",None),("cycles",True),("cycles",0),
                      ("read_count",1.5),("dynamic_pj",float("nan")),("report","")):
        data=complete_synthetic_contract()
        data["nonmac"]["profiles"]["softmax"]["32"][key]=value
        rejects(data,"nonmac")
    data=complete_synthetic_contract();del data["nonmac"]
    rejects(data,"nonmac")
    data=complete_synthetic_contract();data["nonmac"]["clock_ns"]=99
    rejects(data,"nonmac")
    data=complete_synthetic_contract();data["schema"]="sim-1017-synopsys-measured/v1"
    rejects(data,"schema")


def test_measured_leakage_is_billed_once_without_extra_cycles():
    pr=prices_from_dataset(synthetic_dataset())
    led=Ledger(leakage_pj_per_cycle=2.5)
    core=Core(Cost.from_prices(pr),led,pr)
    c=core.elementwise("decode",0,"softmax",32,row_length=32)
    total=led.totals()
    assert total["cycles"]==c.cycles
    assert total["whole_pj"]==c.pj+c.cycles*2.5
    assert led.mark().whole_pj==total["whole_pj"]


def test_top_level_nonmac_and_next_matrix_command_do_not_overlap():
    result=run_v3(V3Config(m=32,k=32,batch=3,model_host_io=False),dataset=synthetic_dataset())
    completed={e.metadata["vector_id"]:e.end_cycle for e in result.trace if e.operation=="stable_softmax"}
    starts=result.report["cycles"]["vector_start_cycles"]
    assert starts[1]>=completed[0] and starts[2]>=completed[1]
