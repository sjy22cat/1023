"""Run the current dependency-free V3 regression tests.

This deliberately calls every ``test_*`` function so the suite remains useful
in environments where pytest is not installed.
"""
from __future__ import annotations

import importlib
import traceback
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


DEFAULT_MODULES = ("tests.test_v3_scale_skip", "tests.test_v3_rules", "tests.test_v3", "tests.test_v3_data",
                   "tests.test_v3_current", "tests.test_v3_ppl", "tests.test_v3_hybrid_memory", "tests.test_v3_parameters", "tests.test_v3_nonmac", "tests.test_v3_pe_mc", "tests.test_v3_accelerator_scope", "tests.test_v3_interconnect", "tests.test_v3_fused_attention")


def main() -> int:
    requested = tuple(sys.argv[1:])
    modules = tuple(x for x in requested if not x.startswith("test_")) or DEFAULT_MODULES
    selected = {x for x in requested if x.startswith("test_")}
    total = failed = 0
    for module_name in modules:
        module = importlib.import_module(module_name)
        print(f"MODULE {module_name}")
        for name in sorted(dir(module)):
            if not name.startswith("test_"):
                continue
            if selected and name not in selected:
                continue
            test = getattr(module, name)
            if not callable(test):
                continue
            total += 1
            try:
                test()
            except Exception as exc:  # pragma: no cover - runner diagnostics
                failed += 1
                print(f"FAIL {name}: {type(exc).__name__}: {exc}")
                traceback.print_exc()
            else:
                print(f"PASS {name}")
    print(f"TOTAL {total} FAILED {failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
