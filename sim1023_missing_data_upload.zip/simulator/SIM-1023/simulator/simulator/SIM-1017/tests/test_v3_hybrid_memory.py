"""Hybrid storage, actual Attention dataflow, capacity and timing regressions."""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import sys

import numpy as np
from dataclasses import replace
from tempfile import TemporaryDirectory
import json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from yrr_v3.llm.cost import Cost, Ledger  # noqa: E402
from yrr_v3.llm.core import Core  # noqa: E402
from yrr_v3.llm.memdie import MemDie  # noqa: E402
from yrr_v3.llm.schedule import SimContext, mx_bytes  # noqa: E402
from yrr_v3.llm import LlmConfig, ModelOverride, run_llm, prices_from_dataset  # noqa: E402
from tests.hardware_fixture import synthetic_dataset, synthetic_prices
from yrr_v3.llm.capacity import CapacityError  # noqa: E402


def _cost(*, feram_read_ns=None, feram_write_ns=None) -> Cost:
    """Build only the prices used by these component-level checks."""
    prices = SimpleNamespace(
        mem_rd_pj_per_128b=3.0, mem_wr_pj_per_128b=5.0,
        mem_rd_ns=7.0, mem_wr_ns=11.0,
        feram_rd_pj_per_128b=None, feram_wr_pj_per_128b=None,
        feram_rd_ns=feram_read_ns, feram_wr_ns=feram_write_ns,
        clock_ns=1.0,
    )
    return Cost(pr=prices, block_pj=0.0, block_cycles=0,
                macs_per_block=0, block_unit_pj=0.0)


def test_rram_and_feram_use_independent_pool_offsets_and_limits():
    mem = MemDie(capacity_bytes=100, rram_capacity_bytes=20,
                 feram_capacity_bytes=80)
    rram = mem.allocate("weight", (16,), "weight", fp4=False,
                        raw_bits=8, medium="rram")
    feram = mem.allocate("kv", (16,), "kv_cache", fp4=False,
                         raw_bits=8, medium="feram")

    assert rram.offset == feram.offset == 0
    assert mem.storage_usage()["capacity_status"] == "configured"
    try:
        mem.allocate("too_much_rram", (5,), "weight", fp4=False,
                     raw_bits=8, medium="rram")
    except MemoryError as exc:
        assert "RRAM" in str(exc)
    else:
        raise AssertionError("allocation exceeding the RRAM pool must fail")


def test_host_preload_bytes_are_reported_without_inference_latency():
    cost = _cost()
    ledger = Ledger()
    mem = MemDie(capacity_bytes=1024, cost=cost,
                 rram_capacity_bytes=1024, feram_capacity_bytes=1024)
    weight = mem.allocate("weight", (32,), "weight", fp4=False,
                          raw_bits=8, medium="rram")
    core = Core(cost, ledger, SimpleNamespace(phy_bpc=128), memdie=mem)

    core.host_store("weight", weight.nbytes)
    core.host_load("weight", weight.nbytes)
    traffic = mem.traffic()

    assert traffic["by_medium"]["rram"]["host_write_bytes"] == weight.nbytes
    assert traffic["by_medium"]["rram"]["host_read_bytes"] == weight.nbytes
    assert traffic["host_latency_excluded"] is True
    assert traffic["ns"] == 0.0
    assert ledger.total_cycles() == 0.0
    # Host provisioning bytes are bookkeeping only; all its costs are excluded.
    assert traffic["pj"]["mem_write"] == 0.0
    assert traffic["pj"]["mem_read"] == 0.0

    host_read = cost.mem_read(16, origin="host")
    host_write = cost.mem_write(16, origin="host")
    assert host_read.ns == host_write.ns == 0.0
    assert host_read.cycles == host_write.cycles == 0
    assert host_read.phy_pj == host_write.phy_pj == 0.0


def test_missing_feram_prices_remain_pending_instead_of_using_rram_prices():
    transfer = _cost().mem_read(16, via_phy=False, gsram=False, medium="feram")

    assert transfer.mem_pj == 0.0
    assert transfer.mem_ns == 0.0
    assert set(transfer.pending_components) == {
        "feram_array_energy", "feram_array_latency"}


class _CaptureCore:
    def __init__(self):
        self.matmul_calls = []

    def load_weight_block(self, *args, **kwargs):
        pass

    def matmul(self, *args, **kwargs):
        self.matmul_calls.append(kwargs)

    def evict(self, *args, **kwargs):
        pass


def test_qkv_linear_can_skip_generic_rram_write():
    ctx = object.__new__(SimContext)
    ctx.img = SimpleNamespace(entry_shape=lambda _name: (3, 4))
    ctx.core = _CaptureCore()
    ctx.aquant = lambda _phase, _layer, _kind, x: x
    ctx._wbytes = lambda _name, rows, _inn: mx_bytes((rows,))
    ctx._mm = lambda x, _name: x
    x = np.zeros((1, 4), dtype=np.float32)

    ctx.linear("prefill", 0, "q_proj", x, "L00.q_proj", write_output=False)
    assert ctx.core.matmul_calls[-1]["out_bytes"] is None

    ctx.linear("prefill", 0, "other_proj", x, "L00.other_proj")
    assert ctx.core.matmul_calls[-1]["out_bytes"] == mx_bytes((3,))


def _small_config(**overrides):
    args = dict(prompt_tokens=3, max_new_tokens=3, calib_path="",
                model=ModelOverride(hidden=128, layers=2, heads=4, kv_heads=2,
                                    head_dim=32, intermediate=256, vocab=512),
                rram_capacity_bytes=1024*1024, feram_capacity_bytes=1024*1024)
    args.update(overrides)
    return LlmConfig(**args)


def _infer(**overrides):
    cfg = _small_config(**overrides)
    prices = synthetic_prices()
    if cfg.calib_path:  # legacy flat data is a TEST helper only, never production loading
        prices = replace(prices, **json.loads(Path(cfg.calib_path).read_text(encoding="utf-8")))
    result = run_llm(cfg, prices=prices).report
    if cfg.calib_path:
        result["calib"]["filled"] = list(json.loads(Path(cfg.calib_path).read_text(encoding="utf-8")))
    return result


def test_real_attention_writes_and_reads_feram_without_duplicate_qkv_writes():
    report = _infer()
    trace, kinds = report["trace"], report["ops_by_kind"]
    placement = report["hybrid_memory"]["by_medium"]
    assert all(t["medium"] == "rram" for t in placement["rram"]["tensors"])
    assert {t["name"] for t in placement["feram"]["tensors"]} == {"q_buffer", "kv_cache"}
    assert report["capacity"]["rram_used_bytes"] == placement["rram"]["used_bytes"]
    assert report["capacity"]["feram_used_bytes"] == placement["feram"]["used_bytes"]
    expected_preload = sum(t["nbytes"] for t in placement["rram"]["tensors"]
                           if t["role"] in ("weight", "embedding"))
    traffic = report["memory_traffic"]["by_medium"]
    assert traffic["rram"]["host_write_bytes"] == expected_preload
    assert traffic["feram"]["host_write_bytes"] == 0
    # 3 prefill + 2 decode tokens, 2 layers; Q=128, K=V=64.
    for name, size in (("q_write", 128), ("k_write", 64), ("v_write", 64)):
        assert kinds[name]["mem_wr_bytes"] == 5 * 2 * mx_bytes((size,))
        rows = [r for r in trace if r["kind"] == name]
        assert {r["phase"] for r in rows} == {"prefill", "decode"}
        assert all(r["medium"] == "feram" for r in rows)
    assert "kv_append" not in kinds
    assert not any(name + ".wback" in kinds for name in ("q_proj", "k_proj", "v_proj"))
    assert all(r["medium"] == "rram" for r in trace if r["kind"].endswith(".wload"))
    # Existing schedule reads Q/K/V per (query,key) pair without reuse.
    pairs = 2 * 4 * (3*3 + 4 + 5)
    assert kinds["attn_qk.rd.feram"]["mem_rd_bytes"] == pairs * 2 * mx_bytes((32,))
    assert kinds["attn_pv.rd.feram"]["mem_rd_bytes"] == pairs * mx_bytes((32,))
    assert kinds["attn_pv.rd"]["mem_rd_bytes"] == pairs * 16
    assert traffic["feram"]["inference_read_bytes"] == pairs * 3 * mx_bytes((32,))
    assert traffic["feram"]["inference_write_bytes"] == sum(kinds[k]["mem_wr_bytes"]
                                                             for k in ("q_write", "k_write", "v_write"))
    # MEM read/write totals include provisioning; the inference ledger does not.
    for medium in ("rram", "feram"):
        for direction, field in (("read", "mem_rd_bytes"), ("write", "mem_wr_bytes")):
            assert traffic[medium][f"inference_{direction}_bytes"] == sum(
                r[field] for r in trace if r["medium"] == medium)


def test_hybrid_shape_numeric_and_rerun_traffic_agree():
    numeric, shape = _infer(forward="numeric"), _infer(forward="shape")
    for field in ("hybrid_memory", "memory_traffic", "ops_by_kind", "energy", "latency"):
        assert numeric[field] == shape[field], field
    twice = _infer(n_runs=2)
    for medium in ("rram", "feram"):
        one = numeric["memory_traffic"]["by_medium"][medium]
        two = twice["memory_traffic"]["by_medium"][medium]
        assert two["host_write_bytes"] == one["host_write_bytes"]
        assert two["inference_read_bytes"] == 2 * one["inference_read_bytes"]
        assert two["inference_write_bytes"] == 2 * one["inference_write_bytes"]
    assert twice["latency"]["cycles_serial_1core"] == 2 * numeric["latency"]["cycles_serial_1core"]


def test_both_media_capacity_gates_reject_before_building_weights():
    from yrr_v3.llm import inference
    original = inference.build_weight_image
    def forbidden(*args, **kwargs):
        raise AssertionError("capacity must be checked before materializing weights")
    inference.build_weight_image = forbidden
    try:
        for config, message in (({"rram_capacity_bytes": 1}, "RRAM"),
                                ({"feram_capacity_bytes": 1}, "FeRAM"),
                                ({"mem_die_bytes": 1}, "容量")):
            try:
                _infer(**config)
            except CapacityError as exc:
                assert message in str(exc), str(exc)
            else:
                raise AssertionError("insufficient capacity must reject inference")
    finally:
        inference.build_weight_image = original


def test_feram_calibration_changes_costs_and_preserves_function():
    baseline = _infer()
    values = dict(feram_rd_pj_per_128b=2.0, feram_wr_pj_per_128b=3.0,
                  feram_rd_ns=5.0, feram_wr_ns=7.0)
    with TemporaryDirectory() as tmp:
        filename = Path(tmp) / "feram_calib.json"
        filename.write_text(json.dumps(values), encoding="utf-8")
        calibrated = _infer(calib_path=str(filename))
    assert calibrated["output"] == baseline["output"]
    assert set(values) <= set(calibrated["calib"]["filled"])
    costs = calibrated["memory_traffic"]["by_medium"]["feram"]["array_cost_known"]
    # The existing pair scheduler aggregates one transfer per head per step;
    # each transfer rounds separately to a 16-byte access. Aggregated report
    # rows span several steps and cannot be rounded a second time as one DMA.
    rd_accesses = 2 * 4 * sum((width * pairs + 15)//16
                             for pairs in (9, 4, 5) for width in (34, 17))
    wr_accesses = 2 * sum((tokens * width + 15)//16
                         for tokens in (3, 1, 1) for width in (68, 34, 34))
    assert costs["read_pj"] == 2 * rd_accesses
    assert costs["write_pj"] == 3 * wr_accesses
    assert costs["inference_ns"] == 5 * rd_accesses + 7 * wr_accesses
    assert np.isclose(calibrated["energy"]["total_whole_block_pj"]
                      - baseline["energy"]["total_whole_block_pj"],
                      costs["read_pj"] + costs["write_pj"]
                      + calibrated["energy"]["by_cat"]["leakage"]["whole_pj"]
                      - baseline["energy"]["by_cat"]["leakage"]["whole_pj"])
    assert calibrated["latency"]["cycles_serial_1core"] > baseline["latency"]["cycles_serial_1core"]
    assert "feram_array_energy" in baseline["memory_traffic"]["pending_cost_bytes"]
    assert "feram_array_energy" not in calibrated["memory_traffic"]["pending_cost_bytes"]
    assert baseline["throughput"]["per_core"] is None
    assert baseline["efficiency"]["by_billing"]["whole_block"]["per_token_j"] is None


def test_host_provisioning_never_enters_inference_ledger_or_block_price():
    from yrr_v3.llm.core import Core
    from yrr_v3.llm.config import prices_from_dataset
    from yrr_v3 import V3Datasheet
    baseline = _infer()
    original = Core.host_store
    Core.host_store = lambda *args, **kwargs: None
    try:
        no_preload = _infer()
    finally:
        Core.host_store = original
    assert baseline["latency"] == no_preload["latency"]
    assert baseline["energy"] == no_preload["energy"]
    assert baseline["latency"]["host_io_included"] is False
    assert baseline["memory_traffic"]["by_medium"]["rram"]["host_write_bytes"] > 0
    assert no_preload["memory_traffic"]["by_medium"]["rram"]["host_write_bytes"] == 0
    ds = synthetic_dataset()
    changed = replace(ds, mem_die_latency=ds.mem_die_latency + 1000)
    # Weight cold-start latency is charged by runtime RRAM reads, not again
    # inside every GEMV's price. These snapshots must therefore be identical.
    a = prices_from_dataset(ds, force=True)
    b = prices_from_dataset(changed, force=True)
    assert a.block_cycles == b.block_cycles
    assert a.block_pj == b.block_pj
    assert Cost.from_prices(a).block_pj > 0


def test_fused_qkv_also_uses_only_feram_output_writes():
    from yrr_v3.llm.arch import ArchSpec
    spec = ArchSpec(hidden=128, layers=2, q_heads=4, kv_heads=2,
                    head_dim=32, intermediate=256, vocab=512, fused_qkv=True)
    report = _infer(model_spec=spec)
    kinds = report["ops_by_kind"]
    assert "qkv_proj" in kinds and "qkv_proj.wback" not in kinds
    assert "kv_append" not in kinds
    for kind, size in (("q_write", 128), ("k_write", 64), ("v_write", 64)):
        assert kinds[kind]["mem_wr_bytes"] == 5 * 2 * mx_bytes((size,))
        assert all(r["medium"] == "feram" for r in report["trace"] if r["kind"] == kind)


def test_hybrid_report_renders_and_serializes_without_nonfinite_numbers():
    from yrr_v3.llm import format_report
    report = _infer()
    json.dumps(report, allow_nan=False)
    rendered = format_report(report)
    assert "RRAM / FeRAM 地址池" in rendered
    assert "内部全阵列 GEMV" in rendered
    assert "主机读写延迟排除" in rendered


def test_transfer_volume_is_independent_of_missing_or_zero_energy_and_delay():
    prices = replace(synthetic_prices(), phy_pj_per_bit=0, phy_ps_per_bit=0,
                     gsram_read_pj_per_128b=0, gsram_write_pj_per_128b=0)
    cost, ledger = Cost.from_prices(prices), Ledger()
    mem = MemDie(1024, cost)
    core = Core(cost, ledger, prices, memdie=mem)
    core.read_back("prefill", 0, "q_read", 17, medium="feram")
    assert mem.traffic()["phy_bytes"] == 17
    assert mem.traffic()["gsram_bytes"] == 17
    assert ledger.rows()[0].phy_bytes == 17
    assert ledger.rows()[0].gsram_bytes == 17
    core.gsram("prefill", 0, "local_only", 16, write=True)
    assert mem.traffic()["phy_bytes"] == 17
    assert mem.traffic()["gsram_bytes"] == 33
