#!/usr/bin/env python3
"""SIM-1017 matrix evaluation using externally characterized hardware inputs."""
import argparse
import json
from pathlib import Path
from yrr_v3 import V3Config, V3Datasheet, default_1017_measured_path, format_report, run_v3
from yrr_v3.rtl_dataset import WORKLOAD_FIELDS
from yrr_v3.characterization import default_component_path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--rtl-1017-calibration", "--parameters", dest="parameters", default=str(default_component_path()),
                    help="component JSON (partial results) or complete measured JSON")
    ap.add_argument("--mx-skip-threshold", type=int, help="explicit scale distance threshold; unspecified disables block skip")
    ap.add_argument("--json")
    ap.add_argument("--trace")
    ap.add_argument("--rtl-vectors")
    ap.add_argument("--batch", type=int, default=1)
    ap.add_argument("--workload", choices=("gemv", "gemm"), default="gemv")
    for dim in ("m", "n", "k"):
        ap.add_argument("--"+dim, type=int, default=1024)
    ap.add_argument("--no-softmax", action="store_true")
    ap.add_argument("--no-tag-skip", action="store_true")
    ap.add_argument("--no-block-skip", action="store_true")
    ap.add_argument("--nonmac-parameters", help="1024-lane parallel non-MAC unit-cost JSON; pending values remain unknown")
    ap.add_argument("--interconnect-parameters", help="optional dedicated parallel-tree topology/wire estimate JSON (not measured RTL)")
    ap.add_argument("--config", help="optional workload JSON (hardware values must come from measured JSON)")
    args = ap.parse_args()
    try:
        ds = V3Datasheet.from_parameters(args.parameters)
        if args.nonmac_parameters:
            ds = ds.with_nonmac_parameters(args.nonmac_parameters)
        if args.interconnect_parameters:
            ds = ds.with_interconnect_parameters(args.interconnect_parameters)
        if args.mx_skip_threshold is not None:
            from dataclasses import replace
            ds = replace(ds, config_values={**ds.config_values,"mx_skip_threshold_bits":args.mx_skip_threshold})
        values = dict(m=args.m, n=args.n, k=args.k, batch=args.batch, workload=args.workload,
                      enable_softmax=not args.no_softmax, enable_tag_skip=not args.no_tag_skip,
                      enable_mx_block_skip=not args.no_block_skip)
        if args.config:
            supplied = json.loads(Path(args.config).read_text(encoding="utf-8"))
            forbidden = set(supplied) - (WORKLOAD_FIELDS - {"energy", "latency_source"})
            if forbidden:
                raise ValueError("hardware/unknown overrides forbidden: " + ", ".join(sorted(forbidden)))
            values.update(supplied)
        result = run_v3(V3Config(**values), dataset=ds)
    except (OSError, ValueError, TypeError) as exc:
        ap.error(str(exc))
    print(format_report(result))
    if args.json:
        Path(args.json).write_text(json.dumps(result.report, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    if args.trace:
        result.export_trace_json(args.trace)
    if args.rtl_vectors:
        result.export_rtl_vectors(args.rtl_vectors)


if __name__ == "__main__":
    main()
