# SIM-1017 模拟器说明

> **并行广播/互连更新，Python 3.5：** 32 列专用广播树已支持分别记录首次延迟和连续供数间隔；默认估算为 5-cycle latency、II=1。已运行完整 32×32 BookSim mesh 对照及不同线长校准，保存原始配置和 trace。详见 [并行广播与互连评估](docs/并行广播与互连评估_20261019.md)。用 `--interconnect-parameters interconnect_eval_20261019/dedicated_network_parameters.json` 启用；这是有来源和布局假设的模型估算，等待真实布局/RTL 定标。

> **2026-10-19 更新：请先读 [每 PE 独立 MC 与 RTL 数据接入说明](docs/每PE独立MC与RTL数据接入_20261019.md)。** 当前 Python 矩阵路径已改为 32768 个 PE-local 128-bit MC，默认加载 `calibration/rtl_1017sim/components_20261019_sram128.json`。该参数文件采用 `RTL数据.xlsx` 的 Sheet1，并叠加用户提供的 `SRAM_128X128_高速` 与 `SRAM_128X8_高速` 数据；PHY 经确认按 pJ/128 bit。新 SRAM 的访问延迟尚未提供，当前 1 ns 只是一项明确的 timing assumption。缺失参数保留未知，支持部分结果。运行 `python -B run.py --no-softmax` 或 `python -B validate_parameters.py`。
>
> **以下正文保留为上一版历史说明。** 其中“32 MC/32 channel”、v2 schema、必须全部表征才能运行矩阵路径等内容已被上述新文档覆盖。旧 `run_llm.py` 仍需要独立的完整 LLM 表征，不具备本次逐 PE 数据掩码计费；不要混用结果。

本文件整合原 `README.md`、`README_LLM.md` 的有效使用说明，是 SIM-1017 的统一入口，后续运行与模型数据要求统一维护于此。旧报告中的性能数值不代表当前硬件的实测结果。

SIM-1017 评估近存加速器上的推理数值、调度、流量、容量、能耗与延迟。正式硬件参数全部由 **Synopsys 运行 `RTL/RTL_1017SIM` 及配套 memory/PHY IP 后的结果**提供；模拟器不再解析 RTL 或 `.vh` 推导时序、面积、能耗，也不以 Python 默认值补缺。

## 1. 先回答：读什么、从哪里读、结果放哪里

| 问题 | 当前规则 |
|---|---|
| 模拟器读取什么？ | 一个 UTF-8 JSON，schema 为 `sim-1017-synopsys-measured/v2`，正式运行要求 `status=MEASURED` |
| 默认从哪里读取？ | 本目录的 `calibration/rtl_1017sim/rtl_1017sim_measured.json`；按软件包位置定位，与启动命令所在目录无关 |
| 如何指定其他版本/PVT？ | `run.py`、`run_llm.py`、`run_ppl.py` 使用 `--parameters PATH`，兼容别名 `--rtl-1017-calibration PATH`；显式相对路径按当前工作目录解释 |
| PPL 从哪里读？ | `run_ppl.py` 的 `finite_mxfp4` 路径读取同一参数文件；纯 `fp32`、`dense_mxfp4` 质量比较不依赖物理参数 |
| 新思输出放哪里？ | 原始报告、trace、活动文件放在下述目录，人工按本契约归一化后填入 JSON；模拟器不直接解析 `.rpt/.lib/.saif` |
| 缺数据怎么办？ | 加载时报错并停止。当前随附 JSON 为 **PENDING 空模板**，必须填入真实结果后才能正式评估 |

默认位置的绝对路径：

```text
D:\ZJLab\zjlab_exp\zjlab_exp\cooperation\YRR\YRR_system\simulator\SIM-1017\calibration\rtl_1017sim\rtl_1017sim_measured.json
```

建议将一次表征的证据放在同一个目录中，其他 PVT/版本使用独立目录保存：

```text
calibration/rtl_1017sim/
  rtl_1017sim_measured.json   # 模拟器唯一直接消费的硬件参数文件
  synthesis/                # 展开配置、综合/布局布线面积、层次报告
  sta/                      # SDC、约束时钟、setup/hold、WNS/TNS、寄生参数说明
  power/                    # PT PX 功耗报告、SAIF/VCD、活动覆盖率、统计窗口
  memory/                   # SRAM/RRAM/FeRAM macro 与 PHY/HB IP 的模型和表征报告
  traces/                   # VCS 请求/响应、逐 channel 流量、lane mask、冷/热启动
```

`provenance.reports` 记录原始报告的位置、版本，建议另存 SHA256。文件归档不会自动填参，修改 RTL 或 PVT 后必须重新表征。

## 2. 硬件与控制契约

```text
1 套全局总控：任务配置、阶段调度、依赖、整体完成
  ├─ MC 0  → channel 0  → tile[0..31][0]
  ├─ ...
  └─ MC 31 → channel 31 → tile[0..31][31]
各 tile → 32 PE/tile → 32 MAC lane/PE，本地 lane enable / zero / TAG mask
```

物理阵列为 32×32 tile，共 32,768 PE、1,048,576 路 MAC。每个 MC 服务一列的 32 个 tile，共享一套总控。单 channel 数据为 **128 bit payload + 8 bit E8M0 scale**；这是 32 个 MXFP4 元素的一组，合计 17 B。32 路并行不改变单路宽度。

Mem Die → HB/PHY → MC → tile 是 32 路存储通道；MC 管本通道的请求、地址、返回与完成状态。Host → GSRAM 的 DMA 是另一条路径。`--with-host-io` 决定单算子报告是否计入主机与 DMA，不能把 Mem Die 传输再次算成 Host DMA。

预判 block skip 只看 E8M0 scale：`Esum=(Wscale-127)+(Xscale-127)`，按输出求 `EMXmax`，当 `EMXmax-Esum >= T` 时跳过。它发生在 input payload 读取、广播和 MAC 之前。`mx_skip_threshold_bits=null` 表示未确认阈值、关闭此跳过；不能从已算出的乘积/partial 反推跳过。

TAG/零值门控在本地译码后控制单路 MAC。一个 tile 仍有 PE 需要某组输入时，不能省去共享输入接收；源端全部接收方都跳过才省去源 payload 读取。输入 scale 检查仍发生。**冷启动完整权重装载在 skip 判断之前，不能将 block skip 计为首次权重搬运的节省。**

## 3. 参数清单、单位与采集来源

以下所有硬件章节都是当前统一加载器的必需输入，包括单算子运行时暂未使用的 LLM 参数。模板保留全部键；也可运行 `python validate_parameters.py --list-required` 查看代码要求。除明确说明外，必需数值不能缺失或为 `null`；零值必须有对应实现/测量依据，不能用 0 代替未知。

### 3.1 `structure`：展开后的设计配置

| 字段 | 填写要求 |
|---|---|
| `mc_count`、`mem_die_channels` | 均为 32 |
| `tile_rows`、`tile_cols` | 均为 32 |
| `pe_per_tile`、`tile_k` | 均为 32；后者为每 PE 的 MAC lane 数 |
| `payload_bits`、`scale_bits` | 分别为 128、8 |
| `mc_channel_map`、`mc_tile_column_map` | 都为 `[0,1,...,31]`，MC c 绑定 channel c、tile column c |
| `gsram_banks`、`gsram_depth`、`gsram_pages` | 展开和 memory macro 实际 bank 数、每 bank 深度、页数；均为正整数 |

这些是设计/综合展开记录，不是模拟器估计量。GSRAM 可用容量另由 `global_sram_bytes` 指定，应核对 payload、scale、双缓冲与保留空间的一致性。

### 3.2 `timing`：实测周期与工作时钟

`clock_ns` 的单位为 ns；其余字段为非负整数 cycles，其中乘法、归约周期要求大于 0。非 MAC 周期另在 `nonmac` 中逐算子/长度表征。应以 VCS handshake/阶段 trace 测周期，以 STA 收敛结果确定可用时钟；不能仅填 SDC 目标频率。

| 字段 | 当前消费口径 |
|---|---|
| `clock_ns` | 对应 PVT/实现的实际采用周期 |
| `mc_request_to_response_cycles` | 非理想通道事务的固定请求/响应开销，**不含下述有效字节服务段** |
| `gsram_payload_read_cycles`、`gsram_scale_read_cycles` | payload 读取、scale sideband 读取周期 |
| `gsram_write_latency_cycles` | GSRAM 写入固定启动周期 |
| `host_dma_setup_cycles` | Host DMA descriptor/staging 启动开销 |
| `mx_control_cycles`、`tag_decode_cycles` | scale 预判、TAG/格式译码的阶段周期 |
| `broadcast_cycles` | 输入广播阶段周期 |
| `pe_mul_cycles`、`pe_acc_cycles` | PE 乘法及局部累加阶段周期 |
| `reduction_cycles` | 当前架构模型使用的整体归约延迟 |

当前通道事务按 tile/K 组聚合，调度持续时间为：

```text
duration_cycles = mc_request_to_response_cycles
                + ceil(transaction_bytes / mem_die_bytes_per_cycle)
```

因此若 VCS 给的是一个事务的完整 request→complete 时间，必须先扣除同口径的有效传输服务段，再填写固定开销，并用多个事务长度验证。不能把完整延迟原样填入后又加一次带宽时间。这是测量值的口径归一化；模拟器不根据 RTL 结构推测该开销。

### 3.3 `config_overrides`：带宽、容量与实际实现选项

本章节覆盖所有硬件字段；正式运行强制绑定这些值，不允许 `run.py --config` 或普通 `V3Config` 默认值覆盖。实验的 shape、seed、skip 开关、是否计算 softmax/Host I/O 仍由任务配置决定。

| 字段 | 单位/取值 |
|---|---|
| `ideal_mem_die` | 必须为 `false`，本参数包对应非理想 32 通道模式 |
| `mem_die_count` | 当前单算子模型契约为 2 个同构 Mem Die；每层映射到其中一个，并非自动将带宽翻倍 |
| `mem_die_bytes_per_cycle` | **每 channel**有效 payload+scale 的 B/cycle；一拍完成 128+8 bit 时为 17，不能将 128 bit 写成 128 B |
| `mem_die_queue_depth` | 当前调度器的**总 outstanding 事务槽位数**，不是每 MC 深度；少于 32 会限制同时启动的通道数 |
| `global_sram_bytes`、`gsram_write_bytes_per_cycle` | SRAM 可用 B、写入 B/cycle |
| `source_lanes` | 源端可同时供应的输入组数 |
| `input_double_buffer`、`logits_double_buffer` | JSON 布尔值；实际双缓冲选项 |
| `dma_staging_bytes`、`dma_descriptor_bytes`、`dma_status_bytes_per_descriptor` | B；staging 容量、单 descriptor 大小、每 descriptor 状态大小 |
| `dma_descriptor_count`、`host_bus_width` | descriptor 数量、Host 总线 bit/拍 |
| `broadcast_style`、`reduction_style` | 分别为 `wide/serial`、`tree/serial`，应匹配实现 |
| `partial_bits`、`output_format` | 有符号 partial 位宽 2..52；输出 `fp32/bf16` |
| `mx_metadata_available`、`tag_metadata_available` | scale/TAG 元数据路径是否实际存在，布尔值 |
| `mx_skip_threshold_bits` | RTL 确认的正整数阈值；唯一允许为 `null` 的硬件配置字段，表示关闭 block skip |
| `rram_enabled`、`ferram_enabled` | 对应存储路径是否启用，布尔值；注意代码键名保留 `ferram` 拼写 |
| `ferram_kv_capacity_bytes` | FeRAM KV 可用 B |
| `ferram_kv_read_bytes_per_cycle`、`ferram_kv_write_bytes_per_cycle` | FeRAM KV 读/写 B/cycle |
| `ferram_kv_read_latency`、`ferram_kv_write_latency` | FeRAM KV 读/写固定 cycles |
| `ferram_channel_mode` | `independent/shared`，FeRAM 与其他存储流量是否共享资源 |

带宽需从持续流量下的已完成字节/周期获取，容量和选项来自实际设计配置。当前 B/cycle 字段要求正整数；不能把小数吞吐率直接塞入或任意四舍五入，非整数/可变吞吐需要扩展契约及调度模型。

### 3.4 `energy`：事件能耗

用 VCS 的有效活动窗口、SAIF/VCD 和 PT PX/合格 macro 模型获取动态能量，再除以同窗口的事件数。换算为 `pJ = W × s × 10^12`。扣除独立记录的 leakage/idle，明确时钟网络和控制开销如何归属；不能把同一段能量同时计入 block、MAC、互连、PHY。

| 字段 | 分母/含义 |
|---|---|
| `pe_mac_pj` | 每次有效 MAC |
| `gsram_read_pj_per_128b`、`gsram_write_pj_per_128b` | 每 128 bit SRAM 读/写；scale 也按实际位数归一化记账 |
| `broadcast_pj_per_bit` | 每 bit 广播接收活动 |
| `tile_reg_write_pj_per_bit`、`tile_weight_write_pj_per_bit` | 每 bit 输入寄存器/权重寄存器写入 |
| `partial_link_pj_per_bit` | 每 bit partial 链路活动 |
| `alignment_pj_per_bit` | 每 bit 对齐移位活动 |
| `reduction_add_pj` | 每次归约加法活动 |
| `mx_control_pj_per_block` | 每输出 PE、每 32-lane block 的预判活动 |
| `tag_decode_pj_per_element` | 每个元素的 TAG/格式译码 |
| `dma_pj_per_bit`、`host_pj_per_bit` | Host DMA 内部与 Host 接口每 bit 的独立能量 |
| `rram_read_pj_per_byte` | RRAM array 每 B 读取，不含另计的 HB/PHY |
| `ferram_read_pj_per_byte`、`ferram_write_pj_per_byte` | FeRAM array 每 B 读/写 |
| `hybrid_bond_pj_per_bit` | 单算子路径合计的 HB+PHY 每 bit 能量，不再重复另加 PHY |
| `fp32_conversion_pj` | 每个输出的转换活动 |
| `leakage_pj_per_cycle` | 明确统计范围的静态功耗 × 一个工作周期，pJ/cycle |

### 3.5 `area`：外部面积结果

所有值单位 mm²：`logic_die_mm2`、`global_controller_mm2`、`mc_unit_mm2`、`mc_total_mm2`、`phy_total_mm2`、`tile_total_mm2`、`gsram_mm2`、`dma_mm2`、`reduction_mm2`、`nonmac_mm2`。非 MAC 面积覆盖集成模块，scratch macro 的归属须在 provenance 中注明，避免重复相加。

来自 DC/ICC II/Fusion Compiler 的层次面积报告及 macro 数据。记录是 cell area 还是 die/core area、是否含 SRAM/PHY macro、filler/CTS 等。`logic_die_mm2` 必须大于零；各分项未必能直接相加，需要在 provenance 解释范围。模拟器只展示输入面积，不据此反推走线长度、延迟或能耗。

### 3.6 `llm_hardware` 与 `llm_prices`：LLM 专用输入

`llm_hardware` 必填：`mem_die_bytes`（LLM 可用的聚合存储 B）、`mem_die_count`（记录堆叠数量）、`rram_capacity_bytes`、`feram_capacity_bytes`。RRAM+FeRAM 容量不能超过聚合容量；`mem_die_bytes` 不再乘 die 数。应与同次硬件配置一致，软件目前不自动证明两种入口容量布局等价。

`llm_prices` 直接读取外部测量/表征结果，**不会在 Python 中先跑一次阵列，再推算块单价**：

| 字段 | 单位/采集范围 |
|---|---|
| `block_pj`、`block_cycles` | 权重驻留、无 Host/DMA/权重装载/softmax 的一次满 1024×1024 GEMV 动态 pJ 与 cycles；泄漏另计 |
| `macs_per_block` | 该 GEMV 的 MAC 数，固定为 `1024^2`，不是 GEMM 的 `1024^3` |
| `clock_ns` | 必须与 `timing.clock_ns` 一致 |
| `pe_mac_pj`、`reduction_add_pj` | 每有效 MAC、每累加/归约加法的 pJ |
| `gsram_read_pj_per_128b`、`gsram_write_pj_per_128b` | 每 128 bit SRAM 访问 pJ |
| `tile_reg_write_pj_per_bit`、`leakage_pj_per_cycle` | 每 bit 寄存器写入 pJ、静态 pJ/cycle |
| `mem_rd_pj_per_128b`、`mem_wr_pj_per_128b` | RRAM 每 128 bit 读/写 pJ，不含 PHY/HB |
| `mem_rd_ns`、`mem_wr_ns` | RRAM 每 128 bit 访问的**串行服务时间 ns**；不是任意长 burst 的一次首字延迟 |
| `feram_rd_pj_per_128b`、`feram_wr_pj_per_128b` | FeRAM 每 128 bit 读/写 pJ |
| `feram_rd_ns`、`feram_wr_ns` | FeRAM 每 128 bit 访问的串行服务时间 ns |
| `phy_pj_per_bit` | PHY 路径每 bit pJ；其能量范围要覆盖 LLM 另未计价的 HB 部分 |
| `phy_bpc` | 每 channel payload 宽度，固定为 128 bit，不可填 4096 冒充 32 路并行 |
| `phy_ps_per_bit` | **保留的旧字段名**：实际填每个 `phy_bpc` bit payload 节拍的 ps，不是串行每 bit 时间 |
| `hb_latency_ns` | 每次跨 Die 搬运的固定 HB 延迟 ns，与 PHY/array 时间分开 |

同名能耗字段必须与 `energy` 一致。`f_max_mhz=1000/clock_ns`、`block_pj_by_mac=macs_per_block×pe_mac_pj` 仅作单位/账目换算，不需填入 JSON。`energy` 的 `ferram_*` 与本章节的 `feram_*` 拼写不同，请保留模板键名。

LLM 当前搬运公式是串行聚合：`ceil(bytes/16)×mem_*_ns + bytes×8/phy_bpc×phy_ps_per_bit/1000 + hb_latency_ns`，再换算 cycles。输入规模应包含实际 payload+scale。GSRAM 部分、寄存器写入另记；能量范围必须避免与 `block_pj` 重复。

### 3.7 来源、格式与验收信息

`provenance` 七项必填：`rtl_revision`（版本/源码哈希）、`tool_versions`、`pvt`、`clock_constraint`、`activity_window`、`reports`、`energy_scope`（各单价统计范围、扣除项和归属）。

`format_contract` 记录 RRAM/TAG LUT 版本、zero code、E8M0、32 元素分组、阈值、舍入、饱和与 golden vectors。`validation` 归档逐 channel 请求数/返回字节、请求响应 trace、active/skipped blocks、lane mask、active MAC、饱和计数、冷/热启动 cycles。**这两节目前是验收证据，不会自动覆盖数值模型或重放 trace。**

加载器检查 schema、状态、必需字段、数值合法性及部分配置一致性；不会自动检查报告真伪、STA 是否收敛、面积分项是否相加或 RTL 数值等价。工程交付时仍须核对这些证据。

### 3.8 集成 FP32 非 MAC 的实测记录

RTL 已集成 `llm_nonmac_fp32.sv/nonmac_fp32_pipe.sv/nonmac_microcode.vh`，另加归约转 FP32 和命令接口。完整接线、scratch 布局、opcode、新思命令、测量窗口及 JSON 契约见 [非 MAC 实测说明](../../Instruction/nonmac_1017SIM_measurement.md)。集成目录中的版本为准，根目录原文件保留作参考。

v2 新增必填章节 `nonmac`：固定 `implementation=llm_nonmac_fp32`、`max_vector_length=1024`，并填写 `clock_ns/rtl_revision/dw_version/scratch_implementation/activity_policy/reports/scope`。`profiles.<op>.<length>` 按真实命令填写 `cycles/dynamic_pj/read_count/write_count/report`，不再提供通用非 MAC 单元素价格。`scope` 固定为 `engine_and_scratch_dynamic_excludes_staging_and_leakage`；命令动态能量包含 scratch 访问，禁止再按全局 SRAM 单价重复计算。泄漏在活动周期另计一次。

`run.py` 的归约转换和 scratch 写入另读取 `reduce_staging.<length>`；该窗口不含核心启动与执行，和命令窗口不得重叠。模板只有待填示例长度，按目标模型实际需要增加条目。缺失算子/长度直接报错，不插值、不从微码/流水级数推导周期，也不恢复旧 Softmax 公式。

`run_llm.py` 保留每个 Softmax、RMSNorm 的真实行边界，重复相同命令时才线性累计已测结果。普通点运算可以分为 1024 元素及尾块；Softmax、RMSNorm、LayerNorm、split-half RoPE 的超长行拒绝运行，不能用独立小块改变算法语义。精确 GELU 等没有硬件实现的算子也会拒绝。

旧 v1 JSON 及 `softmax_lanes/materialize_exp/softmax_cycles_per_group/softmax_exp_pj/softmax_add_pj/softmax_div_pj` 已退出运行接口。迁移需要对集成 RTL 重新表征并核对范围，不能只替换 schema 字符串。当前 v2 模板仍为 PENDING，没有新思结果。

Python/NumPy 继续提供数值参考；它不提供非 MAC 性能和能耗。MXFP4 编码、RoPE 正余弦表生成、token 采样/argmax 没有在三个模块中实现，当前属于 Host 参考步骤，成本明确排除。LLM `execution_scope` 将 `full_system_metrics_complete` 标为 false；性能指标限于已覆盖的加速器服务，不能理解成含 Host 的整机测量。

## 4. 从新思结果到正式运行

### 4.1 当前已有内容与运行条件

截至 2026-10-18，当前工程已有模型结构预设、权重加载代码、MXFP4 数值路径和内置 `ByteTokenizer`。**工程内未发现真实预训练 checkpoint 或真实 tokenizer 文件；默认 Qwen3-0.6B 是模型结构，默认数值权重由固定 seed 随机生成。** 随附硬件参数文件仍为 PENDING，尚未填入真实新思结果。

先按目的选择入口：

| 目的 | 命令/模式 | 是否需要完整实测硬件 JSON | 还需要哪些模型数据 |
|---|---|---|---|
| 检查软件与回归 | `tests/run_current.py`、`--help`、`validate_parameters.py --list-required` | 否；回归使用显式合成测试参数 | 无 |
| 查看模型预设 | `run_llm.py --list-models` | 否；列表容量是已标注的设计默认参考 | 无；使用内置形状 |
| 单算子评估 | `run.py` | 是 | 可用随机矩阵；真实算子需通过 Python 提供权重/输入或 payload+scale |
| 小规模数值链路检查 | `run_llm.py --smoke` | 是 | 无外部模型文件；生成小模型权重，使用占位 tokenizer |
| 模型形状/容量/性能账目评估 | `run_llm.py --forward shape` | 是 | 内置 `--model` 名，或目标模型的 `config.json`；无需 checkpoint/tokenizer |
| 真实权重数值推理 | `run_llm.py --forward numeric` | 是 | 匹配的结构配置、完整浮点 safetensors、原生入口可读的 tokenizer、prompt |
| FP32 与 dense MXFP4 困惑度比较 | `run_ppl.py --modes fp32 dense_mxfp4` | 否；这是数值质量评估 | 完整本地预训练模型目录、真实 tokenizer、独立 UTF-8 测试文本 |
| 有限位宽困惑度比较 | PPL 中加入 `finite_mxfp4` | 是 | 同上，并须满足当前 Linear/K 分块覆盖限制，见第 5 节 |

`shape` 给出指定模型结构和工作负载规模下的架构预测，不读取权重数值，也不能得到真实数据的零值、lane mask 或 skip 分布。需要验证这些行为时，应向单算子数值接口提供真实操作数，并与 RTL trace 对照。

### 4.2 获取硬件参数

1. 固定 RTL 版本、32 MC 配置、macro/IP、PVT、SDC、数值格式与 skip 阈值。
2. 用 VCS 导出请求/响应与活动统计，覆盖冷/热启动、32 路同时请求、错峰返回、背压、不同流量长度、全活跃/零值/lane mask/scale skip。
3. 用 DC/ICC II/Fusion Compiler 获取实际实现面积，PrimeTime 获取时序；在对应实现与活动窗口运行 PT PX 获取功耗。SRAM/RRAM/FeRAM/PHY/HB 必须使用有效的 macro/IP 模型与报告。
4. 按第 3 节的事件分母和范围归一化、填写所有必需字段，关联原始报告。确认齐全后才设置 `status=MEASURED`，不要直接把 PENDING 改名。
5. 校验参数后运行，保留输入 JSON 和报告副本，比较模拟调度与 VCS 的事务数、字节、mask、MAC 与周期差异。

### 4.3 安装依赖、先检查软件，再运行评估

以下使用 PowerShell，所有相对路径以 `SIM-1017` 为工作目录：

```powershell
Set-Location 'D:\ZJLab\zjlab_exp\zjlab_exp\cooperation\YRR\YRR_system\simulator\SIM-1017'
python -m pip install -r requirements.txt
```

基础模拟器/原生 LLM 入口依赖 NumPy；原生 Qwen BPE 建议另装 `regex`，以使用原版预切分正则。PPL 安装 `python -m pip install -r requirements-ppl.txt`，其中包含 torch、transformers、safetensors、regex；选择适合本机 CPU/CUDA 的 torch，按目标模型补齐 tokenizer 依赖。离线环境需预先安装这些依赖或使用离线 wheel。

当前没有实测 JSON、没有 checkpoint/tokenizer 时，可以先执行：

```powershell
python tests/run_current.py
python run_llm.py --list-models
python validate_parameters.py --list-required
python run.py --help
python run_llm.py --help
python run_ppl.py --help
```

**以下校验与推理命令需要先填齐实测 JSON，PENDING 时会报错：**

```powershell
python validate_parameters.py
python run.py --m 1024 --k 1024 --no-softmax --json report.json --trace trace.json
python run_llm.py --smoke --json llm_smoke.json
python run_llm.py --model qwen3-0.6b --forward shape --prompt-tokens 128 --max-new-tokens 16 --json llm_shape.json
```

这里的单算子、smoke、shape 命令均不要求外部 checkpoint/tokenizer。`--smoke` 的随机数值只检查链路；`shape` 用于模型结构对应的资源与性能账目。

显式选择另一份实测结果：

```powershell
python validate_parameters.py --parameters calibration/my_pvt/rtl_1017sim_measured.json
python run.py --parameters calibration/my_pvt/rtl_1017sim_measured.json --json report.json
python run_llm.py --parameters calibration/my_pvt/rtl_1017sim_measured.json --smoke
```

当前空模板执行默认校验/推理会非零退出，这是禁止估算回退的预期行为。`--estimate`、`--rtl`、`--latency-source`、`--calib` 等旧参数来源选择方式已移除。

Python 调用：

```python
from yrr_v3 import V3Config, V3Datasheet, run_v3

ds = V3Datasheet.from_1017_calibration()  # 或传入实测 JSON 路径
result = run_v3(V3Config(m=128, k=1024, enable_softmax=False), dataset=ds)
result.export_trace_json("trace.json")
```

`run_v3` 可直接传入 `weights/inputs` 浮点数组，或 `weight_payload/weight_scale`、`input_payload/input_scale`。MXFP4 payload 数组每元素保存 0..15 码值，scale 为每 32 元素一组的 E8M0；尾部 K 按组补齐。复用 `SimulatorSession` 可保留跨调用的权重驻留状态。CLI 不给数组时使用固定 seed 的合成工作负载，不代表真实模型精度。

`run.py --config FILE` 只接收 shape、batch、workload、seed、layer 映射/驻留、skip/softmax/Host I/O 开关等任务字段；硬件参数必须来自实测 JSON。`gemm` 下每 batch 有 `n` 个输入向量，`gemv` 下每 batch 一个向量。

## 5. LLM 推理使用方法（原 README_LLM 合并内容）

### 5.1 模型、数值前向与运行规模

`run_llm.py` 默认 Qwen3-0.6B，S=128、生成 T=1024、一次推理。建议先 `--smoke`：hidden=128、1 层、S=8、T=4。`--weights DIR` 读取本地 safetensors，`--tokenizer DIR` 提供真实分词器；未指定时使用生成权重/占位分词器，仅可验证链路。**指定 `--model` 只选择结构，不会自动下载或加载该模型的预训练权重。**

```powershell
python run_llm.py --model D:/models/Qwen3-0.6B --weights D:/models/Qwen3-0.6B --tokenizer D:/models/Qwen3-0.6B --forward numeric --prompt "你好" --prompt-tokens 32 --max-new-tokens 8 --json llm_numeric.json
python run_llm.py --model qwen3-0.6b --forward shape --prompt-tokens 128 --max-new-tokens 16
python run_llm.py --compare qwen3-0.6b,llama-3.2-1b,gemma-2-2b --forward shape --max-new-tokens 8
python run_llm.py --list-models
```

`--model` 支持内置动物园名、本地 config.json/目录、内联 `json:{...}`，以及有 `huggingface_hub` 时的 HF repo id。主运行可离线；不会默默替换不支持的模型。`--list-models` 无需硬件测量，只展示模型形状及明确标注的默认容量参考，不能代替实测参数下的容量门。

`--forward numeric` 实算数值；`shape` 只走算子形状、访存和计费，不生成有语义的文本；`auto` 按容量/规模选择。两种模式在相同模型、路由与配置下共用账目路径，shape 的速度优势来自跳过宿主矩阵计算。`--weight-cache full/none` 与 Python `kv_shadow` 影响宿主内存和速度，宿主 fp32 影子不计入 Mem Die 容量。

指定真实权重时应显式使用 `--forward numeric`：`auto` 可能为大模型选择 shape，而 shape 即使收到 `--weights` 也不读取权重文件。`--prompt-tokens` 固定输入长度，当前实现对短 prompt 左补 pad、对长 prompt 截断；不是自动采用文本的自然 token 长度。首先用小 prompt/少量生成步验证接入，再增加规模。

### 5.2 还需要哪些模型数据，放在哪里

模型数据与硬件 measured JSON 独立。建议从模型官方发布源获取同一 revision 的完整本地目录，保留模型名称、版本/哈希和 tokenizer 版本。下列路径是**建议准备的位置，当前工程未附带这些文件**：

```text
D:/models/Qwen3-0.6B/
  config.json
  model.safetensors                 # 单文件权重；或下述全部分片
  model-00001-of-0000N.safetensors   # 分片命名以发布内容为准
  model-....safetensors
  model.safetensors.index.json      # 分片发布时一并保留
  vocab.json
  merges.txt
  tokenizer.json
  tokenizer_config.json
  special_tokens_map.json           # 发布包如提供，则保留
  generation_config.json           # 如提供则归档；原生入口不自动应用其全部生成设置
D:/datasets/test.txt                 # 独立的 UTF-8 质量测试文本
```

单文件权重与分片权重二选一；所有分片必须完整。不要将不同模型/版本的权重或 tokenizer 混放。配置/权重可放在其他位置，通过 CLI 指定；不应放入 `calibration/`，该目录保存硬件参数。

| 模型数据 | 需要准备的内容 | 模拟器如何读取 |
|---|---|---|
| 结构配置 | 模型族、层数、hidden、FFN intermediate、attention/KV head 数、head_dim、vocab、位置长度、权重绑定、RoPE/归一化及架构特殊字段；优先提供原始 `config.json` | `--model DIR` 或 `--model DIR/config.json`；已有准确内置预设时 shape 可仅给预设名 |
| 预训练权重 | 与结构一致的 embedding、各层投影/FFN/归一化、final norm、需要时的独立 lm_head 等全部张量 | `run_llm.py --weights DIR` 扫描该目录全部 `*.safetensors`，检查张量名和形状 |
| 原生入口 tokenizer | **`vocab.json` 和 `merges.txt` 必需**，当前实现是 Qwen 字节 BPE；建议保存完整 tokenizer 发布文件 | `run_llm.py --tokenizer DIR`；仅有 `tokenizer.json` 当前不能替代这两个必需文件 |
| PPL tokenizer/模型目录 | Transformers 可离线加载的完整 checkpoint 和 tokenizer 文件，通常包括 `config.json`、全部权重、`tokenizer_config.json`、`tokenizer.json` 或该 tokenizer 的词表/模型文件 | `run_ppl.py --checkpoint DIR`，通过 `AutoModelForCausalLM/AutoTokenizer`、`local_files_only=True` 加载；不另给 `--tokenizer` |
| 推理输入与规模 | prompt 文本、输入 token 数 S、生成 token 数 T、运行次数；正式比较固定这些值 | `--prompt`、`--prompt-tokens`、`--max-new-tokens`、`--n-runs` |
| 质量测试数据 | 独立于训练/校准的 UTF-8 文本，记录来源、版本/哈希、context、stride 和 token 上限 | PPL 的 `--text FILE`、`--context`、`--stride`、`--max-tokens` |

原生权重读取器支持普通浮点 FP32/FP16/BF16 safetensors，并在内部转为 MXFP4 进行模拟；GGUF、GPTQ/AWQ 等预打包量化权重需要额外适配。PPL 入口另可通过 Transformers 读取其支持的 `pytorch_model*.bin`；不能将 PPL 的格式支持等同于原生 `--weights`。

不需要用户提前准备全部中间激活或 KV cache，数值路径在运行时生成，shape 路径由形状推导容量/流量。真实数据依赖的 skip 验证需要真实操作数或专门 trace，不会因为指定模型名称而自动获得。

原生入口的真实 tokenizer 当前只实现 Qwen BPE，不自动使用 Hugging Face chat template 或全部生成策略；其他分词体系需要适配。结构/张量名支持仍需首次接入真实 checkpoint 时复核，当前没有随工程提供的真实 checkpoint 接入验收结果。文件齐全后，仍可能需要处理明确报出的架构/张量差异。

### 5.3 W4A4、混合存储与容量门

MXFP4 每 32 元素含 16 B payload+1 B scale，即平均 0.53125 B/元素。权重与算子边界激活按 MXFP4 往返，KV 在写入时量化。`--no-act-quant` 用于取消激活量化的数值对照；它不是新的 RTL 测量结果。

模型对权重、激活、Q、KV 的 RRAM/FeRAM 摆放分别记账；FeRAM 读写有独立容量/能耗/延迟，不借用 RRAM 的单价。容量门在分配大型数组前检查：聚合容量、各存储池容量、权重+KV+scratch、上下文上限。超容返回 `OVER_CAPACITY` 和限制项。`--max-ctx` 为 prompt+生成总长度。

### 5.4 切块与两种计费口径

算子按 1024 边长切块：`blocks(M,N,K)=ceil(M/1024)×ceil(N/1024)×ceil(K/1024)`。`whole_block` 按块占用乘 `block_pj/block_cycles`，不足一块也按满块计费；`unit` 按有效 MAC×单 MAC 能耗计费，两者同时出现在报告中，`--billing` 只选择主显示口径。

LLM 的基准块当前定义为一次满阵列 GEMV。将其单价用于更大矩阵的 block 账目是一项建模约定，不能当作完整 1024³ GEMM 的测量。K 被调度器逐块调用时，只在最后一个 K 块计 `bk-1` 次跨块累加，避免重复计数。非 MAC 已改为集成 FP32 RTL 的实测算子/长度记录；跨 K 累加及整机调度仍有简化，报告属于使用实测组件数据的架构预测。

### 5.5 架构族、MoE/MLA 与质量验证

架构 spec 支持 Qwen、Llama、Mistral、Gemma、Phi、DeepSeek、OLMoE 等预设及 full/sliding/plain-MHA、gated/plain-MLP 等差异。fused QKV/gate-up 布局和逐层注意力种类会影响块数与流量。未知配置键被记录，必填字段/不完整 MoE 或 MLA 字段会报错。实际支持名单以 `--list-models` 与解析器为准。

MoE/MLA 的参数解析、权重/KV 容量描述已存在，**当前前向仍会明确返回 NOT_IMPLEMENTED/异常**。`--moe-routing` 不是已实现的专家执行器。不能用稠密近似结果冒充 MoE 的真实权重访问；MLA 容量节省也不等于已实现 MLA 运算。RoPE scaling、soft-capping 等数值近似见报告 `approximations`。

正式质量评估使用本地预训练 checkpoint、真实 tokenizer、独立文本集和逐位置 logits 的因果困惑度；随机权重、生成文本和 shape 模式不能替代质量指标：

```powershell
python run_ppl.py --checkpoint D:/models/Qwen3-0.6B --text D:/datasets/test.txt --modes fp32 dense_mxfp4 --context 256 --stride 128 --json ppl.json
```

先显式选择上述两种模式进行质量比较，避免默认模式列表自动加入有限位宽路径。若加入 `finite_mxfp4`，还需实测硬件参数及满足支持范围：

```powershell
python run_ppl.py --checkpoint D:/models/SUPPORTED_SMALL_MODEL --text D:/datasets/test.txt --modes fp32 dense_mxfp4 finite_mxfp4 --parameters calibration/rtl_1017sim/rtl_1017sim_measured.json --context 256 --stride 128 --max-tokens 1024 --json ppl_finite.json
```

`SUPPORTED_SMALL_MODEL` 需替换成实际 checkpoint，要求被包装的 Linear 输入 K 不超过 1024，且架构能由当前 Transformers/适配器加载；这是调用示例，不代表已有对应权重或已通过验收。Qwen3-0.6B 的部分投影 K 超过此范围，不能直接套用该有限位宽命令宣称完整通过。PPL 的 `--modes` 若省略，默认包含 `finite_mxfp4`。

PPL 需要 `torch`、`transformers` 及 checkpoint 依赖。`dense_mxfp4` 量化 Linear 权重/输入后用浮点累加；`finite_mxfp4` 将 Linear 接到有限位宽内核并读取实测硬件参数，也支持 `--parameters PATH`；partial 位宽和 skip 阈值由该文件提供。embedding、非 Linear、KV 等不全部覆盖，报告包含 Linear 覆盖表、活动统计及相对 FP32 的 ΔPPL。finite 路径目前未实现任意大 K 的硬件分块，超过 1024 的投影会被拒绝；不能据此声称全部大模型已通过 RTL 等价的 PPL 验证。

### 5.6 报告与指标

单算子报告包含 skip、有限位宽饱和/误差、有效 MAC、流量/请求响应、事件 trace、容量峰值、能耗分项及输入面积；`--rtl-vectors` 导出数值/控制向量，不等于已经完成 RTL 验收。

LLM 报告包含模型、容量/摆放、块数/MAC、算子/阶段账本、能耗、周期、trace、单价来源、TTFT/decode/e2e 指标。`--json` 输出完整 JSON，`--trace` 输出聚合 op trace。TTFT 包括 prefill+首个 lm_head/采样，decode 为其后步骤，e2e 为两者相加。当前实现使用：

- TTFT token/s = `1/TTFT_s`；decode token/s = `T/decode_s`；e2e token/s = `T/e2e_s`。
- decode/e2e J/token 分别为对应阶段 J 除以生成 token 数 T；首 token 单独给 J。decode 段通常含 T-1 步，但分母沿用 T，这是当前报告定义。
- 历史 `energy.per_token_*` 有按 prompt+生成均摊的字段，不要与 `efficiency.per_token_j` 混用。
- `--cores >1` 仅是乐观摊薄对照，不能代表多核调度；core 数不是 MC 数。输入/计费不变时能量账本不随该对照改变。

吞吐和能效依赖完整实测输入；测试注入的合成价格标为 `TEST_ONLY`，不能发布为硬件结果。Python/CPU 运行的墙钟时间也不是加速器推理延迟。

## 6. 当前模型与 RTL 的边界

单算子的非理想事件模型按 tile/K 组预约 32 个独立 channel 资源，列 c 固定绑定 channel c，可以表达并发和资源等待。它没有逐拍重放 RTL 的每个 128-bit 请求、MC 仲裁和完整背压协议；LLM 入口更进一步使用串行聚合搬运账本，**尚不具备逐 MC、逐 channel 的 32 路 LLM 调度**。仅填 32 MC 参数不会消除这个限制。

`RTL/RTL_1017SIM` 当前实现包含总控、32 MC/PHY 边界、skip/lane mask，以及共享微码 FP32 非 MAC 单元和归约转换路径。RRAM-FP/TAG-FP LUT、真实 scratch/memory/PHY macro、Host 回传及模型级硬件指令流仍有替换/外接边界。缺少这些实现和有效 IP 模型时，单跑 RTL 不能得到全部物理参数。必须补齐实现/独立 IP 表征，保持 PENDING 至数据齐全；不再用模拟器填补未知值。

数值模型仍是可替换行为模型。把新思数据填进 JSON 只完成参数接入，不自动证明格式译码、有限位宽和 RTL 完全等价。需以 golden vectors、逐阶段输出、mask、计数和误差/PPL 另行验收。

## 7. 回归、清理范围与历史资料

```powershell
python tests/run_current.py
python run.py --help
python run_llm.py --help
```

当前回归显式使用 `tests/hardware_fixture.py` 的合成数据，覆盖数值、scale-only 预判、资源/流量、混合存储及参数加载拒绝规则；不要求用户先有新思结果。测试临时 JSON 中的 MEASURED 只是校验器测试，不能复制为生产数据。

已删除 `RTL/RTL_1017SIM/export_calibration.py`、旧 `calibration/rtl_1017_calibration.json`、`calib/llm_calib.json`、运行包内的 `area.py` 和旧 LLM calib 读取器，以及 `ESTIMATE/from_rtl/fallback` 参数生成路径。旧 `area_synth.json` 占位文件已清理；面积、走线、块单价均不再由 Python/Verilog 公式补出。

`RTL_v3/` 是历史数值参考快照；`check_rtl.py` 比较该旧 golden，不验收新的 RTL_1017SIM。`verification/`、`examples/previous_verification/` 及 `docs/` 中标注历史的结果保留用于追溯，禁止作为当前实测输入。`PACKAGE_SOURCE.json` 为原始打包溯源，不是修改后文件的完整性清单。旧 `tests/test_llm.py` 已移至 `tests/reference/legacy_llm_checks.py`，不属于当前回归入口。

RTL 结构与验证见 [RTL_1017SIM 说明](../../Instruction/RTL_1017SIM_instruction.md)，实测参数交付按本文件第 3–4 节执行，模拟器操作流程见 [simulator 操作说明](../../Instruction/simulator_1017SIM_instruction.md)。
> **当前入口更新：Python 3.4，主机/DMA 开销已移除，非 MAC 按 1024 路并行估算。** 详见 [本次说明](docs/主机DMA移除与1024路非MAC估算_20261019.md)。非 MAC 单实例参数填写 `calibration/rtl_1017sim/nonmac_parallel_1024.json`；尚未提供的成本保持 `null`。下文涉及 `--with-host-io`、DMA 容量预留和旧串行非 MAC 的说明属于历史口径。
