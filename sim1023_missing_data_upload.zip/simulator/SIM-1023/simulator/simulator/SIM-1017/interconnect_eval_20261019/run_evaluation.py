"""Reproduce SIM-1017 wire calibration and finite BookSim mesh experiments.

Run from any directory: python run_evaluation.py
No Desktop files are changed. Raw configs, traces, packet arrivals and logs survive.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
import numpy as np

BASE_CONFIG = """topology = mesh;
k = {k};
n = 2;
routing_function = dor;
router = iq;
num_vcs = 4;
vc_buf_size = 4;
vc_allocator = islip;
sw_allocator = islip;
alloc_iters = 1;
credit_delay = 1;
routing_delay = 1;
vc_alloc_delay = 1;
sw_alloc_delay = 1;
st_final_delay = 1;
input_speedup = 1;
output_speedup = 1;
internal_speedup = 1.0;
traffic = uniform;
sim_type = trace;
sim_count = 1;
include_queuing = 1;
seed = 1;
sim_power = 1;
channel_width = {width};
evaluation_clock_ns = 1.0;
tech_file = {tech};
trace_file = {trace};
trace_output = {arrivals};
"""


def write_json(p, data):
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def run_case(name, rows, *, k, width, length):
    folder = HERE / "raw" / name
    folder.mkdir(parents=True, exist_ok=True)
    tech = (HERE / "techfile_28nm_original.txt").read_text(encoding="utf-8")
    tech = re.sub(r"wire_length\s*=\s*[^;]+;", f"wire_length = {length:.12f};", tech)
    (folder / "tech.txt").write_text(tech, encoding="utf-8")
    (folder / "traffic.trace").write_text(
        "# ready_cycle source destination flits\n" +
        "".join(" ".join(map(str, row))+"\n" for row in rows), encoding="utf-8")
    cfg = BASE_CONFIG.format(k=k, width=width, tech="tech.txt", trace="traffic.trace", arrivals="arrivals.csv")
    (folder / "network.cfg").write_text(cfg, encoding="utf-8")
    exe = HERE / "booksim" / "src" / "booksim.exe"
    if not exe.exists():
        exe = exe.with_suffix("")
    env = os.environ.copy()
    env["PATH"] = r"C:\msys64\ucrt64\bin" + os.pathsep + env.get("PATH", "")
    started = time.perf_counter()
    command = [str(exe), "network.cfg"]
    p = subprocess.run(command, cwd=folder, env=env, capture_output=True, timeout=180)
    log = p.stdout.decode("utf-8", errors="replace") + p.stderr.decode("utf-8", errors="replace")
    (folder / "booksim.log").write_text(log, encoding="utf-8")
    write_json(folder / "command.json", {"command": command, "cwd": str(folder),
        "returncode": p.returncode, "wall_seconds": time.perf_counter()-started})
    done = re.search(r"TRACE_COMPLETE (\d+) (\d+) (\d+)", log)
    if not done or int(done[1]) != len(rows) or int(done[2]) != len(rows):
        raise RuntimeError(f"incomplete BookSim trace: {name}; see {folder / 'booksim.log'}")
    if "K = -1" in log or "M = -1" in log or "unstable" in log.lower():
        raise RuntimeError(f"invalid wire solution/network run: {name}")
    packets = list(csv.DictReader((folder / "arrivals.csv").open(encoding="utf-8")))
    assert len(packets) == len(rows)
    power = {}
    for label, value in re.findall(r"^- ([A-Za-z ]+Power):\s+([\d.eE+\-]+)", log, re.M):
        power[label.strip()] = float(value)
    frequency = float(re.search(r"POWER_CLOCK_HZ ([\d.eE+\-]+)", log)[1])
    cycles = int(done[3])
    power_cycles = float(re.search(r"Completion Time:\s+([\d.eE+\-]+)", log)[1])
    energy = {name.replace("Power", "energy_pj"): val*power_cycles/frequency*1e12
              for name, val in power.items()}
    result = {"name": name, "packets": len(rows), "flits": sum(r[3] for r in rows),
        "cycles_including_final_credit_drain": power_cycles,
        "all_packets_delivered_cycles": cycles, "clock_ns": 1.0,
        "power_model_frequency_hz": frequency, "link_width_bits": width,
        "link_length_mm": length, "energy_pj": energy,
        "total_area_mm2": float(re.search(r"Total Area:\s+([\d.eE+\-]+)", log)[1]),
        "packet_latency_mean_cycles": float(np.mean([int(r['tail_arrival_cycle'])-int(r['ready_cycle']) for r in packets])),
        "packet_latency_max_cycles": max(int(r['tail_arrival_cycle'])-int(r['ready_cycle']) for r in packets),
        "source_queue_mean_cycles": float(np.mean([int(r['head_injection_cycle'])-int(r['ready_cycle']) for r in packets])),
        "raw_directory": str(folder.relative_to(HERE)), "returncode": p.returncode,
        "wire_calibration": [list(map(float, m.split())) for m in re.findall(r"^WIRE_CALIBRATION (.+)$", log, re.M)]}
    assert all(math.isfinite(v) and v >= 0 for v in energy.values())
    write_json(folder / "parsed.json", result)
    print(f"{name}: {cycles} cycles, {energy.get('Total energy_pj', float('nan'))/1000:.3f} nJ", flush=True)
    return result


def mesh_rows(compute_mask, width, stage):
    """32x32 mesh, node=r*32+c; local Tile/root data do not enter mesh."""
    rows = []
    for r in range(32):
        for c in range(32):
            active = int(compute_mask[r*32:(r+1)*32, c].sum())
            if not active:
                continue
            if stage == "broadcast" and r != 0:
                # Explicit source replication, not multicast support in routers.
                rows.append((0, c, r*32+c, math.ceil((136+8+32)/width)))
            if stage == "gather" and c != 0:
                # 32-bit container per active PE; 32-bit packet routing header.
                rows.append((0, r*32+c, r*32, math.ceil((active*32+32)/width)))
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--wire-only", action="store_true")
    args = ap.parse_args()
    results = []
    wire_rows = {}
    for pitch in (0.4, 0.5, 0.7):
        for level in range(5):
            length = pitch*2**level/2
            name = f"wire_{length:g}mm"
            result = run_case(name, [(0, 0, 1, 2)], k=2, width=128, length=length)
            results.append(result)
            row = result["wire_calibration"][0]
            assert abs(row[0]-length) < 1e-9 and min(row[1:4]) > 0
            wire_rows[f"{length:.8f}"] = dict(length_mm=row[0], repeater_size=row[1],
                retiming_stages=int(row[2]), repeater_segments=int(row[3]),
                wire_pj_per_bit_transfer=row[4], retiming_pj_per_bit_transfer=row[5],
                leakage_w_per_bit=row[6], gated_clock_pj_per_bit_transfer=row[7])
    calibration = dict(schema="sim-1017-interconnect/v1", status="TECHNOLOGY_DERIVED_ASSUMPTIONS",
        topology="dedicated_binary_trees", clock_ns=1.0, physical_rows=32, physical_cols=32,
        tile_pitch_mm=0.4, broadcast_bits=144, partial_bits=32,
        broadcast_issue_cycles=1, reduction_issue_cycles=1,
        source="BookSim repeated-wire/retiming equations + 3D-CIMlet projected 28nm techfile; not PDK/RTL measurement",
        clock_gating="per-link transfer gating assumed; no free-running whole-network clock charge",
        partial_format="20-bit accumulator + 10-bit expanded exponent + 2 validity/control bits; assumed transport container",
        bank_placement="one bank/tree root at midpoint of each Tile column; source/root lead and endpoint wiring excluded",
        limitations=["floorplan/pitch unmeasured", "II=1 assumes fully pipelined links and reduction arithmetic; not RTL-verified",
                    "projected technology parameters, not foundry extraction",
                    "fanout pin loading/branch logic/local endpoint wires not characterized",
                    "dedicated trees analytical, not BookSim router/multicast simulation",
                    "MX metadata/control distribution and FP32 output collection not included"],
        wires=wire_rows)
    write_json(HERE / "dedicated_network_parameters.json", calibration)
    if not args.wire_only:
        dense = np.ones((1024, 32), bool)
        half = dense.copy(); half[:, 16:] = False
        for width in (64, 128, 256):
            for stage in ("broadcast", "gather"):
                results.append(run_case(f"mesh_{stage}_{width}", mesh_rows(dense, width, stage),
                                        k=32, width=width, length=0.4))
        for stage in ("broadcast", "gather"):
            results.append(run_case(f"mesh_half_columns_{stage}_128", mesh_rows(half, 128, stage),
                                    k=32, width=128, length=0.4))
    write_json(HERE / "booksim_results.json", results)
    write_json(HERE / "execution_manifest.json", dict(
        python=sys.version, numpy=np.__version__, no_traffic_scaling=True,
        executable_sha256=hashlib.sha256((HERE/'booksim'/'src'/'booksim.exe').read_bytes()).hexdigest(),
        technology_sha256=hashlib.sha256((HERE/'techfile_28nm_original.txt').read_bytes()).hexdigest(),
        packet_header_bits=32, mesh_is_alternative=True,
        note="Mesh gather is centralized communication only; no arithmetic or in-network reduction. Stages run separately; no whole-accelerator timing claim."))


if __name__ == "__main__":
    main()
