# SIM-1017 广播与互连评估

先读 [完整中文说明](../docs/并行广播与互连评估_20261019.md)。

当前推荐：32 列并行硬件广播树。默认首份延迟 5 cycles、连续注入间隔 1 cycle，均为明确架构假设，等待物理实现验证。线路能量来自实际运行 BookSim 的线模型与 3D-CIMlet 投影 28 nm 技术参数。与之分开的通用 mesh 对照保留 router/VC/credit/仲裁/争用。

从 Python 根目录执行：

```powershell
python run.py --no-softmax --interconnect-parameters interconnect_eval_20261019/dedicated_network_parameters.json --json interconnect_eval_20261019/my_result.json
```

重新准备、编译、运行本目录实验：

```powershell
python prepare_booksim.py
python build_booksim.py
python run_evaluation.py
python verify_and_summarize.py
```

Windows 已有工具链：`C:/msys64/ucrt64/bin` 与 `C:/msys64/usr/bin`。生成的配置/trace/日志在 `raw/`，不向 Desktop 原始工具目录写入。BookSim 许可在 [booksim/LICENSE.md](booksim/LICENSE.md)，改动和新增适配器分别在 `booksim_adapter.diff` 与 `adapter/`。

`booksim_results.json` 保存实际运行结果；`dedicated_network_parameters.json` 可直接接入 Python；`dedicated_sensitivity.json` 是布局和 skip 分布敏感性；`verification.json` 是功能一致性与原版对照。源代码和二进制哈希分别记录在 `source_manifest.json` 和 `execution_manifest.json`。

注意原版 BookSim 成功时返回 -1，Windows 显示 `4294967295`。脚本检查 `TRACE_COMPLETE`、生成/退役包数、逐包 CSV 与有效线模型解，不以“返回码为 0”作为成功条件。mesh 能量覆盖全 router 网络，专用树表中的数值为动态线路能量，比较时要保持统计范围一致。
