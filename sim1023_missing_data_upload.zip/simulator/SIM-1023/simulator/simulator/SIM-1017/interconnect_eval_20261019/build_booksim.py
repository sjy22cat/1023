"""Build the workspace copy on Windows using the existing MSYS2 toolchain."""
from pathlib import Path
import os
import subprocess

HERE = Path(__file__).resolve().parent

if __name__ == "__main__":
    env = os.environ.copy()
    env["PATH"] = r"C:\msys64\ucrt64\bin;C:\msys64\usr\bin;"+env.get("PATH", "")
    command = [r"C:\msys64\usr\bin\make.exe", "-j4", "CXX=g++", "CC=gcc",
               "CPPFLAGS=-O2 -I. -Iarbiters -Iallocators -Irouters -Inetworks -Ipower", "booksim"]
    with (HERE/"build.log").open("w",encoding="utf-8") as log:
        p = subprocess.run(command,cwd=HERE/"booksim"/"src",env=env,stdout=log,stderr=subprocess.STDOUT)
    print("BookSim build return code:",p.returncode)
    raise SystemExit(p.returncode)
