"""Copy the inspected BookSim into this workspace and apply a small trace adapter.

Upstream routers, arbitration, credits, routing and activity counters stay intact.
The patch adds finite trace injection and prints wire-model calibration values.
"""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
SOURCE = Path(r"C:\Users\China\Desktop\DAC25-3D\inspection")


def main():
    src = SOURCE / "booksim2" / "src"
    dst = HERE / "booksim" / "src"
    shutil.copytree(src, dst, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("*.o", "*.d", "booksim.exe", "booksim"))
    shutil.copy2(SOURCE / "booksim2" / "LICENSE.md", dst.parent / "LICENSE.md")
    patch = []

    def edit(name, replacements):
        p = dst / name
        old = p.read_text(encoding="utf-8")
        new = old
        for a, b in replacements:
            assert new.count(a) == 1, (name, a)
            new = new.replace(a, b)
        p.write_text(new, encoding="utf-8")
        patch.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                          fromfile="upstream/"+name, tofile="adapted/"+name))

    edit("booksim_config.cpp", [('_int_map["batch_size"] = 1000;',
         '_str_map["trace_file"] = "";\n  _str_map["trace_output"] = "";\n'
         '  _float_map["evaluation_clock_ns"] = 0.0;\n  _int_map["batch_size"] = 1000;')])
    edit("trafficmanager.hpp", [('void _GeneratePacket( int source, int size, int cl, int time );',
         'virtual void _GeneratePacket( int source, int size, int cl, int time, int dest_override = -1, int size_override = 0 );')])
    edit("trafficmanager.cpp", [('#include "batchtrafficmanager.hpp"',
         '#include "batchtrafficmanager.hpp"\n#include "tracetrafficmanager.hpp"'),
         ('} else if(sim_type == "batch") {',
          '} else if(sim_type == "trace") {\n        result = new TraceTrafficManager(config, net);\n    } else if(sim_type == "batch") {'),
         ('int cl, int time )\n{\n    assert(stype!=0);',
          'int cl, int time, int dest_override, int size_override )\n{\n    assert(stype!=0);'),
         ('int size = _GetNextPacketSize(cl); //input size',
          'int size = size_override > 0 ? size_override : _GetNextPacketSize(cl);'),
         ('int packet_destination = _traffic_pattern[cl]->dest(source);',
          'int packet_destination = dest_override >= 0 ? dest_override : _traffic_pattern[cl]->dest(source);')])
    edit("power/power_module.cpp", [('fCLK   = 1.0 / tCLK;',
         'if(config.GetFloat("evaluation_clock_ns") > 0.0) tCLK = config.GetFloat("evaluation_clock_ns") * 1e-9;\n'
         '  fCLK   = 1.0 / tCLK;'),
         ('wire_map.insert(make_pair(L, temp)).first;',
          'wire_map.insert(make_pair(L, temp)).first;\n'
          '    cout.precision(15);\n'
          '    cout << "WIRE_CALIBRATION " << L << " " << bestK << " " << bestM << " " << bestN\n'
          '         << " " << powerRepeatedWire(L,bestK,bestM,bestN)/fCLK*1e12\n'
          '         << " " << powerWireDFF(bestM,1,1)/fCLK*1e12\n'
          '         << " " << powerRepeatedWireLeak(bestK,bestM,bestN)\n'
          '         << " " << powerWireClk(bestM,1)/fCLK*1e12 << endl;'),
         ('totalTime = GetSimTime();',
          'totalTime = GetSimTime();\n  cout.precision(15);\n  cout << "POWER_CLOCK_HZ " << fCLK << endl;')])
    for name in ("tracetrafficmanager.hpp", "tracetrafficmanager.cpp"):
        shutil.copy2(HERE / "adapter" / name, dst / name)
    (HERE / "booksim_adapter.diff").write_text("".join(patch), encoding="utf-8")
    manifest = {"booksim_commit": "28f43299f1706a3160ffac721ca461d74eb6e618",
                "cimlet_commit": "2114e08bfc920835d7523710329424a92426bddd",
                "upstream_source": str(src), "desktop_source_modified": False,
                "changes": "finite deterministic trace injection; explicit power clock; wire calibration logging",
                "source_sha256": {str(p.relative_to(dst)): hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in dst.rglob("*") if p.is_file() and p.suffix in (".cpp", ".hpp", ".c", ".h")}}
    (HERE / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
