# Candidate Evidence Scan

> This automated scan finds leads for manual inspection. It does not assign simulator fidelity levels and must not be cited as proof.

- Repository: `F:\AID\MXFP4\仿真器\SIM-1017\SIM-1017-2\simulator\simulator\SIM-1017\yrr_v3`
- Scanned text files: 37
- Per-file size limit: 2 MiB
- Scan time (UTC): 2026-10-19T13:09:27.191898+00:00

## Interpretation Warnings

- Matches are candidate evidence only. Comments and documentation may describe a missing feature, and declarations may be unused; trace the executed call path before assigning A/M/I/C/S/E/V levels.
- Both communication and queue/contention signals were found. This is only a lead for I3: verify that link/router/switch state is executed and affects reported time.
- Composition/overlap signals were found. Inspect every sum/max/pipeline for dependencies, finite buffers, startup/drain, shared-resource occupancy, and mutable-state idempotence.

## Signal Summary

| Signal class | Matching lines |
|---|---:|
| Simulation style | 37 |
| Compute model | 70 |
| Memory model | 7 |
| Interconnect/communication | 9 |
| Queues/arbitration/contention | 7 |
| Host CPU/runtime timing | 7 |
| Accelerator/internal scheduling | 5 |
| Energy/area | 88 |
| Zero/placeholder energy | 0 |
| Validation/calibration | 21 |
| Composition/overlap/mutable state | 174 |
| Host tool parallelism | 0 |

## Candidate Evidence

### Simulation style

- `architecture.py:49` — `if cfg.latency_source in ("rtl", "measured") and not measured and ds.structure is None:`
- `architecture.py:431` — `category = "measured" if detail.startswith("measured:") else "technology-derived" if detail.startswith(("derived:", "rtl:")) else "user-supplied" if detail.startswith("user-supplied") else "placeholder/assumption"`
- `behavior.py:1` — `"""Executed V3 numerical path. No device/RTL calibration is implied."""`
- `behavior.py:16` — `"""Replace these callables with server RTL-derived behavior when available.`
- `behavior.py:25` — `name: str = "workbook-reference behavior (replaceable; no RTL implementation)"`
- `behavior.py:270` — `"rtl_equivalence": "pending server RTL vectors; existing RTL arithmetic differs"}`
- `config.py:77` — `latency_source: Literal["auto", "config", "rtl", "measured"] = "auto"`
- `config.py:112` — `# must be supplied by the RTL contract; None leaves MX gating inactive`
- _Showing 8 of 37 matching lines; raise `--max-evidence` if needed._

### Compute model

- `architecture.py:59` — `"compute_cycles": int(cfg.pe_mul_cycles + cfg.pe_acc_cycles), "compute_cycles_source": origin,`
- `architecture.py:91` — `# Non-MAC local workspace is separate from Global SRAM I/O buffers.`
- `architecture.py:208` — `# A shared non-MAC vector engine conservatively completes one command`
- `architecture.py:302` — `timing["compute_cycles"] if active_each[v] else 0,`
- `architecture.py:323` — `ev = sched.reserve("FP32 non-MAC", "reduce_to_fp32_scratch", ev.end_cycle,`
- `architecture.py:326` — `ev = sched.reserve("FP32 non-MAC", "stable_softmax", ev.end_cycle, soft_cost.cycles,`
- `architecture.py:356` — `logits_reads = 0 # non-MAC scratch traffic is included in measured command profiles`
- `architecture.py:444` — `"array_mac": timing["compute_cycles"],`
- _Showing 8 of 70 matching lines; raise `--max-evidence` if needed._

### Memory model

- `architecture.py:220` — `metadata={"vector_id": v, "input_buffer": ib,`
- `architecture.py:244` — `"input_buffer": ib, "active_banks": min(lanes, source_counts[v])})`
- `architecture.py:479` — `"bank_conflict_stall_cycles": 0,`
- `architecture.py:482` — `"bank_mapping": "K block modulo bank count, conflict-free issue groups; reduced banks require extra prefetch cycles"},`
- `architecture.py:496` — `"broadcast_replication_bytes": recv*17, "tile_input_buffer_write_bytes": ceil(regbits/8),`
- `architecture.py:548` — `"input_buffer_demand_bytes": inbytes*micro*input_copies,`
- `architecture.py:550` — `"softmax_output_buffer_bytes": softbytes*micro*log_copies,`

### Interconnect/communication

- `architecture.py:3` — `This is an architectural event model, not a router-level NoC or a timing CPU.`
- `architecture.py:380` — `"partial_interconnect_pj": price(partial_bits,e.partial_link_pj_per_bit),`
- `architecture.py:531` — `"scheduling": "integer shared-resource reservations, buffer ownership, microbatch barriers; no router-level NoC"},`
- `architecture.py:534` — `"uncharacterized": ["RRAM array latency", "broadcast/interconnect latency"]+`
- `characterization.py:58` — `"broadcast/interconnect", "leakage", "softmax/non-MAC characterization",`
- `characterization.py:130` — `excluded=["PHY replication (topology not supplied)", "RRAM/FeRAM arrays", "softmax", "global routing/control"],`
- `llm/arch/families.py:28` — `"approximations": ("未注入专家路由直方图时按**均匀**路由计（见 routing.py）",),`
- `llm/arch/names.py:139` — `if rest == "router":`
- _Showing 8 of 9 matching lines; raise `--max-evidence` if needed._

### Queues/arbitration/contention

- `architecture.py:123` — `queue_free = [0]*cfg.mem_die_queue_depth`
- `architecture.py:633` — `("mem_die_latency","mem_die_channels","mem_die_bytes_per_cycle","mem_die_queue_depth","ideal_mem_die")}`
- `config.py:81` — `mem_die_queue_depth: int = 32`
- `config.py:161` — `"mem_die_channels", "mem_die_bytes_per_cycle", "mem_die_queue_depth",`
- `llm/core.py:122` — `# 腾地方（FIFO；本模型里一个块就占满，所以等价于整块换出）`
- `llm/provenance.py:41` — `names, tool = _THROUGHPUT_NAMES, "VCS/PrimeTime/PHY or memory IP timing characterization"`
- `llm/provenance.py:43` — `names, tool = _ENERGY_NAMES + (("block_pj",) if billing == "whole_block" else ()), "PrimeTime PX with VCS SAIF and memory/PHY macro power models"`

### Host CPU/runtime timing

- `architecture.py:3` — `This is an architectural event model, not a router-level NoC or a timing CPU.`
- `rtl_dataset.py:25` — `"dma_latency": "host_dma_setup_cycles", "mx_control_cycles": "mx_control_cycles",`
- `rtl_dataset.py:78` — `data["timing"].setdefault("host_dma_setup_cycles", 0)`
- `rtl_dataset.py:85` — `if key == "host_dma_setup_cycles":`
- `llm/core.py:247` — `"""Record host preloading before inference; host latency is excluded."""`
- `llm/inference.py:698` — `"full_system_metrics_complete":False,`
- `llm/memdie.py:385` — `"host_latency_excluded": True,`

### Accelerator/internal scheduling

- `architecture.py:279` — `mc_next_issue[wave_ids] = max(int(start)+cfg.mc_issue_cycles,mc_ev.end_cycle)`
- `architecture.py:607` — `"mc_read_cycles":cfg.mc_read_cycles,"mc_initiation_interval":cfg.mc_issue_cycles,`
- `characterization.py:85` — `mc_read_cycles=ceil(r["mc"]["latency_ns"]), mc_issue_cycles=ceil(r["mc"]["latency_ns"]),`
- `config.py:69` — `mc_issue_cycles: int = 2`
- `config.py:163` — `"mc_read_cycles", "mc_issue_cycles"):`

### Energy/area

- `architecture.py:1` — `"""Resource-reservation timing, traffic, capacity and disjoint energy accounting.`
- `architecture.py:362` — `e = ds.energy`
- `architecture.py:414` — `# do not assume wire/MC energy scales with enabled RRAM columns.`
- `architecture.py:419` — `energy = {**dynamic, "components_pj": dynamic,`
- `architecture.py:423` — `energy["total_pj"] = None if missing_energy or energy["leakage_pj"] is None else known_dynamic+energy["leakage_pj"]`
- `architecture.py:424` — `energy.update(batch=cfg.batch, vectors=nv, total_pj_per_vector=None if energy["total_pj"] is None else energy["total_pj"]/nv,`
- `architecture.py:425` — `pj_per_mac_total=None if energy["total_pj"] is None else energy["total_pj"]/(cfg.m*cfg.k*nv), leakage_busy_cycles=total)`
- `architecture.py:458` — `"scratch_bytes": workspace, "numeric_reference":"Python functional reference, not timing/power"},`
- _Showing 8 of 88 matching lines; raise `--max-evidence` if needed._

### Zero/placeholder energy

No candidate matches in scanned files.

### Validation/calibration

- `architecture.py:363` — `e.validate(allow_missing=bool(ds.components))`
- `architecture.py:536` — `"interpretation":"configured architectural schedule; partial module latencies, not validated end-to-end silicon timing" if ds.components else "configured architectural schedule",`
- `behavior.py:93` — `cfg.validate(allow_partial_energy=bool(ds.components))`
- `config.py:39` — `def validate(self, *, allow_missing=False):`
- `config.py:157` — `def validate(self, *, allow_partial_energy=False):`
- `config.py:202` — `self.energy.validate(allow_missing=allow_partial_energy)`
- `report.py:47` — `"Hardware inputs: Synopsys measured JSON; results use the architectural scheduler. RTL numerical equivalence requires golden-vector validation." if r["dataset"]["parameter_status"] == "MEASURED" else "Synthetic test inputs; no hardware per…`
- `rtl_dataset.py:120` — `cfg.validate()`
- _Showing 8 of 21 matching lines; raise `--max-evidence` if needed._

### Composition/overlap/mutable state

- `architecture.py:79` — `src, recv = sum(source_counts), sum(receiver_counts)`
- `architecture.py:93` — `input_copies = 2 if cfg.input_double_buffer else 1`
- `architecture.py:94` — `log_copies = 2 if cfg.logits_double_buffer else 1`
- `architecture.py:110` — `runtime_read_words = sum(p.read_words for p in read_plans) if per_pe_rram else 0`
- `architecture.py:111` — `runtime_read_bits = sum(p.physical_read_bits for p in read_plans) if per_pe_rram else 0`
- `architecture.py:112` — `runtime_skip_words = sum(p.skipped_words for p in read_plans) if per_pe_rram else 0`
- `architecture.py:136` — `qr = ready if cfg.ideal_mem_die else max(ready, queue_free[qi])`
- `architecture.py:162` — `done = max(done, ev.end_cycle)`
- _Showing 8 of 174 matching lines; raise `--max-evidence` if needed._

### Host tool parallelism

No candidate matches in scanned files.

## Required Manual Follow-up

1. Start at the reported latency/energy writer and trace each matched parameter into the executed equations or event loop.
2. Classify A/M/I/C/S/E/V independently; use `unknown` when the executed path is unclear.
3. Separate offline DSE, accelerator scheduling, serving policy, and host CPU execution.
4. Test repeated-evaluation idempotence and worker-count invariance.
5. Check split-K/channel/tensor-parallel reductions and all shared-resource overlap assumptions.
6. Align validation ground truth with the exact prediction unit before accepting end-to-end claims.
