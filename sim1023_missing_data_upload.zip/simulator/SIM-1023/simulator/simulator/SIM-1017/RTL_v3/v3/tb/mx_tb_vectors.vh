//=============================================================================
//  mx_tb_vectors.vh  —— 确定性 MXFP4 激励与实数参考模型
//  ---------------------------------------------------------------------------
//  【无 include guard】——需在 tb 的 module 内部 `include。
//  与 simulator/V3/check_rtl.py 用**同一组哈希**，两侧生成完全相同的向量，
//  因此 RTL 的黄金转储可以直接与 Python 的 run_v3 逐项比对。
//=============================================================================

    // ---- 确定性哈希（与 check_rtl.py 对齐）----
    function [3:0] mx_wcode;                  // 权重 FP4 码
        input integer t;                      // tile 号
        input integer p;                      // tile 内 PE 号
        input integer k;                      // k 下标
        integer x;
        begin
            x = ((t * 1103515245) + (p * 12345) + (k * 7919) + 2531011) & 32'h7FFFFFFF;
            x = ((x >> 16) ^ x) & 32'h7FFFFFFF;
            mx_wcode = x[3:0];
        end
    endfunction

    function [3:0] mx_xcode;                  // 输入 FP4 码
        input integer c;                      // k 段号（tile_col）
        input integer k;
        integer x;
        begin
            x = ((c * 22695477) + (k * 104729) + 1013904223) & 32'h7FFFFFFF;
            x = ((x >> 13) ^ x) & 32'h7FFFFFFF;
            mx_xcode = x[3:0];
        end
    endfunction

    // 权重尺度只取决于 (tile_row, pe)：V3 的 E8M0 是"每 32 元素一个"，
    // 同一输出行的整行共用一个尺度，故不能按 tile_col 变化。
    function [`MX_SCALE_W-1:0] mx_wscale;
        input integer tr;                     // tile_row
        input integer p;                      // tile 内 PE 号
        integer x;
        begin
            x = ((tr * 69069) + (p * 362437) + 7) & 32'h7FFFFFFF;
            x = ((x >> 11) ^ x) & 32'h7FFFFFFF;
            mx_wscale = 127 + (x % 5) - 2;
        end
    endfunction

    // 输入尺度恒定（V3 在 k<=32 时整行共用一组尺度）
    function [`MX_SCALE_W-1:0] mx_xscale;
        input integer c;
        begin
            mx_xscale = 127;
        end
    endfunction