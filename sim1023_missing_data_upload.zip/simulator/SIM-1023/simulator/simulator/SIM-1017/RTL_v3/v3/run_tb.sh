#!/bin/sh
#=============================================================================
#  run_tb.sh —— V3 架构 RTL 仿真脚本（iverilog + vvp）
#  用法：sh run_tb.sh [tb_name]        默认 tb_yrr_v3
#  环境变量：
#    MX_DEFS    追加编译宏，例如 MX_DEFS="-DMX_SIM_INIT -DMX_GOLDEN"
#    IVERILOG / VVP   工具链路径覆盖
#
#  生成与 Python 交叉验证的黄金数据：
#    MX_DEFS="-DMX_SIM_INIT -DMX_GOLDEN" sh run_tb.sh tb_yrr_v3
#    -> 写出当前目录下的 golden_v3.txt
#       （**不会**触碰 RTL/RTL/golden_rtl.txt）
#=============================================================================
set -e

cd "$(dirname "$0")"

# 工具链：优先环境变量，其次探测两处常见安装路径
if [ -z "$IVERILOG" ]; then
    for c in /d/VSCODE/iverilog/iverilog/bin/iverilog /d/iverilog/iverilog/bin/iverilog iverilog; do
        if command -v "$c" >/dev/null 2>&1; then IVERILOG="$c"; break; fi
    done
fi
if [ -z "$VVP" ]; then
    for c in /d/VSCODE/iverilog/iverilog/bin/vvp /d/iverilog/iverilog/bin/vvp vvp; do
        if command -v "$c" >/dev/null 2>&1; then VVP="$c"; break; fi
    done
fi

TB=${1:-tb_yrr_v3}
DEFS=${MX_DEFS:--DMX_SIM_INIT}
OUT=sim/${TB}.vvp
mkdir -p sim

echo "==> 编译 ${TB}   (defines: ${DEFS})"
"$IVERILOG" -g2005 -Wall \
    ${DEFS} \
    -I rtl -I tb \
    -o "$OUT" \
    tb/${TB}.v \
    rtl/*.v

echo "==> 运行 ${TB}"
"$VVP" "$OUT"