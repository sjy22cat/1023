//=============================================================================
//  mx_fmt_funcs.vh  —— MXFP4 数值函数（实数参考模型 + 打包）
//  ---------------------------------------------------------------------------
//  【本文件不含 include guard】——Verilog-2001 的 function 必须定义在 module
//  作用域内，故在每个使用它的 module 内部 `include。文件顶部需先：
//      `include "mx_fmt_defs.vh"
//
//  与 simulator/V3/yrr_v3/formats.py 的 FP4_VALUES / decode_fp4 / stable_softmax
//  逐条对齐；供测试平台与调试使用，不进入综合数据通路。
//=============================================================================

    // 4bit 载荷 -> 码值×2 的**有符号整数**（-12..12）
    function signed [`MX_FP4_INT_W-1:0] mx_fp4_int;
        input [`MX_FP4_W-1:0] c;
        reg [3:0] mag;
        begin
            case (c[2:0])
                3'd0: mag = 4'd0;
                3'd1: mag = 4'd1;
                3'd2: mag = 4'd2;
                3'd3: mag = 4'd3;
                3'd4: mag = 4'd4;
                3'd5: mag = 4'd6;
                3'd6: mag = 4'd8;
                default: mag = 4'd12;
            endcase
            mx_fp4_int = c[3] ? -$signed({1'b0, mag}) : $signed({1'b0, mag});
        end
    endfunction

    // 2 的整数次幂（exp 为有符号）
    function real ldexp2;
        input real base;
        input integer n;
        real r;
        integer i;
        begin
            r = base;
            if (n >= 0) for (i = 0; i < n; i = i + 1) r = r * 2.0;
            else        for (i = 0; i < -n; i = i + 1) r = r / 2.0;
            ldexp2 = r;
        end
    endfunction

    // FP4 载荷 + E8M0 尺度 -> 实数值（= formats.decode_fp4 的单元素版）
    function real mx_fp4_real;
        input [`MX_FP4_W-1:0]   c;
        input [`MX_SCALE_W-1:0] s;
        begin
            mx_fp4_real = ($itor(mx_fp4_int(c)) / 2.0)
                          * ldexp2(1.0, $signed({1'b0, s}) - `MX_E8M0_BIAS);
        end
    endfunction

    // 定点（有符号尾数 m，指数 e：值 = m * 2^e）-> 实数
    function real mx_fixed_real;
        input signed [63:0] m;
        input integer       e;
        begin
            mx_fixed_real = $itor(m) * ldexp2(1.0, e);
        end
    endfunction

    // FP32 位模式 -> 实数（测试平台参考用）
    function real fp32_to_real;
        input [31:0] f;
        integer e;
        real m, r;
        begin
            e = f[30:23];
            if (e == 0) begin
                r = 0.0;
            end else begin
                m = 1.0 + $itor(f[22:0]) / 8388608.0;
                r = m * ldexp2(1.0, e - 127);
                if (f[31]) r = -r;
            end
            fp32_to_real = r;
        end
    endfunction

    // 实数 -> FP32 位模式（就近取整；仅测试平台用）
    function [31:0] real_to_fp32;
        input real v;
        real a, frac;
        integer e, ei, ifrac;
        reg [22:0] mant;
        reg [7:0]  expo;
        reg sign;
        begin
            sign = (v < 0.0);
            a = (v < 0.0) ? -v : v;
            if (a == 0.0) begin
                real_to_fp32 = 32'h0000_0000;
            end else begin
                e = 0;
                while (a >= 2.0) begin a = a / 2.0; e = e + 1; end
                while (a <  1.0) begin a = a * 2.0; e = e - 1; end
                frac = (a - 1.0) * 8388608.0;
                ifrac = $rtoi(frac);
                mant = ifrac[22:0];
                if ((frac - $itor(ifrac)) >= 0.5) mant = mant + 1'b1;
                ei = e + 127;
                expo = ei[7:0];
                real_to_fp32 = {sign, expo, mant};
            end
        end
    endfunction