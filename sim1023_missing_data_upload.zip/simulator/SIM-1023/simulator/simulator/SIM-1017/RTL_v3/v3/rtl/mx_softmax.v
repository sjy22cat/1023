`timescale 1ns/1ps

//=============================================================================
//  mx_softmax.v  —— 多 lane softmax（对应 V3 的 SoftmaxPacket / stable_softmax）
//  ---------------------------------------------------------------------------
//  **单遍 + max 外置 + 归一化下沉**（旧版是三遍扫描，每遍 ceil(M/SOF_LANES) 拍）
//
//  旧结构的问题：max / exp+sum / 归一化三遍**首尾相接**，没有任何重叠，
//  于是 softmax 吃掉整条流水 90% 的拍数。现在拆成三件事，各归其位：
//
//    (1) 求 max        -> **外置**：mx_reduce 里已有一条与加法树同深的组合 max 树
//                         （同一批叶子、同一对齐口径），深度不变、**不增加拍数**。
//                         故本模块删掉整个 S_MAX 段，max 由 `i_max` 直接喂进来。
//    (2) exp + 求和    -> 本模块**唯一**的工作段，块间无依赖，天然可流水：1 块/拍。
//    (3) 归一化        -> **下沉**：1/sum 是"每行一个标量"，交给下游消费者吸收
//                         （flash-attention 的做法）。故本模块不再有 S_NORM 段。
//
//  拍数：**o_cycles = ceil(M/SOF_LANES)**（末块在同一拍并入累加器并给出 o_sum /
//  o_inv_sum）。**SOF_LANES >= M 时整块 softmax 只占 1 拍** —— 这是 lane 数
//  与输出行数 1:1 时的下界（一拍做完全部 exp + 归约求和 + 倒数）。
//
//  mx_ctrl 的 P_SOF 相位比它多 1 拍（o_valid 是**寄存输出**，控制器晚一拍采样到），
//  故 model.py 记 soft_lat = ceil(n/lanes) + 1。
//
//  lane 数的取法：M = TILE_ROWS x PE_PER_TILE 是输出行数，**一个输出行一个 exp 单元**
//  与阵列"一个 k 位置一个乘法器"同构；给到 M 路即把 softmax 从瓶颈里摘出去。
//  旧的 32 路是随手取的常数，与阵列的 32768 路并行度严重不对称（见 report §4.2）。
//
//  ---------------------------------------------------------------------------
//  输出契约（**变了**，消费方注意）
//  ---------------------------------------------------------------------------
//      o_y        **未归一化**的分子 exp(x - max)，Q16.16
//      o_sum      该行分母 Σexp，Q16.16
//      o_inv_sum  1/o_sum，Q16.16 —— 想要概率就 y_i x inv_sum >> FRAC
//  下游若不消费 o_inv_sum，则自己在行末做一次除法即可（每行一次，不是每元素一次）。
//
//  ---------------------------------------------------------------------------
//  exp 的硬件实现（**未改动**）
//  ---------------------------------------------------------------------------
//      exp(d) = 2^(d*log2e) = 2^-m * 2^-g,  d <= 0, g in [0,1)
//      2^-g = exp(-g*ln2)，u = -g*ln2 in [-0.693, 0]，4 项级数，相对误差 < 4e-3
//  全程 Q16.16。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_softmax #(
    parameter M         = 4,                // 输出元素数
    parameter SOF_LANES = 1024,             // 并行 lane 数 = M（一输出行一 lane；tb 按 M 传）
    parameter QW        = 32,               // 定点位宽（Q16.16）
    parameter FRAC      = 16
)(
    input  wire                    clk,
    input  wire                    rst_n,

    input  wire                    i_valid,
    input  wire signed [M*QW-1:0]  i_x,          // 输入 logits（Q16.16）
    input  wire signed [QW-1:0]    i_max,        // 行内最大值（来自 mx_reduce 的 max 树）

    output reg                     o_valid,
    output reg  signed [M*QW-1:0]  o_y,          // **未归一化**的 exp 分子（Q16.16）
    output reg  signed [QW-1:0]    o_sum,        // 分母 Σexp
    output reg  signed [QW-1:0]    o_inv_sum,    // 1/分母（归一化因子，下沉给下游）
    output reg  [15:0]             o_cycles      // 本次 softmax 用了多少拍
);

    localparam NCHUNK = (M + SOF_LANES - 1) / SOF_LANES;
    localparam CW     = $clog2(NCHUNK + 1);
    localparam ONE    = (1 << FRAC);

    localparam S_IDLE = 2'd0, S_EXP = 2'd1;      // S_OUT 已并入 S_EXP（见下）
    reg [1:0]    st;
    reg [CW-1:0] ch;
    reg [15:0]   cyc;
    reg signed [QW-1:0] acc;                     // 已累加的块（不含当前块）

    integer i;
    // 注意：不再需要 e_v[] / yv[] / mx / sum —— max 外置、归一化下沉，
    // 本模块只需"逐块算 exp 并滚动累加分母"，寄存器只剩一个累加器。

    // Q16.16 倒数（64bit 中间量）：int_q(ONE, sum) = 2^32 / sum
    function signed [QW-1:0] int_q;
        input signed [QW-1:0] e;
        input signed [QW-1:0] s;
        reg signed [2*QW-1:0] num, den;
        begin
            num = e;
            num = num <<< FRAC;
            den = (s == 0) ? 1 : s;
            int_q = num / den;
        end
    endfunction

    // ---------------- exp：平方倍角（组合）----------------
    //  exp(d) = 2^(d*log2e) = 2^-m * 2^-g,  d<=0, m=floor(-d*log2e)>=0, g in [0,1)
    //    * 2^-m 用右移（整数部分）
    //    * 2^-g = exp(-g*ln2)，u = -g*ln2 in [-0.693, 0]，用 4 项级数
    //         1 + u + u^2/2 + u^3/6 + u^4/24，误差 ~u^5/120 < 4e-3 相对
    //  注意：早期版本用 u=d/128 的平方倍角，|u|>1 时级数会**发散**（d 很负时炸掉）。
    function signed [QW-1:0] exp_q;
        input signed [QW-1:0] d;                  // d <= 0
        reg signed [2*QW-1:0] d64, y64, gq, u64, t64, p64;
        integer m;
        begin
            d64 = d;
            y64 = (d64 * 94548) >>> FRAC;         // y = d * log2(e)，94548 = 1.4427*2^16
            m   = (-y64) >>> FRAC;                // 整数部分（>= 0）
            if (m < 0) m = 0;
            if (m > 40) begin                      // 太负 -> 直接 0
                exp_q = {QW{1'b0}};
            end else begin
                gq  = (-y64) - (m <<< FRAC);      // g in [0,1)
                u64 = -((gq * 45426) >>> FRAC);   // u = -g*ln2，45426 = ln2*2^16
                t64 = (1 <<< FRAC) + u64;
                p64 = (u64 * u64) >>> FRAC;
                t64 = t64 + (p64 >>> 1);          // +u^2/2
                p64 = (p64 * u64) >>> FRAC;
                t64 = t64 + (p64 / 6);            // +u^3/6
                p64 = (p64 * u64) >>> FRAC;
                t64 = t64 + (p64 / 24);           // +u^4/24
                if (t64 < 0) t64 = 0;
                exp_q = t64 >>> m;                // * 2^-m
            end
        end
    endfunction

    // ---------------- 逐块取数（组合）----------------
    // 当前块参与运算的元素索引为 ch*SOF_LANES + i，越界时取 0
    wire signed [QW-1:0] xblk [0:SOF_LANES-1];
    genvar gi;
    generate
        for (gi = 0; gi < SOF_LANES; gi = gi + 1) begin : g_blk
            assign xblk[gi] = (ch*SOF_LANES + gi < M)
                            ? $signed(i_x[(ch*SOF_LANES+gi)*QW +: QW])
                            : {QW{1'b0}};
        end
    endgenerate

    // 本块 exp 之和（组合）—— 只对这一块求和，跨块由 acc 寄存器串起来。
    // 块间因此没有组合依赖，1 块/拍，天然可流水。
    reg signed [QW-1:0] chsum;
    always @(*) begin
        chsum = {QW{1'b0}};
        for (i = 0; i < SOF_LANES; i = i + 1)
            if (ch*SOF_LANES + i < M)
                chsum = chsum + exp_q(xblk[i] - i_max);
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st        <= S_IDLE;
            ch        <= {CW{1'b0}};
            cyc       <= 16'd0;
            acc       <= {QW{1'b0}};
            o_valid   <= 1'b0;
            o_sum     <= {QW{1'b0}};
            o_inv_sum <= {QW{1'b0}};
            o_y       <= {(M*QW){1'b0}};
            o_cycles  <= 16'd0;
        end else begin
            o_valid <= 1'b0;
            case (st)
                S_IDLE: begin
                    cyc <= 16'd0;
                    acc <= {QW{1'b0}};
                    if (i_valid) begin
                        ch <= {CW{1'b0}};      // max 已由 i_max 给出，无需扫描
                        st <= S_EXP;
                    end
                end

                // 唯一的工作段：1 块/拍，写出未归一化的 exp 分子并滚动累加分母。
                // **末块在同一拍并入**（acc + chsum 是组合的，无需额外一拍）：
                //   NCHUNK=1（SOF_LANES >= M，即 lane 数与输出行数 1:1）时整块
                //   softmax 只占 **1 拍**，是本模块的拍数下界。
                S_EXP: begin
                    cyc <= cyc + 16'd1;
                    for (i = 0; i < SOF_LANES; i = i + 1)
                        if (ch*SOF_LANES + i < M)
                            o_y[(ch*SOF_LANES+i)*QW +: QW] <= exp_q(xblk[i] - i_max);
                    if (ch == NCHUNK[CW-1:0] - 1'b1) begin
                        o_sum     <= acc + chsum;                  // 末块同拍并入
                        o_inv_sum <= int_q(ONE[QW-1:0], acc + chsum);
                        o_cycles  <= cyc + 16'd1;                  // = NCHUNK
                        o_valid   <= 1'b1;
                        st        <= S_IDLE;
                    end else begin
                        acc <= acc + chsum;
                        ch  <= ch + 1'b1;
                    end
                end

                default: st <= S_IDLE;
            endcase
        end
    end

endmodule
