`timescale 1ns/1ps

//=============================================================================
//  mx_ctrl.v  —— 任务级 FSM：把 V3 的流水相位落成拍级时序
//  ---------------------------------------------------------------------------
//  相位（与 model.py 的 trace 顺序一一对应）：
//      P_WREQ/P_WWAIT/P_WPHY/P_WWRITE   权重回读 Mem Die -> MC -> PHY -> tile
//                                        （V3 冷启装载；p_row = LAT + STAGES + 握手）
//      P_BRD_RD/P_BRD_WR                输入分发：GSRAM **宽读**（全 bank 一拍）
//                                       -> **TILE_COLS 路广播总线**全体写入（一拍）
//                                       固定 2 拍，与 tile_cols 无关（旧实现是
//                                       "逐列窄读 + 单路广播"的 2 x TILE_COLS 拍）
//      P_MAC                            PE 阵列 MAC：占 MAC_STAGES 拍
//                                       （1 = 乘+累加合并；2 = 乘法一拍 + 累加一拍）
//      P_RED                            树形归约：占 RED_STAGES 拍
//                                       （= mx_reduce 的 PIPE；1 = 纯组合）
//      P_SOF                            softmax：占 SOF_STAGES 拍（按拍数推进，不等握手）
//      P_OUT                            结果回传
//
//  !! 相位使能一律**组合**产生（assign = (o_phase == P_xxx)）!!
//  若在同一个时序块里"先清 0 再置 1"，非阻塞赋值会让脉冲滞后一拍，
//  下游（阵列/存储）就会在相位已经前进之后才看到使能 —— 写错行/列。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_ctrl #(
    parameter TILE_ROWS   = 2,
    parameter TILE_COLS   = 2,
    parameter PE_PER_TILE = 2,
    parameter TILE_K      = 4,
    parameter MC_LAT      = 12,
    parameter PHY_STAGES  = 2,
    parameter BPC         = 1,
    parameter M           = TILE_ROWS * PE_PER_TILE,
    parameter SOF_LANES   = 4,
    parameter PAGES       = `MX_GSRAM_PAGES,     // 全局缓存乒乓页数
    parameter RED_STAGES  = 1,                   // 归约占几拍（= mx_reduce 的 PIPE）
    parameter MAC_STAGES  = 1,                   // MAC 占几拍（= mx_pe 的 PIPE+1）
    parameter SOF_STAGES  = 1                    // softmax 占几拍（= ceil(M/SOF_LANES)）
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        i_start,

    input  wire        i_mc_rvalid,       // MC 读回数据有效
    input  wire        i_phy_out_valid,   // PHY 串行化完成
    input  wire        i_softmax_done,    // softmax 完成

    output reg  [3:0]  o_phase,
    output wire        o_mc_req,          // 发一次 MC 读
    output wire        o_phy_ld,          // 给 PHY 压一行
    output wire        o_wr_tile,         // 把 PHY 输出写进 tile
    output wire        o_gsram_re,        // 宽读 GSRAM（全 bank，取整条输入向量）
    output wire        o_bcast_we,        // 广播写（TILE_COLS 路，一拍写完）
    output wire        o_mac_en,          // 阵列计算使能
    output wire        o_red_en,          // 采样归约结果
    output reg         o_done,
    output reg  [15:0] o_cycles,
    output reg  [15:0] o_wload_cycles,    // 仅权重装载段
    output reg  [15:0] o_idist_cycles,    // 仅输入分发段（宽读 + 广播）
    output wire [15:0] o_row,             // 当前权重行号 r
    output reg  [PGW-1:0] o_page          // 本任务从哪一页读输入（每任务翻转 = 乒乓）
);

    localparam NROWS = TILE_ROWS * TILE_COLS * PE_PER_TILE;
    localparam PGW   = (PAGES <= 1) ? 1 : $clog2(PAGES);

    localparam P_IDLE    = 4'd0, P_WREQ   = 4'd1, P_WWAIT  = 4'd2, P_WPHY  = 4'd3,
               P_WWRITE  = 4'd4, P_BRD_RD = 4'd6, P_BRD_WR = 4'd12,
               P_MAC     = 4'd7, P_RED    = 4'd8, P_SOF    = 4'd9, P_OUT    = 4'd10,
               P_DONE    = 4'd11;

    reg [15:0] r;      // 权重行
    reg [15:0] rcnt;   // 归约级计数器（PIPE > 1 时逐级推进）
    reg [15:0] mcnt;   // MAC 级计数器（PE 流水化时逐级推进）
    reg [15:0] scnt;   // softmax 计数器
    reg [PGW-1:0] pg;  // 乒乓页：本任务读 pg，任务结束后翻到另一页

    assign o_row = r;

    // ---- 相位使能：全部组合产生（关键，见文件头）----
    assign o_mc_req   = (o_phase == P_WREQ);
    assign o_phy_ld   = (o_phase == P_WWAIT) && i_mc_rvalid;
    assign o_wr_tile  = (o_phase == P_WWRITE);
    assign o_gsram_re = (o_phase == P_BRD_RD);
    assign o_bcast_we = (o_phase == P_BRD_WR);
    // MAC 可能占多拍（pe 流水化：乘法一拍 + 累加一拍）：整个 P_MAC 段都使能
    assign o_mac_en   = (o_phase == P_MAC);
    // 归约可能占多拍（mx_reduce 流水化）：**只在最后一拍**给出 o_red_en，
    // 那一拍 o_sums/o_exps 才是有效结果，softmax 也正好从那一拍开始。
    assign o_red_en   = (o_phase == P_RED) && (rcnt == RED_STAGES[15:0] - 16'd1);

    wire in_wload = (o_phase == P_WREQ) || (o_phase == P_WWAIT) ||
                    (o_phase == P_WPHY) || (o_phase == P_WWRITE);
    wire in_idist = (o_phase == P_BRD_RD) || (o_phase == P_BRD_WR);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_phase <= P_IDLE; r <= 16'd0; rcnt <= 16'd0; mcnt <= 16'd0; scnt <= 16'd0;
            o_done <= 1'b0; o_cycles <= 16'd0; o_wload_cycles <= 16'd0;
            o_idist_cycles <= 16'd0;
            pg <= {PGW{1'b0}};
        end else begin
            o_page <= pg;
            if (o_phase != P_IDLE && o_phase != P_DONE) o_cycles <= o_cycles + 16'd1;
            if (in_wload) o_wload_cycles <= o_wload_cycles + 16'd1;
            if (in_idist) o_idist_cycles <= o_idist_cycles + 16'd1;

            case (o_phase)
                P_IDLE: begin
                    o_done <= 1'b0;
                    if (i_start) begin
                        r <= 16'd0; mcnt <= 16'd0; scnt <= 16'd0;
                        o_cycles <= 16'd0; o_wload_cycles <= 16'd0;
                        o_idist_cycles <= 16'd0;
                        o_phase <= P_WREQ;
                    end
                end

                // ---- 权重回读：Mem Die -> MC -> PHY -> tile ----
                P_WREQ:   o_phase <= P_WWAIT;
                P_WWAIT:  if (i_mc_rvalid) o_phase <= P_WPHY;
                P_WPHY:   if (i_phy_out_valid) o_phase <= P_WWRITE;
                P_WWRITE: begin
                    if (r == NROWS[15:0] - 16'd1) begin
                        o_phase <= P_BRD_RD;      // 权重装载完成 -> 输入分发
                    end else begin
                        r <= r + 16'd1;
                        o_phase <= P_WREQ;
                    end
                end

                // ---- 输入分发：宽读（全 bank 一拍）+ 广播（TILE_COLS 路一拍）----
                //  没有列循环：bank = k 段号，宽读一次拿全 32 段；广播总线是
                //  TILE_COLS 路，每路喂自己那一列 tile，故一拍写完整个阵列。
                P_BRD_RD: o_phase <= P_BRD_WR;
                P_BRD_WR: o_phase <= P_MAC;

                // ---- 计算 / 归约 / softmax / 回传 ----
                P_MAC: begin
                    if (mcnt == MAC_STAGES[15:0] - 16'd1) begin
                        rcnt <= 16'd0; scnt <= 16'd0; o_phase <= P_RED;
                    end else mcnt <= mcnt + 16'd1;
                end
                P_RED: begin
                    if (rcnt == RED_STAGES[15:0] - 16'd1) o_phase <= P_SOF;
                    else                                  rcnt <= rcnt + 16'd1;
                end
                // **按拍数推进，不等握手**：mx_softmax 的 o_valid 是寄存输出，
                // 若在此等 i_softmax_done，P_SOF 会白挂一拍（数据其实已经出来，
                // 只是控制器晚一拍看到 done）。softmax 的拍数是确定的
                // （= ceil(M/SOF_LANES)），故直接计数。
                P_SOF: begin
                    if (scnt == SOF_STAGES[15:0] - 16'd1) o_phase <= P_OUT;
                    else                                  scnt <= scnt + 16'd1;
                end
                P_OUT: o_phase <= P_DONE;
                // 任务结束：翻页。下一个任务从另一页读，主机可在本任务执行期间
                // 向另一页写入下一个样本 —— 输入装载与计算因此可以重叠。
                P_DONE: begin
                    o_done <= 1'b1;
                    pg     <= pg + 1'b1;
                    o_phase <= P_IDLE;
                end
                default: o_phase <= P_IDLE;
            endcase
        end
    end

endmodule