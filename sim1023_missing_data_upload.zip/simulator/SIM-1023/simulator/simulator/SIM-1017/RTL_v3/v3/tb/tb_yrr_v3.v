//=============================================================================
//  tb_yrr_v3.v  —— V3 架构顶层端到端测试平台
//  ---------------------------------------------------------------------------
//  小配置：TILE_ROWS=2, TILE_COLS=2, PE_PER_TILE=2, TILE_K=4
//          -> tile 4 个 / PE 8 个 / 输出行 m=4 / k=8
//
//  自检项（编号以**运行时打印的**为准）：
//      [1] 复位后无残留
//      [2] 输入写入 Global SRAM（打印）
//      [3] 启动任务（打印）
//      [4] 归约结果 vs Verilog 实数参考（1e-3 相对）
//      [5] softmax：先用 o_softmax_inv 归一化，再校验概率和为 1 与逐元素偏差
//          —— 归一化已**下沉**，RTL 内部给的是未归一化分子 + 归一化因子
//      [6] 乒乓：启动任务 1（读第 1 页），验证换了页且结果正确
//      [7] PHY 串行化拍数 == ceil(行位宽/BPC) x 行数（口径自检）
//      [8] Global SRAM 容量口径自检（512 KB = BANKS x DEPTH x 行载荷）
//      [9] 输入分发拍数自检：**固定 2 拍**（宽读 1 + 广播 1），与 TILE_COLS 无关
//      [10] 周期观测（打印）
//
//  黄金转储（`ifdef MX_GOLDEN -> golden_v3.txt）供 simulator/V3/check_rtl.py 消费。
//  本 tb 与既有 RTL 的 tb 同风格：negedge 驱动 / posedge 采样 / 看门狗 / errs 计数。
//=============================================================================

`timescale 1ns/1ps

module tb_yrr_v3;

    // ---------------- 配置（须与 check_rtl.py 一致）----------------
    //  默认 = 小配置（可仿真、可验证）
    //  -DMX_MID  = 中等规模（证明参数化可扩）
    //  -DMX_FULL = V3 目标规模（32x32 tile / 32768 PE / k=1024）
`ifdef MX_FULL
    localparam TILE_ROWS   = 32;
    localparam TILE_COLS   = 32;
    localparam PE_PER_TILE = 32;
    localparam TILE_K      = 32;
`elsif MX_MID
    localparam TILE_ROWS   = 8;
    localparam TILE_COLS   = 8;
    localparam PE_PER_TILE = 8;
    localparam TILE_K      = 8;
`else
    localparam TILE_ROWS   = 2;
    localparam TILE_COLS   = 8;   // k = TILE_COLS*TILE_K = 32，与 V3 的"每 32 元素一个尺度"对齐
    localparam PE_PER_TILE = 2;
    localparam TILE_K      = 4;
`endif
    localparam MC_LAT      = 12;
    localparam PHY_STAGES  = 2;
    localparam BPC         = 1;
    localparam SOF_LANES   = M;   // 一输出行一 lane（NCHUNK=1，softmax 1 拍）
    localparam QW          = 32;
    localparam FRAC        = 16;
    // 移位加法树：**0 = 纯组合（默认，整棵树 1 拍）**；1 = 每拍一级。
    // -DMX_SA_PIPE 打开流水化。**两者数值结果逐位相同**。
`ifdef MX_SA_PIPE
    localparam SA_PIPE     = 1;
`else
    localparam SA_PIPE     = 0;
`endif
    localparam RED_LVLS    = (TILE_COLS <= 1) ? 1 : $clog2(TILE_COLS);
    localparam RED_PIPE    = SA_PIPE ? RED_LVLS : 1;

    localparam NTILE = TILE_ROWS * TILE_COLS;
    localparam M     = TILE_ROWS * PE_PER_TILE;
    localparam NROWS = NTILE * PE_PER_TILE;
    localparam NBITS = TILE_K*4 + 8;
    localparam NBEAT = (NBITS + BPC - 1) / BPC;
    localparam NTASKS = 2;      // 本 tb 跑两个任务（乒乓的两拍）

    `include "mx_fmt_defs.vh"
    `include "mx_fmt_funcs.vh"
    `include "mx_tb_vectors.vh"

    // 定点 Q(FRAC) -> 实数（顶层输出是定点，不是 FP32）
    function real q_to_real;
        input [QW-1:0] v;
        reg signed [QW-1:0] sv;
        begin
            sv = v;
            q_to_real = $itor(sv) / ldexp2(1.0, FRAC);
        end
    endfunction

    // ---------------- 时钟 / 复位 ----------------
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #5 clk = ~clk;

    // ---------------- DUT 端口 ----------------
    reg                     start;
    reg                     in_we;
    reg                     in_page;                 // 乒乓：主机写哪一页
    reg  [$clog2(TILE_COLS)-1:0] in_col;
    reg  [TILE_K*4-1:0]     in_payload;
    reg  [7:0]              in_scale;

    wire                    done, out_valid;
    wire signed [M*QW-1:0]  out_y;
    wire [M*QW-1:0]         logits;
    wire signed [QW-1:0]    sof_sum, sof_inv;   // softmax 分母与其倒数（归一化下沉）
    wire                    mem_en, mem_wr;
    wire [15:0]             mem_addr;
    wire [TILE_K*4-1:0]     mem_wdata;
    wire [7:0]              mem_wsc;
    wire [3:0]              phase;
    wire [15:0]             cycles, wload_cycles, idist_cycles, phy_cycles, sof_cycles;
    wire                    obs_page;                // 本任务读哪一页（观测）
    wire                    red_sticky;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*(`MX_PROD_W+$clog2(TILE_K)+1)-1:0] arr_sums_dbg;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*(`MX_SCALE_W+1)-1:0] arr_exps_dbg;
    wire [(TILE_ROWS*PE_PER_TILE)*(`MX_PROD_W+$clog2(TILE_K)+1+24)-1:0] red_sums_dbg;
    wire [(TILE_ROWS*PE_PER_TILE)*(`MX_SCALE_W+1)-1:0] red_exps_dbg;
    assign arr_sums_dbg = u_dut.u_arr.o_sums;
    assign arr_exps_dbg = u_dut.u_arr.o_exps;
    assign red_sums_dbg = u_dut.red_sums;
    assign red_exps_dbg = u_dut.red_exps;

    // ---------------- Mem Die 行为模型（含权重的"黄金"副本）----------------
    reg [NBITS-1:0] mem [0:NROWS-1];
    wire [NBITS-1:0] mem_rdata = mem[mem_addr % NROWS];

    integer t, p, k, c, r;
    initial begin
        for (r = 0; r < NROWS; r = r + 1) begin
            t = r / PE_PER_TILE;
            p = r % PE_PER_TILE;
            mem[r] = {(8){1'b0}};
            for (k = 0; k < TILE_K; k = k + 1)
                mem[r][k*4 +: 4] = mx_wcode(t, p, k);
            mem[r][TILE_K*4 +: 8] = mx_wscale(t / TILE_COLS, p);
        end
    end

    // ---------------- DUT ----------------
    //  说明：G_DEPTH 在仿真里显式取小值（4），只是为了让 netlist 小、跑得快；
//  **容量账以 mx_fmt_defs.vh 的 MX_GSRAM_BYTES/DEPTH 为准**（512 KB），
//  自检项 [7] 会把声明容量与除法自洽性一并打出来。不带覆盖例化 yrr_v3_top
//  时（即综合路径）拿到的是完整深度。
    yrr_v3_top #(
        .TILE_ROWS(TILE_ROWS), .TILE_COLS(TILE_COLS), .PE_PER_TILE(PE_PER_TILE),
        .TILE_K(TILE_K), .MC_LAT(MC_LAT), .PHY_STAGES(PHY_STAGES), .BPC(BPC),
        .G_BANKS(TILE_COLS), .G_DEPTH(4), .SOF_LANES(SOF_LANES),
        .QW(QW), .FRAC(FRAC), .SA_PIPE(SA_PIPE)
    ) u_dut (
        .clk(clk), .rst_n(rst_n),
        .i_start(start),
        .i_in_we(in_we), .i_in_page(in_page), .i_in_col(in_col),
        .i_in_payload(in_payload), .i_in_scale(in_scale),
        .o_done(done), .o_out_valid(out_valid), .o_out(out_y), .o_logits(logits),
        .o_softmax_sum(sof_sum), .o_softmax_inv(sof_inv),
        .o_mem_en(mem_en), .o_mem_wr(mem_wr), .o_mem_addr(mem_addr),
        .o_mem_wdata(mem_wdata), .o_mem_wsc(mem_wsc),
        .i_mem_rdata(mem_rdata[TILE_K*4-1:0]),
        .i_mem_rsc(mem_rdata[NBITS-1:TILE_K*4]),
        .o_phase(phase), .o_cycles(cycles), .o_wload_cycles(wload_cycles),
        .o_idist_cycles(idist_cycles),
        .o_phy_cycles(phy_cycles), .o_softmax_cycles(sof_cycles), .o_page(obs_page),
        .o_red_sticky(red_sticky)
    );

    // ---------------- 检查与记分 ----------------
    integer errs = 0;
    integer bad;
    reg [M*QW-1:0] got_y;
    reg [M*QW-1:0] got_logits;
    reg signed [QW-1:0] got_sum;                // softmax 分母（归一化下沉后由消费方施加）
    reg signed [QW-1:0] y_norm [0:M-1];         // 归一化后的概率（任务 0）
    reg signed [QW-1:0] y_norm1 [0:M-1];        // 归一化后的概率（任务 1）

    // 第 1 页的输入码：与第 0 页不同，用于验证乒乓确实换了页
    //   （第 0 页仍用共用的 mx_xcode，故 golden 与 check_rtl.py 的比对不受影响）
    function [3:0] mx_xcode_p1;
        input integer c;
        input integer k;
        integer x;
        begin
            x = ((c * 22695477) + (k * 104729) + 1013904223) & 32'h7FFFFFFF;
            x = ((x >> 13) ^ x) & 32'h7FFFFFFF;
            mx_xcode_p1 = x[3:0] ^ 4'h5;
        end
    endfunction

    // Q16.16 定点乘（**必须先加宽到 2*QW** —— Verilog 会按操作数位宽截断乘积）
    function signed [QW-1:0] q_mul;
        input signed [QW-1:0] a, b;
        reg signed [2*QW-1:0] wa, wb, w;
        begin
            wa = a;  wb = b;
            w  = wa * wb;
            q_mul = w >>> FRAC;
        end
    endfunction

    // 实数参考
    real ref_partial [0:NTILE*PE_PER_TILE-1];   // 每个 (tile,pe) 的部分和
    real ref_sum     [0:M-1];                   // 归约后的输出行
    real ref_soft    [0:M-1];
    real maxv, ssum, d;

    // ---- 主机侧：把一组输入写进指定页 ----
    task load_page;
        input integer pg;
        integer cc, kk;
        begin
            for (cc = 0; cc < TILE_COLS; cc = cc + 1) begin
                @(negedge clk);
                in_we   = 1'b1;
                in_page = pg[0];
                in_col  = cc[$clog2(TILE_COLS)-1:0];
                for (kk = 0; kk < TILE_K; kk = kk + 1)
                    in_payload[kk*4 +: 4] = (pg == 0) ? mx_xcode(cc, kk)
                                                      : mx_xcode_p1(cc, kk);
                in_scale = mx_xscale(cc);
                @(posedge clk);
                @(negedge clk);
                in_we = 1'b0;
                @(posedge clk);
            end
        end
    endtask

    // ---- 指定页的实数参考 ----
    task compute_ref;
        input integer pg;
        integer rr, tt, pp, kk, cc;
        begin
            for (rr = 0; rr < NROWS; rr = rr + 1) begin
                tt = rr / PE_PER_TILE;
                pp = rr % PE_PER_TILE;
                ref_partial[rr] = 0.0;
                for (kk = 0; kk < TILE_K; kk = kk + 1)
                    ref_partial[rr] = ref_partial[rr]
                        + mx_fp4_real(mx_wcode(tt, pp, kk), mx_wscale(tt / TILE_COLS, pp))
                        * mx_fp4_real((pg == 0) ? mx_xcode(tt % TILE_COLS, kk)
                                                : mx_xcode_p1(tt % TILE_COLS, kk),
                                      mx_xscale(tt % TILE_COLS));
            end
            for (pp = 0; pp < M; pp = pp + 1) begin
                ref_sum[pp] = 0.0;
                for (cc = 0; cc < TILE_COLS; cc = cc + 1)
                    ref_sum[pp] = ref_sum[pp]
                        + ref_partial[((pp / PE_PER_TILE)*TILE_COLS + cc)*PE_PER_TILE
                                      + (pp % PE_PER_TILE)];
            end
        end
    endtask

    task check_phase_wait;                       // 等 done
        input integer limit;
        integer w;
        begin
            w = 0;
            while (!done && w < limit) begin
                @(posedge clk);
                w = w + 1;
            end
            if (!done) begin
                $display("      [FAIL] 等待 o_done 超时（%0d 拍）", limit);
                errs = errs + 1;
            end
        end
    endtask

    initial begin
        start = 1'b0; in_we = 1'b0; in_col = 0; in_payload = 0; in_scale = 0;

        // 复位
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        //--------------------------------------------------------------
        $display("");
        $display("[1] 复位后检查");
        bad = 0;
        if (done !== 1'b0 || out_valid !== 1'b0) begin
            bad = bad + 1; $display("      [FAIL] 复位后 done/out_valid 非 0");
        end
        $display("      done=%b out_valid=%b : %0d 处不符", done, out_valid, bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        // 输入写入 GSRAM **第 0 页**（每段 k 一行）：主机侧广播写
        $display("");
        $display("[2] 输入写入 Global SRAM 第 0 页（%0d 段）", TILE_COLS);
        load_page(0);
        $display("      已写入第 0 页 %0d 段输入；当前读页 o_page=%0d", TILE_COLS, obs_page);

        //--------------------------------------------------------------
        // 启动任务 0；**在其执行期间**主机向第 1 页写第二组样本
        //   —— 这正是乒乓的用途：输入装载与计算重叠，且两页互不干扰。
        $display("");
        $display("[3] 启动任务 0，并在其执行期间写入第 1 页（乒乓重叠）");
        @(negedge clk);
        start = 1'b1;
        @(posedge clk);
        @(negedge clk);
        start = 1'b0;

        load_page(1);          // 与任务 0 并发：主机填另一页

        check_phase_wait(NROWS * (MC_LAT + NBEAT + PHY_STAGES + 8) + 2000);
        // 上限随规模推导，避免大配置被固定阈值误判超时
        repeat (2) @(posedge clk);
        got_logits = logits;
        got_y = out_y;
        got_sum = sof_sum;
        // 归一化下沉：o_out 是未归一化的 exp 分子，这里按契约施加 o_softmax_inv。
        //   一个向量只做 M 次定点乘（下游也可以在行末做一次除法，等价）。
        for (p = 0; p < M; p = p + 1)
            y_norm[p] = q_mul($signed(out_y[p*QW +: QW]), sof_inv);

        //--------------------------------------------------------------
        // 实数参考（第 0 页）
        //--------------------------------------------------------------
        compute_ref(0);

        //--------------------------------------------------------------

        $display("");
        $display("[4] 归约结果 vs 实数参考（容差 1e-3 相对）");
        bad = 0;
        for (p = 0; p < M; p = p + 1) begin
            d = q_to_real(logits[p*QW +: QW]);
            $display("      行 %0d: RTL=%12.6f 参考=%12.6f", p, d, ref_sum[p]);
            if ((ref_sum[p] > 1e-9 || ref_sum[p] < -1e-9) &&
                ((d - ref_sum[p]) > 1e-3*(ref_sum[p] > 0 ? ref_sum[p] : -ref_sum[p]) ||
                 (ref_sum[p] - d) > 1e-3*(ref_sum[p] > 0 ? ref_sum[p] : -ref_sum[p]))) begin
                bad = bad + 1;
                $display("      [FAIL] 行 %0d 偏差过大", p);
            end
        end
        $display("      归约 sticky=%b : %0d 处不符", red_sticky, bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        $display("");
$display("[5] softmax 概率和 = 1（容差 1e-2）");
        bad = 0;
        ssum = 0.0;
        for (p = 0; p < M; p = p + 1) ssum = ssum + q_to_real(y_norm[p]);
        $display("      概率和 = %f（分母 %f）", ssum, q_to_real(got_sum));
        if (ssum < 0.99 || ssum > 1.01) begin
            bad = bad + 1; $display("      [FAIL] 概率和偏离 1");
        end
        // 与实数参考的 softmax 比较
        maxv = ref_sum[0];
        for (p = 1; p < M; p = p + 1) if (ref_sum[p] > maxv) maxv = ref_sum[p];
        ssum = 0.0;
        for (p = 0; p < M; p = p + 1) begin
            ref_soft[p] = $exp(ref_sum[p] - maxv);
            ssum = ssum + ref_soft[p];
        end
        for (p = 0; p < M; p = p + 1) begin
            d = q_to_real(y_norm[p]);
            $display("      行 %0d: RTL=%8.5f 参考=%8.5f", p, d, ref_soft[p]/ssum);
            if ((d - ref_soft[p]/ssum) > 0.02 || (ref_soft[p]/ssum - d) > 0.02) begin
                bad = bad + 1; $display("      [FAIL] 行 %0d softmax 偏差过大", p);
            end
        end
        $display("      %0d 处不符", bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        // 第 1 页：乒乓的第二拍
        $display("");
        $display("[6] 乒乓：启动任务 1（读第 1 页），验证换了页且结果正确");
        bad = 0;
        if (obs_page !== 1'b1) begin
            bad = bad + 1;
            $display("      [FAIL] 任务 0 结束后读页未翻到第 1 页（o_page=%0d）", obs_page);
        end
        @(negedge clk);
        start = 1'b1;
        @(posedge clk);
        @(negedge clk);
        start = 1'b0;
        check_phase_wait(NROWS * (MC_LAT + NBEAT + PHY_STAGES + 8) + 2000);
        repeat (2) @(posedge clk);
        for (p = 0; p < M; p = p + 1)
            y_norm1[p] = q_mul($signed(out_y[p*QW +: QW]), sof_inv);
        compute_ref(1);
        // 任务 1 的 logits 必须等于**第 1 页**的参考（换页生效）
        for (p = 0; p < M; p = p + 1) begin
            d = q_to_real(logits[p*QW +: QW]);
            if ((ref_sum[p] > 1e-9 || ref_sum[p] < -1e-9) &&
                ((d - ref_sum[p]) > 1e-3*(ref_sum[p] > 0 ? ref_sum[p] : -ref_sum[p]) ||
                 (ref_sum[p] - d) > 1e-3*(ref_sum[p] > 0 ? ref_sum[p] : -ref_sum[p]))) begin
                bad = bad + 1;
                $display("      [FAIL] 任务 1 行 %0d 偏差过大（换页或乒乓失效）", p);
            end
        end
        // 第 1 页的概率和仍应为 1
        ssum = 0.0;
        for (p = 0; p < M; p = p + 1) ssum = ssum + q_to_real(y_norm1[p]);
        if (ssum < 0.99 || ssum > 1.01) begin
            bad = bad + 1; $display("      [FAIL] 任务 1 概率和偏离 1");
        end
        $display("      任务 1 概率和 = %f，换页后 o_page=%0d : %0d 处不符", ssum, obs_page, bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        $display("");
        $display("[7] PHY 串行化拍数口径自检");
        bad = 0;
        $display("      行位宽 %0d bit / BPC %0d -> 每行 %0d 拍", NBITS, BPC, NBEAT);
        $display("      权重装载段 %0d 行 x %0d 个任务, 实测 PHY 拍数 %0d",
                 NROWS, NTASKS, phy_cycles);
        if (phy_cycles !== (NBEAT * NROWS * NTASKS)) begin
            bad = bad + 1;
            $display("      [FAIL] PHY 拍数期望 %0d, 实测 %0d", NBEAT*NROWS*NTASKS, phy_cycles);
        end
        $display("      %0d 处不符", bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        $display("");
        $display("[8] Global SRAM 容量与乒乓口径自检");
        bad = 0;
        $display("      声明容量 %0d B = PAGES(%0d) x BANKS(%0d) x 每页 DEPTH(%0d) x 行载荷(%0d B)",
                 `MX_GSRAM_BYTES, `MX_GSRAM_PAGES, `MX_GSRAM_BANKS, `MX_GSRAM_DEPTH,
                 `MX_GSRAM_LINE_BYTES);
        $display("      本仿真例化的深度 = %0d（小值，仅为跑得快；容量账以声明值为准）", 4);
        if (`MX_GSRAM_PAGES < 2) begin
            bad = bad + 1;
            $display("      [FAIL] PAGES < 2：输入没有乒乓");
        end
        if (`MX_GSRAM_BYTES !== (`MX_GSRAM_PAGES * `MX_GSRAM_BANKS * `MX_GSRAM_DEPTH * `MX_GSRAM_LINE_BYTES)) begin
            bad = bad + 1;
            $display("      [FAIL] 容量宏不自洽");
        end
        if (`MX_GSRAM_BANKS < TILE_COLS) begin
            bad = bad + 1;
            $display("      [FAIL] BANKS(%0d) < TILE_COLS(%0d)：bank 会混叠", `MX_GSRAM_BANKS, TILE_COLS);
        end
        $display("      %0d 处不符", bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        $display("");
        $display("[9] 输入分发拍数自检（宽读 + TILE_COLS 路广播）");
        bad = 0;
        //  计数器每任务清零（与 o_wload_cycles 同口径），故这里是**单任务**的拍数
        $display("      输入分发段实测拍数 = %0d/任务（期望固定 2 拍：宽读 1 + 广播 1）",
                 idist_cycles);
        $display("      旧实现为逐列窄读+单路广播 = 2 x TILE_COLS = %0d 拍", 2*TILE_COLS);
        if (idist_cycles !== 16'd2) begin
            bad = bad + 1;
            $display("      [FAIL] 期望固定 2 拍，实测 %0d", idist_cycles);
        end
        if (16'd2 >= 2*TILE_COLS) begin
            bad = bad + 1;
            $display("      [FAIL] 分发拍数没有与 TILE_COLS 解耦");
        end
        $display("      %0d 处不符", bad);
        errs = errs + bad;

        //--------------------------------------------------------------
        $display("");
        $display("[10] 周期观测");
        $display("      总拍数 %0d, 权重装载段 %0d, 输入分发段 %0d, softmax %0d, 归约级数见 o_phase=%0d",
                 cycles, wload_cycles, idist_cycles, sof_cycles, phase);
        $display("      归约：%s（SA_PIPE=%0d，P_RED 占 %0d 拍，树级数 %0d）",
                 SA_PIPE ? "流水，每拍一级" : "纯组合，整棵树一拍", SA_PIPE, RED_PIPE, RED_LVLS);
        $display("      softmax 期望拍数 = ceil(M/SOF_LANES) = %0d（o_cycles；P_SOF 相位再 +1）", (M + SOF_LANES - 1)/SOF_LANES);

        //--------------------------------------------------------------
        // 黄金转储（**新文件**，不碰 RTL/RTL/golden_rtl.txt）
        //--------------------------------------------------------------
`ifdef MX_GOLDEN
        begin : dump
            integer gf;
            gf = $fopen("golden_v3.txt", "w");
            $fdisplay(gf, "# YRR V3-arch RTL golden dump -- tb_yrr_v3.v");
            $fdisplay(gf, "FORMAT MX_V3");
            $fdisplay(gf, "PARAM TILE_ROWS %0d",   TILE_ROWS);
            $fdisplay(gf, "PARAM TILE_COLS %0d",   TILE_COLS);
            $fdisplay(gf, "PARAM PE_PER_TILE %0d", PE_PER_TILE);
            $fdisplay(gf, "PARAM TILE_K %0d",      TILE_K);
            $fdisplay(gf, "PARAM M %0d",           M);
            $fdisplay(gf, "PARAM MC_LAT %0d",      MC_LAT);
            $fdisplay(gf, "PARAM PHY_STAGES %0d",  PHY_STAGES);
            $fdisplay(gf, "PARAM BPC %0d",         BPC);
            $fdisplay(gf, "PARAM SOF_LANES %0d",   SOF_LANES);
            $fdisplay(gf, "PARAM GSRAM_BANKS %0d", `MX_GSRAM_BANKS);
            $fdisplay(gf, "PARAM GSRAM_DEPTH %0d", `MX_GSRAM_DEPTH);
            $fdisplay(gf, "PARAM GSRAM_BYTES %0d", `MX_GSRAM_BYTES);
            $fdisplay(gf, "PARAM SIM_G_DEPTH %0d", 4);
            $fdisplay(gf, "CYCLE TOTAL %0d",       cycles);
            $fdisplay(gf, "CYCLE WLOAD %0d",       wload_cycles);
            $fdisplay(gf, "CYCLE IDIST %0d",       idist_cycles);
            $fdisplay(gf, "CYCLE PHY %0d",         phy_cycles);
            $fdisplay(gf, "CYCLE SOFTMAX %0d",     sof_cycles);
            for (r = 0; r < NROWS; r = r + 1) begin
                t = r / PE_PER_TILE;
                p = r % PE_PER_TILE;
                $fdisplay(gf, "WROW %0d %0d %0d %08h %0d", t, p, r,
                          mem[r][TILE_K*4-1:0], mem[r][TILE_K*4 +: 8]);
            end
            for (c = 0; c < TILE_COLS; c = c + 1) begin
                $fdisplay(gf, "XROW %0d %08h %0d", c,
                          {TILE_K{4'h0}}, mx_xscale(c));
            end
            for (p = 0; p < M; p = p + 1) begin
                // 用**捕获的**任务 0 结果（任务 1 会把线上的 logits 覆盖掉）
                $fdisplay(gf, "LOGIT %0d %.9f", p, q_to_real(got_logits[p*QW +: QW]));
            end
            for (p = 0; p < M; p = p + 1) begin
                // 写**归一化后**的概率：与 check_rtl.py 的比对口径保持一致
                // （RTL 内部已改成输出未归一化分子 + 归一化因子）
                $fdisplay(gf, "SOFTMAX %0d %.9f", p, q_to_real(y_norm[p]));
            end
            $fdisplay(gf, "END");
            $fclose(gf);
            $display("");
            $display("[TB] 已写出 golden_v3.txt");
        end
`endif

        //--------------------------------------------------------------
        $display("");
        $display("================================================================");
        if (errs == 0) $display("  RESULT: ALL PASS");
        else           $display("  RESULT: FAIL  (%0d errors)", errs);
        $display("================================================================");
        $finish;
    end

    // ---------------- 看门狗 ----------------
    initial begin
        repeat (200000) @(posedge clk);
        $display("[TB] ** 错误：仿真超时 **");
        $finish;
    end

endmodule