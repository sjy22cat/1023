`timescale 1ns/1ps

//=============================================================================
//  yrr_v3_top.v  —— V3 架构顶层（MXFP4 近存阵列）
//  ---------------------------------------------------------------------------
//  按 simulator/V3/yrr_v3 的结构组织，数据流与 model.py 的 trace 顺序一致：
//
//      Mem Die ──> MC ──> PHY(串行) ──> tile 权重存储        （冷启装载）
//      Host ──> Global SRAM ──> 广播 ──> tile 输入存储
//                        tile 阵列 MAC
//                             │
//                        树形归约 (mx_reduce)
//                             │
//                        logits（定点）
//                             │
//                        softmax (mx_softmax)
//                             │
//                        Host 回传
//
//  参数默认值 = **小配置**（可仿真）。目标规模（32x32 tile / 32768 PE / k=1024）
//  由例化方显式传参，见 RTL/v3/README.md 的参数对照表。
//
//  接口侧对齐 V3 的 interfaces.py：
//      MemDieRequest/Response -> Mem Die 行为模型端口（tb 提供）
//      PhyWord                -> mx_phy
//      TileWeightLoad         -> 阵列定向写
//      TileInputBlock         -> 阵列广播写
//      SoftmaxPacket          -> 输出结果
//=============================================================================

`include "mx_fmt_defs.vh"

module yrr_v3_top #(
    parameter TILE_ROWS   = 2,
    parameter TILE_COLS   = 2,
    parameter PE_PER_TILE = 2,
    parameter TILE_K      = 4,
    parameter MC_LAT      = 12,
    parameter PHY_STAGES  = 2,
    parameter BPC         = 1,                 // PHY 每拍传几位（1 = 位串行）
    parameter G_PAGES     = `MX_GSRAM_PAGES,   // 乒乓页数（2）
    parameter G_BANKS     = `MX_GSRAM_BANKS,   // 每页 32 bank
    parameter G_DEPTH     = `MX_GSRAM_DEPTH,   // 每页 512 行；两页合计 512 KB（mx_fmt_defs）
    parameter SOF_LANES   = 4,
    parameter QW          = 32,
    parameter FRAC        = 16,
    // 移位加法树是否流水化：
    //   **0 = 纯组合（默认，评估口径：整棵树 1 拍 / 延迟 2 ns）**
    //   1 = 每拍穿一级（级数 = ceil(log2(TILE_COLS))）—— 备选形态
    // **两者数值结果逐位相同**；差别只在拍数与拍长（见 report §4.2）：
    //   组合：P_RED 1 拍、拍长 2.00 ns（由树的 2.00 ns 决定）-> f_max 500 MHz
    //   流水：P_RED = 树级数 拍、每级 ~0.4 ns -> 拍长改由 PE 核 0.97 ns 决定
    parameter SA_PIPE     = 0,
    // PE 核内部：0 = 矩阵乘法与累加合并一拍；**1 = 各占一拍（新思口径，默认）**
    parameter PE_PIPE     = 1
)(
    input  wire                        clk,
    input  wire                        rst_n,

    // ---- 主机侧：启动 / 输入写入 / 结果读出 ----
    input  wire                        i_start,
    input  wire                        i_in_we,          // 写一行输入到 GSRAM
    input  wire [$clog2(G_PAGES)-1:0]  i_in_page,        // 写入哪一页（乒乓：主机填另一页）
    input  wire [$clog2(TILE_COLS)-1:0] i_in_col,        // 哪一段 k
    input  wire [TILE_K*`MX_FP4_W-1:0] i_in_payload,
    input  wire [`MX_SCALE_W-1:0]      i_in_scale,

    output wire                        o_done,
    output wire                        o_out_valid,
    output wire signed [TILE_ROWS*PE_PER_TILE*QW-1:0] o_out,   // softmax 结果 (Q16.16)
    output wire [TILE_ROWS*PE_PER_TILE*QW-1:0] o_logits, // 归约后的 logits（定点）
    output wire signed [QW-1:0]        o_softmax_sum,  // softmax 分母 Σexp（Q16.16）
    output wire signed [QW-1:0]        o_softmax_inv,  // 1/分母 —— 归一化因子（下沉给下游）

    // ---- Mem Die 行为模型端口（tb 驱动）----
    output wire                        o_mem_en,
    output wire                        o_mem_wr,
    output wire [15:0]                 o_mem_addr,
    output wire [TILE_K*`MX_FP4_W-1:0] o_mem_wdata,
    output wire [`MX_SCALE_W-1:0]      o_mem_wsc,
    input  wire [TILE_K*`MX_FP4_W-1:0] i_mem_rdata,
    input  wire [`MX_SCALE_W-1:0]      i_mem_rsc,

    // ---- 观测 ----
    output wire [3:0]                  o_phase,
    output wire [15:0]                 o_cycles,
    output wire [15:0]                 o_wload_cycles,
    output wire [15:0]                 o_idist_cycles,   // 输入分发段（宽读 + 广播）
    output wire [15:0]                 o_phy_cycles,
    output wire [15:0]                 o_softmax_cycles,
    output wire [$clog2(G_PAGES)-1:0]  o_page,          // 本任务读哪一页（观测）
    output wire                        o_red_sticky
);

    localparam NBITS  = TILE_K*`MX_FP4_W + `MX_SCALE_W;      // 一行的总位宽
    localparam ACCW   = `MX_PROD_W + $clog2(TILE_K) + 1;
    localparam EXPW   = `MX_SCALE_W + 1;
    localparam RW     = ACCW + 24;                            // 归约累加器宽
    localparam M      = TILE_ROWS * PE_PER_TILE;              // 输出行数
    // 归约流水级数：SA_PIPE=1 时每拍一级（= 树的级数），否则纯组合 1 拍
    localparam integer RED_LVLS = (TILE_COLS <= 1) ? 1 : $clog2(TILE_COLS);
    localparam integer RED_PIPE = SA_PIPE ? RED_LVLS : 1;
    // MAC 段拍数：PE 流水时 = 乘法 1 拍 + 累加 1 拍
    localparam integer MAC_STG  = PE_PIPE ? 2 : 1;
    // softmax 占几拍 = 单遍块数（lanes >= M 时 = 1）
    localparam integer SOF_STG  = (M + SOF_LANES - 1) / SOF_LANES;

    // ---------------- 控制 FSM ----------------
    wire        c_mc_req, c_phy_ld, c_wr_tile, c_gsram_re, c_bcast_we;
    wire        c_mac_en, c_red_en;
    wire [15:0] ctrl_row;
    wire [$clog2(G_PAGES)-1:0] ctrl_page;
    wire        mc_rvalid, phy_out_valid, sof_done;

    assign o_page = ctrl_page;

    mx_ctrl #(.TILE_ROWS(TILE_ROWS), .TILE_COLS(TILE_COLS),
              .PE_PER_TILE(PE_PER_TILE), .TILE_K(TILE_K),
              .MC_LAT(MC_LAT), .PHY_STAGES(PHY_STAGES), .BPC(BPC),
              .M(M), .SOF_LANES(SOF_LANES), .PAGES(G_PAGES),
              .RED_STAGES(RED_PIPE), .MAC_STAGES(MAC_STG), .SOF_STAGES(SOF_STG)) u_ctrl (
        .clk(clk), .rst_n(rst_n), .i_start(i_start),
        .i_mc_rvalid(mc_rvalid), .i_phy_out_valid(phy_out_valid),
        .i_softmax_done(sof_done),
        .o_phase(o_phase), .o_mc_req(c_mc_req), .o_phy_ld(c_phy_ld),
        .o_wr_tile(c_wr_tile), .o_gsram_re(c_gsram_re), .o_bcast_we(c_bcast_we),
        .o_mac_en(c_mac_en), .o_red_en(c_red_en),
        .o_done(o_done),
        .o_cycles(o_cycles), .o_wload_cycles(o_wload_cycles),
        .o_idist_cycles(o_idist_cycles),
        .o_row(ctrl_row), .o_page(ctrl_page)
    );

    // ---------------- Mem Die 控制器 ----------------
    wire [NBITS-1:0] phy_in_data;      // MC 读回的整行（payload + scale）

    mx_mc #(.LAT(MC_LAT), .AW(16), .LINE_W(TILE_K*`MX_FP4_W),
            .SCALE_W(`MX_SCALE_W)) u_mc (
        .clk(clk), .rst_n(rst_n),
        .i_req(c_mc_req), .i_wr(1'b0), .i_addr(ctrl_row),
        .i_wdata({TILE_K*`MX_FP4_W{1'b0}}), .i_wsc({`MX_SCALE_W{1'b0}}),
        .o_ready(), .o_rvalid(mc_rvalid),
        .o_rdata(phy_in_data[TILE_K*`MX_FP4_W-1:0]),
        .o_rsc(phy_in_data[NBITS-1:TILE_K*`MX_FP4_W]),
        .o_mem_en(o_mem_en), .o_mem_wr(o_mem_wr), .o_mem_addr(o_mem_addr),
        .o_mem_wdata(o_mem_wdata), .o_mem_wsc(o_mem_wsc),
        .i_mem_rdata(i_mem_rdata), .i_mem_rsc(i_mem_rsc),
        .o_req_cnt()
    );

    // ---------------- 归约后到 softmax 的组合链 ----------------
    //  **P_RED 与 P_SOF 之间没有空闲拍**：定点化 fixed_from、行内取大 logit_max
    //  都是纯组合，必须和 mx_reduce 一起在同一个拍长内走完。
    //  (mx_reduce 的流水化改变的是 P_RED 的**拍数**，不改变这条组合链的深度。)

    // ---------------- PHY（串行化）----------------
    wire [NBITS-1:0] phy_out_data;
    wire [15:0] phy_last_cycles;
    mx_phy #(.LINE_W(TILE_K*`MX_FP4_W), .SCALE_W(`MX_SCALE_W),
             .STAGES(PHY_STAGES), .BPC(BPC)) u_phy (
        .clk(clk), .rst_n(rst_n),
        .i_ld_valid(c_phy_ld), .i_ld_data(phy_in_data), .o_ld_ready(),
        .o_ld_out_valid(phy_out_valid), .o_ld_out_data(phy_out_data),
        .o_busy(), .o_cycles(phy_last_cycles), .o_total_cycles(o_phy_cycles)
    );

    // ---------------- 权重行号 -> (tile, pe) ----------------
    //   r = tile * PE_PER_TILE + pe
    wire [15:0] rrow = ctrl_row;
    wire [$clog2(TILE_ROWS*TILE_COLS)-1:0] wtile = rrow / PE_PER_TILE;
    wire [$clog2(PE_PER_TILE)-1:0]         wpe   = rrow % PE_PER_TILE;

    // ---------------- 全局缓存 ----------------
    //  读口是**宽读**：一次取全部 G_BANKS 的同一行 = 整条输入向量（bank = k 段号）。
    wire [G_BANKS*TILE_K*`MX_FP4_W-1:0] gs_pay;
    wire [G_BANKS*`MX_SCALE_W-1:0]      gs_scl;
    wire                                gs_rv;

    mx_gsram #(.BANKS(G_BANKS), .DEPTH(G_DEPTH), .PAGES(G_PAGES),
               .LINE_W(TILE_K*`MX_FP4_W), .SCALE_W(`MX_SCALE_W)) u_gsram (
        .clk(clk), .rst_n(rst_n),
        // 写口：主机指定页；读口：控制器指定页（每任务翻转）。
        // 两个口各自带页选择，因此主机写入与阵列读出可落在不同页上 —— 乒乓。
        .i_we(i_in_we), .i_wpage(i_in_page), .i_wbank(i_in_col),
        .i_waddr({$clog2(G_DEPTH){1'b0}}),
        .i_wpayload(i_in_payload), .i_wscale(i_in_scale),
        .i_re(c_gsram_re), .i_rpage(ctrl_page),
        .i_raddr({$clog2(G_DEPTH){1'b0}}),
        .o_rpayload(gs_pay), .o_rscale(gs_scl), .o_rvalid(gs_rv)
    );

    // ---------------- tile 阵列 ----------------
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*ACCW-1:0] arr_sums;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*EXPW-1:0] arr_exps;

    mx_array #(.TILE_ROWS(TILE_ROWS), .TILE_COLS(TILE_COLS),
               .PE_PER_TILE(PE_PER_TILE), .TILE_K(TILE_K),
               .ACCW(ACCW), .EXPW(EXPW), .PE_PIPE(PE_PIPE)) u_arr (
        .clk(clk), .rst_n(rst_n),
        .i_w_we(c_wr_tile), .i_w_tile(wtile), .i_w_addr(wpe),
        .i_w_payload(phy_out_data[TILE_K*`MX_FP4_W-1:0]),
        .i_w_scale(phy_out_data[NBITS-1:TILE_K*`MX_FP4_W]),
        // 广播总线：bank b 的那一段 -> 第 b 列 tile（G_BANKS >= TILE_COLS，取前 TILE_COLS 路）
        .i_x_we(c_bcast_we),
        .i_x_payload(gs_pay[TILE_COLS*TILE_K*`MX_FP4_W-1:0]),
        .i_x_scale(gs_scl[TILE_COLS*`MX_SCALE_W-1:0]),
        .i_calc_en(c_mac_en),
        .o_sums(arr_sums), .o_exps(arr_exps), .o_valid()
    );

    // ---------------- 树形归约 ----------------
    wire [M*RW-1:0]   red_sums;
    wire [M*EXPW-1:0] red_exps;
    wire [EXPW-1:0]   red_maxexp;
    wire [7:0]        red_stages;

    mx_reduce #(.TILE_ROWS(TILE_ROWS), .TILE_COLS(TILE_COLS),
                .PE_PER_TILE(PE_PER_TILE), .TILE_K(TILE_K),
                .ACCW(ACCW), .EXPW(EXPW), .PIPE(RED_PIPE)) u_red (
        .clk(clk), .rst_n(rst_n),
        .i_sums(arr_sums), .i_exps(arr_exps),
        .o_sums(red_sums), .o_exps(red_exps),
        .o_sticky(o_red_sticky),
        .o_max_exponent(red_maxexp), .o_stages(red_stages)
    );

    // ---------------- logits：定点 (sum,exp) -> Q16.16 ----------------
    //  值 = sum * 2^exp；先归一化到 |v| < 2^14，再折算到 Q16.16（带饱和）
    //  **归一化不再用串行循环**：早期实现是
    //      for (k = 0; k < 48; k = k+1) if (|v| > 2^14) { v >>>= 1; sh++; }
    //  按 RTL 字面是 48 级串行条件移位，一阶外推 ~60 ns —— 和归约夹在同一对
    //  寄存边界之间，会把拍长拖垮。改成**最高置位下标（对数深度的优先级编码）
    //  + 桶形移位**：深度 ~log2(RW) + log2(RW)，与位宽同阶而非与移位次数同阶。
    localparam integer FIX_PW = (RW <= 2) ? 1 : $clog2(RW);

    // 最高置位下标（对半搜索，深度 log2(RW)）
    function integer msb_idx;
        input [RW-1:0] av;
        integer lv;
        integer p;
        begin
            p = 0;
            for (lv = (1 << (FIX_PW-1)); lv >= 1; lv = lv >> 1)
                if ((av >> (p + lv)) != {RW{1'b0}}) p = p + lv;
            msb_idx = p;
        end
    endfunction

    function signed [QW-1:0] fixed_from;
        input signed [RW-1:0]   s;
        input signed [EXPW-1:0] e;
        reg signed [RW-1:0] v;
        reg        [RW-1:0] av;
        reg signed [QW-1:0] q;
        reg signed [2*QW-1:0] wide;
        integer sh, shn, p;
        begin
            v  = s;
            av = (v < 0) ? (~v + 1'b1) : v;     // |v|
            p  = msb_idx(av);                   // 最高置位下标
            // 归一化到 |v| < 2^14：需右移 max(0, p-13) 位
            shn = (p > 13) ? (p - 13) : 0;
            v  = v >>> shn;                     // 桶形移位（对数深度）
            sh = shn + e + FRAC;                // 目标 Q16.16 还需左移多少
            if (sh >= 0) begin
                wide = v;
                if (sh > 17) q = 32'sh7FFF_FFFF;          // 移位过大 -> 饱和
                else begin
                    wide = wide <<< sh;
                    if (wide > 64'sh0000_0000_7FFF_FFFF) q = 32'sh7FFF_FFFF;
                    else if (wide < -64'sh0000_0000_8000_0000) q = 32'sh8000_0000;
                    else                  q = wide[QW-1:0];
                end
            end else begin
                q = (v >>> ((-sh > 47) ? 47 : -sh));
            end
            fixed_from = q;
        end
    endfunction

    genvar gm;
    generate
        for (gm = 0; gm < M; gm = gm + 1) begin : g_logit
            assign o_logits[gm*QW +: QW] =
                fixed_from($signed(red_sums[gm*RW +: RW]),
                           $signed(red_exps[gm*EXPW +: EXPW]));
        end
    endgenerate

    // ---------------- 行内最大值：**树形**（组合，0 拍）----------------
    //  softmax 要的是**归约后 logits** 的最大值，所以这里对 o_logits 取大，
    //  而不是在 mx_reduce 里对部分和取大（部分和的最大值 != 行输出的最大值）。
    //  纯组合：logits 在归约相位就已经稳定，故 softmax 开始的那一拍即取到，
    //  **不增加任何拍数**。但**"0 拍"不等于"没有延迟"** —— 它的组合深度
    //  必须和归约一起挤进同一个拍长，故必须是**树**而不是串行链。
    //  **改成平衡树**：早期实现是
    //      logit_max = L[0]; for (i=1;i<M;i++) if (L[i] > logit_max) logit_max = L[i];
    //  按 RTL 字面是 M-1 级**串行**比较链（M=1024 时 1023 级，一阶外推 ~1048 ns），
    //  而它与归约夹在同一对寄存边界之间 —— 会把拍长拖垮。
    //  树形后深度只有 ceil(log2(M)) = 10 级。
    localparam integer MXLVL = (M <= 1) ? 1 : $clog2(M);
    localparam integer MPAD  = (1 << MXLVL);        // 补齐到 2 的幂
    wire signed [QW-1:0] mx_lv [0:(MXLVL+1)*MPAD-1];  // 展平：级 l 的第 i 个 = mx_lv[l*MPAD+i]

    genvar gml, gmi;
    generate
        for (gmi = 0; gmi < MPAD; gmi = gmi + 1) begin : g_mx0
            // 越界位置补**最小负数**，不影响取大结果
            assign mx_lv[gmi] = (gmi < M) ? $signed(o_logits[gmi*QW +: QW])
                                          : {1'b1, {(QW-1){1'b0}}};
        end
        for (gml = 0; gml < MXLVL; gml = gml + 1) begin : g_mxl
            for (gmi = 0; gmi < (MPAD >> (gml+1)); gmi = gmi + 1) begin : g_mxi
                assign mx_lv[(gml+1)*MPAD + gmi] =
                    ($signed(mx_lv[gml*MPAD + 2*gmi]) > $signed(mx_lv[gml*MPAD + 2*gmi + 1]))
                    ? mx_lv[gml*MPAD + 2*gmi] : mx_lv[gml*MPAD + 2*gmi + 1];
            end
        end
    endgenerate

    wire signed [QW-1:0] logit_max = mx_lv[MXLVL*MPAD];

    // ---------------- softmax（单遍；归一化下沉）----------------
    mx_softmax #(.M(M), .SOF_LANES(SOF_LANES), .QW(QW), .FRAC(FRAC)) u_softmax (
        .clk(clk), .rst_n(rst_n),
        .i_valid(c_red_en),                    // 归约采样那一拍给出 logits 与 max
        .i_x(o_logits),
        .i_max(logit_max),
        .o_valid(sof_done), .o_y(o_out),
        .o_sum(o_softmax_sum), .o_inv_sum(o_softmax_inv),
        .o_cycles(o_softmax_cycles)
    );

    // o_out 是**未归一化**的 exp 分子；下游用 o_softmax_inv 归一化（每行一次）。
    assign o_out_valid = sof_done;   // softmax 完成那一拍给出结果

endmodule