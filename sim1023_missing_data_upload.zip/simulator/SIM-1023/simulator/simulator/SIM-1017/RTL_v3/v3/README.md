# YRR V3 架构 RTL（`RTL/v3/`）

> 历史数值参考快照：本页旧性能数据和参数生成方法不用于当前 SIM-1017。当前 RTL 是 `RTL/RTL_1017SIM`，实测参数流程见 [主 README](../../README_SIM-1017.md)。旧估算宏文件 `yrr_tech_params.vh` 和 `area_synth.json` 已清理，不影响本快照数值 RTL 的编译。

按 `simulator/V3/yrr_v3` 的**系统结构**重写的可综合 RTL：MXFP4 数值通路、
树形归约、32 lane **单遍** softmax（归一化下沉）、权重经 MC→PHY 串行回读。

**与 `RTL/RTL/`（W4→A5、32 ACC、串行 `shift_adder`）并列存在，旧树一字未动。**
golden 文件也不共用 —— 新设计写 `golden_v3.txt`，绝不触碰 `RTL/RTL/golden_rtl.txt`
（后者有 `V1/run.py --check-golden`、`V1/tests/test_v1.py`、`V2/tests/test_v2.py`
三个 Python 消费点）。

## 怎么跑

```bash
cd RTL/v3

sh run_tb.sh                                   # 小配置，自检 10 项（含输入乒乓）
MX_DEFS="-DMX_SIM_INIT -DMX_GOLDEN" sh run_tb.sh   # 另写出 golden_v3.txt

MX_DEFS="-DMX_SIM_INIT -DMX_MID"  sh run_tb.sh     # 512 PE（证明参数化可扩）
MX_DEFS="-DMX_SIM_INIT -DMX_FULL" sh run_tb.sh     # V3 目标规模（见下"规模"）

# 与 Python 模型交叉验证
cd ../../simulator/V3 && python check_rtl.py
```

工具链：iverilog 12.0 + vvp。`run_tb.sh` 会探测 `/d/VSCODE/iverilog/...` 与
`/d/iverilog/...` 两处路径，也可用 `IVERILOG` / `VVP` 环境变量覆盖。

## 架构映射：V3 的流水 → RTL 模块

```
Mem Die ─> MC ─> PHY(串行) ─> tile 权重存储          冷启装载（V3 数据通路②）
Host ─> Global SRAM ─> TILE_COLS 路广播 ─> tile 输入  输入广播（通路③，不经 PHY）
                        （宽读全 bank：1 拍出整条输入向量）
                     tile 阵列 MAC (mx_array)
                          │
                     树形归约 (mx_reduce)
                          │
                     logits（Q16.16）
                          │
                     softmax (mx_softmax)
                          │
                     Host 回传
```

| V3（`model.py` 相位 / `interfaces.py` 契约） | RTL 模块 |
|---|---|
| PE 阵列 MAC | `mx_pe` / `mx_tile` / `mx_array` |
| `PeMacResult` / `TilePartial` | `mx_pe` 的 `(o_sum, o_exp)` |
| `MxControl` / `ReductionPacket` | `mx_reduce`（含 `o_sticky` / `o_max_exponent` / `o_stages`） |
| `SoftmaxPacket` | `mx_softmax` |
| `PhyWord` | `mx_phy`（串行化链路） |
| `MemDieRequest/Response` | `mx_mc` + tb 里的 Mem Die 行为模型 |
| `TileWeightLoad` / `TileInputBlock` | `mx_array` 的定向写 / **TILE_COLS 路**广播写 |
| 任务相位 FSM | `mx_ctrl` |

### 数值格式（对齐 `formats.py`）

```
FP4 载荷 4bit，码值 [0,.5,1,1.5,2,3,4,6]；E8M0 共享指数 8bit，bias 127
硬件用「码值 ×2」整数： [0,1,2,3,4,6,8,12]（signed 5bit）
一行 = TILE_K 个 FP4 载荷 + 1 个 E8M0 尺度    （TILE_K=32 时 LINE_W=128）
```

主通路全程整数、无舍入；归一化只在 logits 转定点时做一次。

## 参数（`V3Config` ↔ RTL）

| V3 `V3Config` | RTL parameter | 小配置 | MX_MID | **MX_FULL（V3 目标规模）** |
|---|---|---|---|---|
| `tile_rows` | `TILE_ROWS` | 2 | 8 | **32** |
| `tile_cols`（= k/tile_k） | `TILE_COLS` | 8 | 8 | **32** |
| `pe_per_tile` | `PE_PER_TILE` | 2 | 8 | **32** |
| `tile_k` | `TILE_K` | 4 | 8 | **32** |
| `gsram_payload_bits` = tile_k×4 | — | 16 | 32 | **128** |
| `gsram_scale_bits` | — | 8 | 8 | **8** |
| `partial_bits`（= PEO15） | — | 15 | 15 | 15 |
| `softmax_lanes` | `SOF_LANES` | 4（tb 覆盖） | 4（tb 覆盖） | **32**（默认值） |
| `mem_die_latency` | `MC_LAT` | 12 | 12 | **12** |
| `gsram_banks` | `G_BANKS` | 8 | 8 | **32** |
| `max_micro_batch` | — | — | — | 32（未实现，见"不做"） |
| 导出量：tile 数 | | 16 | 64 | **1024** |
| 导出量：PE 数 | | 32 | **4096** | **32768** |
| 导出量：输出行 m | | 4 | 64 | **1024** |
| 导出量：k | | 32 | 64 | **1024** |

**PHY 口径**：`BPC`（每拍传几位）默认 1 = 位串行，即 V3 数据集里
"每 bit 数据 625 ps / 1.44 pJ"的硬件形态（一行 `LINE_W+SCALE_W` bit 需同样多拍）。
改成 `BPC = LINE_W+SCALE_W` 即"每 bit 位宽"口径。参数已留出，两种都能跑。

## 本轮口径变更（softmax / 全局缓存）

三处改动，动机都是"旧口径把一个建模选择写成了硬件事实"：

**① softmax：三遍扫描 → 单遍 + 归一化下沉。**
旧版 `S_MAX → S_EXP → S_NORM` 每遍 `ceil(M/SOF_LANES)` 拍、首尾相接、零重叠，
于是 softmax 吃掉整条流水 90% 的拍数（V3 抽象账 106 拍里占 96）。现在：

| 旧 | 新 | 拍数影响 |
|---|---|---|
| `S_MAX` 整遍扫描求 max | max 由**顶层对 logits 组合取大**（`yrr_v3_top.v`） | −ceil(M/LANES)，**0 拍** |
| `S_EXP` 算 exp 并求和 | **保留**，且块间无依赖、天然可流水 | = ceil(M/LANES) |
| `S_NORM` 逐元素除法 | **下沉**：只给每行一个 `o_inv_sum`，由消费方施加 | −ceil(M/LANES) |

`o_cycles` 从 `3*ceil(M/LANES)` 变成 `ceil(M/LANES)+1`（小配置 3 → 2，
MX_MID 49 → 17，目标规模 96 → 33）。

> **注意 max 为什么不放在归约树里**：一个自然的想法是在 `mx_reduce` 的加法树上
> 并一条 max 树。但那棵树的叶子是**部分和**，部分和的最大值 ≠ 行输出的最大值
> （该模块做的是求和，不是逐元素取大）。实测踩过这个坑：算出来的 max 是 132
> 而真值是 111。故 max 放在顶层对 logits 取大 —— 同样 0 拍，且语义正确。

**② 输出契约变了。** `o_out` 现在是**未归一化**的 `exp(x−max)` 分子，
新增 `o_softmax_sum`（分母）与 `o_softmax_inv`（归一化因子）。
`tb` 与 `check_rtl.py` 的比对口径不变（golden 里仍写归一化后的值）。

**③ 全局缓存：容量有 RTL 依据 + 输入乒乓。** 容量以 `mx_fmt_defs.vh` 的
`MX_GSRAM_PAGES/BANKS/DEPTH/BYTES` 声明（**两页合计 512 KB**，每页 256 KB
= 32 bank × 512 行 × 16 B 载荷），
`mx_gsram` 与 `yrr_v3_top` 的参数默认值直接取这组宏，`simulator/V3` 也从同一组宏
提取 —— 模型不会再记一个 RTL 里没有的数字。仿真里 tb 显式传 `G_DEPTH(4)`
只为跑得快，**容量账以宏为准**，自检项 [7] 会把声明值打出来。
**输入乒乓**：`mx_gsram` 的读、写两个口各自带页选择（`i_wpage` / `i_rpage`），
`mx_ctrl` 持有页寄存器并在**每个任务结束时翻页**（`o_page`）。于是主机可以在阵列
计算当前样本的同时，把下一个样本写进另一页 —— 输入装载因此可与计算重叠，
这也是 RTL 取得**向量级流水**的前提。自检项 [6] 跑两个任务（第 0 页 / 第 1 页），
并验证换页生效、两页互不干扰、两页各自的归约与 softmax 均正确。

（旧树 `RTL/RTL/rtl/global_sram.v` 的 512×128 bit = 8 KB 是**另一个口径**，
且该模块已无任何实例化；两树容量不做合并。）

---

## 验证结果（分两阶段）

### 阶段一 · 小配置（TILE_ROWS=2, TILE_COLS=8, PE_PER_TILE=2, TILE_K=4）

`sh run_tb.sh` → **`RESULT: ALL PASS`**，9 项自检全过：

| 项 | 内容 | 结果 |
|---|---|---|
| [1] | 复位后无残留 | PASS |
| [2] | 输入写入 Global SRAM | PASS |
| [3] | 权重经 MC→PHY 装载落点 + 阵列 MAC + 归约 + softmax | PASS |
| [4] | 归约结果 vs Verilog 实数参考（逐行精确相等） | PASS |
| [5] | softmax：施加 `o_softmax_inv` 后概率和 = 1.000000，且与实数参考一致 | PASS |
| [6] | PHY 串行化拍数 = ceil(行位宽/BPC) × 行数 | PASS |
| [7] | 周期观测 | PASS |

**与 Python 交叉验证**（`simulator/V3/check_rtl.py`）→ **`CROSS-CHECK: ALL PASS`**：

```
logits     RTL vs Python f32 : |差| = 0.000e+00（4/4 行）
softmax    RTL vs Python f64 : |差| ≤ 1.4e-37
概率和     1.000000
```

向量由**同一组哈希**在两侧生成（RTL `tb/mx_tb_vectors.vh` / Python `check_rtl.py`），
所以这是真正的端到端一致性检查，不是趋势对比。

### 阶段二 · 放大到 V3 规模

| 级别 | 结果 |
|---|---|
| **编译** | 全参数化设计在 iverilog 12.0 下编译通过 |
| **MX_MID（64 tile / 512 PE / m=64 / k=64）** | **`RESULT: ALL PASS`** —— 归约逐行精确相等、softmax 和为 1，证明参数化正确、规模可扩 |
| **MX_FULL（1024 tile / 32768 PE / m=1024 / k=1024）** | **编译 + 展开通过**（`iverilog` 退出码 0，netlist 680 MB）。**未做端到端仿真**：按 `NROWS × (MC_LAT + PHY 拍数 + 握手) ≈ 32768 × 146 ≈ 4.8M 拍`估算，在这个规模的 netlist 上跑完不现实 |

如实记录：MX_FULL 这一档只到"编译/展开通过"，**没有**跑出 `ALL PASS`。

## 已知边界

1. **MX_FULL 未仿真**（见上）。要跑通全规模仿真需要把 Mem Die/PHY 换成带背压的
   行为模型、或把权重装载改成可中断的流式，不在本轮范围。
2. **未实现微批**（V3 的 `max_micro_batch`）：每个任务按单批处理。
3. **未实现 2 Mem Die 与层级映射**：tb 的 Mem Die 是一个平坦数组，
   `layer_die_map` / `mem_die_count` 未落到 RTL。
4. **softmax 的 exp 是近似**（4 项级数，相对误差 < 4e-3），数值通路未改；
   与 Python 的 `np.exp` 比有 ~1e-37 量级的差（实测）。
5. **RTL 拍数 ≠ V3 的 `critical_path`**：V3 报的是占用/依赖链/流水三张表。
   当前评估口径**不含主机读写**（边界：输入已在 Global SRAM、结果已出 softmax），
   且输入分发已改为**宽读 + TILE_COLS 路广播**（固定 2 拍），
   故依赖链 = 输入分发 2 + MAC 1 + 归约 1 + softmax 34 = **38 拍**。
   可复原的对照口径：
   `python run.py --serial-broadcast`（旧 1 路广播 → 100 拍）、
   `python run.py --with-host-io`（含主机段 → 618 拍）。
   RTL 报的是真实时序（MX_MID 为 **29719** 拍，其中权重装载 29696、输入分发 2）。
   两者口径不同，**不声称逐拍相等**。
6. **除法**用 `/`（综合时换倒数 LUT）；**Mem Die 的写通路**未使用（只读权重）。

## 文件

```
RTL/v3/
  run_tb.sh                 编译 + 运行
  README.md                 本文件
  rtl/
    mx_fmt_defs.vh          MXFP4 常量（带 include guard）
    mx_fmt_funcs.vh         实数参考/打包函数（无 guard，module 内 include）
    mx_pe.v                 一个 PE：TILE_K 路 MXFP4 乘累加（整数、精确）
    mx_tile.v               PE_PER_TILE 个 PE + 本地权重/输入存储
    mx_array.v              TILE_ROWS×TILE_COLS 阵列 + TILE_COLS 路输入广播
    mx_reduce.v             树形归约（左移到最小指数，精确，与串行等价）
    mx_softmax.v            单遍 softmax，32 lane，exp 用 2^x 分解 + 4 项级数
                            max 由顶层对 logits 组合取大（0 拍）；归一化下沉
    mx_gsram.v              全局缓存（两页合计 512 KB = 2 x 32 x 512 x 16 B，输入乒乓）
                            读口是**宽读**：一次取全部 bank 的同一行 = 整条输入向量
    mx_mc.v                 Mem Die 控制器（LAT 拍）
    mx_phy.v                跨 Die PHY（串行化，BPC 可配）
    mx_ctrl.v               任务相位 FSM
    yrr_v3_top.v            顶层
  tb/
    tb_yrr_v3.v             端到端测试平台（自检 + golden 转储）
    mx_tb_vectors.vh        确定性向量（与 check_rtl.py 同源）
  sim/                      编译产物（.gitignore 级）
simulator/V3/check_rtl.py   RTL ↔ Python 交叉验证
```

## 实现中修掉的三类典型坑（记录备查）

1. **相位使能不能用"同块先清后置"**：`mx_ctrl` 早期把 `o_wr_tile` 在同一个时序块里
   先赋 0 再赋 1，非阻塞赋值让脉冲滞后一拍，阵列就在相位已前进之后才看到使能 ——
   权重写错行、输入写错列。现全部改为 `assign = (o_phase == P_xxx)`。
2. **Verilog 的乘法按操作数位宽截断**：`mx_pe` 里两个 5bit 有符号直接相乘会被截成
   5bit（真积可达 144）。必须先把操作数加宽到 9bit 再乘。`mx_softmax` 的 `exp`
   与 `int_q` 同理（32bit 乘会溢出，必须用 64bit 中间量）。
3. **归约对齐方向**：对齐到**最大**指数需要右移（丢位），对齐到**最小**指数才是
   左移（精确）。早期写反，"树的归约 == 串行累加"这条就不成立了。
   另：`mx_array` 的打包顺序是 `[tile][pe]`，`mx_reduce` 必须按同一顺序取数。
