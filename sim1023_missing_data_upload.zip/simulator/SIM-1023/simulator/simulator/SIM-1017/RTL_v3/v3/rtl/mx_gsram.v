`timescale 1ns/1ps

//=============================================================================
//  mx_gsram.v  —— 全局缓存（Global SRAM）
//  ---------------------------------------------------------------------------
//  与 V3 的对应：capacity / traffic 段里的 Global SRAM。V3 的参数是
//  gsram_banks=32、每行 payload 128 bit + scale 8 bit、**容量 512 KB**。
//  这里做成 BANKS x DEPTH 的 bank 化存储，每行 = (LINE_W + SCALE_W)。
//
//  !! 容量不再是随口一句注释 !! ：默认值直接取 `mx_fmt_defs.vh` 的
//  MX_GSRAM_BANKS / MX_GSRAM_DEPTH（512 KB = 32 x 1024 x 16 B），
//  simulator/V3 从同一组宏提取，因此模型不会再记一个 RTL 里没有的数字。
//  仿真若嫌 32x1024 的 reg 数组太大，可显式传小的 DEPTH（tb 就是这么做的），
//  但**容量账以宏为准**，并由 tb 打印核对。
//
//  ---------------------------------------------------------------------------
//  **读口是"宽读"**：一次读出全部 BANKS 的同一行（读延迟仍为 1 拍）
//  ---------------------------------------------------------------------------
//  每段 k 占一个 bank（bank = k 段号，与 TILE_COLS 一一对应），故
//  "读一行 × 全部 bank" 恰好 = 取出**整条输入向量**（TILE_COLS 段）。
//  旧实现是"一次读一个 bank"的窄读口，控制器必须逐列读 32 次；
//  宽读把这个串行循环压成 1 拍 —— 这是本轮输入分发加速的一半（另一半是
//  mx_array 的 TILE_COLS 路广播总线）。
//  写口仍是**窄写**（一次一个 bank）：主机按段写入，属主机侧节奏（评估边界之外）。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_gsram #(
    parameter BANKS   = `MX_GSRAM_BANKS,
    parameter DEPTH   = `MX_GSRAM_DEPTH,     // **每页**行数
    parameter PAGES   = `MX_GSRAM_PAGES,     // 乒乓页数
    parameter LINE_W  = 16,
    parameter SCALE_W = `MX_SCALE_W
)(
    input  wire                        clk,
    input  wire                        rst_n,

    // ---- 写口（主机侧）：页由主机指定 ----
    input  wire                        i_we,
    input  wire [$clog2(PAGES)-1:0]    i_wpage,
    input  wire [$clog2(BANKS)-1:0]    i_wbank,
    input  wire [$clog2(DEPTH)-1:0]    i_waddr,
    input  wire [LINE_W-1:0]           i_wpayload,
    input  wire [SCALE_W-1:0]          i_wscale,

    // ---- 读口（阵列侧）：**宽读**，一次取全部 bank 的同一行 ----
    //  不再有 i_rbank：段号就是输出向量的下标（bank b = 第 b 段 k）。
    input  wire                        i_re,
    input  wire [$clog2(PAGES)-1:0]    i_rpage,
    input  wire [$clog2(DEPTH)-1:0]    i_raddr,

    output reg  [BANKS*LINE_W-1:0]     o_rpayload,   // 每 bank 一段，共 BANKS 段
    output reg  [BANKS*SCALE_W-1:0]    o_rscale,
    output reg                         o_rvalid
);

    // 乒乓：读写各带一个页选择，故主机可在向一页写入的同时从另一页读出。
    // 存储按 [page][bank][addr] 展平；两页在物理上互不重叠。
    localparam NENT = PAGES * BANKS * DEPTH;

    integer k, b;
    reg [LINE_W-1:0]  pay [0:NENT-1];
    reg [SCALE_W-1:0] scl [0:NENT-1];
    wire [$clog2(NENT)-1:0] widx = (i_wpage * BANKS + i_wbank) * DEPTH + i_waddr;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
`ifdef MX_SIM_INIT
            for (k = 0; k < NENT; k = k + 1) begin
                pay[k] <= {LINE_W{1'b0}};
                scl[k] <= {SCALE_W{1'b0}};
            end
`endif
            o_rpayload <= {(BANKS*LINE_W){1'b0}};
            o_rscale   <= {(BANKS*SCALE_W){1'b0}};
            o_rvalid   <= 1'b0;
        end else begin
            if (i_we) begin
                pay[widx] <= i_wpayload;
                scl[widx] <= i_wscale;
            end
            // 1 拍读：**全部 bank 并行**（bank b = 第 b 段 k）
            o_rvalid <= i_re;
            if (i_re) begin
                for (b = 0; b < BANKS; b = b + 1) begin
                    o_rpayload[b*LINE_W  +: LINE_W]  <= pay[(i_rpage*BANKS + b)*DEPTH + i_raddr];
                    o_rscale  [b*SCALE_W +: SCALE_W] <= scl[(i_rpage*BANKS + b)*DEPTH + i_raddr];
                end
            end
        end
    end

endmodule