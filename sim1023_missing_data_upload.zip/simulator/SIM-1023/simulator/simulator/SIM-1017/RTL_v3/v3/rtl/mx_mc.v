`timescale 1ns/1ps

//=============================================================================
//  mx_mc.v  —— Mem Die 控制器（对应 V3 的 MemDieRequest / MemDieResponse）
//  ---------------------------------------------------------------------------
//  与 V3 的对应：数据集里的 mem_die_latency = 12（= 既有 RTL 的 mc.LAT）。
//  一次访问传一行：payload LINE_W bit + scale SCALE_W bit。
//  读：请求后数 LAT 拍给 o_rvalid；写：不返回数据，只发 Mem Die 侧信号。
//
//  Mem Die 阵列本身是行为模型（由 tb 提供，对应 V3 的 2 个 Mem Die + 分层映射）。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_mc #(
    parameter LAT     = 12,
    parameter AW      = 16,
    parameter LINE_W  = 16,
    parameter SCALE_W = `MX_SCALE_W,
    parameter CNTW    = 8
)(
    input  wire                clk,
    input  wire                rst_n,

    // ---- 逻辑侧请求 ----
    input  wire                i_req,
    input  wire                i_wr,
    input  wire [AW-1:0]       i_addr,
    input  wire [LINE_W-1:0]   i_wdata,
    input  wire [SCALE_W-1:0]  i_wsc,
    output reg                 o_ready,        // 可收新请求
    output reg                 o_rvalid,       // 读数据有效（1 拍脉冲）
    output reg [LINE_W-1:0]    o_rdata,
    output reg [SCALE_W-1:0]   o_rsc,

    // ---- Mem Die 侧（行为模型）----
    output reg                 o_mem_en,
    output reg                 o_mem_wr,
    output reg [AW-1:0]        o_mem_addr,
    output reg [LINE_W-1:0]    o_mem_wdata,
    output reg [SCALE_W-1:0]   o_mem_wsc,
    input  wire [LINE_W-1:0]   i_mem_rdata,
    input  wire [SCALE_W-1:0]  i_mem_rsc,

    output reg [31:0]          o_req_cnt
);

    reg [CNTW-1:0] cnt;
    reg            busy;
    reg            wr_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt       <= {CNTW{1'b0}};
            busy      <= 1'b0;
            wr_r      <= 1'b0;
            o_ready   <= 1'b1;
            o_rvalid  <= 1'b0;
            o_rdata   <= {LINE_W{1'b0}};
            o_rsc     <= {SCALE_W{1'b0}};
            o_mem_en  <= 1'b0;
            o_mem_wr  <= 1'b0;
            o_mem_addr<= {AW{1'b0}};
            o_mem_wdata <= {LINE_W{1'b0}};
            o_mem_wsc <= {SCALE_W{1'b0}};
            o_req_cnt <= 32'd0;
        end else begin
            o_rvalid <= 1'b0;
            o_mem_en <= 1'b0;

            if (!busy) begin
                o_ready <= 1'b1;
                if (i_req) begin
                    busy       <= 1'b1;
                    wr_r       <= i_wr;
                    cnt        <= LAT[CNTW-1:0];
                    o_ready    <= 1'b0;
                    o_req_cnt  <= o_req_cnt + 32'd1;
                    o_mem_en   <= 1'b1;
                    o_mem_wr   <= i_wr;
                    o_mem_addr <= i_addr;
                    o_mem_wdata<= i_wdata;
                    o_mem_wsc  <= i_wsc;
                end
            end else begin
                // 写：Mem Die 在收请求当拍写入；读：等 LAT 拍
                if (cnt > {{(CNTW-1){1'b0}}, 1'b1}) begin
                    cnt <= cnt - 1'b1;
                end else begin
                    busy <= 1'b0;
                    if (!wr_r) begin
                        o_rvalid <= 1'b1;
                        o_rdata  <= i_mem_rdata;
                        o_rsc    <= i_mem_rsc;
                    end
                end
            end
        end
    end

endmodule