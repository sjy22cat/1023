`timescale 1ns/1ps

//=============================================================================
//  mx_phy.v  —— 跨 Die 物理接口（对应 V3 的 PhyWord）
//  ---------------------------------------------------------------------------
//  与 V3 数据集的对应：实测 **625 ps / 1.44 pJ 每 bit 数据**。
//  硬件形态就是把这一条落成**串行化链路**：
//
//      PHY_BITS_PER_CYCLE = 1   -> 位串行，一行 (LINE_W+SCALE_W) bit 需同样多拍
//                                  （625 ps/bit @ 1.6 GHz ≈ 1 bit/拍）
//      PHY_BITS_PER_CYCLE = LINE_W+SCALE_W -> 整行并行一次传完
//                                  （这才是"每 bit 位宽"的口径）
//
//  两者都是"每 bit 数据付一次代价"的合法实现，差别只在链路宽度；参数留给上层选。
//  数据路径与既有设计的 phy.v 一致：STAGES 级同步（跨 Die 时序对齐）。
//
//  V3 里 PHY 只挂在**权重回读**通路上（MC -> PHY -> W_L1），输入广播不经 PHY。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_phy #(
    parameter LINE_W  = 16,
    parameter SCALE_W = `MX_SCALE_W,
    parameter STAGES  = 2,                  // 同步级数（须 >= 2）
    parameter BPC     = 1                   // 每拍传几位数据（1 = 位串行）
)(
    input  wire                        clk,
    input  wire                        rst_n,

    // ---- 发送侧（来自 MC）----
    input  wire                        i_ld_valid,
    input  wire [LINE_W+SCALE_W-1:0]   i_ld_data,
    output reg                         o_ld_ready,

    // ---- 接收侧（落到 tile 的 W_L1）----
    output reg                         o_ld_out_valid,
    output reg  [LINE_W+SCALE_W-1:0]   o_ld_out_data,

    // ---- 观测 ----
    output reg                         o_busy,
    output reg  [15:0]                 o_cycles,             // 本次串行化用了多少拍
    output reg  [15:0]                 o_total_cycles        // 累计（整个任务）
);

    localparam TOTAL = LINE_W + SCALE_W;
    localparam NBEAT = (TOTAL + BPC - 1) / BPC;               // 串行化拍数
    localparam BW    = $clog2(NBEAT + 1);

    reg [TOTAL-1:0]  shift;
    reg [TOTAL-1:0]  word;                                    // 保持整行供输出
    reg [BW-1:0]     beat;
    reg              running;
    reg [STAGES-1:0] vpipe;                                   // 同步级

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift          <= {TOTAL{1'b0}};
            word           <= {TOTAL{1'b0}};
            beat           <= {BW{1'b0}};
            running        <= 1'b0;
            vpipe          <= {STAGES{1'b0}};
            o_ld_ready     <= 1'b1;
            o_ld_out_valid <= 1'b0;
            o_ld_out_data  <= {TOTAL{1'b0}};
            o_busy         <= 1'b0;
            o_cycles       <= 16'd0;
            o_total_cycles <= 16'd0;
        end else begin
            // 输出与同步级对齐
            o_ld_out_valid <= vpipe[STAGES-1];
            o_ld_out_data  <= word;
            vpipe          <= {vpipe[STAGES-2:0], 1'b0};

            if (!running) begin
                o_busy     <= 1'b0;
                o_ld_ready <= 1'b1;
                if (i_ld_valid) begin
                    shift      <= i_ld_data;
                    word       <= i_ld_data;
                    beat       <= NBEAT[BW-1:0];
                    running    <= 1'b1;
                    o_busy     <= 1'b1;
                    o_ld_ready <= 1'b0;
                    o_cycles   <= 16'd0;
                end
            end else begin
                o_cycles <= o_cycles + 16'd1;
                o_total_cycles <= o_total_cycles + 16'd1;
                shift    <= shift >> BPC;                     // 每拍移出 BPC 位
                if (beat > {{(BW-1){1'b0}}, 1'b1}) begin
                    beat <= beat - 1'b1;
                end else begin
                    running <= 1'b0;
                    o_busy  <= 1'b0;
                    vpipe   <= {vpipe[STAGES-2:0], 1'b1};     // 打上 valid
                end
            end
        end
    end

endmodule