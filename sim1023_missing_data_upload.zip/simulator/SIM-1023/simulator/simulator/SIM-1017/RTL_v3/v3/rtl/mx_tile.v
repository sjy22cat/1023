`timescale 1ns/1ps

//=============================================================================
//  mx_tile.v  —— 一个 MXFP4 计算 tile（PE_PER_TILE 个 PE + 本地权重/输入存储）
//  ---------------------------------------------------------------------------
//  与 V3 的对应：V3 的 tile = pe_per_tile 个 PE，持有该 tile 的一段权重；
//  输入由阵列**广播**（V3 的 input_broadcast），故 tile 内只有一份输入副本。
//
//  存储（对应 V3 的 capacity.tile_*）：
//      权重：PE_PER_TILE 行 × (TILE_K*4 bit 载荷 + 8 bit E8M0 尺度)
//      输入：1 行 × (TILE_K*4 + 8)
//      部分和：PE_PER_TILE × (ACCW + EXPW)
//
//  读地址约定（与仓库既有 a5_regfile 同一思路）：权重行号 = 该 tile 内的 PE 号，
//  计算时全部 PE 共用同一份输入 —— 没有交叉开关、没有地址运算。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_tile #(
    parameter TILE_K      = 4,
    parameter PE_PER_TILE = 2,
    parameter ACCW        = `MX_PROD_W + $clog2(TILE_K) + 1,
    parameter EXPW        = `MX_SCALE_W + 1,
    parameter PE_PIPE     = 0
)(
    input  wire                            clk,
    input  wire                            rst_n,

    // ---- 权重装载（来自 PHY，逐行；对应 TileWeightLoad）----
    input  wire                            i_w_we,
    input  wire [$clog2(PE_PER_TILE)-1:0]  i_w_addr,
    input  wire [TILE_K*`MX_FP4_W-1:0]     i_w_payload,
    input  wire [`MX_SCALE_W-1:0]          i_w_scale,

    // ---- 输入广播装载（对应 TileInputBlock）----
    input  wire                            i_x_we,
    input  wire [TILE_K*`MX_FP4_W-1:0]     i_x_payload,
    input  wire [`MX_SCALE_W-1:0]          i_x_scale,

    // ---- 计算（对应 PE 阵列 MAC 相位）----
    input  wire                            i_calc_en,

    output wire                            o_valid,
    output wire [PE_PER_TILE*ACCW-1:0]     o_sums,
    output wire [PE_PER_TILE*EXPW-1:0]     o_exps
);

    integer k;
    reg [TILE_K*`MX_FP4_W-1:0] w_mem [0:PE_PER_TILE-1];
    reg [`MX_SCALE_W-1:0]      w_sc  [0:PE_PER_TILE-1];
    reg [TILE_K*`MX_FP4_W-1:0] x_mem;
    reg [`MX_SCALE_W-1:0]      x_sc;

    // ---- 存储：单写口，组合读（与 a5_regfile 同风格）-----------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
`ifdef MX_SIM_INIT
            for (k = 0; k < PE_PER_TILE; k = k + 1) begin
                w_mem[k] <= {(TILE_K*`MX_FP4_W){1'b0}};
                w_sc[k]  <= {`MX_SCALE_W{1'b0}};
            end
            x_mem <= {(TILE_K*`MX_FP4_W){1'b0}};
            x_sc  <= {`MX_SCALE_W{1'b0}};
`endif
        end else begin
            if (i_w_we) begin
                w_mem[i_w_addr] <= i_w_payload;
                w_sc[i_w_addr]  <= i_w_scale;
            end
            if (i_x_we) begin
                x_mem <= i_x_payload;
                x_sc  <= i_x_scale;
            end
        end
    end

    // ---- PE 阵列：PE_PER_TILE 个 mx_pe，共享同一份输入 --------------------
    genvar gp;
    generate
        for (gp = 0; gp < PE_PER_TILE; gp = gp + 1) begin : g_pe
            wire signed [EXPW-1:0] pe_exp;
            wire signed [ACCW-1:0] pe_sum;
            wire                   pe_vld;

            mx_pe #(.TILE_K(TILE_K), .ACCW(ACCW), .EXPW(EXPW), .PIPE(PE_PIPE)) u_pe (
                .clk         (clk),
                .rst_n       (rst_n),
                .i_w_payload (w_mem[gp]),
                .i_w_scale   (w_sc[gp]),
                .i_x_payload (x_mem),
                .i_x_scale   (x_sc),
                .i_valid     (i_calc_en),
                .o_exp       (pe_exp),
                .o_sum       (pe_sum),
                .o_valid     (pe_vld)
            );

            assign o_sums[gp*ACCW +: ACCW] = pe_sum;
            assign o_exps[gp*EXPW +: EXPW] = pe_exp;
            if (gp == 0) assign o_valid = pe_vld;
        end
    endgenerate

endmodule