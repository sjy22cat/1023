`timescale 1ns/1ps

//=============================================================================
//  mx_reduce.v  —— MX 树形归约（把 TILE_COLS 个部分和按级两两相加）
//  ---------------------------------------------------------------------------
//  与 V3 的对应：model.py 的 _reduce_tree()，把 (batch, tile_rows, tile_cols,
//  pe_per_tile) 沿 tile_cols 维归约成 (batch, tile_rows, pe_per_tile)。
//      级数 = ceil(log2(TILE_COLS))      （目标 TILE_COLS=32 -> 5 级）
//  这与仓库既有设计的**串行** shift_adder 是结构性差别：V3 是树，这里是树。
//
//  ---------------------------------------------------------------------------
//  对齐策略：**左移到最小指数**（精确，不丢位）
//  ---------------------------------------------------------------------------
//  每个部分和形如 (sum, exp)，值 = sum * 2^exp。两级相加时：
//      e = min(ea, eb)
//      out = (sa <<< (ea-e)) + (sb <<< (eb-e))     // 两个移位量都 >= 0
//  左移是精确的，所以**树的归约结果与串行累加逐位相同** —— 这是 tb 检查项 [5]
//  的依据。（注意不能对齐到**最大**指数：那需要右移，会丢低位。）
//  移位量超过 RED_PAD 时饱和并置粘滞位（o_sticky），避免累加器无界增长。
//
//  ---------------------------------------------------------------------------
//  时序：**支持流水化**（`PIPE`）
//  ---------------------------------------------------------------------------
//      PIPE = 1     -> 纯组合：整棵 LVLS 级级联在一个拍长内穿过
//      PIPE = LVLS  -> 每拍穿一级：每级的组合深度只有 **一级加法**
//  代价是级间寄存器：每行需要 TILE_COLS-1 个槽位（树每级减半），
//  即 NROW x (TILE_COLS-1) 个 (RW+EXPW) 位寄存器。
//  两种形态的**数值结果逐位相同**（加法与对齐都是精确的）。
//
//  控制信号对齐 V3 的 MxControlTrace：
//      max_exponent / alignment_distance / valid_mask / zero_mask /
//      data_move_en / calc_en / reduction_stage
//
//  ---------------------------------------------------------------------------
//  注：**不**在这里做 max
//  ---------------------------------------------------------------------------
//  一个自然的想法是在这棵树上并一条 max 树，让 softmax 免掉求 max 扫描。
//  但 softmax 要的是**归约后 logits** 的最大值，而这棵树的叶子是**部分和** ——
//  部分和的最大值 ≠ 行输出的最大值（本模块做的是求和，不是逐元素取大）。
//  故 max 放在顶层对 logits 组合取大（同样 0 拍，见 yrr_v3_top.v），
//  本模块只负责加法树。
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_reduce #(
    parameter TILE_ROWS   = 2,
    parameter TILE_COLS   = 2,
    parameter PE_PER_TILE = 2,
    parameter TILE_K      = 4,
    parameter ACCW        = `MX_PROD_W + $clog2(TILE_K) + 1,
    parameter EXPW        = `MX_SCALE_W + 1,
    parameter RED_PAD     = 24,                     // 归约累加器额外位宽
    parameter PIPE        = 1                       // 1 = 纯组合；LVLS = 每拍一级
)(
    input  wire                                       clk,
    input  wire                                       rst_n,

    input  wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*ACCW-1:0] i_sums,
    input  wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*EXPW-1:0] i_exps,

    output wire [TILE_ROWS*PE_PER_TILE*(ACCW+RED_PAD)-1:0] o_sums,
    output wire [TILE_ROWS*PE_PER_TILE*EXPW-1:0]           o_exps,
    output wire                                            o_sticky,   // 任一路饱和
    // MxControl 观测（对齐 V3 的 MxControlTrace）
    output wire [EXPW-1:0]                                 o_max_exponent,
    output wire [7:0]                                      o_stages
);

    localparam NROW  = TILE_ROWS * PE_PER_TILE;     // 归约单元数 = 输出行数 m
    localparam RW    = ACCW + RED_PAD;              // 归约累加器宽
    localparam LVLS  = (TILE_COLS <= 1) ? 0 : $clog2(TILE_COLS);
    localparam SHW   = 10;                          // 移位量位宽（对齐距离）

    integer r, c, lvl, n, tr, pe, tix;
    reg signed [RW-1:0]     s [0:TILE_COLS-1];
    reg signed [EXPW-1:0]   e [0:TILE_COLS-1];
    reg signed [RW-1:0]     ns[0:TILE_COLS-1];
    reg signed [EXPW-1:0]   ne[0:TILE_COLS-1];
    reg signed [EXPW-1:0]   emax;
    reg [SHW-1:0]           da, db;
    reg                     stk_lvl;

    // ---- 一层的对齐相加（组合）-------------------------------------------
    // 把 a、b 左移到 max(ea,eb) 后相加；移位饱和时置粘滞。
    task automatic level_add;
        input  signed [RW-1:0]   sa;
        input  signed [EXPW-1:0] ea;
        input  signed [RW-1:0]   sb;
        input  signed [EXPW-1:0] eb;
        output signed [RW-1:0]   so;
        output signed [EXPW-1:0] eo;
        output                   stk;
        reg signed [SHW-1:0]     d;
        reg signed [RW-1:0]      xa, xb;
        begin
            eo = (ea < eb) ? ea : eb;      // 对齐到**最小**指数 -> 左移精确
            d  = ea - eo;  stk = 1'b0;
            xa = (d > RED_PAD) ? {RW{1'b0}} : (sa <<< d);
            if (d > RED_PAD) stk = 1'b1;
            d  = eb - eo;
            xb = (d > RED_PAD) ? {RW{1'b0}} : (sb <<< d);
            if (d > RED_PAD) stk = 1'b1;
            so = xa + xb;
        end
    endtask

    reg                    k_sticky;
    reg  [EXPW-1:0]        k_maxexp;
    reg  [NROW*RW-1:0]     k_sums;
    reg  [NROW*EXPW-1:0]   k_exps;

    // 对齐相加的**函数版**（末级组合输出要在 generate 的 assign 里用，
    // 而 task 不能出现在连续赋值里）
    function signed [RW-1:0] align_add;
        input signed [RW-1:0]   sa, sb;
        input signed [EXPW-1:0] ea, eb;
        reg signed [EXPW-1:0]   eo;
        reg signed [SHW-1:0]    d;
        reg signed [RW-1:0]     xa, xb;
        begin
            eo = (ea < eb) ? ea : eb;
            d  = ea - eo;
            xa = (d > RED_PAD) ? {RW{1'b0}} : (sa <<< d);
            d  = eb - eo;
            xb = (d > RED_PAD) ? {RW{1'b0}} : (sb <<< d);
            align_add = xa + xb;
        end
    endfunction

    function signed [EXPW-1:0] align_exp;
        input signed [EXPW-1:0] ea, eb;
        begin
            align_exp = (ea < eb) ? ea : eb;
        end
    endfunction

    always @(*) begin
        k_sticky = 1'b0;
        k_maxexp = {EXPW{1'b0}};
        for (r = 0; r < NROW; r = r + 1) begin
            // 装填本行的 TILE_COLS 个部分和
            //  !! 索引必须与 mx_array 的打包顺序一致：[(tile_row*TILE_COLS+tile_col)*PE_PER_TILE + pe]
            tr = r / PE_PER_TILE;
            pe = r % PE_PER_TILE;
            for (c = 0; c < TILE_COLS; c = c + 1) begin
                tix = (tr*TILE_COLS + c)*PE_PER_TILE + pe;
                s[c] = $signed(i_sums[tix*ACCW +: ACCW]);
                e[c] = $signed(i_exps[tix*EXPW +: EXPW]);
            end
            // 逐级两两归约
            n = TILE_COLS;
            for (lvl = 0; lvl < LVLS; lvl = lvl + 1) begin
                for (c = 0; c < n; c = c + 2) begin
                    if (c + 1 < n) begin
                        level_add(s[c], e[c], s[c+1], e[c+1],
                                  ns[c/2], ne[c/2], stk_lvl);
                        k_sticky = k_sticky | stk_lvl;
                    end else begin
                        ns[c/2] = s[c];
                        ne[c/2] = e[c];
                    end
                end
                for (c = 0; c < (n+1)/2; c = c + 1) begin
                    s[c] = ns[c];
                    e[c] = ne[c];
                end
                n = (n + 1) / 2;
            end
            k_sums[r*RW +: RW] = s[0];
            k_exps[r*EXPW +: EXPW] = e[0];
            if (e[0] > k_maxexp) k_maxexp = e[0];   // 结果的指数
        end
    end

    // ======================================================================
    //  流水路径（PIPE > 1）：每拍穿一级
    // ======================================================================
    //  结构：级 0（组合取自阵列输出）-> 级 1 -> ... -> 级 LVLS
    //  每个时钟周期，**所有级并行**各做一次"本级加法"，结果推入下一级；
    //  一个值从级 0 进入，经 LVLS 拍到达输出。每级的组合深度 = 一级加法。
    //
    //  槽位布局：级 l 的第 r 行第 c 个节点在 ds[l*PSTR + r*TILE_COLS + c]
    //  第 l 级只有 TILE_COLS >> l 个节点（树每级减半），故寄存器总数
    //  = NROW x (TILE_COLS-1)，无多余浪费。
    localparam integer PSTR = NROW * TILE_COLS;

    reg signed [RW-1:0]   ds [0:(LVLS+1)*PSTR-1];
    reg signed [EXPW-1:0] de [0:(LVLS+1)*PSTR-1];
    reg                   p_sticky;      // 粘滞（诊断用，跨拍累积）

    // 级 0 的输入（组合取自阵列输出；阵列输出在 P_MAC 之后由 mx_pe 保持稳定）
    reg signed [RW-1:0]   s0 [0:PSTR-1];
    reg signed [EXPW-1:0] e0 [0:PSTR-1];

    // !! 每个 always 块**必须用各自独立**的循环变量 !!
    // iverilog 的 @* 会把循环变量并入敏感表 —— 若两个组合块共用同一个 integer，
    // 一方改写它就会触发另一方，形成**零延迟无限循环**（仿真起不来）。
    integer l4, r4, c4, tr4, pe4, tix4;   // always @(*)：级 0 输入
    integer l7, r7, c7;                    // always @(posedge)：流水寄存器
    reg signed [RW-1:0]   ys;
    reg signed [EXPW-1:0] eys;
    reg                   ysk;

    always @(*) begin
        for (r4 = 0; r4 < NROW; r4 = r4 + 1) begin
            tr4 = r4 / PE_PER_TILE;
            pe4 = r4 % PE_PER_TILE;
            for (c4 = 0; c4 < TILE_COLS; c4 = c4 + 1) begin
                tix4 = (tr4*TILE_COLS + c4)*PE_PER_TILE + pe4;
                s0[r4*TILE_COLS + c4] = $signed(i_sums[tix4*ACCW +: ACCW]);
                e0[r4*TILE_COLS + c4] = $signed(i_exps[tix4*EXPW +: EXPW]);
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (l7 = 0; l7 <= LVLS; l7 = l7 + 1)
                for (c7 = 0; c7 < PSTR; c7 = c7 + 1) begin
                    ds[l7*PSTR + c7] <= {RW{1'b0}};
                    de[l7*PSTR + c7] <= {EXPW{1'b0}};
                end
            p_sticky <= 1'b0;
        end else begin
            // 级 0 -> 级 1（本级 = 第 0 级）
            for (r7 = 0; r7 < NROW; r7 = r7 + 1)
                for (c7 = 0; c7 < (TILE_COLS >> 1); c7 = c7 + 1) begin
                    level_add(s0[r7*TILE_COLS + 2*c7], e0[r7*TILE_COLS + 2*c7],
                              s0[r7*TILE_COLS + 2*c7 + 1], e0[r7*TILE_COLS + 2*c7 + 1],
                              ys, eys, ysk);
                    ds[1*PSTR + r7*TILE_COLS + c7] <= ys;
                    de[1*PSTR + r7*TILE_COLS + c7] <= eys;
                    if (ysk) p_sticky <= 1'b1;
                end
            // 级 l -> 级 l+1（l = 1 .. LVLS-2，全部寄存器）
            for (l7 = 1; l7 < LVLS - 1; l7 = l7 + 1)
                for (r7 = 0; r7 < NROW; r7 = r7 + 1)
                    for (c7 = 0; c7 < (TILE_COLS >> (l7+1)); c7 = c7 + 1) begin
                        level_add(ds[l7*PSTR + r7*TILE_COLS + 2*c7],
                                  de[l7*PSTR + r7*TILE_COLS + 2*c7],
                                  ds[l7*PSTR + r7*TILE_COLS + 2*c7 + 1],
                                  de[l7*PSTR + r7*TILE_COLS + 2*c7 + 1],
                                  ys, eys, ysk);
                        ds[(l7+1)*PSTR + r7*TILE_COLS + c7] <= ys;
                        de[(l7+1)*PSTR + r7*TILE_COLS + c7] <= eys;
                        if (ysk) p_sticky <= 1'b1;
                    end
        end
    end

    // ---- 两条路径的接口选择（只例化一条）----
    genvar gr5;
    generate
        if (PIPE <= 1) begin : g_comb
            assign o_sums         = k_sums;
            assign o_exps         = k_exps;
            assign o_sticky       = k_sticky;
            assign o_max_exponent = k_maxexp;
        end else begin : g_pipe
            // 末级组合输出：第 LVLS-1 级的输入在
            //   ds/de[(LVLS-1)*PSTR + r*TILE_COLS + {0,1}]
            // 用 assign + 函数展开，**不引入额外的 always 块**。
            for (gr5 = 0; gr5 < NROW; gr5 = gr5 + 1) begin : g_pack
                assign o_exps[gr5*EXPW +: EXPW] =
                    align_exp(de[(LVLS-1)*PSTR + gr5*TILE_COLS],
                              de[(LVLS-1)*PSTR + gr5*TILE_COLS + 1]);
                assign o_sums[gr5*RW +: RW] =
                    align_add(ds[(LVLS-1)*PSTR + gr5*TILE_COLS],
                              ds[(LVLS-1)*PSTR + gr5*TILE_COLS + 1],
                              de[(LVLS-1)*PSTR + gr5*TILE_COLS],
                              de[(LVLS-1)*PSTR + gr5*TILE_COLS + 1]);
            end
            // 观察用：流水路径下取末级第 0 行的指数（顶层不消费该信号）
            assign o_max_exponent = o_exps[0 +: EXPW];
            assign o_sticky       = p_sticky;
        end
    endgenerate

    assign o_stages = LVLS[7:0];

endmodule