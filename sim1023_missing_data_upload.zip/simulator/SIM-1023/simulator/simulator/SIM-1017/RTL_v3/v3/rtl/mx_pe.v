`timescale 1ns/1ps

//=============================================================================
//  mx_pe.v  —— MXFP4 处理单元（一个 PE = 一个输出行在一段 k 上的点积）
//  ---------------------------------------------------------------------------
//  与 V3 的对应：V3 的 "PE" 每个算 tile_k 个 MAC（model.py 的
//  pe_count * tile_k），本模块就是那一个 PE。
//
//  计算（全部整数、无舍入）：
//      prod[k] = fp4_int(w[k]) * fp4_int(x[k])          // 码值 x2，signed 5x5 -> 9
//      sum     = Σ prod[k]                              // 精确，ACCW 位有符号
//      exp     = w_scale + x_scale - 2*BIAS - 2         // 值 = sum * 2^exp
//  其中 -2 还原"码值 x2"。权重与输入共用同一个 E8M0 尺度（每 32 元素一个，
//  与 formats.decode_fp4 的 scale.repeat(32) 一致）。
//
//  参考：model.py 的 partials[b,r,c,:] = inputs[:,ks] @ weights[rows,ks].T
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_pe #(
    parameter TILE_K = 4,                                    // 覆盖的 k 元素数
    parameter ACCW   = `MX_PROD_W + $clog2(TILE_K) + 1,      // 累加位宽
    parameter EXPW   = `MX_SCALE_W + 1,                       // 指数位宽（有符号）
    // 0 = 矩阵乘法与累加**合并一拍**（`CAL_PE_DELAY_NS = 0.97 ns` 的实测口径）
    // 1 = **各占一拍**（新思结构口径，默认由 yrr_v3_top 传入）：乘积先寄存，
    //     第 2 拍再做平衡树累加，`o_valid` 相应延后 2 拍
    parameter PIPE   = 0
)(
    input  wire                        clk,
    input  wire                        rst_n,

    input  wire [TILE_K*`MX_FP4_W-1:0] i_w_payload,          // TILE_K 个 FP4 码
    input  wire [`MX_SCALE_W-1:0]      i_w_scale,            // 1 个 E8M0
    input  wire [TILE_K*`MX_FP4_W-1:0] i_x_payload,
    input  wire [`MX_SCALE_W-1:0]      i_x_scale,

    input  wire                        i_valid,              // 与阵列 MAC 相位同步

    output reg  signed [EXPW-1:0]      o_exp,                // 值 = o_sum * 2^o_exp
    output reg  signed [ACCW-1:0]      o_sum,
    output reg                         o_valid
);

    `include "mx_fmt_funcs.vh"

    integer i;
    reg signed [`MX_PROD_W-1:0] prod [0:TILE_K-1];
    reg signed [`MX_PROD_W-1:0] wa, xa;   // 必须先加宽到 9bit 再相乘
                                          // （两个 5bit 直接乘，Verilog 会按 5bit 截断）

    // ---- 组合：TILE_K 路乘积（并行） ----------------------------------------
    always @(*) begin
        for (i = 0; i < TILE_K; i = i + 1) begin
            wa = mx_fp4_int(i_w_payload[i*`MX_FP4_W +: `MX_FP4_W]);
            xa = mx_fp4_int(i_x_payload[i*`MX_FP4_W +: `MX_FP4_W]);
            prod[i] = wa * xa;
        end
    end

    // ---- 可选的"乘法 / 累加 各占一拍"--------------------------------------
    //  **新思口径：矩阵乘法 1 拍 + 累加 1 拍**（PIPE=1）。此时乘积先寄存一拍，
    //  第 2 拍再做平衡树累加；`o_valid` 相应延后 2 拍（由 mx_ctrl 的 MAC_STAGES 对齐）。
    reg signed [`MX_PROD_W-1:0] prod_r [0:TILE_K-1];
    reg v1;
    wire signed [`MX_PROD_W-1:0] src [0:TILE_K-1];
    genvar gs;
    generate
        for (gs = 0; gs < TILE_K; gs = gs + 1) begin : g_src
            assign src[gs] = (PIPE != 0) ? prod_r[gs] : prod[gs];
        end
    endgenerate

    // ---- 累加：**平衡树**，不是串行链 --------------------------------------
    //  !! 累加延迟必须算进 PE 的延迟里 !! 早期写成
    //      acc = 0; for (i...) acc = acc + prod[i];      // TILE_K 级串行
    //  按 .vh 的 DELAY_FA_NS = 0.032 ns/bit-slice 外推：
    //      一个 ACCW(15) 位加法 ≈ 15 x 0.032 = 0.48 ns
    //      串行链 = 32 x 0.48 = **15.36 ns** —— 而实测 PE 核只有 0.97 ns，
    //  两者差 15 倍。纯加法可结合，综合器会重排成树，但 RTL 字面是链，
    //  **按字面评估会把计算延迟高估一个数量级**。
    //  平衡树深度 = ceil(log2(TILE_K)) = 5 级，与实测值自洽。
    localparam integer AKLVL = (TILE_K <= 1) ? 1 : $clog2(TILE_K);
    localparam integer AKPAD = (1 << AKLVL);
    wire signed [ACCW-1:0] ak_lv [0:(AKLVL+1)*AKPAD-1];   // 级 l 的第 i 个 = ak_lv[l*AKPAD+i]

    genvar gkl, gki;
    generate
        for (gki = 0; gki < AKPAD; gki = gki + 1) begin : g_ak0
            // **必须显式符号扩展**：prod 是 9 bit 有符号，而三元表达式里一旦
            // 混入无符号常量（{ACCW{1'b0}}），整个表达式就变成无符号 ——
            // 负积会被零扩展，结果全错。故先取到 9 bit 再手写符号位扩展。
            wire signed [`MX_PROD_W-1:0] pv =
                (gki < TILE_K) ? src[gki] : {`MX_PROD_W{1'b0}};
            assign ak_lv[gki] = {{(ACCW-`MX_PROD_W){pv[`MX_PROD_W-1]}}, pv};
        end
        for (gkl = 0; gkl < AKLVL; gkl = gkl + 1) begin : g_akl
            for (gki = 0; gki < (AKPAD >> (gkl+1)); gki = gki + 1) begin : g_aki
                assign ak_lv[(gkl+1)*AKPAD + gki] =
                    ak_lv[gkl*AKPAD + 2*gki] + ak_lv[gkl*AKPAD + 2*gki + 1];
            end
        end
    endgenerate

    wire signed [ACCW-1:0] acc = ak_lv[AKLVL*AKPAD];

    // ---- 时序：输出寄存（1 拍，与仓库既有 pe_core 的 PE_LATENCY=1 同）------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_sum   <= {ACCW{1'b0}};
            o_exp   <= {EXPW{1'b0}};
            o_valid <= 1'b0;
            v1      <= 1'b0;
            for (i = 0; i < TILE_K; i = i + 1) prod_r[i] <= {`MX_PROD_W{1'b0}};
        end else begin
            o_sum   <= acc;
            o_exp   <= $signed({1'b0, i_w_scale}) + $signed({1'b0, i_x_scale})
                       - (2*`MX_E8M0_BIAS + 2);
            if (PIPE != 0) begin
                if (i_valid) for (i = 0; i < TILE_K; i = i + 1) prod_r[i] <= prod[i];
                v1      <= i_valid;
                o_valid <= v1;          // 2 拍后有效
            end else begin
                o_valid <= i_valid;     // 1 拍后有效
            end
        end
    end

endmodule