`timescale 1ns/1ps

//=============================================================================
//  mx_array.v  —— MXFP4 tile 阵列（TILE_ROWS x TILE_COLS）+ 输入广播网络
//  ---------------------------------------------------------------------------
//  与 V3 的对应：
//      tile_count  = TILE_ROWS * TILE_COLS        （目标 32*32 = 1024）
//      pe_count    = tile_count * PE_PER_TILE     （目标 1024*32 = 32768）
//      输出行 m    = TILE_ROWS * PE_PER_TILE      （目标 1024）
//      k 分块      = TILE_COLS 段，每段 TILE_K    （目标 32 段 x 32）
//
//  两条装载通路（与 RTL 既有设计一致的非对称策略）：
//      权重：**按 tile 定向**装载（来自 PHY；每个 tile 只拿自己那一段权重）
//      输入：**TILE_COLS 路广播**，一次扇出到全部 tile（V3 的 input_broadcast）
//
//  ---------------------------------------------------------------------------
//  输入广播是 **TILE_COLS 路**，不是 1 路（本轮修改）
//  ---------------------------------------------------------------------------
//  数据依赖：tile(tr, tc) 要的是 x 的第 tc 段 —— **只看 tc**。所以
//      同一**列**的 TILE_ROWS 个 tile 需要**完全相同**的一段（列内仍是广播），
//      不同列需要**不同**的段。
//  旧实现用 1 路总线送所有段，每拍带一个列号、由 x_hit 只放行一列 ——
//  一份数据送 1024 个接收端而只有 32 个用得上，且必须 TILE_COLS 拍。
//  现改为 TILE_COLS 路：第 gc 路只喂第 gc 列（扇出 TILE_ROWS），
//  一次 i_x_we 全部列同时写入 —— 分发拍数与 TILE_COLS 无关。
//  能耗不变：两方案的"总线翻转次数 x 长度"与接收端装载位数完全相同。
//
//  计算：所有 tile 同时算自己那一段 k 的部分和，输出
//      o_sums[tile][pe] / o_exps[tile][pe]   —— 交给 mx_reduce 做树形归约。
//
//  地址：tile 线性号 t = tile_row * TILE_COLS + tile_col
//=============================================================================

`include "mx_fmt_defs.vh"

module mx_array #(
    parameter TILE_ROWS   = 2,
    parameter TILE_COLS   = 2,
    parameter PE_PER_TILE = 2,
    parameter TILE_K      = 4,
    parameter ACCW        = `MX_PROD_W + $clog2(TILE_K) + 1,
    parameter EXPW        = `MX_SCALE_W + 1,
    parameter PE_PIPE     = 0
)(
    input  wire                        clk,
    input  wire                        rst_n,

    // ---- 权重定向装载：一次一行（tile + 该 tile 内的 PE 行）----
    input  wire                        i_w_we,
    input  wire [$clog2(TILE_ROWS*TILE_COLS)-1:0] i_w_tile,
    input  wire [$clog2(PE_PER_TILE)-1:0]         i_w_addr,
    input  wire [TILE_K*`MX_FP4_W-1:0] i_w_payload,
    input  wire [`MX_SCALE_W-1:0]      i_w_scale,

    // ---- 输入广播装载：TILE_COLS 路，一次写入，各路扇出自己那一列 ----
    input  wire                        i_x_we,
    input  wire [TILE_COLS*TILE_K*`MX_FP4_W-1:0] i_x_payload,  // 每列一段 k
    input  wire [TILE_COLS*`MX_SCALE_W-1:0]      i_x_scale,

    // ---- 计算 ----
    input  wire                        i_calc_en,

    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*ACCW-1:0] o_sums,
    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*EXPW-1:0] o_exps,
    output wire                        o_valid
);

    localparam NTILE = TILE_ROWS * TILE_COLS;

    genvar gr, gc;
    generate
        for (gr = 0; gr < TILE_ROWS; gr = gr + 1) begin : g_row
            for (gc = 0; gc < TILE_COLS; gc = gc + 1) begin : g_col
                localparam integer T = gr * TILE_COLS + gc;

                wire                     t_vld;
                wire [PE_PER_TILE*ACCW-1:0] t_sums;
                wire [PE_PER_TILE*EXPW-1:0] t_exps;
                wire                     w_hit;   // 本次权重写是否命中本 tile
                wire                     x_hit;   // 本次广播是否命中本 tile 的 k 段

                // 本 tile 取**自己那一列**的那一路广播（一次 i_x_we 全体同时写入）。
                // 列内的 TILE_ROWS 个 tile 拿到的是同一份数据 —— 它们算不同的输出行。
                wire [TILE_K*`MX_FP4_W-1:0] x_pay =
                    i_x_payload[gc*TILE_K*`MX_FP4_W +: TILE_K*`MX_FP4_W];
                wire [`MX_SCALE_W-1:0]      x_scl =
                    i_x_scale[gc*`MX_SCALE_W +: `MX_SCALE_W];

                assign w_hit = i_w_we && (i_w_tile == T);
                assign x_hit = i_x_we;

                mx_tile #(.TILE_K(TILE_K), .PE_PER_TILE(PE_PER_TILE),
                          .ACCW(ACCW), .EXPW(EXPW), .PE_PIPE(PE_PIPE)) u_tile (
                    .clk        (clk),
                    .rst_n      (rst_n),
                    .i_w_we     (w_hit),
                    .i_w_addr   (i_w_addr),
                    .i_w_payload(i_w_payload),
                    .i_w_scale  (i_w_scale),
                    .i_x_we     (x_hit),
                    .i_x_payload(x_pay),
                    .i_x_scale  (x_scl),
                    .i_calc_en  (i_calc_en),
                    .o_valid    (t_vld),
                    .o_sums     (t_sums),
                    .o_exps     (t_exps)
                );

                assign o_sums[T*PE_PER_TILE*ACCW +: PE_PER_TILE*ACCW] = t_sums;
                assign o_exps[T*PE_PER_TILE*EXPW +: PE_PER_TILE*EXPW] = t_exps;
                if (T == 0) assign o_valid = t_vld;
            end
        end
    endgenerate

endmodule