# Historical RTL_v3 reference

The simulator no longer reads area_synth.json or derives area from gate counts. Current inputs and source-report locations are documented in [README_SIM-1017.md](../../../README_SIM-1017.md). RTL_v3 is a numerical/reference snapshot, not the active RTL_1017SIM characterization.
