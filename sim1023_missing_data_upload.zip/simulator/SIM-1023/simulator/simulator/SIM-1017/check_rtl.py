#!/usr/bin/env python3
"""RTL <-> Python 交叉验证：把 RTL/v3 的 golden_v3.txt 与 run_v3 逐项比对。

向量由**同一组哈希**在两侧生成（RTL: tb/mx_tb_vectors.vh；这里：本文件），
所以这是真正的端到端一致性检查，而不是趋势对比。

用法：
    cd RTL/v3 && MX_DEFS="-DMX_SIM_INIT -DMX_GOLDEN" sh run_tb.sh
    cd simulator/V3 && python check_rtl.py ../../../RTL/v3/golden_v3.txt
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from yrr_v3 import V3Config, run_v3  # noqa: E402

MASK = 0x7FFFFFFF
INCOMPATIBLE = 3


def default_golden_path() -> Path | None:
    """Find current RTL_v3 golden data, with legacy layout fallbacks."""
    candidates = (
        ROOT / "RTL_v3" / "v3" / "golden_v3.txt",
        ROOT.parents[1] / "RTL_v3" / "v3" / "golden_v3.txt",
        ROOT.parents[1] / "RTL" / "v3" / "golden_v3.txt",
        ROOT.parents[2] / "RTL_v3" / "v3" / "golden_v3.txt",
        ROOT.parents[2] / "RTL" / "v3" / "golden_v3.txt",
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


# ---- 与 tb/mx_tb_vectors.vh 逐行等价的哈希 ----
def wcode(t: int, p: int, k: int) -> int:
    x = (t * 1103515245 + p * 12345 + k * 7919 + 2531011) & MASK
    x = ((x >> 16) ^ x) & MASK
    return x & 0xF


def xcode(c: int, k: int) -> int:
    x = (c * 22695477 + k * 104729 + 1013904223) & MASK
    x = ((x >> 13) ^ x) & MASK
    return x & 0xF


def wscale(tr: int, p: int) -> int:
    x = (tr * 69069 + p * 362437 + 7) & MASK
    x = ((x >> 11) ^ x) & MASK
    return 127 + (x % 5) - 2


def xscale(c: int) -> int:            # RTL 里是常数 127
    return 127


def load_golden(path: Path) -> dict:
    g = {"params": {}, "cycles": {}, "wrow": [], "logit": {}, "softmax": {}}
    for line in path.read_text(encoding="utf-8").splitlines():
        f = line.split()
        if not f or f[0].startswith("#"):
            continue
        if f[0] == "PARAM":
            g["params"][f[1]] = int(f[2], 0)
        elif f[0] == "CYCLE":
            g["cycles"][f[1]] = int(f[2], 0)
        elif f[0] == "WROW":                       # tile pe row payload scale
            g["wrow"].append((int(f[1]), int(f[2]), int(f[3]), int(f[4], 16), int(f[5])))
        elif f[0] == "LOGIT":
            g["logit"][int(f[1])] = float(f[2])
        elif f[0] == "SOFTMAX":
            g["softmax"][int(f[1])] = float(f[2])
    return g


def main() -> int:
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else default_golden_path()
    if path is None:
        print("RTL V3 golden_v3.txt was not found.")
        print("Generate it with: cd RTL_v3/v3 && MX_DEFS='-DMX_SIM_INIT -DMX_GOLDEN' sh run_tb.sh")
        return 2
    if not path.exists():
        print(f"找不到 {path}；先跑：cd RTL/v3 && MX_DEFS='-DMX_SIM_INIT -DMX_GOLDEN' sh run_tb.sh")
        return 2

    g = load_golden(path)
    p = g["params"]
    required = ("TILE_ROWS", "TILE_COLS", "PE_PER_TILE", "TILE_K")
    missing = [name for name in required if name not in p]
    if missing:
        print(f"RTL golden is malformed; missing PARAM fields: {', '.join(missing)}")
        return 2
    TR, TC, PP, TK = (p[name] for name in required)
    if min(TR, TC, PP, TK) < 1:
        print("RTL golden is malformed; structural parameters must be positive")
        return 2
    if TK != 32:
        print("RTL/Python cross-check is pending: incompatible MXFP4 block width.")
        print(f"  golden: TILE_K={TK}, TILE_COLS={TC}")
        print("  Python V3 requires one external block = 32 FP4 elements = 128-bit payload + 8-bit E8M0 scale.")
        print("  Re-run after the server RTL exports TILE_K=32 vectors; no padding or legacy arithmetic is applied.")
        return INCOMPATIBLE
    M, K = TR * PP, TC * TK

    # ---- 按 V3 的布局构造权重/输入（与 RTL 的 mem[] 同源）----
    W = np.zeros((M, K), dtype=np.uint8)
    WS = np.zeros((M, max(1, K // 32)), dtype=np.uint8)
    # golden 的 WROW 是 <tile> <pe> <row> <payload> <scale>；tile = tile_row*TC + tile_col
    for tile, pe, row, payload, scale in g["wrow"]:
        tr, tc = tile // TC, tile % TC
        for kk in range(TK):
            W[tr * PP + pe][tc * TK + kk] = (payload >> (4 * kk)) & 0xF
        if tc >= WS.shape[1]:
            print(f"RTL golden WROW scale group {tc} exceeds {WS.shape[1]} groups")
            return 2
        WS[tr * PP + pe][tc] = scale
    X = np.zeros((1, K), dtype=np.uint8)
    XS = np.zeros((1, max(1, K // 32)), dtype=np.uint8)
    for tc in range(TC):
        for kk in range(TK):
            X[0][tc * TK + kk] = xcode(tc, kk)
        XS[0][tc] = xscale(tc)

    cfg = V3Config(m=M, n=M, k=K, tile_rows=TR, tile_k=TK, pe_per_tile=PP, batch=1)
    r = run_v3(cfg, weight_payload=W, weight_scale=WS,
               input_payload=X, input_scale=XS)

    print("=" * 68)
    print("RTL <-> Python 交叉验证")
    print("=" * 68)
    print(f"配置: TILE_ROWS={TR} TILE_COLS={TC} PE_PER_TILE={PP} TILE_K={TK} -> m={M}, k={K}")

    errs = 0
    print("\n-- logits（归约结果）--")
    print(f"{'行':>4s} {'RTL(Q16.16)':>14s} {'Python f32':>14s} {'|差|':>12s}")
    for i in range(M):
        rt = g["logit"][i]
        py = float(r.logits_hardware[0][i])
        d = abs(rt - py)
        flag = "" if d < 1e-3 * max(1.0, abs(py)) else "  <== 不符"
        if flag:
            errs += 1
        print(f"{i:4d} {rt:14.6f} {py:14.6f} {d:12.3e}{flag}")

    print("\n-- softmax --")
    print(f"{'行':>4s} {'RTL(Q16.16)':>14s} {'Python f64':>14s} {'|差|':>12s}")
    for i in range(M):
        rt = g["softmax"][i]
        py = float(r.softmax_output[0][i])
        d = abs(rt - py)
        flag = "" if d < 2e-2 else "  <== 不符"
        if flag:
            errs += 1
        print(f"{i:4d} {rt:14.6f} {py:14.6f} {d:12.3e}{flag}")

    s_rtl = sum(g["softmax"].values())
    print(f"\nRTL softmax 和 = {s_rtl:.6f}（应为 1）")
    if abs(s_rtl - 1.0) > 1e-2:
        errs += 1
        print("  <== 概率和偏离 1")

    print("\n-- 周期（RTL 实测，V3 的周期账另计）--")
    for k, v in g["cycles"].items():
        print(f"  {k:10s} {v}")
    print(f"  参考: V3 抽象账 critical_path={r.report['cycles']['critical_path']} 拍")

    print("\n" + "=" * 68)
    print("  CROSS-CHECK: ALL PASS" if errs == 0
          else f"  CROSS-CHECK: FAIL ({errs} 处不符)")
    print("=" * 68)
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
