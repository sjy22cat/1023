# 给 RTL 同事的 V3 补充模块说明（新手版）

> **Current SIM-1017 SRAM contract (2026-10-19):** use 32 banks, each with a 128-row x 128-bit payload macro and a separate 128-row x 8-bit E8M0 scale macro. This is 64 KiB payload plus 4 KiB sideband (68 KiB physical pair). Any 512 KiB capacity mentioned below is historical context; the RTL interface and per-cycle bandwidth remain 32 x 128-bit payload plus 32 x 8-bit scale.

> 历史设计/验证记录：正文保留原始背景，其中旧参数路径、估算方法、命令与性能数字不适用于当前版本，请勿据此运行或发布结果。当前参数、运行方式和限制以 [README_SIM-1017.md](../README_SIM-1017.md) 为准；RTL 实测交付见 [RTL_instruction.md](../../../Instruction/RTL_instruction.md)。

这份说明从零描述需要补齐的硬件功能。**请按这里的功能要求实现，不需要先读旧工程，也不需要沿用旧工程的模块名或结构。**

## 现在已经有的东西

按目前约定，已有三个可以接入的 RTL 单元：

1. **PE**：乘法和局部计算单元。它需要按本文的 E3/M10、32-lane 和饱和规则确认或补齐接口与行为。
2. **格式转换译码器**：负责 RRAM-FP/TAG-FP 相关码值转换或译码。转换逻辑已经在服务器实现，**不要重新写一套 LUT**。需要把接口接好，并提供实际位宽和逐码对照数据。
3. **BF16→FP32 移位加法器**：可作为浮点格式转换或加法中的已有单元复用。它不能自动代替本文要求的 MX 指数对齐、20-bit 有限位宽归约和 skip 控制；只有接口与数值行为都验证一致的部分才能复用。

本文所说的“新增模块”是新增功能边界；同事可以把几个功能放在同一个 Verilog/SystemVerilog 模块里，也可以拆成多个模块。模块名不重要，功能、数据格式、握手和可观测结果必须一致。

## 先分清哪些要做、哪些可以后做

要证明“矩阵乘法功能正确”，最少需要：输入/权重数据接口、Tile/PE 阵列连接、MX 对齐与 skip 控制、32 路 K-block 归约、任务控制和 logits 输出。没有这些，现有 PE 只是一个计算零件，还不能独立完成一次矩阵向量运算。

要评估周期、数据搬运和活动量，还要接上 Global SRAM/输入广播、Mem Die 权重装载接口、DMA 或等效的主机接口，以及计数器。第一轮可以由 testbench 直接灌 SRAM、模拟 Mem Die 和 DMA；但报告必须标明这是 testbench 模式，不能把它说成已测得的真实主机/DMA/存储器延迟或能耗。

Softmax 可以留到后续 RTL 阶段。第一阶段必须把每个样本的 1024 个 logits 完整交给 Python；Python 才能进一步计算稳定 softmax 和语言模型困惑度（PPL）。RRAM/FeRAM 宏、混合 3D 器件和相对 DRAM 的能耗收益也留待获得真实器件数据后校准。

## 一句话说明要做什么

硬件要完成一个矩阵向量运算：把 1024 个输出各自与 1024 个输入相乘累加，输出 1024 个 logits；阵列使用 1024 个 Tile、每 Tile 32 个 PE，每个 PE 一次处理 32 个 K 方向元素。数据进入 PE 前使用 RRAM-FP 权重格式和 TAG-FP 激活格式；计算时利用共享指数与有限位宽判断小贡献是否可以跳过；最后把每个输出的 32 个 K 分块 partial 合并起来。

这对应论文的格式和 skip 创新。RRAM/FeRAM 混合 3D 存储器的器件实现与能耗优势暂不要求在这版 RTL 中定论，等后续拿到器件和宏数据再校准。

## 数据怎么经过硬件

```text
主机/DMA 写入输入
        ↓
Global SRAM 保存输入 payload 和 E8M0 scale
        ↓
输入格式适配：MXFP4 → TAG-FP（接入已有服务器译码/转换 RTL）
        ↓
输入广播网络把一个 K block 送到对应列的 32 个输出行组
        ↓
每个 Tile 的 32 个 PE 与本地 RRAM-FP 权重做乘积和局部累加
        ↓
MX 控制器按 E3max / EMXmax 对齐，并决定哪些贡献可以跳过
        ↓
32 路 K-block 归约，得到每个输出的 logit
        ↓
输出 logits；如果本版 RTL 包含 softmax，再输出归一化概率
        ↓
DMA/主机读取结果
```

格式转换器需要先提供“输入位宽、输出位宽、字段含义、零值标记、valid/ready 延迟和固定码值对照”。本说明不规定 RRAM-FP/TAG-FP 的 LUT，也不假定还未确认的 wire 编码。零值标记和指数等必要 sideband 应与对应 payload 同拍、同 tag 传递。

权重在开始计算前从选中的 Mem Die 装入 Tile 本地权重缓存。权重常驻时，后续输入向量继续复用本地权重；切换到新层时再装入新权重。

## 阵列和编号规则

硬件目标参数如下：

| 项目 | 目标值 |
|---|---:|
| 输出数 M | 1024 |
| 输入长度 K | 1024 |
| Tile 阵列 | 32 行 × 32 列，共 1024 Tile |
| 每 Tile 的 PE | 32 |
| PE 总数 | 32768 |
| 每 PE 每次处理的 lane | 32 |
| K 分块数 | 32，每块 32 个元素 |
| 每个输出的 K-block partial 数 | 32 |
| 每个输入向量的理论 MAC 数 | 1,048,576 |

`Tile[r][c]` 中：

- `r` 是输出行组，范围 0 到 31。
- `c` 是 K 分块编号，范围 0 到 31。
- Tile 内第 `p` 个 PE 对应输出 `m = 32*r + p`。
- 每个 PE 读取这个输出行在 K block `c` 内的 32 个权重，与同一 K block 的 32 个输入相乘。
- 因此一个输出会从 32 个不同的 `c` 得到 32 个 partial，最后归约成一个 logit。

`batch` 是一次要处理的输入向量数量。它不是 K lane 数，也不是 K block 数。例如 batch=8 表示计算 8 个输入向量；每个向量仍然有 32 个 K block，每个 PE 仍然处理 32 个 lane。

每个 PE 都能并行处理 32 个 lane，因此全阵列一次可覆盖 1,048,576 个乘积。流水线可以有多拍延迟；请分别报告“一个向量从进入到结果出来的 latency”和“隔几拍可以接收下一个向量的 II”。只有 II=1 时，才能说稳态每拍接收一个向量。

## 还需要补齐的 RTL 功能

### 0. 所有模块先遵守同一套接口规矩

为了让 testbench 和 Python 能逐级对照，各模块都使用同一种握手语义：`valid=1` 表示上游给出的字段有效，`ready=1` 表示下游本拍能够接收；只有 `valid && ready` 同时为 1 才算真正传输。下游拉低 `ready` 时，上游必须保持 `payload、scale、zero_mask、batch_id、layer_id、tile_id、k_block、tag` 不变，不能偷偷前进或丢数据。

建议把下面这些宽度做成参数，而不是散落在代码里的常数：

| 参数 | 默认值 | 用途 |
|---|---:|---|
| `LANES` | 32 | 一个 PE 一次处理的 lane 数 |
| `PE_PER_TILE` | 32 | 一个 Tile 的 PE 数 |
| `K_BLOCKS` | 32 | 一个输出沿 K 方向收到的 partial 数 |
| `E3_BITS` | 3 | 产品/partial 的 E3 字段；数值编码按转换器交付资料解释 |
| `M10_BITS` | 10 | 产品有效数，二补码 |
| `SCALE_BITS` | 8 | E8M0 scale wire 宽度 |
| `ACC_BITS` | 20 | 本版有限位宽累加器 |
| `TAG_BITS`、`RRAM_BITS` | 由转换器给出 | TAG-FP、RRAM-FP 实际数据宽度 |

每一类数据都必须携带能把它放回原位置的索引：输入至少有 `batch_id、k_block、tag`，权重至少有 `layer_id、tile_id、k_block、tag`，partial 至少有 `batch_id、output_id、k_block、tag`。指数、scale、zero mask 是 payload 的 sideband，不能单独排队后再靠顺序猜测对应关系。

不要把“模块内部算完了”当作“系统完成了”。每一级都要有 `in_valid/in_ready` 和 `out_valid/out_ready`，并能在 trace 中看到握手发生的 cycle。

### 建议的实现顺序

先做一个可重复的小规模路径，再扩成目标阵列：

1. **单 PE/单 Tile**：用 32 lane 固定向量验证乘积、E3max、向 0 截断、20-bit 饱和和 zero mask。
2. **单输出的 32 个 K block**：验证 `EMXmax`、block skip 和 5 级归约；此时不需要实例化 1024 个输出。
3. **小阵列**：例如 2×2 Tile、每 Tile 2 PE，用带编号的权重确认路由和握手不会串数据。
4. **正式阵列**：恢复 32×32 Tile、每 Tile 32 PE，并保留同一套接口和 golden。
5. **性能/活动模式**：接入 SRAM bank、广播、Mem Die、DMA 和计数器；功能不变，只增加资源时间线和 gate 活动记录。

### 1. Tile：把 32 个 PE 组成一个可用计算块

**做什么：**一个 Tile 管理同一个输出行组和同一个 K block 的 32 个 PE。它保存这组权重，接收这一组输入，启动 32 个 PE，并收集 32 个 partial。

**必须完成：**

- 保存 32 个 PE 各自的 32 个权重码；每个 PE/K block 都要保存它自己的 E8M0 权重 scale，不能让 32 个 PE 错误共用一个 weight scale。
- 接收一个 32-lane activation block、对应 E8M0 input scale，以及 batch、layer、K-block 编号。
- 把输入和每个 PE 对应的权重送到 PE；TAG zero lane 不应更新对应 PE 的无效数据通路。
- 输出 32 个 PE 的 `partial_mantissa`、`partial_exponent`、valid、零值/跳过信息和饱和计数。
- 只有当输入握手成功（`valid && ready`）后才消费输入。被下游阻塞时，输出数据和编号必须保持不变。

**怎么验收：**给一个 Tile 一组固定权重和输入，32 个 PE 的结果能与 Python 逐 PE、逐 lane 对照；对未接收输入的周期，检查输入和状态没有被错误覆盖。

### 2. Tile Array：组成 32×32 阵列并发出计算

**做什么：**连接 1024 个 Tile，按固定编号把权重和输入送到正确位置，并把 32768 个 PE 的 partial 交给后面的归约逻辑。

**必须完成：**

- 实例化或等效实现 32×32 Tile，每个 Tile 含 32 个 PE。
- 权重索引按 `W[32*r+p][32*c+l]`；输入索引按 `X[batch][32*c+l]`。
- 一个 K block 输入需要送到 `Tile[0][c]` 到 `Tile[31][c]`，也就是同一列的 32 个输出行组。
- 阵列输出保持 `batch、r、c、p` 对应关系，避免不同输出、K block 或 batch 的 partial 混在一起。
- 支持参数化小阵列做仿真，同时保证正式配置是 32×32 Tile、每 Tile 32 PE、每 PE 32 lane。

**怎么验收：**对一组输出标记不同的权重/输入，确认数据只到预期 Tile/PE；检查每个输出恰好收齐 32 个 K-block partial。

### 3. 输入 SRAM 和广播网络

**做什么：**保存主机送来的输入，再把每个 K block 同时送到多个输出行组。

**建议目标接口：**Global SRAM 有 32 个 bank；每个 bank 一次读出 128-bit MXFP4 payload 和 8-bit E8M0 scale。32 个 bank 分别对应 32 个 K block。总容量目标为 512 KiB，输入最好有 ping-pong 双缓冲。

**必须完成：**

- 输入 payload 和 scale 分开保存、但地址和有效状态必须对应同一组 32 个元素。
- 提供写入、读出、页号/缓冲区编号、ready/valid 和 bank busy/stall 状态。
- 一个 full-bandwidth 输入拍可同时读出 32 个 K block：payload 源端总计 4096 bit，scale 共 256 bit。
- 每个 K block 要广播给 32 个输出行组。源 SRAM 只读一份，广播网络的复制流量要另行统计，不能把复制量说成 SRAM 源端读取量。
- 如果端口数少于 32，先分多拍预取到输入 buffer；只有 32 个 K block 都 ready 后才启动满阵列计算。报告实际预取拍数，不能仍声称该配置每拍满供 32 个 K block。
- 广播前若已转换成 TAG-FP，广播宽度要按服务器实际 TAG 位宽计算。当前 Python 暂按 5 bit/元素；等同事拿到服务器数据后更新。格式转换本身使用已有服务器 RTL，不重新实现 LUT。
- block/lane skip 关闭了某一级活动时，只有实际被关闭的 SRAM 读、广播或 Tile 写入才能计作节省；上游已经发生的读取照实统计。

**建议提供的计数：**SRAM 读写字节数、每拍 source bits、广播复制 bits、Tile 输入 buffer 写次数、每 bank stall 周期、输入预取周期。

### 4. 权重装载、本地权重缓存和双 Mem Die 接口

**做什么：**两颗 Mem Die 提供相同接口。控制器按 layer 映射选一颗 Die，把权重装入对应 Tile。计算时权重留在 Tile 本地缓存。

**必须完成：**

- 两个接口字段、时序和能力相同，至少有 `request valid/ready` 和 `response valid/ready`。
- 请求和响应带 `die_id、layer_id、tile_id 或 tile_row/tile_k、address、length、tag`。
- 同一 layer 默认只从映射到的 Die 读取；不同请求的响应靠 tag 配回原请求。
- 首次使用某层时装载权重；同层后续 batch 不重复装载；切换 layer 时重新装载。
- 每颗 Die 记录读取字节、请求数、活跃周期、队列等待周期和错误状态。
- 请求队列满或 Die 未 ready 时必须背压，不能丢请求、重复返回或配错权重。

**先不做的事：**这一阶段只实现可替换的数字接口和权重读取时序。不要自行决定 FeRAM 存什么，也不要虚构 RRAM/FeRAM 宏的容量、面积、延迟或能耗。混合 3D 器件模型之后根据用户提供的数据校准。

### 5. MX exponent controller：对齐指数并控制 skip

**做什么：**它跟踪每个 PE 的数值指数，计算该怎么对齐 partial，并在信息证明贡献会被截成零时关闭不必要的后级活动。这是论文“用共享指数和加法器位数跳过无效 block”的控制核心。

#### 5.1 一个 PE 的 32 个 lane 内部

每个非零乘积由 PE 表示为 `(E3, M10)`：E3 是数值指数，M10 是 10-bit 二补码有效数，含 8 个 fraction bit。零值统一为 `E3=0、M10=0、is_zero=1`。

对非零乘积数值 `v`，参考定义为：

```text
v = M10 / 256 × 2^E3
```

E3 在行为模型中是独立的 3-bit 指数字段；参与大小比较和指数相减时，必须先按译码器确认的定义转换成数值指数。**不要自行假设 E3 是有符号补码、偏置指数，或假设某个 wire code 与数值指数之间的偏移。**具体 3-bit 编码、合法值、保留码和零值处理由已有转换/PE RTL 的逐码数据确定，并随交付资料提供。

PE 对一个 K block 的 32 个 lane 执行：

1. 找到非零 lane 中最大的 E3，称为 `E3max`；全零时 block 无效。
2. 用 `E3max` 对齐各 lane 的 M10。默认累加位宽为 20 bit，`guard=20-10-ceil(log2(32))=5`，有效 fraction 位数 `frac=8+5=13`。
3. 每 lane 对齐值为 `toward_zero_shift(M10 << 5, E3max-E3)`。
4. 32 个值经平衡加法树累加。每个加法节点都做 20-bit 二补码有符号饱和，并统计饱和次数，禁止 wrap-around。
5. 输出一个 PE/K-block partial：有符号 mantissa、block exponent、valid 和统计信息。

向 0 截断定义为先取绝对值移位，再恢复符号。例如 `-7` 右移 2 位结果是 `-1`，不是 `-2`。正负 lane 相互抵消时 block sum 可能为 0，但这不等于可以 skip。

#### 5.2 同一个输出的 32 个 K block 之间

每个 PE/K-block 的综合指数为：

`Ew`、`Ex` 分别表示权重和输入 E8M0 scale 译码后的真实二进制指数。按 E8M0 的 bias=127 行为定义，普通码值对应 `code-127`，因此：

```text
Eblock = E3max + Ew + Ex
       = E3max + (W_scale_code - 127) + (X_scale_code - 127)
```

如果转换器对特殊/保留码另有定义，必须由它的码值表明确说明；控制器不能把保留码默认为普通指数。

对同一输出的 32 个 K block，只用有效 block 找最大指数：

```text
EMXmax = max(Eblock[c])
distance[c] = max(0, EMXmax-Eblock[c])
Q_aligned[c] = toward_zero_shift(Q[c], distance[c])
```

随后把 32 个已对齐 mantissa 做 5 级二叉树加法。每一级都使用 20-bit signed saturation 并累计饱和次数；树内不再改变指数。最终 logit 为：

```text
logit = Q_tree × 2^(EMXmax-13)
```

如果全 32 个 block 都是零，logit 为零，`EMXmax` 置零。

#### 5.3 skip 的精确定义

一个 PE/K-block 只有满足以下条件才可标为 skip：先按 block 内 E3max 对齐，再按该 block 到输出 EMXmax 的距离向 0 右移；**所有 lane 移位后保留下来的数值都等于 0**。

- 看每个 lane 对齐后的保留值，不能只看整个 block 的和。
- 不能因为正负数相加等于 0 就 skip。
- 低位移出后被截掉，不算保留位。
- TAG-FP 已明确解码为零的 lane 可以在乘法前关闭。
- 对齐后每个 lane 的保留值要逐 lane 检查；不能用一组正负值的总和代替这个检查。
- 为判断 skip 已经读取或计算过的上游活动不能记成节省；只统计 gate 真正关闭的 PE 乘法/累加、Tile 写入、广播或 SRAM 读取。

这里有两种不同的零信息，RTL 必须分别处理：

- **TAG-FP 的 element zero mask**：译码器已经知道某个输入/权重 element 是零时，给出独立 zero mask。PE 可以不对这个 lane 做乘法；如果广播网络也能传送并使用 zero mask，则可以不搬运该 lane 的有效 payload。只关闭 PE 乘法、但仍读取和广播 payload 时，只能报告计算活动减少，不能报告搬运量减少。
- **MX 对齐后的 block skip**：控制器先依据可用的指数/有效位信息得到对齐距离，再执行规则规定的向 0 截断。只有全部待处理 lane 的保留值都为 0，才能关闭对应的 block 计算或后续搬运。若决策所需信息要到 payload 已读出或乘积已计算后才得到，那些已经发生的 SRAM 读取、广播和乘法都不能记为节省。

因此，RTL 要把“零/指数 sideband 的检查路径”和“较宽 payload/乘加数据路径”分开设计，使控制结果能在它声称要省掉的动作发生前到达 gate。若现有编码无法在某一级动作发生前提供足够信息，就如实把 gate 放在更下游并统计实际省下的动作，不得用软件预判出来的 skip 数冒充硬件节省。

控制器至少能给出每输出、每 K block 的 `E3max/Eblock/EMXmax/distance/valid/element_zero_mask/block_skip/data_move_en/calc_en/reduction_stage/saturation_count`。lane zero mask 与 block valid/skip mask 必须分开。

**怎么验收：**构造一个低指数 block，使右移后所有 lane 保留值都为 0，应 skip；再构造正负 lane 相抵但各 lane 保留值非零的 block，不得 skip。记录 skip 前后真实关闭的模块使能信号。

### 6. K-block reduction tree：把 partial 合成最终 logits

**做什么：**一个输出 PE 收齐 32 个 K block 的 partial 后，先按 `EMXmax` 对齐，再用树形加法得到一个 logit。每个输出独立计算。

**必须完成：**

- 每个输出必须收齐或显式标记缺失的 32 个 K-block partial，不能错配 batch/输出行。
- 每个 block 只向 `EMXmax` 右移一次，右移向 0 截断。
- 对齐后做 5 级二叉树求和；每一级饱和到 20-bit signed 范围 `[-524288, 524287]`。
- 输出 `batch_id、output_id、logit mantissa、EMXmax、frac=13、valid` 以及分级 saturation count。
- 能导出每一级的输入/输出值，供 Python golden 逐级比对。
- 最终至少提供一种无歧义的数值输出：推荐同时输出 `Q_tree、EMXmax、frac` 原始字段和 FP32 logits。若复用 BF16→FP32 单元，必须写明 BF16 输入如何形成、舍入/截断规则、特殊值处理和 latency；这个单元不能吞掉 `Q_tree/EMXmax`，否则无法定位 MX 对齐或饱和误差。

**怎么验收：**对全零、单个有效 block、正负混合、跨度很大的 Eblock 和触发饱和的向量，逐级结果与 Python 参考一致。

### 7. 顶层任务控制器

**做什么：**安排“装权重、搬输入、广播、计算、归约、写结果”的顺序，并负责在模块之间传递编号和处理 backpressure。

**一条任务的基本步骤：**

1. 收到 layer/batch 请求。
2. 检查当前 Tile 权重是否已是该 layer；不是则从映射的 Mem Die 装载。
3. 把输入数据写入 Global SRAM 的空闲页。
4. 按 K block 预取和广播输入；有完整数据后启动 PE。
5. 收集并归约 partial，写入 logits buffer。
6. 如果启用 RTL softmax，计算概率；否则把 logits 交给 Python/主机继续处理。
7. 输出完成状态、中断/完成通知和本次统计。

**必须完成：**

- 所有数据流采用 `valid && ready` 表示真正传输。下游不 ready 时，上游保持 payload、scale、tag 和索引稳定。
- batch 1/2/8/32 的输入语义清楚；超过 buffer 容量时拆 micro-batch。
- ping-pong buffer 有明确 ownership：DMA 不能覆盖计算单元正在读的页。
- 每个任务携带 batch、layer、tag；每个 partial 另带输出编号和 K block 编号。
- `start/done/busy/error` 语义清楚，reset 后无遗留 valid 或旧任务数据。

### 8. DMA/主机数据接口

**做什么：**把输入和输出在主机与 Global SRAM 之间搬运。若第一阶段只用 testbench 直接灌 SRAM，可以把 DMA 延后，但不能据此声称已经建模了完整主机到主机的端到端延迟和能耗。

**建议 descriptor 字段：**`src_addr、dst_addr、length、stride、buffer_id、die_id、tile_group、batch_id、tag、status、error`。

**必须统计：**Host→SRAM 输入字节、SRAM→Host 输出字节、总线 beat 数、descriptor 数、setup 周期、队列等待、完成通知数。descriptor/staging buffer 容量是控制/在途缓存大小，不是实际搬运总量。

### 9. 输出与 Softmax

每个输入向量必须能输出 1024 个 logits。**Softmax RTL 是可分阶段实现的功能**：

- 如果 RTL 要交付完整概率输出，则每个样本沿 1024 个 logits 做稳定 softmax：先减最大值，再算 exp、求和、归一化；输出概率和为 1，并提供数值误差与 latency。
- 如果 RTL 只交付矩阵乘/ logits，必须把 1024 个 logits 完整、无损歧义地交给 Python/主机，由软件执行稳定 softmax。

### 9.1 困惑度评估的边界

困惑度（PPL）不是一个需要硬编码进 PE 的 RTL 单元。RTL 需要做的是：对每个 `batch_id、token_position、layer_id、tag` 输出完整的 1024 维 logits，并说明量化/截断格式、指数、valid 和完成 cycle。Python 端再把这些 logits 接回模型的后续层或输出头，执行稳定 softmax，取目标 token 的概率，并按

```text
PPL = exp( - Σ_i log p(target_token_i) / N )
```

计算整段文本的困惑度。要报告 PPL，测试包还必须提供 tokenizer、输入 token、目标 token、模型层顺序以及 Python FP32 基准；只给一组没有 token 对应关系的 logits，不能声称完成了语言模型 PPL 评估。RTL 的职责是保证每个样本/位置的 logits 不丢、不串、可复现，并提供 latency、skip、饱和和搬运统计，使 Python 能把 PPL 与速度/能耗对应起来。

已有 BF16→FP32 单元可以参与 logits/softmax 输出路径，但需要在交付说明中写明输入/输出格式、舍入方式、溢出行为和延迟。Python 参考模型使用 FP32 logits，并对相同输入计算 stable softmax 作为比较基准。

### 10. 性能、搬运和活动计数器

RTL 本身不用把 pJ 数字写死在逻辑里，但必须提供能解释速度与能耗的计数和活动证据。

至少统计：

- 总 latency、稳态 II、每个阶段的周期、PE busy/idle 周期和计算利用率。
- 激活源 SRAM 读字节、Tile 输入写入、广播复制 bit 数、权重从每颗 Die 读出的字节、partial 归约传输量和输出字节。
- TAG zero lane 数、权重 zero lane 数、zero product 数、MX block skip 数、各级饱和次数。
- 每 bank conflict/stall、Mem Die queue wait、DMA queue wait、backpressure stall。
- dense、TAG-zero-heavy、block-skip-heavy 三组固定输入的可复现 VCD/SAIF。

后续用 Synopsys 库和实际 SRAM/RRAM/FeRAM/PHY 数据把这些活动换算为能量。没有真实库或器件数据时，只报告活动数或明确标记为假设，不能称为芯片实测能耗。

## 数值规则速查

| 项目 | 本版行为要求 |
|---|---|
| 输入与权重 | 外部 MXFP4 payload，每 32 元素一份 8-bit E8M0 scale |
| 转换器 | 使用服务器已有 RRAM-FP/TAG-FP RTL；同事只接接口、记录位宽和导出行为数据 |
| 乘积 | `(E3, M10)`；E3 为独立 3-bit 指数字段，数值解释/码值映射由已有转换器和 PE 的交付数据确定；M10 为 10-bit 二补码有效数 |
| PE block | 32 lane；先 E3max 对齐，再 20-bit 饱和树加法 |
| 右移 | toward-zero；负数对绝对值移位后恢复符号 |
| K 归约 | 32 partial；全局 EMXmax 对齐；5 级树；每级 20-bit signed saturation |
| skip | 对齐和向 0 截断后，待处理贡献的保留位全 0 才跳过；不能只因正负数总和为 0 而跳过 |
| 结果 | 每输入向量 1024 logits；logit=`Q_tree×2^(EMXmax-13)` |

实际转换器交付的位宽、字段、码表和特殊码行为是接口事实，必须据此连线并生成 golden。不要凭猜测写死 E3 的 wire 编码；已确认的行为规则仍按 E3max 对齐、向 0 截断、20-bit 有符号饱和和“保留位全 0 才 skip”执行。

## 验收测试清单

请至少准备这些测试，输入固定且可重复：

1. 一个 PE 的 32 lane：全零、单 lane、全正、全负、正负交替。
2. 正负 lane 部分和抵消为零，但每个 lane 保留值非零：必须继续计算，不得 skip。
3. 一个低指数 block 移位后所有 lane 保留值均为零：允许 skip；检查到底关闭了哪些硬件活动。
4. E3max 对齐差为 0、1、大于 mantissa 位数，以及负数向 0 右移的边界。
5. 20-bit 正饱和、负饱和，以及 PE 树和 K 树各级的饱和次数。
6. 32 个 K block 全零、只有一个 block 非零、指数跨度大、多个 block 同指数。
7. 多个 batch 连续运行、权重常驻、换 layer 重新装载。
8. 随机插入 ready=0 的背压：无丢包、重复、错序和 tag 对错。
9. 32-bank 满带宽与较少 bank 的预取场景：功能结果相同，周期与 source/broadcast 带宽统计不同。
10. 若实现 RTL softmax，检查全相同 logits、单个最大值、极端 logits、概率和及与 FP32 Python 结果的误差。

目标规模不一定要在每次 RTL 功能仿真中完整跑完；可以用缩小阵列参数做逐级功能测试，再做 32×32×32 的 elaboration、综合和资源检查。但正式参数下的 Tile/PE 数量、接口宽度和面积报告必须齐全。

## 实现完成后请交回这些资料

请把下列材料放在同一个版本目录中，注明版本号或 source revision：

1. RTL 源码、顶层端口和参数表、时钟/复位说明、每级 latency 与 II、ready/valid 规则。
2. 服务器格式转换器的实际输入/输出位宽、码表/全码测试结果、zero 定义和 decoded value；不需要重新写转换 RTL。
3. 固定测试向量及 CSV/JSON/NPZ golden，至少包含输入 code/scale、转换后 code、每 lane 产品 E3/M10、E3max、对齐 lane、partial、Eblock、EMXmax、shift distance、zero/skip mask、饱和次数和最终 logits。
4. 每一级握手/周期 trace：cycle、valid/ready、batch、layer、tile、PE、K block、die、tag、实际 gate 信号。
5. Synopsys 综合报告：模块面积、cell count、SRAM/memory macro 单列；如果用 flop 代替宏，明确标为逻辑估算。
6. STA 报告：工艺角、库、电压温度、目标时钟、uncertainty、最差路径起止点、critical delay 和可达频率。
7. dense、TAG-zero-heavy、block-skip-heavy 的 VCD/SAIF 与动态/静态功耗报告；给平均功率、每 vector 能量、测量边界和所用器件模型。
8. 把每个能耗数字标成实测、库推导、器件推导或假设，并说明计数口径。RRAM/FeRAM 相对 DRAM 的收益要等两种存储器真实数据齐全后再算。

拿到这些资料后，Python V3 可以替换格式行为接口、校准 latency/II/带宽/单位能耗，再由 Python LLM 运行器在模型和数据集上评估困惑度。RTL 本身不需要实现整套 LLM 软件或验证集 PPL。
