# Python V3 对应 RTL 缺项与实现要求

> **Current SIM-1017 SRAM contract (2026-10-19):** production Python binding uses 32 banks of `SRAM_128X128_HS` payload (128 rows x 128 bits) plus 32 independent `SRAM_128X8_HS` E8M0 sideband banks. Usable payload capacity is 64 KiB and the sideband is 4 KiB (68 KiB physical pair). The 512 KiB value below is historical design/sensitivity context only; do not implement it as the current default without an explicit capacity experiment.

> 历史设计/验证记录：正文保留原始背景，其中旧参数路径、估算方法、命令与性能数字不适用于当前版本，请勿据此运行或发布结果。当前参数、运行方式和限制以 [README_SIM-1017.md](../README_SIM-1017.md) 为准；RTL 实测交付见 [RTL_instruction.md](../../../Instruction/RTL_instruction.md)。

## 对接基线

- 当前 RTL：`rtl-sim-1015/RTL_v3/v3/rtl`（本次清点日期：2026-10-17）。
- Python 行为参考：`simulator-1016/1016SIM/yrr_v3`，重点为 `behavior.py`、`formats.py`、
  `architecture.py`。
- 本文是 RTL 需求/对接文档；不修改现有 RTL。若同事的服务器版本与此目录不同，请在回传包
  标明实际 source revision，并以逐级 golden 说明差异。

本文供 Synopsys RTL 实现、综合、验证和功耗评估时作为对接规范。基线为
`simulator-1016/1016SIM` 中的 Python V3 行为模型，以及
`rtl-sim-1015/RTL_v3/v3/rtl` 当前 RTL。目标是让 RTL 的逐级数值、握手和有效数据
活动可与 Python V3 对照。

**格式转换特别说明：** RRAM-FP/TAG-FP 的格式转换 RTL 已由用户在服务器端实现。
本交接不要求同事重写转换 LUT 或逆解码器；RTL 只需保留可连接该实现的格式适配边界，
并按第 8 节回传格式真值表/行为数据。Python 侧通过 `FormatBehavior` 接口替换行为，
等收到服务器数据后再接入。工艺能耗、面积和 RRAM/FeRAM 相对 DRAM 的收益必须由
真实库、宏模型和器件数据校准。

## 1. 目标架构和实现边界

目标阵列参数：

| 项目 | 目标 |
|---|---:|
| Tile 阵列 | 32 行 × 32 列 = 1024 Tile |
| 每 Tile PE | 32 |
| PE 总数 | 32768 |
| 每 PE 每 block lane | 32 |
| K block 数 | 32 |
| 每个输入向量输出 | 1024 个 logits |
| 每个向量理论 MAC 数 | 1,048,576 |
| 外部权重/输入元素 | MXFP4，4 bit；每 32 元素一个 E8M0 scale |
| Activation 计算格式 | TAG-FP；当前 Python 行为适配器暂按 5 bit/element，最终以服务器 RTL 数据为准 |
| RRAM 权重格式 | RRAM-FP；当前 Python 行为适配器暂按 4 bit/element，最终以服务器 RTL 数据为准 |
| 有限位宽累加器 | 默认 20 bit，可参数化 |

吞吐口径：每个被接收的向量让 1024 Tile、32768 PE 并行工作，每 PE 处理 32 个 K lane，
对应理论峰值 1,048,576 MAC/向量。允许乘法、局部累加和 K 归约分级流水；必须分别报告
流水 latency 与 initiation interval（II）。只有全阵列能够每拍接收一个新向量时，才可报告
1 vector/cycle；不能把“全阵列一次 active”误写成“端到端延迟只有 1 cycle”。

RTL 的工作单位是一个矩阵向量/单层 GEMV（或明确定义的 GEMM tile）。模型 tokenizer、
LLM 多层调度和验证集困惑度由 Python 运行器负责；RTL 不需要实现 tokenizer 或 PPL。
RTL 应提供可被 Python LLM 路径使用的数值、latency/II、流量、活动计数和能耗校准数据。

映射固定为 `Tile[r][c]`：`r` 是输出行组，`c` 是 K block；Tile 内 PE `p`
对应输出行 `m=32*r+p`。数据关系为：

```text
W[r,c,p,l] = W[32*r+p][32*c+l]
X[b,c,l]   = X[b][32*c+l]
P[b,r,c,p] = 对 l=0..31 的 RRAM-FP × TAG-FP 乘积进行 E3/M10 局部归约
Y[b,32*r+p] = 对 32 个 K block partial 按 EMXmax 规则归约
```

当前 RTL 小配置和 MX_FULL 参数化结构可以保留为结构基线，但不得把现有
`TILE_K=4` golden 当成 V3 算术正确性证明。RTL 的目标 golden 必须覆盖
`TILE_K=32`、E3/M10、zero skip 和有限位宽规则。

## 2. 当前 RTL 清点：哪些已有，哪些还不符合 V3

| 当前文件/模块 | 当前作用 | V3 缺项或修改要求 |
|---|---|---|
| `mx_fmt_defs.vh`、`mx_fmt_funcs.vh` | 外部 MXFP4、E8M0 常量及旧 FP4 整数解码 | 按服务器转换实现补充 RRAM-FP/TAG-FP 接口宽度、E3/M10、partial 位宽等常量；不复制转换 LUT，不能再用旧 FP4 integer path 代表最终数值通路。格式定义参考服务器 RTL/用户提供的转换数据。 |
| `mx_pe.v` | FP4 解码为 ×2 整数，乘法后树形累加，直接把两个 E8M0 相加作为指数 | 改为消费服务器端 RRAM-FP/TAG-FP 适配输出（不重写格式转换），实现 zero lane gating、E3/M10 乘积、block E3max 对齐、20-bit 饱和 partial。当前指数公式及累加语义不符合 V3。 |
| `mx_tile.v`、`mx_array.v` | Tile 权重/输入寄存器、全阵列权重定向、按 K 列广播 | 加入 RRAM-FP 与 TAG-FP 存储/解码边界、lane valid/zero mask、block skip 后的逐 Tile/逐列数据使能和活动计数；对齐最终 32×32×32 配置。 |
| `mx_reduce.v` | 跨 K 树归约；当前把指数对齐到较小指数后左移，扩位并置 sticky | 必须改成对齐到 `EMXmax` 的 toward-zero 右移、保留位全零判 skip、20-bit signed saturation；输出逐 block shift distance、valid/zero mask、各级饱和数。现有 min-exponent/左移路径不能复用为 V3 结果。 |
| `mx_ctrl.v` | 固定相位 FSM，按拍推进权重读、输入读、广播、计算、归约、softmax | 加入 ready/valid 背压、block/lane skip 控制、batch/page 管理、权重常驻和换层重载；固定相位不能假设每个事务都无冲突、无 stall。 |
| `mx_gsram.v` | 两页、32 bank、宽读和窄写；输入外部 payload 当前按 4-bit FP4 | 补齐与服务器 TAG-FP 适配器的连接边界、按 32-lane block 的 metadata/zero 路径及 bank stall/读写计数。若转换放在 SRAM 后、广播前，必须按服务器实际 TAG 位宽统计广播；不能沿用旧的 4-bit 广播流量估值。 |
| `mx_mc.v`、`mx_phy.v` | 单控制器、单 Mem Die 行通路和串行 PHY | 缺双 Mem Die 实例/映射、请求仲裁、队列、tag 回传、层切换及权重常驻管理。当前 `BPC=1` 串行模型只是一个配置点，不代表最终混合键合带宽。 |
| `mx_softmax.v` | 定点 Q16.16，近似 exp，输出 exp 分子、sum 和 inv_sum | 明确并统一最终输出契约；支持 Python V3 的 FP32 logits/stable-softmax 对照。若保留近似 exp，需逐项报告精度误差及完整归一化输出；现在 `o_y` 单独并非归一化概率。 |
| `yrr_v3_top.v` | 单任务顶层，TB 提供平坦 Mem Die 数组和输入写口 | 缺 2-die / layer mapping、batch/microbatch、DMA/descriptor、请求级握手、冷启动/稳态两种路径、目标接口及计数器。当前每次 `start` 都会从 Mem Die 逐行装载权重。 |
| `tb_yrr_v3.v`、`golden_v3.txt` | 小尺寸端到端测试和旧格式 golden | 需新增确定性 V3 数值向量及逐级 golden；目标覆盖 32-lane PE、32 路 K 归约、TAG zero、block skip、饱和和双 Mem Die。 |

上表中多数是“已有模块但功能仍是 legacy/简化行为”，不需要为了文件名重复造一套。
应改造现有 PE/Tile/array/reduce/controller/top，并按需要新增 MX exponent/skip controller、
双 Die fabric、DMA 等模块；格式转换只接入服务器端实现，不重复造 LUT。V1/V2 RTL 和
golden 保持不变。

按当前 RTL 文件清点，以下是**功能缺项**（模块名可改，也可并入现有模块）：

| 缺项 | 当前状态 | 必须补齐的功能 |
|---|---|---|
| V3 数值 PE 路径 | 当前有旧版 `mx_pe`，没有符合本契约的 V3 PE | TAG/RRAM 行为适配边界、E3/M10 product、E3max 对齐、20-bit 逐级饱和、lane/block mask |
| EMX/skip 控制 | 没有独立 MX controller | 生成 Eblock/EMXmax/distance、保留值全零判定、data-move/calc gate 与可观察 trace |
| V3 有限位宽 K 归约 | 当前 `mx_reduce` 是 min-exponent 左移的旧语义 | 全局 EMXmax 一次右移、toward-zero、32 输入 5 级树、每级 signed saturation |
| 双 Mem Die fabric | 只有单 Die `mx_mc`/`mx_phy` 路径 | 两个同构端口、layer-to-die 映射、tag/队列/背压、每 Die 流量和周期统计 |
| DMA/任务队列 | 当前 top 没有完整 descriptor/请求队列 | descriptor、Host/GSRAM 传输、完成状态、错误和 queue stall 统计 |
| V3 系统级握手/批处理 | 当前 `mx_ctrl`/top 是固定相位单任务路径 | ready/valid、batch/microbatch、page ownership、冷启动/常驻/换层、阶段计数器 |
| V3 输出契约 | 当前 softmax 近似且 `o_y` 未归一化 | FP32 logits/softmax 或明确可还原格式，并回传数值误差和 latency |
| V3 golden/testbench | 当前 golden 是小尺寸/旧格式 | 新增 E3/M10、skip、saturation、背压、双 Die 逐级/系统测试 |

格式转换 LUT 不在缺项清单中：服务器已有实现，本次只要求保留可替换适配接口并回传行为数据。

## 3. 必须实现的数值通路（P0）

### 3.1 格式接口和共享 scale

1. 外部权重和输入为 4-bit MXFP4 payload，scale 为 8-bit E8M0；每 32 个元素共享
   一个 scale。E8M0 必须作为独立 sideband 原样传递，不做元素级 RRAM-FP/TAG-FP 重编码。
2. 权重计算路径使用服务器端实现的 RRAM-FP 表示，激活计算路径使用服务器端实现的
   TAG-FP 表示。RTL 同事只需预留适配边界，不能复制/改写服务器端转换 LUT，也不要把
   当前 Python 暂存映射当成最终格式定义。
3. 行为级对接以 `yrr_v3/behavior.py::FormatBehavior` 为准：提供
   `weight_encode/decode`、`input_encode/decode` 四个可替换 callable；输入/输出数组形状
   不变，解码返回有限数值，zero 信息必须来自已实现格式定义。RTL 若能输出显式
   `is_zero`、合法码标志和解码字段，随逐级 golden 一并提供；否则提供服务器 RTL 的
   码表/导出向量，Python adapter 从这些数据建立行为模型。
4. 当前 Python adapter 暂按 RRAM-FP 4-bit、TAG-FP 5-bit 建模；这是**待服务器数据确认的
   行为接口宽度**，不是要求同事固定 RTL 位宽。若服务器 RTL 的实际字段宽度、码字或
   zero 表示不同，应以服务器实现为准，并在接口包中写清楚转换关系。

### 3.2 E3/M10 乘积

行为接口字段：

```text
E3：独立 3-bit 指数字段；RTL 内转成有符号数值指数参与运算。
M10：10-bit 二补码有效数，包含 sign、hidden bit 和 8 个 fraction bit。
零值 canonical：E3=0、M10=0、is_zero=1。
```

乘法器将 RRAM-FP 权重和 TAG-FP 输入解码后的数值相乘，再按 Python V3 行为契约形成
`(E3, M10)`。非零 FP4 乘积的数值指数范围是 `[-2, 5]`。Python 内部保存数值 E3；若
RTL 接口用无符号 3-bit code 表示这 8 个范围值，约定 `E3_code = E3_numeric + 2`，
并在任何比较/加减前恢复数值 E3，禁止 3-bit 环绕。M10 是 10-bit 二补码有效数，
负数不能使用 sign-magnitude。

对非零乘积 `v`，参考定义为：

```text
E3_numeric = floor(log2(abs(v)))
M10_signed = trunc_toward_zero(v × 2^(8 - E3_numeric))
v = M10_signed / 256 × 2^E3_numeric
```

当前 FP4 合法乘积均可被该行为格式精确表达。RTL 乘法中间位宽必须足以容纳完整
乘积和归一化，不允许 Verilog 表达式按窄操作数截断。对 0、正负数、最小/最大码值、
乘积跨 E3 桶边界必须提供 directed tests。

### 3.3 PE 内 E3max、对齐和有限位宽累加

每个输出 PE、每个 K block 独立处理 32 个 lane：

1. 对 32 个非零 lane 的产品 E3 求 `E3max`；全零 block 标记无效，指数置 0。
2. `partial_bits` 默认 20。保护位数为
   `guard=max(0, partial_bits-10-ceil(log2(TILE_K)))`；目标参数 20/32 时 `guard=5`。
   有效小数位数为 `frac=8+guard`，默认 13。
3. 每 lane 对齐值：
   `a_i = toward_zero_shift(M10_i << guard, E3max - E3_i)`。
   右移采用符号保持的绝对值移位，负数也向 0 截断；禁止算术右移造成负数向负无穷取整。
4. 32 lane 采用平衡树累加。每个加法节点结果都按 `partial_bits` 位二补码范围
   做有符号饱和，并增加饱和计数。不能 wrap-around，也不能只在最终输出时饱和。
5. 输出每个 Tile/PE 的 block partial mantissa `Q[b,r,c,p]`、数值指数和 valid。

### 3.4 shared E8M0、EMXmax、跨 K 归约和 skip

每个 PE block 的综合指数：

```text
Eblock = E3max + (W_scale_E8M0 - 127) + (X_scale_E8M0 - 127)
```

每个输出行在 32 个 K block 中求：

```text
EMXmax = max(Eblock[c])，只考虑有非零产品的 block；全零输出定义 EMXmax=0。
d[c] = max(0, EMXmax - Eblock[c])
Q_aligned[c] = toward_zero_shift(Q[c], d[c])
```

所有 32 个 K partial 先一次性对齐到该输出的同一个 `EMXmax`，再做 5 级二叉树整数
加法；归约树每一级的每个加法都按同一目标位宽饱和并计数。树内不再重算指数或做
逐级指数对齐。最终数值与当前 Python V3 参考定义为：

```text
logit = Q_tree × 2^(EMXmax - frac)
```

**skip 判据必须是“对齐后保留值全 0”**：对每个输出 PE/K block，所有有效 lane 的
乘积先按 block 内 `E3max` 对齐，再按该 block 到输出 `EMXmax` 的距离 toward-zero 右移；
只有每个 lane 的保留值都为 0，才能把该 PE/block 标记为可跳过。不得用“block 部分和
等于 0”判 skip，因为正负 lane 抵消仍然是有效计算。被截掉的低位不参与保留值判断；
饱和、skip、输入格式 zero 和乘积 zero 分开统计。

实现位置要与可观测的 gating 位置一致：TAG-FP 明确标记的 zero lane 可以在乘法前关闭
该 lane；MX block skip 只有在硬件已得到足以证明“对齐后保留值全 0”的信息后才能生效。
若判据需要先读取 payload、解码或形成乘积，这些上游活动仍须计入，不能算作已被 skip
省掉。Python 参考模型按该规则统计有效 MAC，但其功能参考路径会先形成候选乘积再评估 mask；
这不等于证明 RTL 在乘法前省掉了能量。RTL 回传的活动 trace 用于校准实际究竟关闭了乘法、
累加、Tile 写入、广播还是仅关闭更下游级。

每个有效单元至少输出/可观测：`E3max`、`Eblock`、`EMXmax`、`alignment_distance`、
`valid_mask`、`zero_mask`、`data_move_en`、`calc_en`、`reduction_stage`、
`saturation_count`。`valid_mask` 为 block 级（每个输出行 × K block），lane zero mask
另行输出，不能混为一张 mask。

### 3.5 Skip 对真实数据搬运的作用范围

同一个 K block 输入会被多个输出行组共用，所以要分级实现和计数：

- **lane gate**：TAG-FP 或权重格式明确标记该 lane 为 zero 时，可以不发起乘法，并关闭
  相应 PE lane 的输入/结果寄存器更新；逐级计数必须标明 gate 实际位于转换、乘法或累加哪一级。
- **Tile receiver gate**：同一个 row-group 的 32 个 PE 对该 K block 全部 skip 时，关闭
  该 Tile 输入 buffer 的接收/切换。
- **broadcast gate**：对应 K block 在所有输出 row-group 都可 skip 时，才关闭该 bank
  的广播复制。
- **GSRAM source read gate**：只有 skip 所需 metadata 在读 payload 前已可访问，并且
  所有接收方都可 skip 时，才可不读该 GSRAM bank。若必须先读完整 payload 才知道 TAG
  code，则这次 SRAM 读不能计作被省掉，只能报告下游广播/寄存器/PE 活动减少。

分别统计 source read bytes、broadcast replicated bits、Tile buffer writes、有效 PE lane
MAC 数、TAG-format zero lanes、权重 zero lanes、zero products 和 block skip 数。这样才能区分
“跳过计算”和“省掉源端访存”，避免
把后者未经实现就写成节能收益。

## 4. 模块拆分和握手要求

建议在现有 V3 RTL 上实现或改造以下模块；命名可调整，但端口语义需保持：

| 模块 | 责任 | 建议输出/状态 |
|---|---|---|
| 格式适配边界（不要求重写 LUT） | 接入服务器端 RRAM-FP/TAG-FP 转换实现；Python 端对应 `FormatBehavior` | 输入/输出码宽、scale sideband、decoded value/字段、zero/合法码、版本与 truth vectors |
| `mx_product_e3_m10` | 由格式适配输出数值形成权重×激活乘积并规范化成 E3/M10 | signed M10、数值 E3（或说明 wire bias）、zero、product valid |
| `mx_pe_v3` | lane zero gate、E3max、lane alignment、20-bit PE 累加 | partial、指数、mask、饱和和活动计数 |
| `mx_mx_controller` | Eblock/EMXmax、距离/移位量、valid/zero/data-move 控制 | 每 block 的 MX control trace 字段 |
| `mx_reduce_v3` | 32 K block、5 级 tree、toward-zero、逐节点饱和 | logits mantissa/exponent、各级统计 |
| `mx_tile` / `mx_array` | 1024 Tile 映射、权重/输入 buffer、广播和 gating | 全阵列部分和及一致的 tile/PE 编号 |
| `mx_memdie_fabric` | 两个同构 Mem Die 端口、layer map、仲裁、tag 和背压 | 每 Die request/response/bytes/active cycles |
| `mx_dma`（系统级） | descriptor、输入/输出传输、状态与完成通知 | AXI beats、descriptor、queue stall、IRQ/done |
| `mx_ctrl_v3` / `yrr_v3_top` | 任务调度、batch/page、warm/cold weights、阶段事件 | valid/ready、cycle、batch/layer/tag、计数器 |
| `mx_softmax_v3` | stable max/exp/sum/normalize 输出契约 | FP32 或精确可解码的 logits/probability、误差/周期 |

跨模块流接口使用 `valid && ready` 定义一次传输。请求/响应还要携带 `tag`、
`batch_id`、`layer_id`、`tile_id`、`die_id`、`k_block` 或等价索引。下游 backpressure
时上游必须保持 payload 和 sideband 稳定，不能丢包、重复消费或错配 response。若内部
采用固定拍 schedule，也要显式声明 ready 恒为 1 的边界，不能把 TB 的无背压假设
伪装成完整接口。数据、scale、zero/valid mask 和所有索引必须作为同一事务保持对齐。

### 4.1 推荐的模块边界和字段语义

以下是供 RTL 接口评审的**语义字段**，可按项目已有命名调整，不要求完全照抄端口名。
所有多字节总线需在接口包中写明 lane 0 所在 bit、字节序及 scale 与 32 lane 的对应关系。

| 边界 | 输入语义 | 输出语义 |
|---|---|---|
| 外部向量/权重输入 | `valid/ready`、MXFP4 32-lane payload、该 block 的 E8M0 scale、batch/layer/K-block/tag | 被接收时锁存 payload、scale 和全部 sideband；未接收时上游保持稳定 |
| 格式适配 | MXFP4 code 与独立 E8M0 scale；权重/激活路径分别选择服务器 RRAM-FP/TAG-FP 实现 | 转换后 code，或 Python 行为接口所需 decoded value；明确 `is_zero`、合法码和实际位宽。转换 RTL 本体由服务器实现提供 |
| 单 PE 乘积/局部归约 | 32 lane 权重与激活表示、各自共享 scale、lane valid/zero | 32 组产品 `(E3_numeric, M10_signed)`，block `E3max`，对齐 lane、20-bit partial、valid/zero mask、饱和计数 |
| K-block MX 控制/归约 | 同一输出 PE 的 32 个 block partial 及其 block exponent/valid | `EMXmax`、每 block distance、对齐后保留 mask、5-stage 饱和归约结果及逐级统计 |
| 输出 | 完成归约的 logit；可选 stable softmax | FP32 logits 和 normalized probability，或足以无歧义还原这两者的 raw mantissa/exponent 与定点格式说明 |

对目标阵列，外部 MXFP4 输入每个 K block 是 128-bit payload + 8-bit scale；经 TAG-FP 转换后
每个 Tile 输入块的理论有效位数按**服务器实际 TAG 位宽**计算（当前 Python 暂为 32×5+8=168 bit）。
每个 Tile 的权重则是 32 个 PE 各自拥有 32 个 K lane；每个 PE/K-block 对应一个权重 scale，
不能把单个 Tile 的所有 PE 错误地共用一个 weight scale。RTL 的广播/缓存位宽应在转换位置确定后再定，
并在综合和活动报告中注明。

## 5. 系统级缺项（P1；完整性能/能耗结论所必需）

P0 是创新数值通路逐级正确的前提；P1 是端到端周期、容量、数据流量和能耗结论的前提，
不是可忽略的装饰项。若当前交付先做 P0，报告必须标为“算术核级”，不能声称完成系统级
推理性能/能耗仿真。

### 双 Mem Die、映射和权重常驻

当前 `mx_mc`/`mx_phy` 只有单路，TB 使用平坦 Mem Die 数组。目标 RTL 要有两颗接口同构
的 Die，至少支持 `layer_id -> die_id` 映射、地址/tag 回传、请求队列和每 Die 读计数。
默认一层只从映射 Die 读取；更换 layer 时加载新权重。`weights_resident=1` 时冷启动
装载一次，后续 batch 不得重复读权重；每 Die 报告权重字节数、请求数、活跃周期、冷启动
拍数和稳态 batch 拍数。先完成 layer mapping；Tile/row striping 可作为可选带宽模式。

### Batch、DMA 和 SRAM

当前 top 一次只处理一个 task，输入写入固定 SRAM 地址，未见完整 DMA descriptor 队列。
P1 至少应支持 batch 1/2/8/32 或按 Global SRAM 容量 microbatch，输入/输出 buffer 双页
ownership 明确，支持写下一页与计算当前页重叠。DMA 控制 staging 大小不得冒充总搬运量。
GSRAM 默认目标容量 512 KiB、32 bank、每 bank 一条 128-bit 外部 MXFP4 payload 和
8-bit scale；TAG-FP 扩展后的本地/broadcast 宽度按转换位置重新计算并实测。

### 输出及 softmax

当前 RTL softmax 的 exp 为近似级数，且 `o_y` 是未归一化 exp 分子，需明确顶层输出是：

1. FP32 logits 和 FP32 normalized softmax；或
2. raw signed mantissa + signed exponent（附明确 frac/rounding），并同时输出完整的
   softmax numerator/sum/inverse，确保 Python 可无歧义还原。

FP32 转换采用 round-to-nearest-even 并做溢出/饱和状态报告。若保留近似 exp，至少给出
相对误差、概率和误差和 logits 范围边界测试；不能只验证概率和约等于 1。

## 6. RRAM/FeRAM 混合 3D 的边界（后续器件校准项）

论文创新点中的 RRAM/FeRAM 混合 3D 存储层还没有落入可校准模型。当前 RTL 可以先提供
同构 memory wrapper：读写请求、容量/地址、burst、ready/valid、错误、bank busy 和周期
计数；RRAM 权重通路保存 RRAM-FP+E8M0，FeRAM 通路先保留可配置端口。不要擅自决定
FeRAM 承载权重、激活或 KV 的最终映射，也不要把标准单元综合面积当作 RRAM/FeRAM 宏面积。
Hybrid-bond/PHY 可以建数字时序/数据宽度模型，但读写能耗、容量密度、retention、写入
限制和相对 DRAM 的收益要等工艺/器件数据。

## 7. RTL 验证与验收标准

### 数值单元测试

- 对服务器端已实现的 MXFP4↔RRAM-FP、MXFP4↔TAG-FP 转换，使用其导出全码表/向量做穷举
  对照；同事不需要重写转换逻辑。覆盖正负零、所有码字和显式 zero metadata。
- 乘积覆盖正负、零、FP4 最小/最大幅值及 product E3 的 `-2`、`5` 边界。
- 32 lane 全零、单 lane、正负交替、抵消为零但不得 skip、不同 E3/E8M0 scale。
- exponent distance 覆盖 0、1、保留最低位、截掉全部低位；负数移位确认 toward-zero。
- `partial_bits=20` 的正/负饱和边界；分别核对 PE tree 和 K-reduction 每级的 saturation count。
- K=32 的 5-stage tree 与 Python V3 逐输出 mantissa/exponent、skip mask 和最终 logits 对比。
- 全零、全正、全负、大指数跨度、block skip 开/关、TAG gate 开/关的成对测试。

### 接口和系统测试

- 小配置 `M=N=K=64` 与目标规模使用相同映射规则；full target 编译/综合参数为
  `TILE_ROWS=32, TILE_COLS=32, PE_PER_TILE=32, TILE_K=32`。
- 断言目标规模 1024 Tile、32768 PE、每输出 32 K partial；batch 不得误作 K lane。
- ready/valid 随机 backpressure 下无丢包、重包、错序、tag 错配；reset 后无残留 valid。
- 双 Die layer mapping、权重冷启动/常驻/换层 reload；warm batch 不重复 weight read。
- 双缓冲页读写互不覆盖；bank conflict、queue stall 和输入带宽不足要可观测。
- 每个有效 skip 都能在计数器中对应到实际被关闭的 buffer write、broadcast 或 PE lane；
  未关闭的上游 source read 不得记为节省。
- 对固定权重/输入/scale/seed 生成稳定 golden，跨周期对照 Python 的逐级结果。

当前 `TILE_K=4` 的 `golden_v3.txt` 只能保留为旧结构 smoke test。V3 新 golden 至少
导出原始外部 payload/scale、转换后 RRAM/TAG code、lane product `(E3,M10)`、E3max、
PE partial、Eblock、EMXmax、alignment distance、valid/zero mask、各级饱和计数、最终
logits 和 softmax。接口变更时在新的 golden 文件中版本化，不能静默覆盖旧基线。

## 8. Synopsys 实现后请回传的资料

为了把 RTL 参数接入 Python V3，请交回一个版本包，至少包含：

1. RTL 源码、顶层参数表、模块端口说明、约束 SDC、仿真 testbench 和所有固定向量；
   注明工具/版本、source revision、时钟、复位、valid/ready 与每一级 latency。
2. 服务器格式转换 RTL 的版本/模块接口，以及每种输入码到输出码、解码值、`is_zero` 的
   真值表或全码导出结果；无需重新实现 LUT。说明实际码宽、E3 wire 编码、M10 小数点、
   E8M0 公式、舍入/饱和和非法码行为，以便替换 Python `FormatBehavior`。
3. 上述逐级 golden 数据，优先 CSV/JSON/NPZ：至少含 `input_code, scale, product_e3,
   product_m10, e3max, aligned_lane, partial, eblock, emxmax, distance, masks,
   saturation_count, logits`。同时提供 cycle/tag/tile/die/batch 信息。
4. 分模块综合面积和 cell count；全局/本地 SRAM、RRAM/FeRAM macro 分开列；不能把
   memory macro 缺失时的 flop 替代面积标成真实 SRAM/RRAM 面积。
5. STA：工艺角、库、电压温度、目标时钟、uncertainty、setup/hold、最差路径起止点、
   critical delay 和可达频率。请注明 `PHY_STAGES/BPC` 和 MC latency 采用值。
6. 功耗：用 dense、TAG-zero-heavy、block-skip-heavy 三组固定 workload 的 VCD/SAIF
   做动态功耗；分别给 PE、格式转换、MX 对齐/归约、GSRAM、广播、PHY/Hybrid bond、
   memory macro、DMA/softmax 和 leakage。提供平均/峰值功率及每 vector 能量。
7. 能耗单价可直接映射到 Python `EnergyParams` 的单位，例如每次 MAC、每次 reduction
   add、每 128-bit SRAM read/write、每 broadcast bit、每 PHY bit、RRAM/FeRAM 每次读写。
   每个值标为实测、库/器件推导或假设，并给来源和计数口径。

面积、时序、动态能耗及器件数据未返回之前，Python V3 的相应输出仍是架构行为估算；
不能写成芯片实测，也不能据此声称 RRAM/FeRAM 相对 DRAM 的已验证能效提升。

## 9. Python 对照入口

当前功能参考位于 `simulator-1016/1016SIM/yrr_v3/behavior.py`、`formats.py` 和
`architecture.py`。对照规则、数组布局、skip masks、饱和数与报告字段以当前工作区该版本
为基线；后续格式表/RTL 数据到手后更新 `FormatBehavior` 和向量，不重写架构数据流。
目前已有 RTL `check_rtl.py` 会因旧 golden `TILE_K=4` 与 V3 外部 32-lane 接口不匹配
而报告 pending，这是预期边界；新 RTL 导出 32-lane golden 后再启用逐级 RTL 比对。
