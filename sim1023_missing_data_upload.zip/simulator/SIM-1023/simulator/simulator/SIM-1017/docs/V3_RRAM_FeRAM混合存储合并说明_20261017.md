# RRAM / FeRAM 混合存储合并说明

> 历史设计/验证记录：正文保留原始背景，其中旧参数路径、估算方法、命令与性能数字不适用于当前版本，请勿据此运行或发布结果。当前参数、运行方式和限制以 [README_SIM-1017.md](../README_SIM-1017.md) 为准；RTL 实测交付见 [RTL_instruction.md](../../../Instruction/RTL_instruction.md)。

更新时间：2026-10-17。已把同事版本的混合存储功能合并到当前 `1016SIM`，并保留此前修正的广播前 E8M0 block skip。

## 最终文件在哪里

- **继续使用的版本**：`F:\AID\MXFP4\仿真器\rtl-sim-1015\simulator-1016\1016SIM`。
- 同事提供的来源：`F:\AID\MXFP4\仿真器\rtl-sim-1015\simulator-1016\1016SIM_2\1016SIM`，保持原样。
- 合并前文件备份：当前版本的 `bak/before_hybrid_memory_merge_20261017/`。
- 没有修改 RTL，也没有修改 `docs/给RTL同事的V3补充模块说明_新手版.md`。

## 现在的数据如何流动

```text
推理前：主机把模型权重预置到 RRAM（记录字节，不计入推理时间）
                                      ↓
推理中：从 RRAM 读取权重 → Logic Die 执行 Q/K/V 投影
                                      ↓
                 Q/K 的归一化与 RoPE → Q/K/V 量化
                                      ↓
                        Q/K/V 写入 FeRAM
                                      ↓
               Attention 从 FeRAM 读取 Q/K，计算分数
                                      ↓
          softmax → 从 FeRAM 读取 V，与注意力概率相乘
                                      ↓
                        后续层 → logits / token
```

这是 `run_llm.py → run_llm → SimContext` 的实际执行路径，包含 prefill 和 decode。
数值模式确实计算投影和 Attention，K/V 的数值缓存保存量化后的值；Q 在当前层保留等价的 NumPy 数组。
`MemDie` 记录存储介质、地址、容量和访问成本，数值实体由 NumPy 保存。
这属于功能数据流和访问记账模型，尚未逐周期模拟 RRAM/FeRAM 阵列内部电路。

## 哪些数据放在哪里

| 数据 | 位置 | 规则 |
|---|---|---|
| 模型矩阵、embedding、norm 参数 | RRAM | 推理前预置；计算时读取，常驻逻辑 Die 的块可以复用 |
| Q | FeRAM 的 `q_buffer` | 按当前 prompt 规模预留，跨层复用 |
| K、V | FeRAM 的 `kv_cache` | 按所有层、最大上下文预留；decode 逐步追加 |
| 一般激活、Attention 分数 S、概率 A 等 | RRAM | 沿用同事版本策略；没有自动改放 FeRAM |
| Tile 权重寄存器、Global SRAM | Logic Die | 是另外的本地缓存，不等于 RRAM 或 FeRAM 容量 |

默认 MXFP4 字节口径仍是 32 个 4-bit payload 加 1 个 E8M0 scale。
这里没有引入新的 RRAM-FP/TAG-FP 转换 LUT；真实转换继续通过已预留的行为接口对接服务器 RTL。

## 容量如何配置

三种上限同时检查：

1. `mem_die_bytes`：RRAM 与 FeRAM 使用量之和的总上限。
2. `rram_capacity_bytes`：RRAM 单独上限。
3. `feram_capacity_bytes`：FeRAM 单独上限。

命令行对应 `--mem-die-gb`、`--rram-gib`、`--feram-gib`，三者单位实际都为 GiB。
单独上限没有配置时记为 `per_medium_capacity_pending`，只检查共享总上限；不会自动假定各占一半。
数值执行、形状执行都在构建权重数组之前检查容量，超容时给出具体介质与明细。
RRAM 和 FeRAM 有各自的逻辑地址空间，因此它们都从偏移 0 开始是正常现象。

在当前版本目录运行：

```powershell
python run_llm.py --smoke --rram-gib 0.01 --feram-gib 0.01 --json hybrid_smoke.json --trace hybrid_trace.json
python run_llm.py --smoke --forward shape --rram-gib 0.01 --feram-gib 0.01 --json hybrid_shape.json
```

上面的容量只供小模型验证，不代表实际器件规格。正式运行时按实际容量修改。

## 时间和能耗的评估边界

**推理时间包含**：运行期 RRAM 访问、FeRAM Q/K/V 读写、跨 Die 传输、Logic Die 计算及其他已建模阶段。
**推理时间排除**：主机预置权重、主机接口读回；Python 自身运行花费的墙钟时间也不是芯片推理时间。

权重预置次数与推理次数分开：`n_runs=2` 不会重新预置两次权重，但运行期流量会累计两次。
`Core.host_store/host_load` 可以独立记录主机预置和读回流量，不进入推理账本。

本次另外修复了 LLM 计算价格与当前 V3 GEMV 默认值不一致的问题：

- 内部矩阵计算价格取一次全阵列 GEMV、1,048,576 MAC、权重已装载、无 Host/DMA、无 softmax 的架构估计。
- RRAM 权重装载和 Attention softmax 由 LLM 调度器分别计入，避免重复收费。
- 不再从单向量价格减去旧版本 `1024×1024` softmax 费用，避免出现负矩阵能耗。
- 该价格是确定性的架构基线，指数移位活动基线为 0；不会把随机 payload 当成实测标定。
- `whole_block` 沿用同事版本的整块占用估算：不足满阵列也付整块费用；`unit` 按实际 MAC 另列。两种都是模型口径。

`memory_traffic` 包含推理前预置的流量与已知阵列能耗，预置部分在 `host_*` 字段单列；
`energy.total_*`、TTFT 和 decode 的推理账本排除这部分，两个总量的边界不同。

当前 Attention 仍采用按 query/key pair 串行计账、不复用 Q/K/V 的既有策略，prefill 还保留因果三角访问的上界估计。
因此这些访问量和时间不能直接当作经过优化的 Attention 硬件性能；本次没有更改调度策略。

## 如何填器件数据

`calib/llm_calib.json` 增加了以下四项，默认全部为 `null`：

| 参数 | 含义 |
|---|---|
| `feram_rd_pj_per_128b` | 每次 128-bit FeRAM 阵列读能耗，pJ |
| `feram_wr_pj_per_128b` | 每次 128-bit FeRAM 阵列写能耗，pJ |
| `feram_rd_ns` | 每次 128-bit FeRAM 阵列读延迟，ns |
| `feram_wr_ns` | 每次 128-bit FeRAM 阵列写延迟，ns |

RRAM 沿用 `mem_rd_pj_per_128b`、`mem_wr_pj_per_128b`、`mem_rd_ns`、`mem_wr_ns`。
当前成本公式为各笔传输分别向上取整到 16 B，再乘介质单价；属于串行访问估计，尚未模拟 bank 并行与阵列内部争用。
实际器件若有别的访问粒度或并行度，需要用后续数据调整访问模型。

FeRAM 缺参不会套用 RRAM 数字：流量照常记录，缺失的能耗/延迟列为 `pending_cost_bytes`，总成本标为 `PARTIAL`。
PHY/GSRAM 成本缺失或设为零也不会把实际流量抹成零。
能耗/时延部分齐全不代表全部参数已经实测；正式 token/s、J/token 仍由 `throughput` / `efficiency` 的来源门检查。
只有真正的标定结果才应填进该标定文件，测试里使用的数值不代表器件数据。

## 报告到哪里找

| 字段 | 作用 |
|---|---|
| `hybrid_memory.by_medium` | 两种介质的独立容量、占用、逻辑地址与张量清单 |
| `hybrid_memory.parameter_status` | FeRAM 成本、主机接口参数的已配置/待补状态 |
| `memory_traffic.by_medium` | 每种介质读写总量、主机读写、纯推理读写 |
| `memory_traffic.by_medium.*.array_cost_known` | 已知阵列读写能耗、其中主机部分、纯推理阵列延迟；不含 PHY 能耗 |
| `memory_traffic.pending_cost_bytes` | 没有完整单价的访问量；不同缺项可以指向同一笔流量，不能再相加当总流量 |
| `trace` | Q/K/V 写入、QK/PV 读取等操作的介质标签和分阶段记账 |
| `latency.host_io_included` | 固定为 `false`，明确完整 LLM 推理的边界 |
| `provenance`、`throughput`、`efficiency` | 参数来源、缺参清单、正式指标是否可出数 |

## 与 skip、困惑度的关系

原有 `run.py/run_v3` 的 block skip 规则继续保留：广播前只用 E8M0 的 Esum 与 EMXmax 差，不用计算后的 E3/M10 决策。
固定阈值未配置时不计 MX skip 收益。TAG 元素零门控继续在译码/PE 阶段执行。
`run_llm.py` 的整体成本仍是按形状计账，不会自动把每个 Transformer 层的真实有限位宽 skip 活动折算成整模型收益。

真实困惑度入口仍是 `run_ppl.py`，需要本地真实模型、分词器和测试文本；本次保留阈值参数，并合并了 skip 开关及相对 FP32 的 PPL/平均 NLL 差。
该入口量化 `torch.nn.Linear`，其余算子、embedding 和 KV 仍为 FP32，不能把这一路 PPL 称为全算子混合存储/有限位宽硬件的准确率验证。

```powershell
python run_ppl.py --help
python tests/run_current.py
```

## 验证与当前边界

本次当前回归包含 53 项，覆盖既有数值/scale-only skip，以及新增的混合存储组件和端到端 Attention。
验证了：QKV 分开/合并投影都只写 FeRAM；Q/K/V 运行期回读；共享及独立容量拒绝；
数值/形状模式的流量与成本一致；重复推理仅重复运行期流量；主机预置不改变推理成本；
FeRAM 标定参数确实影响报告；缺参时成本待补且流量保留；报告为合法 JSON。

历史 `tests/test_llm.py` 保留旧 `1024³` 计费、旧 PHY 和旧算子序列 golden，不属于当前回归入口。
本轮抽查也再次发现这些旧断言与当前契约冲突，未将它们改成新的通过快照。
本次当前回归以 `tests/run_current.py` 和 `test_current_hybrid_20261017.log` 为准。

本地验证记录：`verification_hybrid_20261017.json`；数值冒烟报告与 trace：
`report_hybrid_smoke_20261017.json`、`trace_hybrid_smoke_20261017.json`；
形状模式对照：`report_hybrid_shape_20261017.json`；
Torch 有限位宽线性层阈值/开关验证：`validation_hybrid_torch_20261017.json`。

生成的冒烟报告及 trace 使用小模型、固定种子和未完整标定参数，只用于验证链路。
没有新增真实器件测量、DRAM 对照、逐周期存储争用模型或真实模型困惑度结果。
