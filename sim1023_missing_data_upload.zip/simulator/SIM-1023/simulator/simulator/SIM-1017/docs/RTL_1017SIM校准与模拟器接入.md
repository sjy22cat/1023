# RTL_1017SIM 的实测参数接入

本页只维护当前入口，完整字段、单位、采集方法与限制统一见 [README_SIM-1017.md](../README_SIM-1017.md) 第 1–4 节，RTL 表征交付见 [RTL_instruction.md](../../../Instruction/RTL_instruction.md)。

唯一默认输入为 `calibration/rtl_1017sim/rtl_1017sim_measured.json`，schema 为 `sim-1017-synopsys-measured/v1`。`run.py/run_llm.py` 支持 `--parameters PATH`，不指定时按软件包位置定位。原始报告另存其旁边的 `synthesis/sta/power/memory/traces`。

必填章节为 `structure/timing/config_overrides/energy/area/llm_hardware/llm_prices/provenance`。模板当前为 PENDING；真实新思结果齐全后设置 MEASURED，并运行 `python validate_parameters.py`。缺少或非法必需参数会停止运行，没有 RTL/默认值估算回退。

旧 `export_calibration.py`、`rtl_1017_calibration.json`、`calib/llm_calib.json`、面积和 RTL 推导路径已删除。`format_contract/validation` 用于证据归档，不自动替换数值行为或重放 trace；参数校验不能替代 STA/RTL 等价验收。
