# V3 block skip：广播前仅用 E8M0 预判

控制规则更新于 2026-10-17，参数入口更新于 2026-10-18。本文解释 SIM-1017 的 scale-only 预判；当前参数加载流程以 [README_SIM-1017.md](../README_SIM-1017.md) 为准。旧估算数据集及 `run_v3_legacy` 已移除。

## 为什么需要改

原行为模型先计算乘积的 E3/M10，再检查各 lane 在有限位宽对齐后是否为零，以此决定是否跳过 PE 和搬运。用这种结果统计广播前的节省，决策发生得太晚。现在 block skip 在广播和 PE 之前完成，输入仅为 E8M0 scale，实际产品、partial、零 payload 和正负抵消均不参与这次决策。

## 当前数据路径

```text
Host/DMA 输入（可由配置选择是否计入）
  → Global SRAM：保存 MXFP4 payload 和 E8M0 scale
  → 读取输入 scale 元数据；取得本地驻留权重 scale
  → MX 控制器：Esum、EMXmax、距离、PE-block skip mask
  → 按接收方需要读取 payload
  → 广播外部 MXFP4 block 和 scale
  → Tile 侧 MXFP4 → TAG-FP 译码、取得 element zero mask
  → 保留的 PE block 执行乘积与局部累加
  → 32 路 K-block 数值归约
  → FP32/BF16 输出与可选 stable softmax
  → 可选输出 DMA
```

Global SRAM 可对接 28nm 高密度 SRAM compiler 宏。当前已保留容量、bank、读写端口与单位能耗参数；尚未运行厂商 compiler，面积、读写周期和 pJ 仍需回填，不能把“预留宏接口”写成“已完成宏综合”。

## block skip 的决策

对于输出行 `m` 和 K block `c`：

```text
Esum[m,c] = (E8M0_W[m,c] - 127) + (E8M0_IN[c] - 127)
EMXmax[m] = max_c(Esum[m,c])
d[m,c]    = EMXmax[m] - Esum[m,c]
```

也可以直接将两个 E8M0 码值相加，形成 9-bit sum 后比较；统一减去 254 不改变差值。Python 在加法之前扩宽为 int32，避免 uint8 溢出。每个输出独立在它的 K blocks 间求最大值。零 payload 的 block 仍参与 Esum 最大值计算，因为控制器此时不能根据 PE 后的零信息排除它。

实现见 `yrr_v3/mx_controller.py::decide_scale_blocks`。它的函数参数只有 scale 和固定阈值/配置开关，没有 payload、E3、M10 或 partial，因此这条路径无法使用 PE 结果作回溯判断。

**尚待确认的唯一判定参数是固定阈值及等号边界。**当前接口支持：

```text
mx_skip_threshold_bits = T
skip[m,c] = (d[m,c] >= T)
```

`T` 默认 `None`：模型仍可完整运行矩阵乘、softmax、周期和活动统计，但不启用 MX block skip，不计其节省，并在摘要/JSON 写明 `pending fixed threshold`。没有擅自把 `partial_bits=20` 当作 `T=20`。专项测试中的 T=2、20 是边界测试用例，不是实际 RTL 规则。若实际 RTL 规定 `d>T`，对于整数距离可配置为 `threshold_bits=T+1`。

Python 调用：

```python
from yrr_v3 import V3Datasheet, V3Config, run_v3

# T 由 RTL 确认后写入 measured JSON 的 config_overrides。
# 不要把测试用例的 20 当成硬件结论。
ds = V3Datasheet.from_1017_calibration()
result = run_v3(V3Config(), dataset=ds)
```

CLI 不再单独覆盖硬件阈值；`run.py/run_ppl.py` 使用 `--parameters PATH` 选择实测 JSON，阈值从其中读取。只有完整实测参数包可正式运行。

## 如何正确统计搬运节省

- **一个 PE block skip**：该输出/该 K block 不执行产品和局部累加；不会因为其中正负数抵消而修改决定。PE-block input deliveries、有效 MAC 和 partial 搬运相应减少。
- **Tile 输入共享**：同一 Tile 的 32 个 PE 共享 activation block。只要其中任何 PE 需要该 block，该 Tile 的输入仍要接收。所有 PE 均 skip 才关闭该 Tile 接收。
- **源 SRAM payload**：一个 K block 被多个 Tile 复用。全阵列所有接收方均 skip，才省掉这份源 payload 读取。
- **scale 元数据**：输入 scale 每向量都检查，不能因为后续 skip 而消失。权重 scale 由本地驻留元数据提供，报告它的访问量；这不是每向量重复从 Mem Die 冷加载权重。
- **TAG zero element**：广播后译码才得到，只减少对应 PE lane 活动，不反过来修改 MX block mask 或此前已经发生的广播/读取。
- **Host/DMA**：用户给出的流程先把完整输入写入 SRAM。后续 MX skip 不减少已经发生的 Host 输入传输。是否把主机段计入评估仍由 `model_host_io` 控制。

例如仅两个 K block，所有 PE 对 block 0 的距离都超过已配置阈值，block 1 保留：源端读取 16 B payload 加两份 scale 共 18 B，而不是 17 B；Host 仍输入完整 34 B。

## E3/M10 仍然负责什么

它们继续服务于 PE 内部计算、有限位宽截断/饱和以及 PE 后的数值归约。原来的 20-bit 有符号饱和与 toward-zero 规则保留。PE 后数值归约使用的 `Eblock=E3max+Esum`、数值最大指数，和广播前控制器的 `EMXmax=max(Esum)` 分开报告；前者不会反馈到 block gate。

这次修改不会把“固定阈值跳过”宣称为任意输入下与 FP64 无损等价。报告继续比较 FP64 reference 与实际门控后的有限位宽输出，并保留 PPL 接口评估质量影响。

## 时序、能耗与导出

Trace 新增独立阶段：

| operation | 含义 |
|---|---|
| `input_scale_read` | 从 SRAM 读取所有输入 scale |
| `scale_block_decision` | 广播前仅 scale 决策；依赖权重元数据可用 |
| `input_prefetch` | 根据 mask 读取必要 payload |
| `input_broadcast` | 广播 MXFP4 payload/scale |
| `mxfp4_to_tag_fp` | 广播后的格式适配 |
| `array_mac` | 保留 PE 的计算 |
| `aligned_reduce` | PE 后数值归约 |

`mx_control_cycles`、`tag_decode_cycles` 默认各 1 拍，是可替换的结构假设。新增 `energy.mx_control_pj_per_block`、`energy.tag_decode_pj_per_element`，当前 0 为待校准占位值，报告为 assumption；不能当成实测零能耗。总体仍不具备物理能耗结论所需的完整校准。

`export_rtl_vectors` 新增以下 NPZ 数组：

| 数组 | 形状 | 内容 |
|---|---|---|
| `mx_esum` | `[vectors, outputs, K_blocks]` | 两个 scale 的无偏指数和 |
| `mx_emax` | `[vectors, outputs]` | 每输出沿 K 的最大 Esum |
| `mx_distance` | `[vectors, outputs, K_blocks]` | 广播前的指数距离 |
| `mx_skip_mask` | `[vectors, outputs, K_blocks]` | True 表示 MX block skip |
| `mx_compute_mask` | `[vectors, outputs, K_blocks]` | True 表示允许该 PE block 计算 |

`export_mx_control` 的广播前记录同时带有上述控制信息、`decision_source`、`threshold_bits`、`vector_id`。`valid_mask` 表示结构上有效的 PE block，不再取决于 payload 是否为零；不要将它与 TAG element zero mask 混用。

## 验证结果

2026-10-17 在本地运行：

- `python tests/run_current.py`：40 项通过，0 失败；含 8 项新增 scale-only 测试，以及 1024 规模 B=1/2/8/32 功能、带宽、容量、resident weight、导出和 PPL 滑窗回归。
- V1：64 checks 通过；V2：111 checks 通过。
- Torch 2.5.1 的小型 `Linear(64,4)` finite PPL 适配器检查：显式测试阈值 T=2 传入 V3 后跳过 4 个 PE block，active MAC=128、dense MAC=256，退出上下文后恢复原 forward。
- `python run.py --estimate --latency-source config --json report_scale_only_20261017.json --trace trace_scale_only_20261017.json`：完整默认矩阵运行成功。该文件是 T 尚未确认时不启用 MX skip 的例子，不是实际 RTL 校准性能/能耗结果。

专项测试检查：阈值等号、9-bit scale 相加、payload/E3 变化不改变 skip、零 payload 不影响 scale Emax、共享 Tile/source 的保留、scale 检查不能被省略、trace 顺序、mask 导出以及未确认阈值时不凭空计节省。

真实模型 PPL 尚未运行；需要本地 pretrained checkpoint、tokenizer 与 held-out 文本。现有旧 `report.json`、`final_report.json` 和旧文档中的静态周期/能耗不自动覆写，请根据确认后的阈值重跑。
