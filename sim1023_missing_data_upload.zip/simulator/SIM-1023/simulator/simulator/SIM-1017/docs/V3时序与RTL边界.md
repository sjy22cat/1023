# V3 timing and RTL boundary

> 历史设计/验证记录：正文保留原始背景，其中旧参数路径、估算方法、命令与性能数字不适用于当前版本，请勿据此运行或发布结果。当前参数、运行方式和限制以 [README_SIM-1017.md](../README_SIM-1017.md) 为准；RTL 实测交付见 [RTL_instruction.md](../../../Instruction/RTL_instruction.md)。

`V3Config.latency_source` controls which timing values are consumed by the
shared-resource schedule:

```bash
python run.py                         # auto: use the discovered RTL datasheet
python run.py --latency-source rtl    # require a real V3Datasheet
python run.py --estimate --latency-source config
```

`auto` and `rtl` consume `V3Datasheet.mem_die_latency` in Mem Die cold-start
events. `config` uses `V3Config.mem_die_latency`. The resolved value is
reported in `report["cycles"]["timing_model"]` and in the dependency path.
`PHY_STAGES` and `BPC` are retained as serialized-link metadata; the current
wide ideal baseline does not reinterpret them as a broadcast delay. They must
be calibrated before enabling a finite-link timing model.

The Python RRAM-FP and TAG-FP converters are behavior-level adapters. They
provide stable interfaces for the server RTL LUT/decoder vectors; they do not
claim bit equivalence with the current legacy arithmetic RTL.
`MxControlTrace.valid_mask` is a block-level mask with one entry per output
row and K block. A real PPL number still requires a local checkpoint,
tokenizer, and held-out text; the repository only contains the deterministic
PPL runner and synthetic tests.
