# SIM-1017 操作说明

软件目录是 `simulator/SIM-1017`，对应 RTL 为 `RTL/RTL_1017SIM`。统一使用说明、完整参数表及模型限制已整合到 [README_SIM-1017.md](../simulator/SIM-1017/README_SIM-1017.md)，本文件列出实际操作顺序。

## 0. 当前准备情况

截至 2026-10-18，当前工程有模型结构预设、数值模拟代码和权重加载接口；**未发现真实预训练 checkpoint 或真实 tokenizer 文件**。默认 Qwen3-0.6B 表示结构，未指定权重时使用固定 seed 的随机权重，tokenizer 默认为内置 `ByteTokenizer` 占位实现。硬件 JSON 目前仍为 PENDING，缺真实新思结果。

| 要做什么 | 需要实测硬件参数吗 | 还需要模型数据吗 |
|---|---|---|
| 软件回归、查看帮助/必填字段 | 否；测试显式注入合成参数 | 无 |
| `--list-models` 查看预设 | 否；容量仅为已标注的设计默认参考 | 无 |
| `run.py` 单算子、`--smoke` 小模型链路 | 是 | 可使用生成的随机矩阵/权重与占位 tokenizer |
| `--forward shape` 容量/流量/性能账目 | 是 | 内置模型名或目标 `config.json`；不需要真实权重/tokenizer |
| `--forward numeric` 真实模型数值推理 | 是 | 匹配的结构、完整权重、真实 tokenizer、prompt |
| PPL 的 `fp32/dense_mxfp4` 质量比较 | 否 | 完整本地模型/tokenizer 和独立测试文本 |
| PPL 的 `finite_mxfp4` | 是 | 同上，另受当前 Linear/K 分块覆盖限制 |

硬件数据和模型数据是两份独立输入。没有 checkpoint 不妨碍 shape 评估；没有实测硬件参数时，正式 shape/smoke/单算子评估仍不能运行。shape 不读取真实数值，也不能提供真实输入的稀疏、lane mask 或 skip 分布。

## 1. 准备新思参数

请 RTL 表征方按 [主 README](../simulator/SIM-1017/README_SIM-1017.md) 第 3–4 节运行 Synopsys 与配套 memory/PHY IP 表征，结构与验证见 [RTL_1017SIM 说明](RTL_1017SIM_instruction.md)。模拟器不再从 RTL/.vh、门数、面积或 Python 默认单价推导硬件参数。

将结果按 [模板](../simulator/SIM-1017/calibration/rtl_1017sim/rtl_1017sim_measured.json) 汇总到：

```text
D:\ZJLab\zjlab_exp\zjlab_exp\cooperation\YRR\YRR_system\simulator\SIM-1017\calibration\rtl_1017sim\rtl_1017sim_measured.json
```

该 JSON 是唯一直接读取的硬件参数源，旁边的 `synthesis/sta/power/memory/traces` 保存原始报告。模拟器不会自动从新思 `.rpt/.lib/.saif` 提取数据。各 PVT/版本使用独立 JSON，通过路径选择。

必填章节为 `structure/timing/config_overrides/energy/area/llm_hardware/llm_prices/nonmac/provenance`。固定配置为非理想 32 MC/32 channel、32×32 tile、32 PE/tile、32 lane/PE、128+8 bit。带宽填每 channel 的 B/cycle，总 outstanding 数与每 MC 深度不能混淆；MC 固定延迟与服务段不重复。详见主 README 第 3 节。

确认数据齐全后才设 `status=MEASURED`，schema 为 `sim-1017-synopsys-measured/v2`。当前模板为 PENDING，没有真实新思测量值，默认运行会报错；禁止直接复制测试合成值或以 0 补未知字段。旧 v1 参数需要针对修改后的 RTL 重新核对、表征，不能只改 schema 名字。

### 非 MAC 参数的新口径

按 [非 MAC 实测说明](nonmac_1017SIM_measurement.md) 采集三个 FP32 模块及配套 scratch 的结果。`nonmac.profiles.<op>.<length>` 逐算子、逐实际长度填写 `cycles/dynamic_pj/read_count/write_count/report`，`run.py` 的归约转换及 scratch 写入另用 `nonmac.reduce_staging.<length>`。时钟、RTL revision、DW 版本、scratch 实现、活动策略和报告路径都需要记录；动态能量不含泄漏，泄漏另计一次。已有测量值只代表对应的操作数活动策略。

模拟器已删除通用“非 MAC=Softmax 单元素价”的路径，也不再按 `softmax_lanes` 推算吞吐。旧 `softmax_exp/add/div_pj`、`softmax_cycles_per_group`、`softmax_lanes/materialize_exp` 字段退出接口，面积项使用 `nonmac_mm2`。未测长度直接报错，无插值或软件估算回退。

Softmax 按上下文长度逐行计费，RMSNorm 按 hidden/head_dim 逐行计费；点运算可按 1024 加尾块拆分，Softmax/RMSNorm/LayerNorm/split-half RoPE 超过 1024 会被拒绝。因此下方大模型/长上下文示例还必须满足该硬件限制，并备齐实际使用长度的测量条目；参数齐全不代表所有模型形状都能运行。

NumPy 继续计算功能参考值，性能和能耗来自实测记录。MXFP4 编码、正余弦表准备、token 采样/argmax 尚无这三个模块对应的硬件实现，目前作为 Host 参考步骤并明确排除其成本。报告通过 `execution_scope` 声明加速器服务范围及 `full_system_metrics_complete=false`，不得将其当作含 Host 的整机结果。精确 GELU 等未实现的硬件算子会报错。

## 2. 校验和运行

以下 PowerShell 命令以 `SIM-1017` 为工作目录，基础依赖为 NumPy：

```powershell
Set-Location 'D:\ZJLab\zjlab_exp\zjlab_exp\cooperation\YRR\YRR_system\simulator\SIM-1017'
python -m pip install -r requirements.txt
```

现在没有实测参数/模型文件，也可以检查软件：

```powershell
python tests/run_current.py
python run_llm.py --list-models
python validate_parameters.py --list-required
python run.py --help
python run_llm.py --help
python run_ppl.py --help
```

填齐新思参数后，再执行以下评估；PENDING 时会拒绝运行：

```powershell
python validate_parameters.py
python run.py --m 1024 --k 1024 --no-softmax --json report.json --trace trace.json
python run_llm.py --smoke --json llm_smoke.json
python run_llm.py --model qwen3-0.6b --forward shape --prompt-tokens 128 --max-new-tokens 16 --json llm_shape.json
```

这组命令均不要求外部 checkpoint/tokenizer。`run.py` 默认用生成矩阵，smoke 用随机小模型；要对真实算子数据进行有限位宽/skip 验证，通过 Python `run_v3` 传入真实 `weights/inputs` 或 payload+scale，接口见主 README。

默认路径按软件包位置解析，不受工作目录影响；在工程根运行时只需为脚本添加 `simulator/SIM-1017/` 前缀。`run.py/run_llm.py/run_ppl.py` 可用 `--parameters PATH`（别名 `--rtl-1017-calibration PATH`）指定其他实测文件，显式相对路径以当前工作目录为基准。

参数加载拒绝旧 schema、PENDING、缺失/非法必填值，且不会回退到估算。校验器只检查契约和部分一致性，不证明原始报告真伪、STA 收敛或 RTL 等价。

`run.py --config` 只接受 shape、seed、驻留/层映射和计算开关等任务配置，硬件值由 measured JSON 强制绑定。`--with-host-io` 加计 Host/DMA；Mem Die→HB/PHY→MC 的 32 路搬运与 Host DMA 分开。

## 3. LLM 与质量评估

### 3.1 先运行模型形状评估

在实测 JSON 完整的前提下，使用内置模型名即可运行，不必先下载权重：

```powershell
python run_llm.py --model qwen3-0.6b --forward shape --prompt-tokens 128 --max-new-tokens 16 --json llm_shape.json
python run_llm.py --compare qwen3-0.6b,llama-3.2-1b --forward shape --prompt-tokens 128 --max-new-tokens 16 --json compare_shape.json
```

新模型也可用 `--model D:/models/MODEL/config.json` 提供结构。需要层数、hidden/FFN 尺寸、attention/KV head 数、head_dim、vocab、位置长度、权重绑定、RoPE/归一化和架构特殊配置，优先保留官方原始文件。**`--model` 选择结构，不自动下载/加载预训练权重。** MoE/MLA 前向仍未实现，容量描述不代表可执行。

### 3.2 准备真实模型文件

从官方发布源获取同一 revision 的完整模型目录。以下为建议路径，工程当前未附带这些数据：

```text
D:/models/Qwen3-0.6B/
  config.json
  model.safetensors               # 或完整的全部 model-*.safetensors 分片
  model.safetensors.index.json    # 分片发布时保留
  vocab.json
  merges.txt
  tokenizer.json
  tokenizer_config.json
  special_tokens_map.json         # 如发布包提供则保留
  generation_config.json         # 可归档；原生入口不自动应用全部生成设置
D:/datasets/test.txt               # 独立 UTF-8 测试文本，用于 PPL
```

模型文件可放在其他本地位置，通过参数选择；硬件 `calibration/` 保存新思参数，不存放模型权重。保留模型、tokenizer、测试集的版本/哈希；分片必须齐全，配置、权重和词表必须匹配。

| 数据 | 当前读取要求 |
|---|---|
| 原生 LLM 权重 | `--weights DIR` 读取普通浮点 FP32/FP16/BF16 `*.safetensors`，包含 embedding、所有层矩阵/归一化、final norm、需要时的 lm_head；内部转 MXFP4 |
| 原生 LLM tokenizer | `--tokenizer DIR` 当前为 Qwen 字节 BPE，**必须有 `vocab.json` 和 `merges.txt`**；只有 `tokenizer.json` 不够；其他分词体系需适配 |
| PPL 模型/tokenizer | `--checkpoint DIR` 由 Transformers 离线读取完整 HF 目录，支持其可加载的 safetensors 或 `pytorch_model*.bin` 及配套 tokenizer，不另给 `--tokenizer` |
| 输入规模 | prompt 文本、S 输入 token 数、T 生成 token 数、运行次数；性能比较固定这些值 |
| PPL 测试数据 | `--text FILE` 指向独立 UTF-8 测试文本，同时记录 context、stride、token 上限及数据来源 |

GGUF/GPTQ/AWQ 等预打包量化格式不能直接替代原生浮点 safetensors。无需事先提供全部中间激活或 KV cache，运行时由数值路径生成；shape 由结构推导相应容量/流量。

### 3.3 真实权重数值推理

先准备实测硬件 JSON 和上述模型数据，再从 `SIM-1017` 运行：

```powershell
python -m pip install regex
python run_llm.py --model D:/models/Qwen3-0.6B --weights D:/models/Qwen3-0.6B --tokenizer D:/models/Qwen3-0.6B --forward numeric --prompt "你好" --prompt-tokens 32 --max-new-tokens 8 --json llm_numeric.json
```

显式 `--forward numeric` 确保进入数值路径；`auto` 可能选择 shape，shape 即使收到 `--weights` 也不会读取权重。`--prompt-tokens` 固定输入长度，短文本左补 pad、长文本截断。`regex` 用于原版 Qwen BPE 预切分；原生入口不自动应用 HF chat template。先用短输入和少量生成步验证，再扩大规模。

真实 checkpoint 尚未随工程完成接入验收；第一次加载须检查张量名、形状和词表匹配，遇到架构/格式差异需相应适配。随机权重或占位 tokenizer 的输出只能检查链路，shape 也不验证语言质量。

### 3.4 困惑度/质量比较

```powershell
python -m pip install -r requirements-ppl.txt
python run_ppl.py --checkpoint D:/models/Qwen3-0.6B --text D:/datasets/test.txt --modes fp32 dense_mxfp4 --context 256 --stride 128 --max-tokens 1024 --json ppl.json
```

依赖包括 torch、transformers、safetensors、regex；torch 选择与 CPU/CUDA 环境匹配的版本，按 tokenizer 补齐依赖。PPL 使用本地模型/tokenizer，`local_files_only=True`，不自动下载。上述两种模式不读取物理参数，可在新思参数准备前评估数值质量，但必须先有真实模型与测试文本。

`finite_mxfp4` 额外读取 `--parameters PATH` 指定的实测 JSON，只有 Linear 权重/输入覆盖有限位宽路径，其他算子/embedding/KV 不全部覆盖。当前任意大 K 的硬件分块尚未实现，Linear 的 K 超过 1024 会被拒绝；Qwen3-0.6B 的部分投影超出此范围。只有实际满足支持范围的模型才可加入该模式，不能宣称全部模型已通过有限位宽 PPL/RTL 验收。**省略 `--modes` 时默认会包含 `finite_mxfp4`，因此首次质量比较请显式写出上面的两个模式。**

## 4. 验收和边界

```powershell
python tests/run_current.py
```

回归显式注入合成测试数据，与正式 PENDING 模板分离；通过回归不等于获得物理测量或完成 RTL 验收。与 VCS 对比冷/热启动、每 channel 事务/字节、mask、有效 MAC、阶段周期和输出，再评估误差/PPL。

单算子事件调度支持 32 独立 channel 资源，但不逐拍重放全部 RTL 协议；LLM 当前搬运仍是串行聚合账本。`--cores` 是 core 乐观对照，不能用来配置 32 MC 并行。

`export_calibration.py`、旧 `rtl_1017_calibration.json/llm_calib.json`、`ESTIMATE/from_rtl/fallback` 及面积估算入口已经删除。原 README/README_LLM 的有效内容已合并到主 README。历史 `RTL_v3`、旧验证报告和原始 package manifest 保留追溯，不作为当前硬件参数源。
