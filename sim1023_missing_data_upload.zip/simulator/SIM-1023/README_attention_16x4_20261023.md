# SIM-1023 增量 Attention 映射和新思数据说明

本次已有 calibration 文件内容保持不动。`existing_calibration_sha256_20261023.json` 记录修改前的 5 个 calibration 文件 SHA256；`Attention_confusion/parallel_row/synopsys/existing_data_inventory.json` 记录 Python 入口 4 个 JSON 的逐字段缺口与已有值。没有把预算、测试合成数据或名义 1ns 写入已有测量记录。

## 正确入口和版本差异

SIM-1023 实际 Python 根目录是 `simulator/SIM-1023/simulator/simulator/SIM-1017`；随包 RTL 是 `simulator/SIM-1023/RTL/RTL/RTL_1017SIM`。仓库原来的 `simulator/SIM-1017` 保留原样。

| 项目 | 原 SIM-1017 | SIM-1023 原有更新 |
|---|---|---|
| MC | 以列/外部通道控制器为主要粒度 | 32768 个逐 PE MC，32 个外部通道独立；MC 和 channel 不等同 |
| 数据依赖 | 原 MXFP4/tag/scale skip | 矩阵/PPL 增加逐 PE read/skip mask，按组件记录计费 |
| 广播/归约 | 原整体模型 | 新广播树、可选 BookSim/网格及线模型，区分 latency 和 II |
| Host/DMA | 历史配置和接口 | 移出推理成本；已有 Host 预装载只作流量记录 |
| 非 MAC | 原逐命令表 | 新 1024 路复制估算接口；面积/能量按1024路，延迟按并行波 |
| 完整 LLM Attention | QK、Softmax、PV 独立计费 | 本次修改前仍相同，没有 16×4/head 调度 |

新增的逐 PE MC/读 mask 和互连详细模型主要供矩阵/PPL 使用。`run_llm.py` 仍用串行聚合存储传输账本，没有按 32768 MC、32 通道逐拍调度；新的 Attention 分支也不改变这一点。原有 0.4mm tile pitch、12.8mm 阵列和线模型是带假设的拓扑估算，不是布局后互连测量。

随包 RTL 还存在必须在系统综合前处理的旧/新接口差异：

- `nonmac_sources.f` 仍列 `rtl/llm_nonmac_fp32.sv`，包里实际是 `llm_nonmac_fp32_1017修改版2.sv`；原 MC 文件名也变成 `mx_mc_1017修改版.v`。
- `yrr_1017_top.v` 默认 `MC_COUNT=32`，仍按32个外部通道实例化控制器，不实现 Python 所述32768逐 PE MC。
- 新 `llm_nonmac_fp32` 有 `cmd_vector`、`cmd_x/y/gamma/beta` 等向量端口，旧 `mx_nonmac_1017.sv` 实例没有连接这些端口。不能仅改文件名就宣布可用。

本次没有替用户改动这些既有 RTL 或已有数据。单独 `parallel_row` 综合完全独立于上述系统 RTL；系统表征提示词要求先检查接口，未实现项明确标记。

## 本次新增融合模式

默认仍为 `--attention-impl unfused`，便于对照。选择融合模式：

```text
python run_llm.py --forward shape --kv-shadow none --prompt-tokens 1024 --max-new-tokens 128 --parameters <完整原系统测量契约或新补齐副本> --attention-impl fused_16x4 --attention-calibration <独立Attention实测JSON> --json result.json
```

从实际 Python 根目录执行。另一工作负载改成 `--prompt-tokens 128 --max-new-tokens 1024`。新增独立 `attention_calibration_path`，不覆盖旧价格；shape 模式跳过 NumPy 大矩阵数值计算。没有新增 batch 调度器，`n_runs` 是重复串行运行，不是 batch。先前 batch=32/64/128 的预算脚本仍是独立架构估计。

映射：一个 head 用16个 context row×4个维度 column＝64个逻辑32×32 tile；32×32逻辑阵列最多放16个head（2个行组×8个列组）。一个query的heads按最多16个并发；不同query串行；Qwen3-0.6B的16个Q head为一波。单 head 仍然处理全部可见上下文，只是把 token 分给16路。多波超过512token时合并在线统计。

融合分支的具体计费：

- `attn_fused_16x4`：读取精确 N 的单 head 动态能量，乘head数和query数；计算周期乘head波数，不乘同波head数。
- 单 head profile 的理想 KV load 周期为 ceil(N/32)。从计算项扣除，再以 `max(理想握手下限,现有串行外存传输周期)` 计加载；其余外部Q读取和O写回单独累计。存储/计算不重叠。较慢输入可能增加内部空闲能量，该集成差额仍待测。
- 每个query/head只读Q一次，读该head需要的N行K和V各一次；GQA两个Q head仍独立读取共享KV数据，不假设未实现的广播节省。
- 复用原Q/K/V投影、RMSNorm、RoPE、输出投影、MLP、LM head、RRAM/FeRAM/PHY/GSRAM计费。V投影仍由`v_proj`计费；PV已经包含在融合单元中。
- 移除融合范围的旧QK/PV满阵列计费、standalone Softmax/score缩放计费及S/A外存中间写回；局部MAC、Softmax、KV寄存器在单head profile内只计一次。
- 数值参考保留MXFP4的Q/K/V，融合内部Softmax权重和PV为FP32，不把A再量化。prefill改为因果：第t个query访问`pos+t+1`个token；滑窗取对应KV尾段。旧分支的全P×P prefill上界与数值语义保持不变，因此比较两种模式时除了映射也要注明因果范围变化。

两组工作负载的精确长度都是N=1..1151：prefill为1..P，decode是O−1步，对应P+1..P+O−1；最后一个输出token不再做forward。N=1152只作单head基线。默认RTL周期公式183拍在1152token时成立，但未经STA不能解释成183ns。

## 新增测量契约和限制

新模块 `yrr_v3/llm/fused_attention.py` 只接受 schema=`yrr-fused-attention-16x4/v1`、status=MEASURED，并检查FP32默认参数、官方DW数值、完整映射、无黑盒、setup/hold通过、时钟与旧系统一致、RTL SHA256及报告来源、精确N profile。RTL SHA256用于记录测量版本；远端需核对与待测文件一致，运行时不凭源码自动推算硬件成本。缺项直接拒绝，能量不插值，不使用旧算子价格回退。

模板在 `Attention_confusion/parallel_row/synopsys/fused_attention_16x4.template.json`。不要直接把模板改为MEASURED。另存测量文件，未完成N保持缺失和PENDING。profile.dynamic_pj 包含单head FP32评估器内部MAC、Softmax和局部KV寄存器，排除外存和漏电。漏电另计。

必须区分逻辑映射和真实物理复用：`parallel_row`并未实例化原MXFP4物理tile。仍缺MXFP4↔FP32桥接、多head供数/仲裁、真实多列MXFP4接口和集成漏电差额。输出报告在`attention_mapping`和`attention_pending`列出这些问题，最终全系统tok/s/J/token保持PENDING；已能计价的合计作为partial projection保留。不能把FP32评估器的面积/能量宣称为原MXFP4阵列的实测面积/能量，也不能把16倍单head面积加到原阵列后同时声称MAC复用。

当前完整系统JSON还是PENDING、组件JSON为PARTIAL，正式`run_llm`会在原测量契约加载阶段拒绝。补足Attention本身不会绕过原系统缺项。已有数据可复用，但新增一份完整契约需要明确字段、单位和scope映射；`components_20261019*.json`不能直接当完整`--parameters`运行LLM。

原有decode tok/s公式使用O作为分子、decode时间只包含O−1步；本次未改动旧指标定义。读实际decode服务率时应使用`(O−1)/decode_s`，端到端仍为`O/e2e_s`；多次n_runs还需按每次的token/窗口对应统计。请勿将旧报告decode列作为严格逐步decode吞吐。

## 上传与测量任务

运行 `python Attention_confusion/parallel_row/synopsys/build_upload.py` 可生成两个独立zip：

1. `attention_16x4_synopsys_upload.zip`：三个RTL、测试台、实数数学参考包、文档、约束参考、测量模板和Prompt1。解压后保留目录层级，从包根目录执行。
2. `sim1023_missing_data_upload.zip`：以上文件加SIM-1023的Python/测试/原校准记录/随包RTL/Prompt2，用于系统缺口审计与新增测量。排除本地vvp、缓存、功能DW替身和工具私有库。

已有SMIC标准单元库、官方DW模型和EDA工具在远端环境配置，不在上传包复制。每个包有UPLOAD_MANIFEST.json；系统包有verify_upload.py，用SHA256校验文件传输完整性。

本地验证使用明确TEST_ONLY合成价格检验计费，不构成新硬件数据。官方VCS/DC/PrimeTime/PrimePower结果应由远端执行提示词后取得。
