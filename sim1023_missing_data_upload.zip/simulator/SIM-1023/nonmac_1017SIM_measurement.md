# SIM-1017 FP32 非 MAC 接口与新思实测契约

当前实现位于 `RTL/RTL_1017SIM/rtl`。`llm_nonmac_fp32.sv`、`nonmac_fp32_pipe.sv`、`nonmac_microcode.vh` 为集成版权威源；`RTL` 根目录原文件仅保留作来源参考。集成版向量 RoPE 增加了 split-half 地址适配，不能将原文件覆盖回集成目录。

## 1. 硬件接线与执行顺序

`yrr_1017_top.v` 实例化 `mx_nonmac_1017`，后者包含一套共享 FP32 微码执行引擎及一个 `mx_fixed_to_fp32_1017` 转换器。五类算术单元使用真实 DesignWare `DW_fp_addsub/mult/div/exp/sqrt`；RTL 中没有使用 `real`、`shortreal` 或行为 Softmax 替代计算。

顶层的矩阵和非 MAC 命令串行接收。矩阵 `i_start` 仅在矩阵控制器空闲且非 MAC 不忙时生效；执行非 MAC 或输出待消费时的新矩阵 start 被忽略。软件/外部调度器需要等待接口就绪后发命令。当前没有自动运行整个 Transformer 的硬件指令流。

| 接口 | 使用方法 |
|---|---|
| `i_nonmac_cmd_valid/o_nonmac_cmd_ready` | 在上升沿二者同时为 1 时接收一条命令；等待期间保持命令稳定 |
| `i_nonmac_op/len/a/b/c/d/epsilon/tag` | opcode、向量长度、FP32 标量参数、任务标识 |
| `i_nonmac_from_reduce=0` | 输入及系数已经位于外部 scratch；直接启动引擎 |
| `i_nonmac_from_reduce=1` | 使用最近一次矩阵归约快照，逐行转换 `mantissa × 2^exponent` 为 FP32 并写 scratch，然后执行向量命令 |
| `o_nonmac_valid/i_nonmac_ready` | 完成响应握手；等待消费期间数据、tag、错误和计数保持稳定 |
| `o_nonmac_data/aux` | 标量结果；向量结果写入 scratch，完成响应的数据不代表整条输出向量 |
| `o_nonmac_error` | 非法 opcode/长度、非有限输入/运算结果等；收到错误不能使用该命令的数值结果 |
| `o_busy` | 矩阵或非 MAC 忙；非 MAC 输出尚未消费也保持忙 |
| `o_done/o_cycles/o_result_valid` | 仍表示矩阵阶段完成、矩阵阶段周期和原始归约有效；不表示非 MAC 已完成 |

归约输入模式必须已有有效归约快照，且命令为向量 opcode、`1≤len≤min(ROWS,1024)`。新矩阵 start 会清除旧快照的有效标志；错误长度会返回错误。转换器实现 nearest-even 舍入、正规数/次正规数、溢出检测。默认阵列 `ROWS=1024`。

## 2. 外部 scratch 接口

`o_nonmac_mem_valid/i_nonmac_mem_ready` 接收请求。`o_nonmac_mem_write=1` 为写，写请求握手即完成，不再返回写响应。读请求握手后，存储端应在后续周期给出 `i_nonmac_mem_rsp_valid/rdata`，并保持到 `o_nonmac_mem_rsp_ready=1`。只有一个 outstanding 读；不支持只在读请求同周期脉冲返回且不保持的存储端。

地址是 **32 位 FP32 字地址**，不是字节地址；接口为 13 位，共 8192 个字（32 KiB）。外部必须连接真实 SRAM macro，或提供到真实 GSRAM 的地址适配/仲裁。此存储体不在三个核心文件内部，不能用 testbench 数组的面积和能耗代替 macro。Host/DMA 应在命令前准备输入/系数，完成后读取输出；执行期间不能通过其他端口破坏这些区域。

| 字地址区域 | 用途 |
|---|---|
| `0+i` | 输入 X |
| `1024+i` | 残差/SwiGLU 的第二输入 Y |
| `2048+i` | RMSNorm/LayerNorm 的 gamma；RoPE 的 cos 表 |
| `3072+i` | LayerNorm 的 beta；RoPE 的 sin 表 |
| `4096+i` | 输出；Softmax 也在此物化指数中间结果 |

向量 RoPE 使用 `(X[i],X[i+len/2])` 配对，cos/sin 每对一个值；地址适配直接写回相同的前后半段布局，不需要额外转置。它不负责生成正余弦表。

## 3. opcode 与计数

| opcode | 算子 |
|---|---|
| 0–6 | add、sub、mul、div、exp、sqrt、rsqrt |
| 7–12 | sigmoid、silu、gelu_tanh、rope_pair、swiglu、relu |
| 16–20 | softmax、rmsnorm、layernorm、residual、attention_scale |
| 21–25 | silu_vector、gelu_vector、swiglu_vector、rope_vector、relu_vector |

向量长度范围为 1–1024，RoPE 长度必须为偶数。Attention scale 的乘数放在 `cmd_b`；RMSNorm/LayerNorm 的 epsilon 放在 `cmd_epsilon`。基础标量操作数为 `a/b`；标量 RoPE 输入 `a/b` 为一对值、`c/d` 为 cos/sin。GELU 实现为 tanh 近似，不覆盖 erf 形式的精确 GELU。

`o_nonmac_exec_cycles` 是核心从接收命令到产生结果有效的活动周期；包含微码、ALU 等待、scratch 请求/读响应等待，不包含输出被阻塞的时间。`o_nonmac_cycles` 覆盖外层接收命令、可选转换写入、启动引擎到结果有效；目前纯 scratch 命令比 exec 多一拍启动。不要用流水级数推算整个算子周期。

`o_nonmac_reads/writes` 统计微码中已握手的读/写请求；`o_nonmac_stage_writes` 单独统计归约转换阶段写入，不混入核心计数。归约 staging 的周期按 trace 中进入 STAGE 到最后一次 staging 写握手的窗口测量，排除引擎启动拍；不能把含核心计算的总周期再次填入 staging。

## 4. 本地回归与真实新思运行

在工程根目录执行本地回归：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File RTL/RTL_1017SIM/run_tb.ps1 -TestModels
python simulator/SIM-1017/tests/run_current.py
```

`-TestModels` 明确启用 `tb/nonmac_test_dw.sv` 的测试专用算术模型；它仅验证控制、数值示例和接口，**不是 DesignWare 等价/PPA 证据，不能进入任何物理参数模板**。生产文件列表 `nonmac_sources.f`、DC 脚本及 VCS 脚本均不包含该文件。`tb/nonmac_scratch_tb.sv` 同样只是可施加背压的验证存储模型。

在有授权的 Linux Synopsys 环境，从 `RTL/RTL_1017SIM` 执行：

```sh
export DW_SIM_DIR=/your/synopsys/dw/sim_ver
sh run_vcs_nonmac.sh
export TARGET_LIBRARY='/your/pvt/standard_cells.db'
export CLOCK_NS='your_reviewed_target_period'
export IO_CONSTRAINTS=/your/reviewed_io_constraints.tcl
dc_shell -f synopsys/nonmac_dc.tcl
```

这些路径和时钟需要替换为实际工程值。DC 使用 `compile_ultra -retime`；组合 DW 算术能否通过寄存器重定时满足目标频率必须以实际工具结果验收，不允许用多周期例外掩盖。默认 DC 表征 `mx_nonmac_1017`，不包含真实 scratch macro，也不代表完整百万 MAC 阵列的面积。

功能回归需要波形时运行 `sh run_vcs_nonmac.sh +dump`，输出 `sim/vcs/nonmac.vcd`。这是当前 RTL/验证存储的活动文件，不可直接冒充真实宏和映射后完整路径的功耗活动。

VCS 脚本是全 opcode 数值/接口回归入口，默认只覆盖固定小长度。正式表征需要为目标模型实际用到的每个算子/长度准备真实或已说明分布的操作数，连接与最终实现一致的 scratch 延迟/仲裁，运行映射后 netlist/SDF，生成 SAIF/VCD 活动，并使用对应 macro power model 在 PrimeTime/PrimeTime PX 中表征。STA 确定可用时钟，PT PX 给出选定窗口内的动态能量；保留源码 revision、DW 版本、PVT、约束、活动策略及报告路径。没有安装 Synopsys 的机器不能完成这些物理验证。

## 5. measured JSON v2

唯一默认软件输入仍为 [rtl_1017sim_measured.json](../simulator/SIM-1017/calibration/rtl_1017sim/rtl_1017sim_measured.json)，schema 升级为 `sim-1017-synopsys-measured/v2`。当前模板继续保持 PENDING，所有未知物理量保持 null。旧 v1 参数被拒绝，需要针对集成版重新表征；不能只改 schema 名字继续使用旧非 MAC 估算。

新章节 `nonmac` 要求：

| 字段 | 口径 |
|---|---|
| `implementation/max_vector_length` | 固定 `llm_nonmac_fp32/1024` |
| `clock_ns` | 与顶层 `timing.clock_ns` 一致 |
| `scope` | 固定 `engine_and_scratch_dynamic_excludes_staging_and_leakage` |
| `rtl_revision/dw_version` | 集成版 revision（与顶层 provenance 一致）及实际 DW 版本 |
| `scratch_implementation` | macro/端口/地址适配/延迟/仲裁配置，必须与测量一致 |
| `activity_policy/reports` | 操作数分布、窗口和报告索引；单一能量记录只代表该活动策略 |
| `profiles.<op>.<length>` | 核心命令的精确长度记录；`op` 使用上表英文名称，标量 length 键固定 `"1"` |
| `reduce_staging.<length>` | 转换器及其 scratch 写入的单独实测记录；`run.py` 开 Softmax 时需要 |

每条记录含 `cycles`（正整数）、`dynamic_pj`（有限非负）、`read_count/write_count`（非负整数）及 `report`（原始证据路径）。`profiles` 的 cycles 填核心 `exec_cycles` 加外层启动开销的实测结果（直接使用 from_reduce=0 的 `o_nonmac_cycles`）；动态能量包含该窗口的控制/寄存器/算术与 scratch 访问，排除泄漏和输入 staging。`reduce_staging` 包含转换器/暂存控制及每元素一次 scratch 写的能量和周期。两个窗口不能重叠计费，也不能再次按 GSRAM 单价重复收费。

泄漏使用外部 `energy/llm_prices.leakage_pj_per_cycle` 在串行活动周期上另计一次。staging 和 command 报告应使用同一时钟、PVT、scratch 实现及活动策略。

模板中的 length=1024 只是待填条目，不会覆盖其他长度。按需添加目标长度，如 Softmax 的上下文长度、RMSNorm 的 hidden/head_dim、激活函数的尾块长度。加载器验证已有条目，运行时遇到未测长度直接报错；不插值、不外推、不从 RTL/微码推导周期或能耗。

旧 `softmax_lanes/materialize_exp/softmax_cycles_per_group` 和 `softmax_exp/add/div_pj` 参数已经退出运行接口；面积项改为 `area.nonmac_mm2`。`run.py` 的 Softmax 路径使用实测 staging 加实测核心命令，scratch 访存不再重复记入全局 SRAM 事件。`run_llm.py` 按真正的归一化/Softmax 行边界重复计费；点运算超过 1024 可以拆分，但 Softmax、RMSNorm、LayerNorm 和 split-half RoPE 的超长行拒绝运行。

`run.py` 开启非 MAC 时，下一条矩阵任务要等待上一条非 MAC 结束及输出回传完成，与当前顶层的串行命令约束和单份 scratch 保留期一致；不会利用旧的软件缓冲调度假设 MAC/非 MAC 并行执行。其他存储/阵列阶段仍属于已有架构事件模型，不应将组件实测参数误称为完整 RTL 周期精确仿真。

Python/NumPy 仍提供功能数值参考，不提供非 MAC 性能或能耗。这三个模块不含 MXFP4 编码、正余弦表生成及 token 采样/argmax：当前将这些步骤明确列为 Host 参考操作并排除其成本，LLM 报告的 `execution_scope.full_system_metrics_complete=false`。现有性能结果是被覆盖的加速器服务范围，不是含 Host 的完整系统实测结果；精确 GELU 等没有 RTL 的算子也会报错，不会套用近似算子的价格。

## 6. 本次实际验证（2026-10-18）

- Python 当前回归：`TOTAL 67 FAILED 0`；覆盖旧功能和新非 MAC 契约、精确长度读取、缺项拒绝、行边界、访存不重复收费、泄漏和矩阵/非 MAC 串行约束。
- Icarus 三组 RTL 回归通过：小阵列顶层链路、全部现有非 MAC opcode、1/1024 元素 Softmax、背压/复位/错误、格式转换边界。使用显式测试 DW 模型，未验证真实 DesignWare 的位级等价和 PPA。
- 四个 CLI 帮助入口、参数字段清单、模板键集/状态和文档本地链接检查通过；默认正式入口按预期拒绝 PENDING。
- 本机未安装 VCS、DC、PrimeTime PX，未运行真实新思流程，也未生成面积、频率或能耗测量值。两个 v2 交付模板均保持 PENDING。
