param([switch]$TestModels, [string]$DwSimDir = $env:DW_SIM_DIR)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
New-Item -ItemType Directory -Force (Join-Path $root 'sim') | Out-Null
$sources = @((Join-Path $root 'tb/nonmac_tb_math.sv'))
$dwArgs = @()
if ($TestModels) {
    Write-Output 'TEST ONLY: substitute DW arithmetic. No PPA/DesignWare equivalence claim.'
    $dwArgs += '-DNONMAC_TEST_DW'
    $sources += Join-Path $root 'tb/nonmac_test_dw.sv'
} elseif ($DwSimDir -and (Test-Path -LiteralPath $DwSimDir)) {
    $dwArgs += @('-y', $DwSimDir, '-I', $DwSimDir)
} else {
    throw 'Supply -DwSimDir <Synopsys dw/sim_ver>, or explicitly use -TestModels for local regression.'
}
$sources += Get-ChildItem -LiteralPath (Join-Path $root 'rtl') -File |
    Where-Object { $_.Extension -in '.v','.sv' } | ForEach-Object FullName
$sources += Join-Path $root 'tb/nonmac_scratch_tb.sv'
foreach ($test in @('tb_1017_small', 'tb_nonmac_1017', 'tb_fixed_to_fp32_1017')) {
    $tb = Join-Path $root ('tb/' + $test + $(if ($test -eq 'tb_1017_small') {'.v'} else {'.sv'}))
    $out = Join-Path $root ('sim/' + $test + '.vvp')
    & iverilog -g2012 -Wall -DMX_SIM_INIT @dwArgs -I (Join-Path $root 'rtl') -s $test -o $out @sources $tb
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    & vvp $out
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
