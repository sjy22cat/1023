`timescale 1ns/1ps
// Verification-only synchronous scratch with request/response backpressure.
module nonmac_scratch_tb(
 input wire clk,rst_n,
 input wire req,output wire ready,input wire wr,input wire [12:0] addr,
 input wire [31:0] wdata,output reg rsp,input wire rsp_ready,output reg [31:0] rdata);
 reg [31:0] words[0:8191];
 reg pending;
 reg [31:0] saved;
 integer ticks,delay_q;
 assign ready=!pending&&!rsp&&(ticks%5!=0);
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin rsp<=0;pending<=0;ticks<=0;delay_q<=0;rdata<=0;saved<=0;end
  else begin
   ticks<=ticks+1;
   if(rsp&&rsp_ready) rsp<=0;
   if(req&&ready) begin
    if(wr) words[addr]<=wdata;
    else begin saved<=words[addr];pending<=1;delay_q<=ticks%3+1;end
   end
   if(pending) begin
    if(delay_q!=0) delay_q<=delay_q-1;
    else begin rsp<=1;rdata<=saved;pending<=0;end
   end
  end
 end
endmodule
