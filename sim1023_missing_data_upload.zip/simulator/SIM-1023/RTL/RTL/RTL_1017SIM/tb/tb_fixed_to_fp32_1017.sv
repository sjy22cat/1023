`timescale 1ns/1ps
module tb_fixed_to_fp32_1017;
 reg signed [31:0] m;
 reg signed [10:0] e;
 wire [31:0] z;
 wire overflow;
 mx_fixed_to_fp32_1017 dut(m,e,z,overflow);
 task check(input signed [31:0] mant,input signed [10:0] expn,input [31:0] expected,input bit ov);
  begin m=mant;e=expn;#1;if(z!==expected||overflow!==ov)$fatal(1,"convert m=%0d e=%0d got=%h expected=%h",m,e,z,expected);end
 endtask
 initial begin
  check(0,1000,32'h00000000,0);
  check(1,0,32'h3f800000,0);
  check(-3,-1,32'hbfc00000,0);
  check(-2147483648,0,32'hcf000000,0);
  check(16777217,0,32'h4b800000,0);
  check(16777219,0,32'h4b800002,0);
  check(33554431,0,32'h4c000000,0);
  check(1,-149,32'h00000001,0);
  check(1,-150,32'h00000000,0);
  check(3,-150,32'h00000002,0);
  check(-3,-150,32'h80000002,0);
  check(16777215,-150,32'h00800000,0);
  check(1,-1024,32'h00000000,0);
  check(1,128,32'h7f800000,1);
  $display("PASS: fixed-to-FP32 signs, RNE ties, carry, subnormals, underflow and overflow");$finish;
 end
endmodule
