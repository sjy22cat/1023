`timescale 1ns/1ps
module tb_nonmac_1017;
 import nonmac_test_math::*;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,cmd_valid=0,from_reduce=0,out_ready=0,reduce_valid=0;
 wire cmd_ready,out_valid,error,busy;
 reg [4:0] op=0;
 reg [10:0] len=0;
 reg [31:0] a=0,b=0,c=0,d=0,eps=0,tag=0;
 reg [127:0] reduce_data=0;
 reg [43:0] reduce_exp=0;
 wire [31:0] data,aux,out_tag,cycles,exec_cycles,reads,writes,stage_writes;
 wire req,ready,wr,rsp,rsp_ready;
 wire [12:0] addr;
 wire [31:0] wdata,rdata;
 mx_nonmac_1017 #(.ROWS(4)) dut(
  .clk(clk),.rst_n(rst_n),.i_clear_reduce(1'b0),.i_reduce_valid(reduce_valid),
  .i_reduce(reduce_data),.i_exponent(reduce_exp),.cmd_valid(cmd_valid),.cmd_ready(cmd_ready),
  .cmd_from_reduce(from_reduce),.cmd_op(op),.cmd_len(len),.cmd_a(a),.cmd_b(b),.cmd_c(c),.cmd_d(d),
  .cmd_epsilon(eps),.cmd_tag(tag),.out_valid(out_valid),.out_ready(out_ready),
  .out_data(data),.out_aux(aux),.out_tag(out_tag),.out_error(error),.busy(busy),
  .cycle_count(cycles),.exec_cycle_count(exec_cycles),.read_count(reads),.write_count(writes),
  .stage_write_count(stage_writes),.mem_req_valid(req),.mem_req_ready(ready),.mem_write(wr),
  .mem_addr(addr),.mem_wdata(wdata),.mem_rsp_valid(rsp),.mem_rsp_ready(rsp_ready),.mem_rdata(rdata));
 nonmac_scratch_tb mem(clk,rst_n,req,ready,wr,addr,wdata,rsp,rsp_ready,rdata);
 task check_near(input [31:0] got,input real expected);
  real diff;
  begin
   diff=fp_real(got)-expected;if(diff<0)diff=-diff;
   if(diff>0.00002*(1.0+(expected<0?-expected:expected)))
    $fatal(1,"op=%0d got=%h (%f) expected=%f",op,got,fp_real(got),expected);
  end
 endtask
 task command(input [4:0] opcode,input [10:0] n,input bit use_reduce,input bit expected_error);
  reg [31:0] held_data,held_aux,held_cycles;
  begin
   @(negedge clk);op=opcode;len=n;from_reduce=use_reduce;cmd_valid=1;tag=tag+1;
   do @(posedge clk); while(!cmd_ready);
   @(negedge clk);cmd_valid=0;
   wait(out_valid);#1;
   if(error!==expected_error||out_tag!==tag) $fatal(1,"bad status/tag op=%0d",op);
   held_data=data;held_aux=aux;held_cycles=cycles;
   repeat(4) begin
    @(negedge clk);
    if(!out_valid||cmd_ready||data!==held_data||aux!==held_aux||cycles!==held_cycles)
     $fatal(1,"output backpressure lost response");
   end
   $display("TRACE op=%0d len=%0d source=%0d cycles=%0d exec=%0d reads=%0d writes=%0d stage_writes=%0d error=%0d",op,len,use_reduce,cycles,exec_cycles,reads,writes,stage_writes,error);
   out_ready=1;@(negedge clk);out_ready=0;
  end
 endtask
 integer i;
 real x,y,sum,v;
 initial begin
  if($test$plusargs("dump")) begin
   $dumpfile("sim/vcs/nonmac.vcd");$dumpvars(0,tb_nonmac_1017);
  end
 end
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  a=real_fp(2);b=real_fp(3);c=real_fp(1);d=real_fp(0);eps=real_fp(0.00001);
  command(0,0,0,0);check_near(data,5);
  command(1,0,0,0);check_near(data,-1);
  command(2,0,0,0);check_near(data,6);
  command(3,0,0,0);check_near(data,2.0/3.0);
  command(4,0,0,0);check_near(data,$exp(2.0));
  command(5,0,0,0);check_near(data,$sqrt(2.0));
  command(6,0,0,0);check_near(data,1.0/$sqrt(2.0));
  a=real_fp(-2);
  command(7,0,0,0);check_near(data,1.0/(1.0+$exp(2.0)));
  command(8,0,0,0);check_near(data,-2.0/(1.0+$exp(2.0)));
  command(9,0,0,0);check_near(data,-2.0/(1.0+$exp(1.5957691216*(2.0+0.044715*8.0))));
  command(11,0,0,0);check_near(data,-6.0/(1.0+$exp(2.0)));
  command(12,0,0,0);check_near(data,0);
  a=real_fp(2);b=real_fp(3);c=real_fp(0.8);d=real_fp(0.6);
  command(10,0,0,0);check_near(data,-0.2);check_near(aux,3.6);
  for(i=0;i<8;i=i+1) begin
   mem.words[i]=real_fp(i-3.0);mem.words[1024+i]=real_fp(2.0);
   mem.words[2048+i]=real_fp(1.0);mem.words[3072+i]=real_fp(0.0);
  end
  command(16,8,0,0);sum=0;
  for(i=0;i<8;i=i+1)sum=sum+$exp(i-7.0);
  for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],$exp(i-7.0)/sum);
  if(reads!=24||writes!=16) $fatal(1,"softmax access count");
  command(17,8,0,0);sum=0;for(i=0;i<8;i=i+1)sum=sum+(i-3.0)*(i-3.0);
  for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],(i-3.0)/$sqrt(sum/8.0+0.00001));
  command(18,8,0,0);sum=0;for(i=0;i<8;i=i+1)sum=sum+(i-3.5)*(i-3.5);
  for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],(i-3.5)/$sqrt(sum/8.0+0.00001));
  command(19,8,0,0);for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],i-1.0);
  b=real_fp(0.5);command(20,8,0,0);for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],(i-3.0)*0.5);
  command(21,8,0,0);for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],(i-3.0)/(1.0+$exp(3.0-i)));
  command(22,8,0,0);for(i=0;i<8;i=i+1)begin x=i-3.0;check_near(mem.words[4096+i],x/(1.0+$exp(-1.5957691216*(x+0.044715*x*x*x))));end
  command(23,8,0,0);for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],2*(i-3.0)/(1.0+$exp(3.0-i)));
  for(i=0;i<4;i=i+1)begin mem.words[2048+i]=real_fp(0.8);mem.words[3072+i]=real_fp(0.6);end
  command(24,8,0,0);for(i=0;i<4;i=i+1)begin
   x=i-3.0;y=i+1.0;check_near(mem.words[4096+i],x*0.8-y*0.6);check_near(mem.words[4100+i],x*0.6+y*0.8);
  end
  command(25,8,0,0);for(i=0;i<8;i=i+1)check_near(mem.words[4096+i],i<3?0:i-3.0);
  command(16,0,0,1);command(17,1025,0,1);command(24,3,0,1);command(31,1,0,1);
  a=32'h7f800000;command(0,0,0,1);a=0;
  for(i=0;i<4;i=i+1)begin reduce_data[i*32+:32]=i+1;reduce_exp[i*11+:11]=-1;end
  @(negedge clk);reduce_valid=1;@(negedge clk);reduce_valid=0;
  command(16,4,1,0);sum=0;for(i=0;i<4;i=i+1)sum=sum+$exp((i-3.0)*0.5);
  for(i=0;i<4;i=i+1)check_near(mem.words[4096+i],$exp((i-3.0)*0.5)/sum);
  if(stage_writes!=4) $fatal(1,"reduce staging count");
  command(16,8,1,1);
  mem.words[0]=0;command(16,1,0,0);check_near(mem.words[4096],1.0);
  for(i=0;i<1024;i=i+1)mem.words[i]=0;
  command(16,1024,0,0);
  if(reads!=3072||writes!=2048) $fatal(1,"max length access count");
  for(i=0;i<1024;i=i+1)if(mem.words[4096+i]!==32'h3a800000)$fatal(1,"max length softmax row=%0d",i);
  // Reset cancels both execution and outstanding scratch responses.
  @(negedge clk);op=16;len=8;from_reduce=0;cmd_valid=1;
  do @(posedge clk);while(!cmd_ready);
  @(negedge clk);cmd_valid=0;
  wait(mem.pending);@(negedge clk);rst_n=0;
  repeat(2)@(negedge clk);rst_n=1;
  a=real_fp(2);b=real_fp(3);command(0,0,0,0);check_near(data,5);
  $display("PASS: all non-MAC opcodes, vector arithmetic, tags, errors, stalled memory and output, reduction staging");$finish;
 end
 initial begin #2000000;$fatal(1,"nonmac timeout");end
endmodule
