`timescale 1ns/1ps

module tb_1017_small;
    localparam MC=4, TR=2, TC=4, PE=2, K=4, ROWS=TR*PE, BW=2;
    localparam LW=K*4, SW=8, AW=2, ACCW=12, EXPW=11, RW=16;
    reg clk=0; always #5 clk=~clk;
    reg rst_n=0, start=0, meta=1;
    reg host_we=0; reg [BW-1:0] host_block; reg [LW-1:0] host_payload; reg [SW-1:0] host_scale;
    reg [TC*K-1:0] lane_enable;
    wire [MC-1:0] mem_req, mem_wr;
    wire [MC*AW-1:0] mem_addr;
    wire [MC*LW-1:0] mem_wdata;
    wire [MC*SW-1:0] mem_wscale;
    reg [MC-1:0] mem_valid=0;
    reg [MC*LW-1:0] mem_rdata=0;
    reg [MC*SW-1:0] mem_rscale=0;
    wire done,busy,result_valid;
    wire [3:0] phase;
    wire [31:0] cycles;
    wire [ROWS*TC-1:0] block_skip, compute_mask;
    wire [TC-1:0] data_move;
    wire [ROWS*RW-1:0] result;
    wire [ROWS*EXPW-1:0] result_exp;
    wire [31:0] sats;
    wire [63:0] mac_count;
    reg nonmac_cmd=0,nonmac_out_ready=0;
    wire nonmac_ready,nonmac_valid,nonmac_error,nonmac_busy;
    wire nm_req,nm_mem_ready,nm_wr,nm_rsp,nm_rsp_ready;
    wire [12:0] nm_addr;
    wire [31:0] nm_wdata,nm_rdata,nm_cycles,nm_reads,nm_writes,nm_stage_writes,nm_tag;
    nonmac_scratch_tb scratch(clk,rst_n,nm_req,nm_mem_ready,nm_wr,nm_addr,nm_wdata,nm_rsp,nm_rsp_ready,nm_rdata);

    yrr_1017_top #(.MC_COUNT(MC), .TILE_ROWS(TR), .TILE_COLS(TC), .PE_PER_TILE(PE),
                   .TILE_K(K), .AW(AW), .MEM_LINE_W(LW), .ACCW(ACCW), .EXPW(EXPW),
                   .RESULT_W(RW), .MX_SKIP_THRESHOLD_BITS(4), .ENABLE_MX_SKIP(1)) dut (
        .clk(clk), .rst_n(rst_n), .i_start(start), .i_metadata_valid(meta),
        .i_host_we(host_we), .i_host_block(host_block), .i_host_payload(host_payload),
        .i_host_scale(host_scale), .i_input_lane_enable(lane_enable),
        .o_mem_req(mem_req), .o_mem_wr(mem_wr), .o_mem_addr(mem_addr),
        .o_mem_wdata(mem_wdata), .o_mem_wscale(mem_wscale), .i_mem_valid(mem_valid),
        .i_mem_rdata(mem_rdata), .i_mem_rscale(mem_rscale), .o_done(done), .o_busy(busy),
        .o_phase(phase), .o_cycles(cycles), .o_block_skip(block_skip),
        .o_compute_mask(compute_mask), .o_channel_data_move_en(data_move),
        .o_result(result), .o_result_exponent(result_exp), .o_result_valid(result_valid), .o_saturation_count(sats),
        .o_active_mac_count(mac_count),
        .i_nonmac_cmd_valid(nonmac_cmd),.o_nonmac_cmd_ready(nonmac_ready),
        .i_nonmac_from_reduce(1'b1),.i_nonmac_op(5'd16),.i_nonmac_len(11'd4),
        .i_nonmac_a(32'd0),.i_nonmac_b(32'd0),.i_nonmac_c(32'd0),.i_nonmac_d(32'd0),
        .i_nonmac_epsilon(32'd0),.i_nonmac_tag(32'd123),
        .o_nonmac_valid(nonmac_valid),.i_nonmac_ready(nonmac_out_ready),
        .o_nonmac_error(nonmac_error),.o_nonmac_busy(nonmac_busy),.o_nonmac_tag(nm_tag),
        .o_nonmac_cycles(nm_cycles),.o_nonmac_reads(nm_reads),.o_nonmac_writes(nm_writes),
        .o_nonmac_stage_writes(nm_stage_writes),
        .o_nonmac_mem_valid(nm_req),.i_nonmac_mem_ready(nm_mem_ready),.o_nonmac_mem_write(nm_wr),
        .o_nonmac_mem_addr(nm_addr),.o_nonmac_mem_wdata(nm_wdata),
        .i_nonmac_mem_rsp_valid(nm_rsp),.o_nonmac_mem_rsp_ready(nm_rsp_ready),.i_nonmac_mem_rdata(nm_rdata)
    );

    reg [MC-1:0] pending;
    reg [AW-1:0] pending_addr [0:MC-1];
    integer c, b, i;
    always @(posedge clk) begin
        mem_valid <= 0;
        for (c=0;c<MC;c=c+1) begin
            if (mem_req[c]) begin
                pending[c] <= 1'b1;
                pending_addr[c] <= mem_addr[c*AW +: AW];
            end
            if (pending[c]) begin
                mem_valid[c] <= 1'b1;
                // Channel c returns a distinct payload so column ownership is visible.
                mem_rdata[c*LW +: LW] <= {LW{1'b0}} | (c+1);
                mem_rscale[c*SW +: SW] <= 8'd127;
                pending[c] <= 1'b0;
            end
        end
    end

    task host_line;
        input integer bb;
        input [7:0] sc;
        begin
            @(negedge clk); host_block=bb[BW-1:0]; host_scale=sc; host_payload={LW{1'b0}} | (bb+1);
            host_we=1; @(negedge clk); host_we=0;
        end
    endtask

    initial begin
        lane_enable = {TC*K{1'b1}};
        pending = 0; host_block=0; host_payload=0; host_scale=0;
        repeat(3) @(negedge clk); rst_n=1;
        // Block 0 is 27 exponent bits below block 1: it is skipped by T=4.
        host_line(0,8'd100); host_line(1,8'd127); host_line(2,8'd127); host_line(3,8'd127);
        @(negedge clk); start=1; @(negedge clk); start=0;
        wait(done); $display("PASS: done phase=%0d cycles=%0d data_move=%b skip=%h macs=%0d",phase,cycles,data_move,block_skip,mac_count);
        if (data_move !== 4'b1110) $fatal(1,"expected block0 suppressed, data_move=%b",data_move);
        if (!block_skip[0]) $fatal(1,"expected first output block skip");
        // Exercise the actual top-level array -> reduction -> FP32 -> microcode path.
        @(negedge clk); nonmac_cmd=1;
        do @(posedge clk); while(!nonmac_ready);
        @(negedge clk);nonmac_cmd=0;
        // A matrix start during non-MAC execution must not clear the staged data.
        start=1;@(negedge clk);start=0;
        wait(nonmac_valid);#1;
        if(nonmac_error||nm_tag!=123||nm_stage_writes!=4||nm_reads!=12||nm_writes!=8)
            $fatal(1,"top nonmac response/count error");
        for(i=0;i<4;i=i+1) if(scratch.words[4096+i]!==32'h3e800000)
            $fatal(1,"top softmax expected 0.25, row=%0d value=%h",i,scratch.words[4096+i]);
        if(!busy) $fatal(1,"top busy must include pending nonmac response");
        $display("PASS: top array/reduction/FP32 staging/softmax cycles=%0d",nm_cycles);
        @(negedge clk);nonmac_out_ready=1;@(negedge clk);nonmac_out_ready=0;
        // A second run with all lane masks zero must still carry active blocks,
        // but no PE lane may be counted as an active MAC.
        lane_enable = {TC*K{1'b0}};
        repeat(3) @(negedge clk); start=1; @(negedge clk); start=0;
        wait(done); $display("PASS: lane mask run macs=%0d data_move=%b",mac_count,data_move);
        if (mac_count !== 0) $fatal(1,"lane gating count=%0d",mac_count);
        $finish;
    end
    initial begin #2000000; $fatal(1,"top timeout");end
endmodule
