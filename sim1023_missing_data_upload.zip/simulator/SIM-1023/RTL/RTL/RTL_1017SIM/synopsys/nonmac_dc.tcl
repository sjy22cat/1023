# Run from RTL/RTL_1017SIM: dc_shell -f synopsys/nonmac_dc.tcl
# Explicit target libraries/clock required. No fabricated process/PVT defaults.
foreach name {TARGET_LIBRARY CLOCK_NS} {
    if {![info exists ::env($name)]} { error "Required environment variable: $name" }
}
set_app_var search_path [concat $search_path [list ./rtl]]
set_app_var target_library $::env(TARGET_LIBRARY)
set_app_var synthetic_library dw_foundation.sldb
set_app_var link_library [concat * $target_library $synthetic_library]
file mkdir sim/dc_nonmac
analyze -format sverilog [list rtl/nonmac_fp32_pipe.sv rtl/llm_nonmac_fp32.sv \
    rtl/mx_fixed_to_fp32_1017.sv rtl/mx_nonmac_1017.sv]
elaborate mx_nonmac_1017
current_design mx_nonmac_1017
link
create_clock -name clk -period $::env(CLOCK_NS) [get_ports clk]
if {![info exists ::env(IO_CONSTRAINTS)]} { error "Set IO_CONSTRAINTS to a reviewed SDC file" }
source $::env(IO_CONSTRAINTS)
check_design > sim/dc_nonmac/check_design.rpt
compile_ultra -retime
report_area -hierarchy > sim/dc_nonmac/area.rpt
report_timing -max_paths 30 > sim/dc_nonmac/timing.rpt
report_constraint -all_violators > sim/dc_nonmac/constraints.rpt
write -format verilog -hierarchy -output sim/dc_nonmac/nonmac_mapped.v
write_sdc sim/dc_nonmac/nonmac.sdc
write_sdf sim/dc_nonmac/nonmac.sdf
# Gate simulation + real scratch macro + PrimeTime/PrimeTime PX are required
# next. Do not use multicycle exceptions to conceal untimed DW logic paths.
