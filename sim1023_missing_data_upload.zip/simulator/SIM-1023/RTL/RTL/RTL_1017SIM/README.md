# SIM-1017 非理想模式 RTL

本目录是基于 `simulator/SIM-1017` 新建的 RTL 参考实现，未修改旧的
`RTL/v3`。默认参数对应目标阵列：32 个 MC、32 条 Mem Die channel、32x32
tile、每个 tile 32 个 PE、每个 PE 32 个 MAC lane。

## 数据和控制映射

```text
                       一套 mx_global_ctrl_1017
                                  |
       +--------------------------+--------------------------+
       |                                                     |
 MC[0] -> PHY[0] -> Tile[0..31][0]       ... MC[31] -> PHY[31] -> Tile[0..31][31]
       |                                                     |
       +--------------------- GSRAM / broadcast -------------+
                                  |
                         PE[0..31] / lane mask
```

`MC[c]` 固定绑定 channel `c` 和 tile column `c`。权重冷启动时总控把同一个
output-row address 同时发给 32 个 MC；每个 MC 的返回值只写入自己的 tile
column。MC 没有复制全局 FSM，只包含本 channel 的 outstanding、请求和完成状态；
全局控制器用每行 completion bitmap 收集可能错峰返回的 32 路 PHY response。
`mx_phy_1017` 是每 channel 的 HB/PHY 接收流水线，Mem Die 响应通过
`i_mem_valid/rdata/rscale` 进入；`tb` 中的 channel model 只用于仿真。

Host/DMA 与 Mem Die 路径分开：`mx_gsram_1017` 的 `i_host_*` 是 Host/DMA
写入 GSRAM 的 staging 接口；Mem Die->MC 搬运使用 32 组 `o_mem_req` 和
`i_mem_*`，不经过这个 DMA。

## SIM-1017 预判 skip 时序

1. 权重 scale 在 MC/PHY 返回时写入 resident metadata；GSRAM 的所有 input
   scale 作为 sideband 先可读。
2. `mx_skip_ctrl_1017` 只计算
   `Esum = (W_scale-127) + (X_scale-127)`、每个输出 PE 的 `EMXmax` 和
   `distance = EMXmax - Esum`。它不查看 payload、E3/M10、partial 或符号抵消。
3. `distance >= MX_SKIP_THRESHOLD_BITS` 才产生 block skip。只有该 K block
   的所有输出 PE 都 skip 时，`o_channel_data_move_en[c]` 才为 0，随后总控
   才跳过 GSRAM payload read 和 broadcast。只要一行/一个 PE 需要计算，
   channel payload 仍会搬运。
4. 广播之后，`mx_pe_1017` 将总控的 block/PE enable 与本地
   `i_lane_en`、weight/input zero mask 合并。每个 PE 有独立的
   `TILE_K` bit lane mask；真正关闭的 lane 才不计入 `o_mac_count`，并可从
   顶层 `o_lane_active[output_row][block][lane]` 观察。

## 目录

- `rtl/yrr_1017_top.v`：顶层、32 MC/PHY 展开、GSRAM、阵列和归约连接。
- `rtl/mx_global_ctrl_1017.v`：唯一全局任务 FSM。
- `rtl/mx_mc_1017.v`、`mx_phy_1017.v`：单 channel 控制与 HB/PHY 边界。
- `rtl/mx_skip_ctrl_1017.v`：scale-only block skip 预判。
- `rtl/mx_tile_1017.v`、`mx_pe_1017.v`：tile 本地权重/输入缓存和逐 lane MAC 门控。
- `rtl/mx_gsram_1017.v`：Host/DMA staging SRAM，按 K block 选择性读。
- `rtl/mx_dma_1017.v`：可选的 Host→GSRAM descriptor/stream DMA；不连接 Mem Die。
- `rtl/mx_reduce_1017.v`：跨 K block 的指数对齐、toward-zero 右移和饱和归约。
- `rtl/llm_nonmac_fp32.sv`、`nonmac_fp32_pipe.sv`、`nonmac_microcode.vh`：共享微码 FP32 非 MAC 执行单元，底层使用 DesignWare。
- `rtl/mx_nonmac_1017.sv`、`mx_fixed_to_fp32_1017.sv`：顶层命令接口、归约快照转 FP32、外部 scratch 暂存与执行握手。
- `rtl/mx_memdie_channel_model_1017.v`：仿真用的单 channel 延迟模型。
- `rtl/mx_memdie_fabric_1017.v`：将单 channel model 展开成 32 路的仿真 fabric。
- `tb/tb_1017_small.v`：4 channel/2x4 tile 的快速回归，使用同一套控制结构。

## 验证

PowerShell：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File RTL/RTL_1017SIM/run_tb.ps1 -TestModels
```

回归覆盖 MC/channel、skip/lane mask、顶层阵列→归约→FP32→Softmax、全部现有非 MAC opcode、访存及输出背压、错误返回和 FP32 转换边界。`-TestModels` 仅启用测试专用 DW 算术模型，不能作为 DesignWare 等价、频率或 PPA 证据。真实新思回归入口为 `run_vcs_nonmac.sh`，DC 模板为 `synopsys/nonmac_dc.tcl`；运行要求见下方实测说明。

`MX_SKIP_THRESHOLD_BITS=0`（默认）表示不启用 block skip，符合 SIM-1017
在阈值未配置时的行为。`i_input_lane_enable` 是 TAG-FP/格式适配器的
sideband；全 1 表示所有 lane 有效。

## 接口边界和后续接入

当前 payload decoder 保留 4-bit MXFP4/E8M0 的可替换边界，PE 内的整数译码
用于结构和门控验证。服务器提供真实 RRAM-FP/TAG-FP LUT 后，应替换
`mx_pe_1017` 的 `fp4_int` 和 zero sideband，保留 `i_lane_en`、block skip
和 32 channel 映射。`mx_reduce_1017` 输出的是带指数对齐后的定点
mantissa，并在 `o_result_exponent` 给出每行指数。顶层已将它连接到
`mx_nonmac_1017`，通过 `from_reduce` 命令转换并暂存为 FP32，再执行非 MAC。
外部 scratch、Host/DMA 系数装载/结果回传仍需连接真实存储/控制器。

非 MAC 通过新增的 `i_nonmac_* / o_nonmac_*` 接口显式调用；矩阵与非 MAC
串行接收，`o_done` 仍只表示矩阵阶段，非 MAC 以自己的 valid/ready 完成。
每条向量最多 1024 个元素；RoPE 使用与 Qwen/Llama 一致的前后半段配对。

## Synopsys 实测参数交付

按 [非 MAC 接口与实测说明](../../Instruction/nonmac_1017SIM_measurement.md) 及
[RTL 操作说明](../../Instruction/RTL_1017SIM_instruction.md) 表征和归档，填写
[统一参数模板](../../simulator/SIM-1017/calibration/rtl_1017sim/rtl_1017sim_measured.json)。
旧 `export_calibration.py` 与推断快照已删除，不能再从此 RTL 的结构或 testbench
延迟模型生成模拟器物理参数。v2 新增 `nonmac` 逐算子/长度实测记录，包含动态能量、周期、访存计数和报告索引；模拟器已删除通用 Softmax 单元素价。当前空模板为 PENDING，真实数据齐全后才能正式运行。
