#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p sim
IVERILOG=${IVERILOG:-iverilog}
VVP=${VVP:-vvp}
if [ "${1:-}" = "--test-models" ]; then
  echo 'TEST ONLY: substitute DW arithmetic; not PPA or DW equivalence.'
  set -- -DNONMAC_TEST_DW tb/nonmac_test_dw.sv
else
  : "${DW_SIM_DIR:?Set licensed Synopsys dw/sim_ver path, or pass --test-models}"
  set -- -y "$DW_SIM_DIR" -I "$DW_SIM_DIR"
fi
for test in tb_1017_small tb_nonmac_1017 tb_fixed_to_fp32_1017; do
  ext=sv
  [ "$test" != tb_1017_small ] || ext=v
  "$IVERILOG" -g2012 -Wall -DMX_SIM_INIT -I rtl -s "$test" -o "sim/$test.vvp" \
    tb/nonmac_tb_math.sv "$@" rtl/*.v rtl/*.sv tb/nonmac_scratch_tb.sv "tb/$test.$ext"
  "$VVP" "sim/$test.vvp"
done
