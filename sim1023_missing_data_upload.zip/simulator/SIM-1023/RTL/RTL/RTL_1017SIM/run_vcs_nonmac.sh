#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${DW_SIM_DIR:?Set licensed Synopsys dw/sim_ver directory}"
mkdir -p sim/vcs
# Test-only DW substitutes are intentionally absent from this command.
vcs -full64 -sverilog -timescale=1ns/1ps -top tb_nonmac_1017 \
  +incdir+"$DW_SIM_DIR" -y "$DW_SIM_DIR" +libext+.v \
  -f nonmac_sources.f tb/nonmac_tb_math.sv tb/nonmac_scratch_tb.sv tb/tb_nonmac_1017.sv \
  -o sim/vcs/simv -l sim/vcs/compile.log
sim/vcs/simv -l sim/vcs/run.log "$@"
