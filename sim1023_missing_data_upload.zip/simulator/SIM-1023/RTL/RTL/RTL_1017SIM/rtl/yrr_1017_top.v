`timescale 1ns/1ps
`include "mx_fmt_defs.vh"

// SIM-1017 RTL top level.
//
//   Host/DMA -> GSRAM -> (selected K block) -> broadcast -> Tile array
//   Mem Die channel[c] -> MC[c] -> PHY[c] -> Tile[*][c] weight store
//
// There is one global scheduler.  MC/PHY are replicated only for physical
// channels; no copy of the global scheduler is made per MC or per PE.
module yrr_1017_top #(
    parameter MC_COUNT = 32,
    parameter TILE_ROWS = 32,
    parameter TILE_COLS = 32,
    parameter PE_PER_TILE = 32,
    parameter TILE_K = 32,
    parameter AW = 10,
    parameter MC_PHY_LATENCY = 1,
    parameter MEM_LINE_W = TILE_K*`MX1017_FP4_W,
    parameter SCALE_W = `MX1017_SCALE_W,
    parameter ACCW = 20,
    parameter EXPW = 11,
    parameter RESULT_W = 32,
    parameter MX_SKIP_THRESHOLD_BITS = 0,
    parameter ENABLE_MX_SKIP = 1,
    parameter ROWS = TILE_ROWS*PE_PER_TILE,
    parameter BLOCKS = TILE_COLS,
    parameter RW = (ROWS <= 1) ? 1 : $clog2(ROWS),
    parameter BW = (BLOCKS <= 1) ? 1 : $clog2(BLOCKS),
    parameter CW = (MC_COUNT <= 1) ? 1 : $clog2(MC_COUNT),
    parameter PW = (PE_PER_TILE <= 1) ? 1 : $clog2(PE_PER_TILE)
)(
    input wire clk,
    input wire rst_n,
    input wire i_start,
    input wire i_metadata_valid,
    // Host/DMA writes one input K block into GSRAM.
    input wire i_host_we,
    input wire [BW-1:0] i_host_block,
    input wire [MEM_LINE_W-1:0] i_host_payload,
    input wire [SCALE_W-1:0] i_host_scale,
    input wire [BLOCKS*TILE_K-1:0] i_input_lane_enable,
    // 32 independent Mem Die response channels.
    output wire [MC_COUNT-1:0] o_mem_req,
    output wire [MC_COUNT-1:0] o_mem_wr,
    output wire [MC_COUNT*AW-1:0] o_mem_addr,
    output wire [MC_COUNT*MEM_LINE_W-1:0] o_mem_wdata,
    output wire [MC_COUNT*SCALE_W-1:0] o_mem_wscale,
    input wire [MC_COUNT-1:0] i_mem_valid,
    input wire [MC_COUNT*MEM_LINE_W-1:0] i_mem_rdata,
    input wire [MC_COUNT*SCALE_W-1:0] i_mem_rscale,
    // Completion and observable control trace.
    output wire o_done,
    output wire o_busy,
    output wire [3:0] o_phase,
    output wire [31:0] o_cycles,
    output wire [ROWS*BLOCKS-1:0] o_block_skip,
    output wire [ROWS*BLOCKS-1:0] o_compute_mask,
    output wire [BLOCKS-1:0] o_channel_data_move_en,
    output wire [ROWS*BLOCKS*TILE_K-1:0] o_lane_active,
    output wire [ROWS*RESULT_W-1:0] o_result,
    output wire [ROWS*EXPW-1:0] o_result_exponent,
    output wire o_result_valid,
    output wire [31:0] o_saturation_count,
    output reg [63:0] o_active_mac_count,
    // Shared FP32 non-MAC command endpoint and external 8192-word scratch port.
    input wire i_nonmac_cmd_valid, output wire o_nonmac_cmd_ready,
    input wire i_nonmac_from_reduce,
    input wire [4:0] i_nonmac_op,
    input wire [10:0] i_nonmac_len,
    input wire [31:0] i_nonmac_a,i_nonmac_b,i_nonmac_c,i_nonmac_d,
    input wire [31:0] i_nonmac_epsilon,i_nonmac_tag,
    output wire o_nonmac_valid, input wire i_nonmac_ready,
    output wire [31:0] o_nonmac_data,o_nonmac_aux,o_nonmac_tag,
    output wire o_nonmac_error,o_nonmac_busy,
    output wire [31:0] o_nonmac_cycles,o_nonmac_exec_cycles,
    output wire [31:0] o_nonmac_reads,o_nonmac_writes,o_nonmac_stage_writes,
    output wire o_nonmac_mem_valid, input wire i_nonmac_mem_ready,
    output wire o_nonmac_mem_write,
    output wire [12:0] o_nonmac_mem_addr,
    output wire [31:0] o_nonmac_mem_wdata,
    input wire i_nonmac_mem_rsp_valid, output wire o_nonmac_mem_rsp_ready,
    input wire [31:0] i_nonmac_mem_rdata
);
    wire [MC_COUNT-1:0] mc_ready, mc_rvalid;
    wire [MC_COUNT-1:0] phy_valid;
    wire [MC_COUNT*MEM_LINE_W-1:0] mc_rdata;
    wire [MC_COUNT*SCALE_W-1:0] mc_rscale;
    wire [MC_COUNT*MEM_LINE_W-1:0] phy_data;
    wire [MC_COUNT*SCALE_W-1:0] phy_scale;
    wire all_mc_ready = &mc_ready;
    // Responses need not return on the same cycle in a non-ideal channel
    // fabric.  Accumulate a per-row completion bitmap before advancing.
    reg [MC_COUNT-1:0] phy_seen;
    wire all_phy_valid = &(phy_seen | phy_valid);

    wire ctrl_weight_req, ctrl_gsram_re, ctrl_bcast_we, ctrl_calc_en, ctrl_reduce_en;
    wire [RW-1:0] ctrl_weight_addr;
    wire [BW-1:0] ctrl_block_idx;
    wire [RW-1:0] ctrl_tile_row = ctrl_weight_addr / PE_PER_TILE;
    wire [PW-1:0] ctrl_pe_addr = ctrl_weight_addr % PE_PER_TILE;
    wire ctrl_gsram_valid;
    wire [3:0] ctrl_phase;
    wire ctrl_done, ctrl_busy;
    wire [31:0] ctrl_cycles;
    wire reduce_valid;
    wire accepted_start = i_start && !ctrl_busy && !o_nonmac_busy;
    wire nonmac_cmd_ready;
    assign o_nonmac_cmd_ready = nonmac_cmd_ready && !ctrl_busy && !i_start;

    wire [MEM_LINE_W-1:0] gs_payload;
    wire [SCALE_W-1:0] gs_scale;
    wire [BLOCKS*SCALE_W-1:0] gs_all_scales;
    mx_gsram_1017 #(.BLOCKS(BLOCKS), .LINE_W(MEM_LINE_W), .SCALE_W(SCALE_W), .BW(BW)) u_gsram (
        .clk(clk), .rst_n(rst_n), .i_host_we(i_host_we), .i_host_block(i_host_block),
        .i_host_payload(i_host_payload), .i_host_scale(i_host_scale),
        .i_re(ctrl_gsram_re), .i_rblock(ctrl_block_idx), .o_rvalid(ctrl_gsram_valid),
        .o_payload(gs_payload), .o_scale(gs_scale), .o_all_scales(gs_all_scales)
    );

    // Resident weight scale metadata is indexed [output_row][K block].
    reg [SCALE_W-1:0] weight_scale_mem [0:ROWS*BLOCKS-1];
    wire [ROWS*BLOCKS*SCALE_W-1:0] weight_scale_flat;
    genvar ws_g;
    generate
        for (ws_g = 0; ws_g < ROWS*BLOCKS; ws_g = ws_g + 1) begin : g_ws
            assign weight_scale_flat[ws_g*SCALE_W +: SCALE_W] = weight_scale_mem[ws_g];
        end
    endgenerate

    wire signed [ROWS*BLOCKS*11-1:0] skip_esum;
    wire signed [ROWS*11-1:0] skip_emxmax;
    wire [ROWS*BLOCKS*11-1:0] skip_distance;
    mx_skip_ctrl_1017 #(.OUTPUT_ROWS(ROWS), .BLOCKS(BLOCKS), .SCALE_W(SCALE_W),
                        .ESUM_W(11), .THRESHOLD_BITS(MX_SKIP_THRESHOLD_BITS),
                        .ENABLE(ENABLE_MX_SKIP)) u_skip (
        .clk(clk), .rst_n(rst_n), .i_metadata_valid(i_metadata_valid),
        .i_weight_scale(weight_scale_flat), .i_input_scale(gs_all_scales),
        .o_esum(skip_esum), .o_emxmax(skip_emxmax), .o_distance(skip_distance),
        .o_block_skip(o_block_skip), .o_compute_mask(o_compute_mask),
        .o_channel_data_move_en(o_channel_data_move_en), .o_all_skip()
    );

    mx_global_ctrl_1017 #(.MC_COUNT(MC_COUNT), .TILE_ROWS(TILE_ROWS),
                          .PE_PER_TILE(PE_PER_TILE), .BLOCKS(BLOCKS), .ROWS(ROWS),
                          .RW(RW), .BW(BW), .CW(CW)) u_ctrl (
        .clk(clk), .rst_n(rst_n), .i_start(accepted_start),
        .i_metadata_valid(i_metadata_valid), .i_all_mc_ready(all_mc_ready),
        .i_all_phy_valid(all_phy_valid), .i_gsram_rvalid(ctrl_gsram_valid),
        .i_channel_data_move_en(o_channel_data_move_en), .i_reduce_valid(reduce_valid),
        .o_weight_req(ctrl_weight_req), .o_weight_addr(ctrl_weight_addr),
        .o_gsram_re(ctrl_gsram_re), .o_bcast_we(ctrl_bcast_we), .o_calc_en(ctrl_calc_en),
        .o_reduce_en(ctrl_reduce_en), .o_block_idx(ctrl_block_idx), .o_phase(ctrl_phase),
        .o_done(ctrl_done), .o_busy(ctrl_busy), .o_cycle_count(ctrl_cycles)
    );

    assign o_done = ctrl_done;
    assign o_busy = ctrl_busy | o_nonmac_busy;
    assign o_phase = ctrl_phase;
    assign o_cycles = ctrl_cycles;

    genvar c;
    generate
        for (c = 0; c < MC_COUNT; c = c + 1) begin : g_mc
            mx_mc_1017 #(.AW(AW), .LINE_W(MEM_LINE_W), .SCALE_W(SCALE_W), .CHANNEL_ID(c)) u_mc (
                .clk(clk), .rst_n(rst_n), .i_req(ctrl_weight_req), .i_wr(1'b0),
                .i_addr(ctrl_weight_addr[AW-1:0]), .i_wdata({MEM_LINE_W{1'b0}}),
                .i_wscale({SCALE_W{1'b0}}), .o_ready(mc_ready[c]), .o_rvalid(mc_rvalid[c]),
                .o_rdata(mc_rdata[c*MEM_LINE_W +: MEM_LINE_W]),
                .o_rscale(mc_rscale[c*SCALE_W +: SCALE_W]),
                .o_mem_req(o_mem_req[c]), .o_mem_wr(o_mem_wr[c]),
                .o_mem_addr(o_mem_addr[c*AW +: AW]),
                .o_mem_wdata(o_mem_wdata[c*MEM_LINE_W +: MEM_LINE_W]),
                .o_mem_wscale(o_mem_wscale[c*SCALE_W +: SCALE_W]),
                .i_mem_valid(i_mem_valid[c]),
                .i_mem_rdata(i_mem_rdata[c*MEM_LINE_W +: MEM_LINE_W]),
                .i_mem_rscale(i_mem_rscale[c*SCALE_W +: SCALE_W]), .o_req_count()
            );
            mx_phy_1017 #(.LINE_W(MEM_LINE_W), .SCALE_W(SCALE_W),
                          .LATENCY(MC_PHY_LATENCY)) u_phy (
                .clk(clk), .rst_n(rst_n), .i_valid(mc_rvalid[c]),
                .i_data(mc_rdata[c*MEM_LINE_W +: MEM_LINE_W]),
                .i_scale(mc_rscale[c*SCALE_W +: SCALE_W]), .o_ready(),
                .o_valid(phy_valid[c]), .o_data(phy_data[c*MEM_LINE_W +: MEM_LINE_W]),
                .o_scale(phy_scale[c*SCALE_W +: SCALE_W])
            );
        end
    endgenerate

    // Weight response from MC c is written only to tile column c.  This is the
    // explicit MC -> one PE-tile column mapping requested for the non-ideal path.
    integer wr_i;
    integer wr_c;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            phy_seen <= {MC_COUNT{1'b0}};
            for (wr_i = 0; wr_i < ROWS*BLOCKS; wr_i = wr_i + 1)
                weight_scale_mem[wr_i] <= {SCALE_W{1'b0}};
        end else begin
            if (ctrl_phase == 4'd1) phy_seen <= {MC_COUNT{1'b0}}; // P_WREQ
            else if (ctrl_phase == 4'd2) phy_seen <= phy_seen | phy_valid; // P_WWAIT
            for (wr_c = 0; wr_c < MC_COUNT; wr_c = wr_c + 1)
                if (phy_valid[wr_c])
                    weight_scale_mem[ctrl_weight_addr*BLOCKS + wr_c] <=
                        phy_scale[wr_c*SCALE_W +: SCALE_W];
        end
    end

    // One channel's line is placed in the corresponding array-column slice.
    wire [MC_COUNT*MEM_LINE_W-1:0] weight_payload_bus = phy_data;
    wire [MC_COUNT*SCALE_W-1:0] weight_scale_bus = phy_scale;
    wire [MC_COUNT*MEM_LINE_W-1:0] x_payload_bus;
    wire [MC_COUNT*SCALE_W-1:0] x_scale_bus;
    genvar xb;
    generate
        for (xb = 0; xb < MC_COUNT; xb = xb + 1) begin : g_xbus
            assign x_payload_bus[xb*MEM_LINE_W +: MEM_LINE_W] =
                (ctrl_block_idx == xb) ? gs_payload : {MEM_LINE_W{1'b0}};
            assign x_scale_bus[xb*SCALE_W +: SCALE_W] =
                (ctrl_block_idx == xb) ? gs_scale : {SCALE_W{1'b0}};
        end
    endgenerate
    wire [TILE_ROWS*PE_PER_TILE-1:0] current_pe_enable;
    wire [PE_PER_TILE*TILE_K-1:0] current_lane_enable;
    genvar rp, lp;
    generate
        for (rp = 0; rp < TILE_ROWS; rp = rp + 1) begin : g_pe_en_row
            for (lp = 0; lp < PE_PER_TILE; lp = lp + 1) begin : g_pe_en
                assign current_pe_enable[rp*PE_PER_TILE+lp] =
                    o_compute_mask[(rp*PE_PER_TILE+lp)*BLOCKS + ctrl_block_idx];
            end
        end
        for (lp = 0; lp < PE_PER_TILE; lp = lp + 1) begin : g_lane_rep
            assign current_lane_enable[lp*TILE_K +: TILE_K] =
                i_input_lane_enable[ctrl_block_idx*TILE_K +: TILE_K];
        end
    endgenerate

    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*ACCW-1:0] array_sums;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*EXPW-1:0] array_exps;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE-1:0] array_valid;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*TILE_K-1:0] array_lane_active;
    wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*16-1:0] array_mac_count;
    mx_array_1017 #(.TILE_ROWS(TILE_ROWS), .TILE_COLS(TILE_COLS),
                    .PE_PER_TILE(PE_PER_TILE), .TILE_K(TILE_K), .ACCW(ACCW), .EXPW(EXPW),
                    .RW(RW), .CW(CW), .PW(PW)) u_array (
        .clk(clk), .rst_n(rst_n), .i_w_we(phy_valid), .i_w_tile_row(ctrl_tile_row),
        .i_w_col({CW{1'b0}}), .i_w_pe(ctrl_pe_addr),
        .i_w_payload(weight_payload_bus), .i_w_scale(weight_scale_bus),
        .i_x_we(ctrl_bcast_we), .i_x_col(ctrl_block_idx), .i_x_payload(x_payload_bus),
        .i_x_scale(x_scale_bus), .i_pe_enable(current_pe_enable), .i_lane_en(current_lane_enable),
        .i_calc_en(ctrl_calc_en), .i_calc_col(ctrl_block_idx), .o_sums(array_sums),
        .o_exps(array_exps), .o_valid(array_valid), .o_lane_active(array_lane_active),
        .o_mac_count(array_mac_count)
    );

    // Expose a compact per-output-row/per-K-block lane trace.  The internal
    // array is ordered [tile_row][tile_col][pe][lane]; this view is ordered
    // [output_row][block][lane] and is forced low for a skipped block.
    genvar trv, tcv, pev, kv;
    generate
        for (trv = 0; trv < TILE_ROWS; trv = trv + 1) begin : g_lane_trace_r
            for (tcv = 0; tcv < TILE_COLS; tcv = tcv + 1) begin : g_lane_trace_c
                for (pev = 0; pev < PE_PER_TILE; pev = pev + 1) begin : g_lane_trace_p
                    for (kv = 0; kv < TILE_K; kv = kv + 1) begin : g_lane_trace_k
                        localparam integer ORow = trv*PE_PER_TILE + pev;
                        localparam integer AIdx = ((trv*TILE_COLS+tcv)*PE_PER_TILE+pev)*TILE_K+kv;
                        assign o_lane_active[(ORow*BLOCKS+tcv)*TILE_K+kv] =
                            array_lane_active[AIdx] &&
                            o_compute_mask[ORow*BLOCKS+tcv] &&
                            i_input_lane_enable[tcv*TILE_K+kv];
                    end
                end
            end
        end
    endgenerate

    // Capture one block partial at the accumulator phase.  Skipped blocks are
    // initialized to zero and never reach this write path.
    reg [ROWS*BLOCKS*ACCW-1:0] partial_sums;
    reg [ROWS*BLOCKS*EXPW-1:0] partial_exps;
    integer pr, pcol, ppe, pidx, aidx;
    integer unsigned active_add;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            partial_sums <= {(ROWS*BLOCKS*ACCW){1'b0}};
            partial_exps <= {(ROWS*BLOCKS*EXPW){1'b0}};
            o_active_mac_count <= 64'd0;
        end else begin
            if (accepted_start) begin
                partial_sums <= {(ROWS*BLOCKS*ACCW){1'b0}};
                partial_exps <= {(ROWS*BLOCKS*EXPW){1'b0}};
                o_active_mac_count <= 64'd0;
            end
            if (ctrl_phase == 4'd9) begin // P_ACCUM
                active_add = 0;
                for (pr = 0; pr < ROWS; pr = pr + 1) begin
                    pcol = pr / PE_PER_TILE;
                    ppe  = pr % PE_PER_TILE;
                    pidx = (pcol*TILE_COLS + ctrl_block_idx)*PE_PER_TILE + ppe;
                    aidx = (pr*BLOCKS + ctrl_block_idx);
                    partial_sums[aidx*ACCW +: ACCW] <= array_sums[pidx*ACCW +: ACCW];
                    partial_exps[aidx*EXPW +: EXPW] <= array_exps[pidx*EXPW +: EXPW];
                    active_add = active_add + array_mac_count[pidx*16 +: 16];
                end
                o_active_mac_count <= o_active_mac_count + active_add;
            end
        end
    end

    wire signed [ROWS*RESULT_W-1:0] reduce_result;
    wire signed [ROWS*EXPW-1:0] reduce_exponent;
    mx_reduce_1017 #(.OUTPUT_ROWS(ROWS), .BLOCKS(BLOCKS), .ACCW(ACCW),
                     .EXPW(EXPW), .RESULT_W(RESULT_W)) u_reduce (
        .clk(clk), .rst_n(rst_n), .i_valid(ctrl_reduce_en), .i_sums(partial_sums),
        .i_exps(partial_exps), .o_valid(reduce_valid), .o_result(reduce_result),
        .o_emxmax(reduce_exponent), .o_saturation_count(o_saturation_count)
    );
    assign o_result = reduce_result;
    assign o_result_exponent = reduce_exponent;
    assign o_result_valid = reduce_valid;

    mx_nonmac_1017 #(.ROWS(ROWS),.RESULT_W(RESULT_W),.EXPW(EXPW)) u_nonmac (
        .clk(clk),.rst_n(rst_n),.i_clear_reduce(accepted_start),
        .i_reduce_valid(reduce_valid),.i_reduce(reduce_result),.i_exponent(reduce_exponent),
        .cmd_valid(i_nonmac_cmd_valid && !ctrl_busy && !i_start),.cmd_ready(nonmac_cmd_ready),
        .cmd_from_reduce(i_nonmac_from_reduce),.cmd_op(i_nonmac_op),.cmd_len(i_nonmac_len),
        .cmd_a(i_nonmac_a),.cmd_b(i_nonmac_b),.cmd_c(i_nonmac_c),.cmd_d(i_nonmac_d),
        .cmd_epsilon(i_nonmac_epsilon),.cmd_tag(i_nonmac_tag),
        .out_valid(o_nonmac_valid),.out_ready(i_nonmac_ready),
        .out_data(o_nonmac_data),.out_aux(o_nonmac_aux),.out_tag(o_nonmac_tag),
        .out_error(o_nonmac_error),.busy(o_nonmac_busy),.cycle_count(o_nonmac_cycles),
        .exec_cycle_count(o_nonmac_exec_cycles),.read_count(o_nonmac_reads),
        .write_count(o_nonmac_writes),.stage_write_count(o_nonmac_stage_writes),
        .mem_req_valid(o_nonmac_mem_valid),.mem_req_ready(i_nonmac_mem_ready),
        .mem_write(o_nonmac_mem_write),.mem_addr(o_nonmac_mem_addr),.mem_wdata(o_nonmac_mem_wdata),
        .mem_rsp_valid(i_nonmac_mem_rsp_valid),.mem_rsp_ready(o_nonmac_mem_rsp_ready),
        .mem_rdata(i_nonmac_mem_rdata));
endmodule
