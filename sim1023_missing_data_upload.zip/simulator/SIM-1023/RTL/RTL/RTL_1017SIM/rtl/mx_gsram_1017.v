`timescale 1ns/1ps
`include "mx_fmt_defs.vh"

// Host/DMA-facing staging SRAM.  The Mem Die channels do not use this path:
// they use MC -> HB/PHY directly.  One input K block is one 128-bit line.
module mx_gsram_1017 #(
    parameter BLOCKS = 32,
    parameter LINE_W = `MX1017_LINE_W,
    parameter SCALE_W = `MX1017_SCALE_W,
    parameter BW = (BLOCKS <= 1) ? 1 : $clog2(BLOCKS)
)(
    input wire clk,
    input wire rst_n,
    input wire i_host_we,
    input wire [BW-1:0] i_host_block,
    input wire [LINE_W-1:0] i_host_payload,
    input wire [SCALE_W-1:0] i_host_scale,
    input wire i_re,
    input wire [BW-1:0] i_rblock,
    output reg o_rvalid,
    output reg [LINE_W-1:0] o_payload,
    output reg [SCALE_W-1:0] o_scale,
    output wire [BLOCKS*SCALE_W-1:0] o_all_scales
);
    reg [LINE_W-1:0] payload_mem [0:BLOCKS-1];
    reg [SCALE_W-1:0] scale_mem [0:BLOCKS-1];
    integer b;
    generate
        genvar g;
        for (g = 0; g < BLOCKS; g = g + 1) begin : g_scales
            assign o_all_scales[g*SCALE_W +: SCALE_W] = scale_mem[g];
        end
    endgenerate
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_rvalid <= 1'b0;
            o_payload<= {LINE_W{1'b0}};
            o_scale  <= {SCALE_W{1'b0}};
`ifdef MX_SIM_INIT
            for (b = 0; b < BLOCKS; b = b + 1) begin
                payload_mem[b] <= {LINE_W{1'b0}};
                scale_mem[b]   <= {SCALE_W{1'b0}};
            end
`endif
        end else begin
            o_rvalid <= i_re;
            if (i_host_we) begin
                payload_mem[i_host_block] <= i_host_payload;
                scale_mem[i_host_block]   <= i_host_scale;
            end
            if (i_re) begin
                o_payload <= payload_mem[i_rblock];
                o_scale   <= scale_mem[i_rblock];
            end
        end
    end
endmodule
