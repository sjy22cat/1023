// Imported fixed microcode table; PC is 9 bits. Included by llm_nonmac_fp32.
// The original build_microcode.py generator is not part of this package.
always @* begin
 inst_op=0; rd=0; ra=0; rb=0; rc=0; imm=0;
 case(pc)
  9'd0: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd1: begin inst_op=5'd1; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // ADD
  9'd2: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd3: begin inst_op=5'd2; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // SUB
  9'd4: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd5: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // MUL
  9'd6: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd7: begin inst_op=5'd4; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // DIV
  9'd8: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd9: begin inst_op=5'd5; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // EXP
  9'd10: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd11: begin inst_op=5'd6; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // SQRT
  9'd12: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd13: begin inst_op=5'd6; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SQRT
  9'd14: begin inst_op=5'd4; rd=4'd0; ra=4'd12; rb=4'd0; rc=4'd0; imm=32'h00000000; end // DIV
  9'd15: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd16: begin inst_op=5'd8; rd=4'd10; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd17: begin inst_op=5'd9; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd18: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd19: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd20: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd21: begin inst_op=5'd4; rd=4'd0; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd22: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd23: begin inst_op=5'd8; rd=4'd8; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd24: begin inst_op=5'd8; rd=4'd10; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd25: begin inst_op=5'd9; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd26: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd27: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd28: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd29: begin inst_op=5'd4; rd=4'd7; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd30: begin inst_op=5'd3; rd=4'd0; ra=4'd8; rb=4'd7; rc=4'd0; imm=32'h00000000; end // MUL
  9'd31: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd32: begin inst_op=5'd8; rd=4'd8; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd33: begin inst_op=5'd3; rd=4'd7; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MUL
  9'd34: begin inst_op=5'd3; rd=4'd7; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MUL
  9'd35: begin inst_op=5'd11; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h3d372713; end // CONST
  9'd36: begin inst_op=5'd3; rd=4'd7; ra=4'd7; rb=4'd9; rc=4'd0; imm=32'h00000000; end // MUL
  9'd37: begin inst_op=5'd1; rd=4'd7; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // ADD
  9'd38: begin inst_op=5'd11; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h3fcc422a; end // CONST
  9'd39: begin inst_op=5'd3; rd=4'd7; ra=4'd7; rb=4'd9; rc=4'd0; imm=32'h00000000; end // MUL
  9'd40: begin inst_op=5'd8; rd=4'd10; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd41: begin inst_op=5'd9; rd=4'd4; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd42: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd43: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd44: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd45: begin inst_op=5'd4; rd=4'd7; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd46: begin inst_op=5'd3; rd=4'd0; ra=4'd8; rb=4'd7; rc=4'd0; imm=32'h00000000; end // MUL
  9'd47: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd48: begin inst_op=5'd8; rd=4'd8; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd49: begin inst_op=5'd8; rd=4'd10; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd50: begin inst_op=5'd9; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd51: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd52: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd53: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd54: begin inst_op=5'd4; rd=4'd7; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd55: begin inst_op=5'd3; rd=4'd0; ra=4'd8; rb=4'd7; rc=4'd0; imm=32'h00000000; end // MUL
  9'd56: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // MUL
  9'd57: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd58: begin inst_op=5'd10; rd=4'd0; ra=4'd0; rb=4'd14; rc=4'd0; imm=32'h00000000; end // SELNEG
  9'd59: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd60: begin inst_op=5'd3; rd=4'd4; ra=4'd0; rb=4'd2; rc=4'd0; imm=32'h00000000; end // MUL
  9'd61: begin inst_op=5'd3; rd=4'd5; ra=4'd1; rb=4'd3; rc=4'd0; imm=32'h00000000; end // MUL
  9'd62: begin inst_op=5'd2; rd=4'd6; ra=4'd4; rb=4'd5; rc=4'd0; imm=32'h00000000; end // SUB
  9'd63: begin inst_op=5'd3; rd=4'd4; ra=4'd0; rb=4'd3; rc=4'd0; imm=32'h00000000; end // MUL
  9'd64: begin inst_op=5'd3; rd=4'd5; ra=4'd1; rb=4'd2; rc=4'd0; imm=32'h00000000; end // MUL
  9'd65: begin inst_op=5'd1; rd=4'd1; ra=4'd4; rb=4'd5; rc=4'd0; imm=32'h00000000; end // ADD
  9'd66: begin inst_op=5'd8; rd=4'd0; ra=4'd6; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd67: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd68: begin inst_op=5'd11; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'hff7fffff; end // CONST
  9'd69: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd70: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd71: begin inst_op=5'd7; rd=4'd1; ra=4'd1; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MAX
  9'd72: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000046; end // LOOPSTEP
  9'd73: begin inst_op=5'd11; rd=4'd5; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // CONST
  9'd74: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd75: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd76: begin inst_op=5'd2; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // SUB
  9'd77: begin inst_op=5'd5; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd78: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd79: begin inst_op=5'd1; rd=4'd5; ra=4'd5; rb=4'd0; rc=4'd0; imm=32'h00000000; end // ADD
  9'd80: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h0000004b; end // LOOPSTEP
  9'd81: begin inst_op=5'd4; rd=4'd5; ra=4'd12; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd82: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd83: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // LOAD
  9'd84: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd5; rc=4'd0; imm=32'h00000000; end // MUL
  9'd85: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd86: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000053; end // LOOPSTEP
  9'd87: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd88: begin inst_op=5'd11; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // CONST
  9'd89: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd90: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd91: begin inst_op=5'd3; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MUL
  9'd92: begin inst_op=5'd1; rd=4'd1; ra=4'd1; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd93: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h0000005a; end // LOOPSTEP
  9'd94: begin inst_op=5'd4; rd=4'd5; ra=4'd1; rb=4'd15; rc=4'd0; imm=32'h00000000; end // DIV
  9'd95: begin inst_op=5'd1; rd=4'd5; ra=4'd5; rb=4'd11; rc=4'd0; imm=32'h00000000; end // ADD
  9'd96: begin inst_op=5'd6; rd=4'd5; ra=4'd5; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SQRT
  9'd97: begin inst_op=5'd4; rd=4'd5; ra=4'd12; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd98: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd99: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd100: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd5; rc=4'd0; imm=32'h00000000; end // MUL
  9'd101: begin inst_op=5'd12; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000800; end // LOAD
  9'd102: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd9; rc=4'd0; imm=32'h00000000; end // MUL
  9'd103: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd104: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000063; end // LOOPSTEP
  9'd105: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd106: begin inst_op=5'd11; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // CONST
  9'd107: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd108: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd109: begin inst_op=5'd1; rd=4'd1; ra=4'd1; rb=4'd0; rc=4'd0; imm=32'h00000000; end // ADD
  9'd110: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h0000006c; end // LOOPSTEP
  9'd111: begin inst_op=5'd4; rd=4'd6; ra=4'd1; rb=4'd15; rc=4'd0; imm=32'h00000000; end // DIV
  9'd112: begin inst_op=5'd11; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // CONST
  9'd113: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd114: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd115: begin inst_op=5'd2; rd=4'd0; ra=4'd0; rb=4'd6; rc=4'd0; imm=32'h00000000; end // SUB
  9'd116: begin inst_op=5'd3; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MUL
  9'd117: begin inst_op=5'd1; rd=4'd1; ra=4'd1; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd118: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000072; end // LOOPSTEP
  9'd119: begin inst_op=5'd4; rd=4'd5; ra=4'd1; rb=4'd15; rc=4'd0; imm=32'h00000000; end // DIV
  9'd120: begin inst_op=5'd1; rd=4'd5; ra=4'd5; rb=4'd11; rc=4'd0; imm=32'h00000000; end // ADD
  9'd121: begin inst_op=5'd6; rd=4'd5; ra=4'd5; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SQRT
  9'd122: begin inst_op=5'd4; rd=4'd5; ra=4'd12; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd123: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd124: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd125: begin inst_op=5'd2; rd=4'd0; ra=4'd0; rb=4'd6; rc=4'd0; imm=32'h00000000; end // SUB
  9'd126: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd5; rc=4'd0; imm=32'h00000000; end // MUL
  9'd127: begin inst_op=5'd12; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000800; end // LOAD
  9'd128: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd9; rc=4'd0; imm=32'h00000000; end // MUL
  9'd129: begin inst_op=5'd12; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000c00; end // LOAD
  9'd130: begin inst_op=5'd1; rd=4'd0; ra=4'd0; rb=4'd9; rc=4'd0; imm=32'h00000000; end // ADD
  9'd131: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd132: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h0000007c; end // LOOPSTEP
  9'd133: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd134: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd135: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd136: begin inst_op=5'd12; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000400; end // LOAD
  9'd137: begin inst_op=5'd1; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // ADD
  9'd138: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd139: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000087; end // LOOPSTEP
  9'd140: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd141: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd142: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd143: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd13; rc=4'd0; imm=32'h00000000; end // MUL
  9'd144: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd145: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h0000008e; end // LOOPSTEP
  9'd146: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd147: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd148: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd149: begin inst_op=5'd8; rd=4'd8; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd150: begin inst_op=5'd8; rd=4'd10; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd151: begin inst_op=5'd9; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd152: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd153: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd154: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd155: begin inst_op=5'd4; rd=4'd7; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd156: begin inst_op=5'd3; rd=4'd0; ra=4'd8; rb=4'd7; rc=4'd0; imm=32'h00000000; end // MUL
  9'd157: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd158: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000094; end // LOOPSTEP
  9'd159: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd160: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd161: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd162: begin inst_op=5'd8; rd=4'd8; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd163: begin inst_op=5'd3; rd=4'd7; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MUL
  9'd164: begin inst_op=5'd3; rd=4'd7; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MUL
  9'd165: begin inst_op=5'd11; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h3d372713; end // CONST
  9'd166: begin inst_op=5'd3; rd=4'd7; ra=4'd7; rb=4'd9; rc=4'd0; imm=32'h00000000; end // MUL
  9'd167: begin inst_op=5'd1; rd=4'd7; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // ADD
  9'd168: begin inst_op=5'd11; rd=4'd9; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h3fcc422a; end // CONST
  9'd169: begin inst_op=5'd3; rd=4'd7; ra=4'd7; rb=4'd9; rc=4'd0; imm=32'h00000000; end // MUL
  9'd170: begin inst_op=5'd8; rd=4'd10; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd171: begin inst_op=5'd9; rd=4'd4; ra=4'd7; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd172: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd173: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd174: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd175: begin inst_op=5'd4; rd=4'd7; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd176: begin inst_op=5'd3; rd=4'd0; ra=4'd8; rb=4'd7; rc=4'd0; imm=32'h00000000; end // MUL
  9'd177: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd178: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h000000a1; end // LOOPSTEP
  9'd179: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd180: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd181: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd182: begin inst_op=5'd12; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000400; end // LOAD
  9'd183: begin inst_op=5'd8; rd=4'd8; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd184: begin inst_op=5'd8; rd=4'd10; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd185: begin inst_op=5'd9; rd=4'd4; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // NABS
  9'd186: begin inst_op=5'd5; rd=4'd4; ra=4'd4; rb=4'd0; rc=4'd0; imm=32'h00000000; end // EXP
  9'd187: begin inst_op=5'd1; rd=4'd5; ra=4'd12; rb=4'd4; rc=4'd0; imm=32'h00000000; end // ADD
  9'd188: begin inst_op=5'd10; rd=4'd6; ra=4'd10; rb=4'd4; rc=4'd12; imm=32'h00000000; end // SELNEG
  9'd189: begin inst_op=5'd4; rd=4'd7; ra=4'd6; rb=4'd5; rc=4'd0; imm=32'h00000000; end // DIV
  9'd190: begin inst_op=5'd3; rd=4'd0; ra=4'd8; rb=4'd7; rc=4'd0; imm=32'h00000000; end // MUL
  9'd191: begin inst_op=5'd3; rd=4'd0; ra=4'd0; rb=4'd1; rc=4'd0; imm=32'h00000000; end // MUL
  9'd192: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd193: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h000000b5; end // LOOPSTEP
  9'd194: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd195: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd196: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd197: begin inst_op=5'd12; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000001; end // LOAD
  9'd198: begin inst_op=5'd17; rd=4'd2; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000800; end // LOADH
  9'd199: begin inst_op=5'd17; rd=4'd3; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000c00; end // LOADH
  9'd200: begin inst_op=5'd3; rd=4'd4; ra=4'd0; rb=4'd2; rc=4'd0; imm=32'h00000000; end // MUL
  9'd201: begin inst_op=5'd3; rd=4'd5; ra=4'd1; rb=4'd3; rc=4'd0; imm=32'h00000000; end // MUL
  9'd202: begin inst_op=5'd2; rd=4'd6; ra=4'd4; rb=4'd5; rc=4'd0; imm=32'h00000000; end // SUB
  9'd203: begin inst_op=5'd3; rd=4'd4; ra=4'd0; rb=4'd3; rc=4'd0; imm=32'h00000000; end // MUL
  9'd204: begin inst_op=5'd3; rd=4'd5; ra=4'd1; rb=4'd2; rc=4'd0; imm=32'h00000000; end // MUL
  9'd205: begin inst_op=5'd1; rd=4'd1; ra=4'd4; rb=4'd5; rc=4'd0; imm=32'h00000000; end // ADD
  9'd206: begin inst_op=5'd8; rd=4'd0; ra=4'd6; rb=4'd0; rc=4'd0; imm=32'h00000000; end // MOV
  9'd207: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd208: begin inst_op=5'd13; rd=4'd0; ra=4'd1; rb=4'd0; rc=4'd0; imm=32'h00001001; end // STORE
  9'd209: begin inst_op=5'd18; rd=4'd2; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h000000c4; end // LOOPSTEP
  9'd210: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  9'd211: begin inst_op=5'd14; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // SETI
  9'd212: begin inst_op=5'd12; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // LOAD
  9'd213: begin inst_op=5'd10; rd=4'd0; ra=4'd0; rb=4'd14; rc=4'd0; imm=32'h00000000; end // SELNEG
  9'd214: begin inst_op=5'd13; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00001000; end // STORE
  9'd215: begin inst_op=5'd18; rd=4'd1; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h000000d4; end // LOOPSTEP
  9'd216: begin inst_op=5'd0; rd=4'd0; ra=4'd0; rb=4'd0; rc=4'd0; imm=32'h00000000; end // HALT
  default: begin end
 endcase
end
function automatic [8:0] entry(input [4:0] opcode);
 begin case(opcode)
  5'd0: entry=9'd1; // add
  5'd1: entry=9'd3; // sub
  5'd2: entry=9'd5; // mul
  5'd3: entry=9'd7; // div
  5'd4: entry=9'd9; // exp
  5'd5: entry=9'd11; // sqrt
  5'd6: entry=9'd13; // rsqrt
  5'd7: entry=9'd16; // sigmoid
  5'd8: entry=9'd23; // silu
  5'd9: entry=9'd32; // gelu_tanh
  5'd11: entry=9'd48; // swiglu
  5'd12: entry=9'd58; // relu
  5'd10: entry=9'd60; // rope_pair
  5'd16: entry=9'd68; // softmax
  5'd17: entry=9'd88; // rmsnorm
  5'd18: entry=9'd106; // layernorm
  5'd19: entry=9'd134; // residual
  5'd20: entry=9'd141; // attention_scale
  5'd21: entry=9'd147; // silu_vector
  5'd22: entry=9'd160; // gelu_vector
  5'd23: entry=9'd180; // swiglu_vector
  5'd24: entry=9'd195; // rope_vector
  5'd25: entry=9'd211; // relu_vector
 default: entry=0;
 endcase end
endfunction
