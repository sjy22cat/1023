`ifndef MX_1017_FMT_DEFS_VH
`define MX_1017_FMT_DEFS_VH

// SIM-1017 hardware-facing format boundary.  The server-side RRAM-FP/TAG-FP
// adapters may replace the payload decoder; this RTL keeps the 4-bit payload,
// E8M0 scale and explicit zero/lane-mask sidebands visible.
`define MX1017_FP4_W       4
`define MX1017_SCALE_W     8
`define MX1017_FP4_INT_W   5
`define MX1017_PROD_W      10
`define MX1017_E8M0_BIAS   127
`define MX1017_LINE_W      128

`endif
