`timescale 1ns/1ps
// Synthesizable signed mantissa * 2^exponent -> binary32, round-to-nearest-even.
// Handles zero, subnormals, normal rounding carry and overflow. No real/shortreal.
module mx_fixed_to_fp32_1017 #(parameter W=32, EW=11)(
 input wire signed [W-1:0] mantissa,
 input wire signed [EW-1:0] exponent,
 output reg [31:0] fp32,
 output reg overflow
);
 reg sign_bit;
 reg [63:0] mag, rounded;
 integer k, lead, e, shift;
 function automatic [63:0] rshift_even(input [63:0] v, input integer n);
  reg guard_bit, sticky;
  reg [63:0] q;
  integer j;
  begin
   q=0; guard_bit=0; sticky=0;
   if(n<=0) q=v << (-n);
   else if(n<=64) begin
    q=(n==64)?64'd0:(v>>n);
    guard_bit=v[n-1];
    for(j=0;j<64;j=j+1) if(j<n-1) sticky=sticky|v[j];
    q=q+(guard_bit&&(sticky||q[0]));
   end
   rshift_even=q;
  end
 endfunction
 always @* begin
  sign_bit=mantissa[W-1];
  mag={{(64-W){mantissa[W-1]}},mantissa};
  if(sign_bit) mag=-mag;
  lead=0;
  for(k=0;k<64;k=k+1) if(mag[k]) lead=k;
  e=$signed(exponent)+lead;
  rounded=0; shift=0; fp32=0; overflow=0;
  if(mag!=0) begin
   if(e < -126) begin
    shift=-($signed(exponent)+149);
    rounded=rshift_even(mag,shift);
    // Rounding a subnormal may produce the smallest normal number.
    fp32={sign_bit,8'b0,23'b0} | rounded[31:0];
   end else begin
    rounded=rshift_even(mag,lead-23);
    if(rounded[24]) begin rounded=rounded>>1; e=e+1; end
    if(e>127) begin fp32={sign_bit,8'hff,23'b0}; overflow=1; end
    else begin
     fp32[31]=sign_bit; fp32[30:23]=e+127; fp32[22:0]=rounded[22:0];
    end
   end
  end
 end
endmodule
