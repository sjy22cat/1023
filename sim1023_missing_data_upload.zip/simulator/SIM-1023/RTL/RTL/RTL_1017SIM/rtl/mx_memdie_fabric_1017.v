`timescale 1ns/1ps

// Optional 32-channel behavioral fabric for standalone RTL tests.  In a chip,
// replace each generated model with the corresponding Mem Die/HB channel.
module mx_memdie_fabric_1017 #(
    parameter CHANNELS = 32,
    parameter AW = 10,
    parameter LINE_W = 128,
    parameter SCALE_W = 8,
    parameter DEPTH = 1024,
    parameter LATENCY = 2,
    parameter CW = (CHANNELS <= 1) ? 1 : $clog2(CHANNELS)
)(
    input wire clk,
    input wire rst_n,
    input wire [CHANNELS-1:0] i_req,
    input wire [CHANNELS-1:0] i_wr,
    input wire [CHANNELS*AW-1:0] i_addr,
    input wire [CHANNELS*LINE_W-1:0] i_wdata,
    input wire [CHANNELS*SCALE_W-1:0] i_wscale,
    output wire [CHANNELS-1:0] o_valid,
    output wire [CHANNELS*LINE_W-1:0] o_rdata,
    output wire [CHANNELS*SCALE_W-1:0] o_rscale
);
    genvar c;
    generate
        for (c = 0; c < CHANNELS; c = c + 1) begin : g_ch
            mx_memdie_channel_model_1017 #(.AW(AW), .LINE_W(LINE_W), .SCALE_W(SCALE_W),
                                           .DEPTH(DEPTH), .LATENCY(LATENCY)) u_channel (
                .clk(clk), .rst_n(rst_n), .i_req(i_req[c]), .i_wr(i_wr[c]),
                .i_addr(i_addr[c*AW +: AW]), .i_wdata(i_wdata[c*LINE_W +: LINE_W]),
                .i_wscale(i_wscale[c*SCALE_W +: SCALE_W]), .o_valid(o_valid[c]),
                .o_rdata(o_rdata[c*LINE_W +: LINE_W]),
                .o_rscale(o_rscale[c*SCALE_W +: SCALE_W])
            );
        end
    endgenerate
endmodule
