`timescale 1ns/1ps
`include "mx_fmt_defs.vh"

module mx_tile_1017 #(
    parameter TILE_K = 32,
    parameter PE_PER_TILE = 32,
    parameter ACCW = 20,
    parameter EXPW = 11,
    parameter PW = (PE_PER_TILE <= 1) ? 1 : $clog2(PE_PER_TILE)
)(
    input wire clk,
    input wire rst_n,
    input wire i_w_we,
    input wire [PW-1:0] i_w_addr,
    input wire [TILE_K*`MX1017_FP4_W-1:0] i_w_payload,
    input wire [`MX1017_SCALE_W-1:0] i_w_scale,
    input wire i_x_we,
    input wire [TILE_K*`MX1017_FP4_W-1:0] i_x_payload,
    input wire [`MX1017_SCALE_W-1:0] i_x_scale,
    input wire [PE_PER_TILE-1:0] i_pe_enable,
    input wire [PE_PER_TILE*TILE_K-1:0] i_lane_en,
    input wire i_calc_en,
    output wire [PE_PER_TILE*ACCW-1:0] o_sums,
    output wire [PE_PER_TILE*EXPW-1:0] o_exps,
    output wire [PE_PER_TILE-1:0] o_valid,
    output wire [PE_PER_TILE*TILE_K-1:0] o_lane_active,
    output wire [PE_PER_TILE*16-1:0] o_mac_count
);
    reg [TILE_K*`MX1017_FP4_W-1:0] w_mem [0:PE_PER_TILE-1];
    reg [`MX1017_SCALE_W-1:0] w_sc [0:PE_PER_TILE-1];
    reg [TILE_K*`MX1017_FP4_W-1:0] x_mem;
    reg [`MX1017_SCALE_W-1:0] x_sc;
    integer p;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_mem <= {TILE_K*`MX1017_FP4_W{1'b0}};
            x_sc  <= {`MX1017_SCALE_W{1'b0}};
`ifdef MX_SIM_INIT
            for (p = 0; p < PE_PER_TILE; p = p + 1) begin
                w_mem[p] <= {TILE_K*`MX1017_FP4_W{1'b0}};
                w_sc[p] <= {`MX1017_SCALE_W{1'b0}};
            end
`endif
        end else begin
            if (i_w_we) begin
                w_mem[i_w_addr] <= i_w_payload;
                w_sc[i_w_addr]  <= i_w_scale;
            end
            if (i_x_we) begin
                x_mem <= i_x_payload;
                x_sc  <= i_x_scale;
            end
        end
    end
    genvar g;
    generate
        for (g = 0; g < PE_PER_TILE; g = g + 1) begin : g_pe
            wire signed [ACCW-1:0] s;
            wire signed [EXPW-1:0] e;
            wire v;
            mx_pe_1017 #(.TILE_K(TILE_K), .ACCW(ACCW), .EXPW(EXPW)) u_pe (
                .clk(clk), .rst_n(rst_n), .i_w_payload(w_mem[g]), .i_w_scale(w_sc[g]),
                .i_x_payload(x_mem), .i_x_scale(x_sc),
                .i_lane_en(i_lane_en[g*TILE_K +: TILE_K]),
                .i_w_zero({TILE_K{1'b0}}), .i_x_zero({TILE_K{1'b0}}),
                .i_valid(i_calc_en && i_pe_enable[g]), .o_sum(s), .o_exp(e),
                .o_valid(v), .o_lane_active(o_lane_active[g*TILE_K +: TILE_K]),
                .o_mac_count(o_mac_count[g*16 +: 16])
            );
            assign o_sums[g*ACCW +: ACCW] = s;
            assign o_exps[g*EXPW +: EXPW] = e;
            assign o_valid[g] = v;
        end
    endgenerate
endmodule
