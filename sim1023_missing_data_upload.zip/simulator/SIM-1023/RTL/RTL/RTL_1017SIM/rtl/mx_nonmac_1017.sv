`timescale 1ns/1ps
// Shared non-MAC command endpoint. External scratch is a real request/response
// interface, not an internal behavioral softmax or a fabricated memory macro.
// A from_reduce command snapshots the last reduction and stages binary32 X[i]
// at scratch word address i, honoring write backpressure, then starts microcode.
module mx_nonmac_1017 #(parameter ROWS=1024, RESULT_W=32, EXPW=11)(
 input wire clk,rst_n,
 input wire i_clear_reduce,i_reduce_valid,
 input wire [ROWS*RESULT_W-1:0] i_reduce,
 input wire [ROWS*EXPW-1:0] i_exponent,
 input wire cmd_valid, output wire cmd_ready,
 input wire cmd_from_reduce,
 input wire [4:0] cmd_op,
 input wire [10:0] cmd_len,
 input wire [31:0] cmd_a,cmd_b,cmd_c,cmd_d,cmd_epsilon,cmd_tag,
 output wire out_valid, input wire out_ready,
 output wire [31:0] out_data,out_aux,out_tag,
 output wire out_error, output wire busy,
 output reg [31:0] cycle_count,
 output wire [31:0] exec_cycle_count,read_count,write_count,
 output reg [31:0] stage_write_count,
 output wire mem_req_valid, input wire mem_req_ready,
 output wire mem_write, output wire [12:0] mem_addr,
 output wire [31:0] mem_wdata,
 input wire mem_rsp_valid, output wire mem_rsp_ready,
 input wire [31:0] mem_rdata
);
 localparam IDLE=0,STAGE=1,LAUNCH=2,EXEC=3,OUTPUT=4;
 reg [2:0] state;
 reg have_reduce,stage_error;
 reg [ROWS*RESULT_W-1:0] saved_reduce;
 reg [ROWS*EXPW-1:0] saved_exponent;
 reg [10:0] idx,len_q;
 reg [4:0] op_q;
 reg [31:0] a_q,b_q,c_q,d_q,eps_q,tag_q;
 wire core_ready,core_valid,core_error,core_busy;
 wire req,wr,rsp_ready;
 wire [12:0] addr;
 wire [31:0] wdata,converted;
 wire conversion_overflow;
 mx_fixed_to_fp32_1017 #(.W(RESULT_W),.EW(EXPW)) u_convert(
  .mantissa(saved_reduce[idx*RESULT_W +: RESULT_W]),
  .exponent(saved_exponent[idx*EXPW +: EXPW]),
  .fp32(converted),.overflow(conversion_overflow));
 assign cmd_ready=(state==IDLE)&&(!cmd_from_reduce||have_reduce)&&!i_reduce_valid&&!i_clear_reduce;
 assign busy=(state!=IDLE);
 assign out_valid=core_valid&&(state==EXEC||state==OUTPUT);
 assign out_error=core_error|stage_error;
 assign mem_req_valid=(state==STAGE)||req;
 assign mem_write=(state==STAGE)?1'b1:wr;
 assign mem_addr=(state==STAGE)?{2'b0,idx}:addr;
 assign mem_wdata=(state==STAGE)?converted:wdata;
 assign mem_rsp_ready=rsp_ready;
 llm_nonmac_fp32 u_exec(
  .clk(clk),.rst_n(rst_n),.cmd_valid(state==LAUNCH),.cmd_ready(core_ready),
  .cmd_op(op_q),.cmd_len(len_q),.cmd_a(a_q),.cmd_b(b_q),.cmd_c(c_q),.cmd_d(d_q),
  .cmd_epsilon(eps_q),.cmd_tag(tag_q),.out_valid(core_valid),
  .out_ready(out_ready&&(state==EXEC||state==OUTPUT)),
  .out_data(out_data),.out_aux(out_aux),.out_tag(out_tag),.out_error(core_error),
  .busy(core_busy),.cycle_count(exec_cycle_count),.read_count(read_count),.write_count(write_count),
  .mem_req_valid(req),.mem_req_ready(mem_req_ready&&(state!=STAGE)),
  .mem_write(wr),.mem_addr(addr),.mem_wdata(wdata),
  .mem_rsp_valid(mem_rsp_valid),.mem_rsp_ready(rsp_ready),.mem_rdata(mem_rdata));
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=IDLE; have_reduce<=0; idx<=0;len_q<=0;op_q<=0;
   saved_reduce<=0;saved_exponent<=0;
   a_q<=0;b_q<=0;c_q<=0;d_q<=0;eps_q<=0;tag_q<=0;
   cycle_count<=0;stage_write_count<=0;stage_error<=0;
  end else begin
   if(i_clear_reduce) have_reduce<=0;
   if(i_reduce_valid) begin
    saved_reduce<=i_reduce;saved_exponent<=i_exponent;have_reduce<=1;
   end
   if(state!=IDLE&&state!=OUTPUT&&!core_valid) cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(cmd_valid&&cmd_ready) begin
     op_q<=cmd_op;len_q<=cmd_len;idx<=0;
     a_q<=cmd_a;b_q<=cmd_b;c_q<=cmd_c;d_q<=cmd_d;eps_q<=cmd_epsilon;tag_q<=cmd_tag;
     cycle_count<=0;stage_write_count<=0;stage_error<=0;
     if(cmd_from_reduce&&cmd_op>=16&&cmd_len!=0&&cmd_len<=1024&&cmd_len<=ROWS) state<=STAGE;
     else begin
      state<=LAUNCH;
      if(cmd_from_reduce) begin op_q<=31;stage_error<=1; end
     end
    end
    STAGE:if(mem_req_ready) begin
     stage_write_count<=stage_write_count+1;
     if(conversion_overflow) stage_error<=1;
     if(idx+1>=len_q) state<=LAUNCH;
     else idx<=idx+1;
    end
    LAUNCH:if(core_ready) state<=EXEC;
    EXEC:if(core_valid) state<=out_ready?IDLE:OUTPUT;
    OUTPUT:if(out_ready) state<=IDLE;
    default:state<=IDLE;
   endcase
  end
 end
endmodule
