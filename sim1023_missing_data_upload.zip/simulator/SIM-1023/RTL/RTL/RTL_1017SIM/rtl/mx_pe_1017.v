`timescale 1ns/1ps
`include "mx_fmt_defs.vh"

// One PE owns TILE_K MAC lanes.  i_lane_en is the local 32-bit (by default)
// activity mask; format zero sidebands can disable a lane before multiplication.
module mx_pe_1017 #(
    parameter TILE_K = 32,
    parameter ACCW = 20,
    parameter EXPW = 11
)(
    input wire clk,
    input wire rst_n,
    input wire [TILE_K*`MX1017_FP4_W-1:0] i_w_payload,
    input wire [`MX1017_SCALE_W-1:0] i_w_scale,
    input wire [TILE_K*`MX1017_FP4_W-1:0] i_x_payload,
    input wire [`MX1017_SCALE_W-1:0] i_x_scale,
    input wire [TILE_K-1:0] i_lane_en,
    input wire [TILE_K-1:0] i_w_zero,
    input wire [TILE_K-1:0] i_x_zero,
    input wire i_valid,
    output reg signed [ACCW-1:0] o_sum,
    output reg signed [EXPW-1:0] o_exp,
    output reg o_valid,
    output reg [TILE_K-1:0] o_lane_active,
    output reg [15:0] o_mac_count,
    output reg signed [3:0] o_e3_max
);
    function integer fp4_int;
        input [3:0] code;
        begin
            case (code[2:0])
                3'd0: fp4_int = 0;
                3'd1: fp4_int = 1;
                3'd2: fp4_int = 2;
                3'd3: fp4_int = 3;
                3'd4: fp4_int = 4;
                3'd5: fp4_int = 6;
                3'd6: fp4_int = 8;
                default: fp4_int = 12;
            endcase
            if (code[3]) fp4_int = -fp4_int;
        end
    endfunction
    integer k;
    integer signed acc_i;
    integer signed pv;
    integer active_count_i;
    integer signed e3_max_i;
    integer signed pabs_i;
    integer sh_i;
    integer signed e_now_i;
    integer signed m_now_i;
    function integer msb_int;
        input integer v;
        integer t;
        begin
            msb_int = 0; t = v;
            while (t > 1) begin t = t >> 1; msb_int = msb_int + 1; end
        end
    endfunction
    function integer tz_shift;
        input integer v;
        input integer d;
        integer av;
        begin
            if (d <= 0) tz_shift = v;
            else begin
                av = (v < 0) ? -v : v;
                tz_shift = (v < 0) ? -(av >> d) : (av >> d);
            end
        end
    endfunction
    reg [TILE_K-1:0] lane_now;
    // Explicit sensitivity avoids treating the temporary unpacked arrays as
    // feedback signals in older Icarus versions.
    always @(i_w_payload or i_x_payload or i_lane_en or i_w_zero or i_x_zero) begin
        acc_i = 0;
        active_count_i = 0;
        e3_max_i = -100;
        lane_now = {TILE_K{1'b0}};
        for (k = 0; k < TILE_K; k = k + 1) begin
            lane_now[k] = i_lane_en[k] && !i_w_zero[k] && !i_x_zero[k] &&
                          (i_w_payload[k*4 +: 4] != 4'd0) &&
                          (i_x_payload[k*4 +: 4] != 4'd0);
            if (lane_now[k]) begin
                pv = fp4_int(i_w_payload[k*4 +: 4]) *
                     fp4_int(i_x_payload[k*4 +: 4]);
                pabs_i = (pv < 0) ? -pv : pv;
                e_now_i = msb_int(pabs_i) - 2;
                if (e_now_i > e3_max_i) e3_max_i = e_now_i;
                active_count_i = active_count_i + 1;
            end
        end
        if (e3_max_i < -10) e3_max_i = 0;
        for (k = 0; k < TILE_K; k = k + 1) begin
            if (lane_now[k]) begin
                pv = fp4_int(i_w_payload[k*4 +: 4]) *
                     fp4_int(i_x_payload[k*4 +: 4]);
                pabs_i = (pv < 0) ? -pv : pv;
                e_now_i = msb_int(pabs_i) - 2;
                sh_i = 6 - e_now_i;
                m_now_i = (sh_i >= 0) ? (pv <<< sh_i) : tz_shift(pv, -sh_i);
                acc_i = acc_i + tz_shift(m_now_i, e3_max_i-e_now_i);
            end
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_sum <= {ACCW{1'b0}};
            o_exp <= {EXPW{1'b0}};
            o_valid <= 1'b0;
            o_lane_active <= {TILE_K{1'b0}};
            o_mac_count <= 16'd0;
            o_e3_max <= 4'sd0;
        end else begin
            o_valid <= i_valid;
            if (i_valid) begin
                o_sum <= acc_i;
                // o_sum is an M10 mantissa (binary point eight places from
                // the right), aligned to the block E3 maximum.
                o_exp <= e3_max_i + $signed({1'b0,i_w_scale}) +
                         $signed({1'b0,i_x_scale}) - 127 - 127 - 8;
                o_lane_active <= lane_now;
                o_mac_count <= active_count_i[15:0];
                o_e3_max <= e3_max_i[3:0];
            end
        end
    end
endmodule
