`timescale 1ns/1ps

// Cross-K-block reduction.  Each block partial is represented as signed
// mantissa * 2^exponent.  Alignment is toward zero and the final sum saturates.
module mx_reduce_1017 #(
    parameter OUTPUT_ROWS = 1024,
    parameter BLOCKS = 32,
    parameter ACCW = 20,
    parameter EXPW = 11,
    parameter RESULT_W = 32
)(
    input wire clk,
    input wire rst_n,
    input wire i_valid,
    input wire [OUTPUT_ROWS*BLOCKS*ACCW-1:0] i_sums,
    input wire [OUTPUT_ROWS*BLOCKS*EXPW-1:0] i_exps,
    output reg o_valid,
    output reg signed [OUTPUT_ROWS*RESULT_W-1:0] o_result,
    output reg signed [OUTPUT_ROWS*EXPW-1:0] o_emxmax,
    output reg [31:0] o_saturation_count
);
    integer r, c;
    integer signed e, em, d;
    reg signed [ACCW-1:0] sv;
    reg signed [63:0] term;
    reg signed [63:0] total;
    reg signed [63:0] maxv, minv;
    always @(*) begin
        o_result = {(OUTPUT_ROWS*RESULT_W){1'b0}};
        o_emxmax = {(OUTPUT_ROWS*EXPW){1'b0}};
        o_saturation_count = 32'd0;
        maxv = (64'sh1 <<< (RESULT_W-1)) - 1;
        minv = -(64'sh1 <<< (RESULT_W-1));
        for (r = 0; r < OUTPUT_ROWS; r = r + 1) begin
            em = -100000;
            for (c = 0; c < BLOCKS; c = c + 1) begin
                e = $signed(i_exps[(r*BLOCKS+c)*EXPW +: EXPW]);
                sv = $signed(i_sums[(r*BLOCKS+c)*ACCW +: ACCW]);
                if (sv != 0 && e > em) em = e;
            end
            if (em == -100000) em = 0;
            o_emxmax[r*EXPW +: EXPW] = em[EXPW-1:0];
            total = 0;
            for (c = 0; c < BLOCKS; c = c + 1) begin
                e = $signed(i_exps[(r*BLOCKS+c)*EXPW +: EXPW]);
                sv = $signed(i_sums[(r*BLOCKS+c)*ACCW +: ACCW]);
                d = em - e;
                term = sv;
                if (d > 0) begin
                    if (d >= 63) term = 0;
                    else if (term < 0) term = -((-term) >>> d);
                    else term = term >>> d;
                end
                total = total + term;
            end
            if (total > maxv) begin
                o_result[r*RESULT_W +: RESULT_W] = maxv[RESULT_W-1:0];
                o_saturation_count = o_saturation_count + 1'b1;
            end else if (total < minv) begin
                o_result[r*RESULT_W +: RESULT_W] = minv[RESULT_W-1:0];
                o_saturation_count = o_saturation_count + 1'b1;
            end else begin
                o_result[r*RESULT_W +: RESULT_W] = total[RESULT_W-1:0];
            end
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) o_valid <= 1'b0;
        else o_valid <= i_valid;
    end
endmodule
