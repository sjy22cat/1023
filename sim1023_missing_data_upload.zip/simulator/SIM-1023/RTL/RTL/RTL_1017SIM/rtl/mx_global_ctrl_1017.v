`timescale 1ns/1ps

// One shared scheduler.  It drives all 32 MC request wires together and only
// carries a small row/block index; it is not replicated once per channel.
module mx_global_ctrl_1017 #(
    parameter MC_COUNT = 32,
    parameter TILE_ROWS = 32,
    parameter PE_PER_TILE = 32,
    parameter BLOCKS = 32,
    parameter ROWS = TILE_ROWS*PE_PER_TILE,
    parameter RW = (ROWS <= 1) ? 1 : $clog2(ROWS),
    parameter BW = (BLOCKS <= 1) ? 1 : $clog2(BLOCKS),
    parameter CW = (MC_COUNT <= 1) ? 1 : $clog2(MC_COUNT)
)(
    input wire clk,
    input wire rst_n,
    input wire i_start,
    input wire i_metadata_valid,
    input wire i_all_mc_ready,
    input wire i_all_phy_valid,
    input wire i_gsram_rvalid,
    input wire [BLOCKS-1:0] i_channel_data_move_en,
    input wire i_reduce_valid,
    output reg o_weight_req,
    output reg [RW-1:0] o_weight_addr,
    output reg o_gsram_re,
    output reg o_bcast_we,
    output reg o_calc_en,
    output reg o_reduce_en,
    output reg [BW-1:0] o_block_idx,
    output reg [3:0] o_phase,
    output reg o_done,
    output reg o_busy,
    output reg [31:0] o_cycle_count
);
    localparam P_IDLE=0, P_WREQ=1, P_WWAIT=2, P_PREP=3, P_DECIDE=4,
               P_GSREQ=5, P_GSWAIT=6, P_BCAST=7, P_CALC=8, P_ACCUM=9,
               P_REDUCE=10, P_DONE=11;
    reg [3:0] state;
    reg [RW-1:0] row;
    reg [BW-1:0] block;
    always @(*) begin
        o_weight_req = (state == P_WREQ) && i_all_mc_ready;
        o_weight_addr = row;
        o_gsram_re = (state == P_GSREQ);
        o_bcast_we = (state == P_BCAST);
        o_calc_en = (state == P_CALC);
        o_reduce_en = (state == P_REDUCE);
        o_block_idx = block;
        o_phase = state;
        o_done = (state == P_DONE);
        o_busy = (state != P_IDLE) && (state != P_DONE);
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= P_IDLE; row <= 0; block <= 0; o_cycle_count <= 0;
        end else begin
            if (state != P_IDLE && state != P_DONE)
                o_cycle_count <= o_cycle_count + 1'b1;
            case (state)
                P_IDLE: begin
                    if (i_start) begin
                        row <= 0; block <= 0; o_cycle_count <= 0; state <= P_WREQ;
                    end
                end
                P_WREQ: if (i_all_mc_ready) state <= P_WWAIT;
                P_WWAIT: begin
                    if (i_all_phy_valid) begin
                        if (row == ROWS-1) state <= P_PREP;
                        else begin row <= row + 1'b1; state <= P_WREQ; end
                    end
                end
                P_PREP: if (i_metadata_valid) begin block <= 0; state <= P_DECIDE; end
                P_DECIDE: begin
                    if (i_channel_data_move_en[block]) state <= P_GSREQ;
                    else if (block == BLOCKS-1) state <= P_REDUCE;
                    else begin block <= block + 1'b1; state <= P_DECIDE; end
                end
                P_GSREQ: state <= P_GSWAIT;
                P_GSWAIT: if (i_gsram_rvalid) state <= P_BCAST;
                P_BCAST: state <= P_CALC;
                P_CALC: state <= P_ACCUM;
                P_ACCUM: begin
                    if (block == BLOCKS-1) state <= P_REDUCE;
                    else begin block <= block + 1'b1; state <= P_DECIDE; end
                end
                P_REDUCE: if (i_reduce_valid) state <= P_DONE;
                P_DONE: state <= P_IDLE;
                default: state <= P_IDLE;
            endcase
        end
    end
endmodule
