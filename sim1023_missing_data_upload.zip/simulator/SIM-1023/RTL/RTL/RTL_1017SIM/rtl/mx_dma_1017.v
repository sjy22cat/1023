`timescale 1ns/1ps

// Small Host -> GSRAM descriptor engine.  It is intentionally separate from
// MC/PHY: no signal from this module is connected to the Mem Die channels.
// The top level may either use this interface directly (i_host_*) or insert
// this engine between a system DMA and mx_gsram_1017.
module mx_dma_1017 #(
    parameter BLOCKS = 32,
    parameter LINE_W = 128,
    parameter SCALE_W = 8,
    parameter BW = (BLOCKS <= 1) ? 1 : $clog2(BLOCKS)
)(
    input wire clk,
    input wire rst_n,
    input wire i_desc_valid,
    input wire [BW-1:0] i_desc_first_block,
    input wire [BW-1:0] i_desc_count,
    input wire i_data_valid,
    input wire [BW-1:0] i_data_block,
    input wire [LINE_W-1:0] i_data_payload,
    input wire [SCALE_W-1:0] i_data_scale,
    output wire o_gsram_we,
    output wire [BW-1:0] o_gsram_block,
    output wire [LINE_W-1:0] o_gsram_payload,
    output wire [SCALE_W-1:0] o_gsram_scale,
    output reg o_ready,
    output reg o_done,
    output reg [31:0] o_bytes_written
);
    reg active;
    reg [BW:0] remaining;
    assign o_gsram_we = active && i_data_valid;
    assign o_gsram_block = i_data_block;
    assign o_gsram_payload = i_data_payload;
    assign o_gsram_scale = i_data_scale;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active <= 1'b0; remaining <= 0; o_ready <= 1'b1;
            o_done <= 1'b0; o_bytes_written <= 0;
        end else begin
            o_done <= 1'b0;
            o_ready <= !active;
            if (!active && i_desc_valid) begin
                active <= 1'b1;
                remaining <= (i_desc_count == 0) ? BLOCKS : i_desc_count;
                o_ready <= 1'b0;
            end
            if (active && i_data_valid) begin
                o_bytes_written <= o_bytes_written + LINE_W/8 + SCALE_W/8;
                if (remaining <= 1) begin
                    active <= 1'b0;
                    remaining <= 0;
                    o_done <= 1'b1;
                end else remaining <= remaining - 1'b1;
            end
        end
    end
endmodule
