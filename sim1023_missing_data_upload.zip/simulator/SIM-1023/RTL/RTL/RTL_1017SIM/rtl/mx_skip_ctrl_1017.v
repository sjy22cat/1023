`timescale 1ns/1ps
`include "mx_fmt_defs.vh"

// Scale-only, pre-payload decision used by SIM-1017.  No payload, product,
// partial sum or sign is read here.  A block is suppressed only when every
// receiver PE in that K block has the configured scale distance.
module mx_skip_ctrl_1017 #(
    parameter OUTPUT_ROWS = 1024,
    parameter BLOCKS = 32,
    parameter SCALE_W = `MX1017_SCALE_W,
    parameter ESUM_W = 11,
    parameter THRESHOLD_BITS = 0,
    parameter ENABLE = 1
)(
    input wire clk,
    input wire rst_n,
    input wire i_metadata_valid,
    input wire [OUTPUT_ROWS*BLOCKS*SCALE_W-1:0] i_weight_scale,
    input wire [BLOCKS*SCALE_W-1:0] i_input_scale,
    output reg signed [OUTPUT_ROWS*BLOCKS*ESUM_W-1:0] o_esum,
    output reg signed [OUTPUT_ROWS*ESUM_W-1:0] o_emxmax,
    output reg [OUTPUT_ROWS*BLOCKS*ESUM_W-1:0] o_distance,
    output reg [OUTPUT_ROWS*BLOCKS-1:0] o_block_skip,
    output reg [OUTPUT_ROWS*BLOCKS-1:0] o_compute_mask,
    output reg [BLOCKS-1:0] o_channel_data_move_en,
    output reg o_all_skip
);
    integer r, c;
    integer signed e, em, d;
    reg [SCALE_W-1:0] ws, xs;
    always @(*) begin
        o_esum = {(OUTPUT_ROWS*BLOCKS*ESUM_W){1'b0}};
        o_emxmax = {(OUTPUT_ROWS*ESUM_W){1'b0}};
        o_distance = {(OUTPUT_ROWS*BLOCKS*ESUM_W){1'b0}};
        o_block_skip = {(OUTPUT_ROWS*BLOCKS){1'b0}};
        o_compute_mask = {(OUTPUT_ROWS*BLOCKS){1'b1}};
        o_channel_data_move_en = {BLOCKS{1'b0}};
        o_all_skip = 1'b1;
        for (r = 0; r < OUTPUT_ROWS; r = r + 1) begin
            em = -100000;
            for (c = 0; c < BLOCKS; c = c + 1) begin
                ws = i_weight_scale[(r*BLOCKS+c)*SCALE_W +: SCALE_W];
                xs = i_input_scale[c*SCALE_W +: SCALE_W];
                e = $signed({1'b0,ws}) - 127 + $signed({1'b0,xs}) - 127;
                o_esum[(r*BLOCKS+c)*ESUM_W +: ESUM_W] = e[ESUM_W-1:0];
                if (e > em) em = e;
            end
            o_emxmax[r*ESUM_W +: ESUM_W] = em[ESUM_W-1:0];
            for (c = 0; c < BLOCKS; c = c + 1) begin
                ws = i_weight_scale[(r*BLOCKS+c)*SCALE_W +: SCALE_W];
                xs = i_input_scale[c*SCALE_W +: SCALE_W];
                e = $signed({1'b0,ws}) - 127 + $signed({1'b0,xs}) - 127;
                d = em - e;
                o_distance[(r*BLOCKS+c)*ESUM_W +: ESUM_W] = d[ESUM_W-1:0];
                if (ENABLE && i_metadata_valid && (THRESHOLD_BITS > 0) &&
                    (d >= THRESHOLD_BITS)) begin
                    o_block_skip[r*BLOCKS+c] = 1'b1;
                    o_compute_mask[r*BLOCKS+c] = 1'b0;
                end else begin
                    o_block_skip[r*BLOCKS+c] = 1'b0;
                    o_compute_mask[r*BLOCKS+c] = 1'b1;
                    o_channel_data_move_en[c] = 1'b1;
                    o_all_skip = 1'b0;
                end
            end
        end
        if (!i_metadata_valid || !ENABLE || (THRESHOLD_BITS <= 0))
            o_all_skip = 1'b0;
    end
endmodule
