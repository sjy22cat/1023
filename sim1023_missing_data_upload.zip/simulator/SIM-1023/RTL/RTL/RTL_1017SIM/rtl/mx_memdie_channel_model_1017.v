`timescale 1ns/1ps

// Deterministic channel model used by the small RTL regression.  It models
// channel-local latency and storage; it is not part of the synthesized die.
module mx_memdie_channel_model_1017 #(
    parameter AW = 10,
    parameter LINE_W = 128,
    parameter SCALE_W = 8,
    parameter DEPTH = 1024,
    parameter LATENCY = 2
)(
    input wire clk,
    input wire rst_n,
    input wire i_req,
    input wire i_wr,
    input wire [AW-1:0] i_addr,
    input wire [LINE_W-1:0] i_wdata,
    input wire [SCALE_W-1:0] i_wscale,
    output reg o_valid,
    output reg [LINE_W-1:0] o_rdata,
    output reg [SCALE_W-1:0] o_rscale
);
    localparam integer N = (LATENCY < 1) ? 1 : LATENCY;
    reg [LINE_W-1:0] mem_data [0:DEPTH-1];
    reg [SCALE_W-1:0] mem_scale [0:DEPTH-1];
    reg pending;
    reg [AW-1:0] addr_r;
    reg [N-1:0] delay_pipe;
    integer j;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending   <= 1'b0;
            addr_r    <= {AW{1'b0}};
            delay_pipe<= {N{1'b0}};
            o_valid   <= 1'b0;
            o_rdata   <= {LINE_W{1'b0}};
            o_rscale  <= {SCALE_W{1'b0}};
        end else begin
            o_valid <= delay_pipe[N-1];
            delay_pipe[0] <= 1'b0;
            for (j = 1; j < N; j = j + 1)
                delay_pipe[j] <= delay_pipe[j-1];
            if (i_req && !pending) begin
                pending <= 1'b1;
                addr_r  <= i_addr;
                if (i_wr) begin
                    mem_data[i_addr]  <= i_wdata;
                    mem_scale[i_addr] <= i_wscale;
                    delay_pipe[0] <= 1'b1;
                end else begin
                    delay_pipe[0] <= 1'b1;
                end
            end
            if (delay_pipe[N-1]) begin
                pending  <= 1'b0;
                o_rdata  <= mem_data[addr_r];
                o_rscale <= mem_scale[addr_r];
            end
        end
    end
endmodule
