`timescale 1ns/1ps
`include "mx_fmt_defs.vh"

// 32x32 tile array.  Tile column c is owned by MC/PHY channel c.
module mx_array_1017 #(
    parameter TILE_ROWS = 32,
    parameter TILE_COLS = 32,
    parameter PE_PER_TILE = 32,
    parameter TILE_K = 32,
    parameter ACCW = 20,
    parameter EXPW = 11,
    parameter RW = (TILE_ROWS <= 1) ? 1 : $clog2(TILE_ROWS),
    parameter CW = (TILE_COLS <= 1) ? 1 : $clog2(TILE_COLS),
    parameter PW = (PE_PER_TILE <= 1) ? 1 : $clog2(PE_PER_TILE)
)(
    input wire clk,
    input wire rst_n,
    input wire [TILE_COLS-1:0] i_w_we,
    input wire [RW-1:0] i_w_tile_row,
    input wire [CW-1:0] i_w_col,
    input wire [PW-1:0] i_w_pe,
    input wire [TILE_COLS*TILE_K*`MX1017_FP4_W-1:0] i_w_payload,
    input wire [TILE_COLS*`MX1017_SCALE_W-1:0] i_w_scale,
    input wire i_x_we,
    input wire [CW-1:0] i_x_col,
    input wire [TILE_COLS*TILE_K*`MX1017_FP4_W-1:0] i_x_payload,
    input wire [TILE_COLS*`MX1017_SCALE_W-1:0] i_x_scale,
    input wire [TILE_ROWS*PE_PER_TILE-1:0] i_pe_enable,
    input wire [PE_PER_TILE*TILE_K-1:0] i_lane_en,
    input wire i_calc_en,
    input wire [CW-1:0] i_calc_col,
    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*ACCW-1:0] o_sums,
    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*EXPW-1:0] o_exps,
    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE-1:0] o_valid,
    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*TILE_K-1:0] o_lane_active,
    output wire [TILE_ROWS*TILE_COLS*PE_PER_TILE*16-1:0] o_mac_count
);
    genvar r, c;
    generate
        for (r = 0; r < TILE_ROWS; r = r + 1) begin : g_row
            for (c = 0; c < TILE_COLS; c = c + 1) begin : g_col
                wire w_hit = i_w_we[c] && (i_w_tile_row == r);
                wire x_hit = i_x_we && (i_x_col == c);
                wire calc_hit = i_calc_en && (i_calc_col == c);
                wire [PE_PER_TILE*ACCW-1:0] ts;
                wire [PE_PER_TILE*EXPW-1:0] te;
                wire [PE_PER_TILE-1:0] tv;
                wire [PE_PER_TILE*TILE_K-1:0] tl;
                wire [PE_PER_TILE*16-1:0] tc;
                mx_tile_1017 #(.TILE_K(TILE_K), .PE_PER_TILE(PE_PER_TILE),
                               .ACCW(ACCW), .EXPW(EXPW), .PW(PW)) u_tile (
                    .clk(clk), .rst_n(rst_n), .i_w_we(w_hit), .i_w_addr(i_w_pe),
                    .i_w_payload(i_w_payload[c*TILE_K*`MX1017_FP4_W +: TILE_K*`MX1017_FP4_W]),
                    .i_w_scale(i_w_scale[c*`MX1017_SCALE_W +: `MX1017_SCALE_W]),
                    .i_x_we(x_hit),
                    .i_x_payload(i_x_payload[c*TILE_K*`MX1017_FP4_W +: TILE_K*`MX1017_FP4_W]),
                    .i_x_scale(i_x_scale[c*`MX1017_SCALE_W +: `MX1017_SCALE_W]),
                    .i_pe_enable(i_pe_enable[r*PE_PER_TILE +: PE_PER_TILE]), .i_lane_en(i_lane_en), .i_calc_en(calc_hit),
                    .o_sums(ts), .o_exps(te), .o_valid(tv), .o_lane_active(tl), .o_mac_count(tc)
                );
                assign o_sums[(r*TILE_COLS+c)*PE_PER_TILE*ACCW +: PE_PER_TILE*ACCW] = ts;
                assign o_exps[(r*TILE_COLS+c)*PE_PER_TILE*EXPW +: PE_PER_TILE*EXPW] = te;
                assign o_valid[(r*TILE_COLS+c)*PE_PER_TILE +: PE_PER_TILE] = tv;
                assign o_lane_active[(r*TILE_COLS+c)*PE_PER_TILE*TILE_K +: PE_PER_TILE*TILE_K] = tl;
                assign o_mac_count[(r*TILE_COLS+c)*PE_PER_TILE*16 +: PE_PER_TILE*16] = tc;
            end
        end
    endgenerate
endmodule
