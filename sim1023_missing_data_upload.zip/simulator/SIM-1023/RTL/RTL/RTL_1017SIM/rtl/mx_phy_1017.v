`timescale 1ns/1ps

// Per-channel HB/PHY receive pipeline.  BPC is represented by a fixed number
// of receive stages here; the channel remains independent from the other 31.
module mx_phy_1017 #(
    parameter LINE_W = 128,
    parameter SCALE_W = 8,
    parameter LATENCY = 1
)(
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    i_valid,
    input  wire [LINE_W-1:0]       i_data,
    input  wire [SCALE_W-1:0]      i_scale,
    output wire                    o_ready,
    output wire                    o_valid,
    output wire [LINE_W-1:0]       o_data,
    output wire [SCALE_W-1:0]      o_scale
);
    localparam integer N = (LATENCY < 1) ? 1 : LATENCY;
    reg [N-1:0] vpipe;
    reg [LINE_W-1:0] dpipe [0:N-1];
    reg [SCALE_W-1:0] spipe [0:N-1];
    integer k;
    assign o_ready = 1'b1;
    assign o_valid = vpipe[N-1];
    assign o_data  = dpipe[N-1];
    assign o_scale = spipe[N-1];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vpipe <= {N{1'b0}};
            for (k = 0; k < N; k = k + 1) begin
                dpipe[k] <= {LINE_W{1'b0}};
                spipe[k] <= {SCALE_W{1'b0}};
            end
        end else begin
            vpipe[0] <= i_valid;
            if (i_valid) begin
                dpipe[0] <= i_data;
                spipe[0] <= i_scale;
            end
            for (k = 1; k < N; k = k + 1) begin
                vpipe[k] <= vpipe[k-1];
                if (vpipe[k-1]) begin
                    dpipe[k] <= dpipe[k-1];
                    spipe[k] <= spipe[k-1];
                end
            end
        end
    end
endmodule
