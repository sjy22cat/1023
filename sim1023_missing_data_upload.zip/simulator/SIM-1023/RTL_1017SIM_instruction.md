# RTL_1017SIM 结构与验证说明

本文件描述 `RTL/RTL_1017SIM`。当前已集成共享 FP32 非 MAC 单元，接口、scratch 布局、新思流程和参数交付详见 [非 MAC 实测说明](nonmac_1017SIM_measurement.md)。精确软件字段以 [SIM-1017 主 README](../simulator/SIM-1017/README_SIM-1017.md) 和 v2 参数模板为准。

## 控制与数据路径

`yrr_1017_top.v` 展开 32 MC/PHY 与 32×32 tile。每 tile 有 32 PE，每 PE 32 MAC lane。全局只有一套 `mx_global_ctrl_1017`，负责冷启动权重装载、scale 预判、输入读/广播、计算、归约和完成判断。

MC c 固定使用 channel c，并将数据送入 tile[0..31][c]。全局对同一输出行同时发起 32 路请求，通过 completion bitmap 收集错峰响应；MC 只有本通道请求/outstanding/完成逻辑，不复制完整全局总控。

| 模块 | 当前职责 |
|---|---|
| `mx_mc_1017` | 单通道请求与响应状态 |
| `mx_phy_1017` | 每 channel HB/PHY 接收流水边界；真实物理成本需 IP 模型 |
| `mx_skip_ctrl_1017` | 仅依据 E8M0 scale 在 payload 读取/计算前生成 block/PE enable |
| `mx_gsram_1017` | Host staging 和 input payload/scale，按 K block 选择读取 |
| `mx_dma_1017` | 可选 Host→GSRAM descriptor/stream DMA，不连接 Mem Die 通道 |
| `mx_tile_1017`、`mx_pe_1017` | 本地权重/输入、PE enable、lane mask 与零值门控 |
| `mx_reduce_1017` | 跨 K block 指数对齐、toward-zero 右移、饱和归约 |
| `mx_nonmac_1017` | 非 MAC 命令接收、归约快照、FP32 转换暂存、执行和完成响应 |
| `llm_nonmac_fp32` | 共享 FP32 微码执行器，支持 Softmax、RMSNorm、LayerNorm、激活、残差、RoPE 等 |
| `nonmac_fp32_pipe` | DesignWare FP32 算术与输入/输出寄存器；时序需综合重定时与 STA 验证 |
| `nonmac_microcode.vh` | 固定微程序、向量循环和算子入口表 |
| `mx_fixed_to_fp32_1017` | 将 signed mantissa×2^exponent 转为 FP32，nearest-even 舍入 |
| `mx_memdie_channel_model_1017`、`mx_memdie_fabric_1017` | 仿真用存储延迟模型与多路展开，不可当作存储物理实现综合表征 |

Mem Die 请求/响应通过 `o_mem_req/i_mem_*`；数据行为为 128 bit payload+8 bit scale。Host staging 通过 `i_host_*`。这两条通路分别测量和记账。

## 预判与逐 lane 控制

权重返回后保留 scale metadata；输入 scale sideband 提前可读。预判器计算 `Esum`、每输出 `EMXmax` 与距离，`distance>=T` 时 skip，不使用乘积、partial、E3/M10 或正负抵消。只有一个 channel 对应 block 的全部输出都 skip，才关闭该组 payload read/broadcast。

PE 将全局计算有效、block/PE enable、`i_lane_en` 和本地零值 mask 合并为逐路 MAC enable。可从 `o_lane_active` 与 `o_mac_count` 验证。默认 `MX_SKIP_THRESHOLD_BITS=0` 关闭 block skip；软件 JSON 使用 `mx_skip_threshold_bits=null` 表示相同的禁用意图。

## 结构回归

从工程根目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File RTL/RTL_1017SIM/run_tb.ps1 -TestModels
```

脚本编译 `.v` 与 `.sv`，运行顶层结构/非 MAC 链路、全部非 MAC opcode 和格式转换三个回归。`tb_1017_small.v` 使用小规模参数检查并行请求、独立返回、block skip、lane mask，以及阵列→归约→FP32→Softmax。`tb_nonmac_1017.sv` 检查数值、访存计数、背压、tag 和错误返回；转换测试覆盖 RNE、次正规数、溢出等边界。

`-TestModels` 只用于没有 DesignWare 的本地控制/数值回归，不产生可用于模拟器的新思测量值。真实 DW 回归使用 `-DwSimDir` 或 Linux 下的 `run_vcs_nonmac.sh`。DC 脚本是 `synopsys/nonmac_dc.tcl`；真实宏、工艺库、PVT、约束、门级活动和 PT PX 仍需新思环境提供。

## 非 MAC 的调用与评估

顶层新增 `i_nonmac_* / o_nonmac_*` 命令、结果及外部 scratch 握手接口。矩阵完成后发送 `from_reduce=1` 的向量命令，会将归约快照转 FP32 写入 scratch 后执行；其他输入可预先由外部存储/DMA 准备，然后发送 `from_reduce=0`。结果向量在 scratch `4096+i`，不能将单个 `o_nonmac_data` 当作整条向量。`o_done` 仍只表示矩阵阶段完成，非 MAC 以 `o_nonmac_valid` 为准。

单条向量最长 1024；RMSNorm/Softmax 等超长归约不能拆成独立向量替代。RoPE 已适配 Qwen/Llama 前后半段配对。各算子与各长度通过新思采集 cycles、dynamic_pj、read_count、write_count 和报告路径，填写 v2 参数的 `nonmac.profiles`；归约转换写入另填 `nonmac.reduce_staging`。模拟器不从寄存级数或微码步数推导物理参数。

## 仍需完成/外接的边界

PE 的 `fp4_int` 与 zero sideband 仍是用于结构/门控验证的可替换整数译码，必须接入真实 RRAM-FP/TAG-FP LUT 后再验收完整数值等价。FP32 非 MAC 已接入，外部 scratch、SRAM、RRAM、FeRAM、PHY/HB 仍需真实 macro/IP 模型及地址适配；Host/DMA 仍需组织系数装载和结果回传。MXFP4 编码器、RoPE 表生成和 token 采样不在这三个 FP32 模块内。完整 LLM 硬件任务流尚需外部调度器发命令，不能把单元回归描述为完整模型已经在 RTL 中运行。

不能将这些未实现部分填成虚构新思单价，也不能把旧 `RTL_v3` golden 比较视为新 RTL_1017SIM 的完整验收。正式交付应同时给出源码/配置、数值 vectors、阶段 trace、PPA 证据及统一 measured JSON。
